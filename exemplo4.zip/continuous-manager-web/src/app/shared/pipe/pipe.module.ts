import { NgModule } from '@angular/core';
import { EscapeHtmlPipe } from './keep-html.pipe';

@NgModule({
  imports: [],
  declarations: [EscapeHtmlPipe],
  exports: [EscapeHtmlPipe]
})
export class PipeModule {
  static forRoot() {
    return {
      ngModule: PipeModule,
      providers: []
    };
  }
}

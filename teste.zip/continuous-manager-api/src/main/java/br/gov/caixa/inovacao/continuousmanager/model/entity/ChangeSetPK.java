package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * The primary key class for the build database table.
 * 
 * @author Fabio Iwakoshi
 */
@Embeddable
public class ChangeSetPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable = false, updatable = false, unique = true, nullable = false, length = 30)
	private String project;

	@Column(insertable = false, updatable = false, unique = true, nullable = false, length = 30)
	private String wallet;

	@Column(insertable = false, updatable = false, unique = true, nullable = false, length = 50)
	private String job;

	@JsonView(ViewJson.ChangeSetView.class)
	@Column(insertable = false, updatable = false, unique = true, nullable = false)
	private Integer build;

	@JsonView({ViewJson.BuildView.class, ViewJson.ChangeSetView.class})
	@Column(insertable = false, updatable = false, unique = true, nullable = false, length = 40)
	private String commit;

	public ChangeSetPK() {
		/* class constructor intentionally left blank */
	}

	public Integer getBuild() {
		return this.build;
	}

	public void setBuild(Integer build) {
		this.build = build;
	}

	public String getCommit() {
		return this.commit;
	}

	public void setCommit(String commit) {
		this.commit = commit;
	}

	public String getProject() {
		return this.project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getWallet() {
		return this.wallet;
	}

	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	public String getJob() {
		return this.job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ChangeSetPK)) {
			return false;
		}
		ChangeSetPK castOther = (ChangeSetPK) other;
		return this.build.equals(castOther.build) && this.commit.equals(castOther.commit)
				&& this.project.equals(castOther.project) && this.wallet.equals(castOther.wallet)
				&& this.job.equals(castOther.job);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.build.hashCode();
		hash = hash * prime + this.commit.hashCode();
		hash = hash * prime + this.project.hashCode();
		hash = hash * prime + this.wallet.hashCode();
		hash = hash * prime + this.job.hashCode();

		return hash;
	}
}
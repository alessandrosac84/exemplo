describe('Abstract test to make sure that karma works properly', function() {
  it('Is true always true?', function() {
    expect(true).toBe(true);
  });
});
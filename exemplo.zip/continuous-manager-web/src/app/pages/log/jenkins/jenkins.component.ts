import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jmw-jenkins',
  templateUrl: './jenkins.component.html',
  styleUrls: ['./jenkins.component.scss']
})
export class JenkinsComponent implements OnInit {
  pageTitle = 'Log View';
  checkout: Boolean = true;
  setup: Boolean = true;
  build: Boolean = true;
  unitTest: Boolean = true;
  sonar: Boolean = true;
  deploy: Boolean = true;

  constructor() { }

  ngOnInit() {
  }

  click(nameButton: string) {
    if (nameButton === 'checkout') {
      if (this.checkout === false) {
        this.checkout = true;
      } else {
        this.checkout = false;
      }
    } else if (nameButton === 'setup') {
      if (this.setup === false) {
        this.setup = true;
      } else {
        this.setup = false;
      }
    } else if (nameButton === 'build') {
      if (this.build === false) {
        this.build = true;
      } else {
        this.build = false;
      }
    } else if (nameButton === 'unitTest') {
      if (this.unitTest === false) {
        this.unitTest = true;
      } else {
        this.unitTest = false;
      }
    } else if (nameButton === 'sonar') {
      if (this.sonar === false) {
        this.sonar = true;
      } else {
        this.sonar = false;
      }
    } else if (nameButton === 'deploy') {
      if (this.deploy === false) {
        this.deploy = true;
      } else {
        this.deploy = false;
      }
    }
  }

}

import { Component, OnInit } from '@angular/core';
import { Project } from '../../../shared/model/entity/project.model';
import { Observable } from 'rxjs';
import { single, multi } from '../../../../assets/file/data';
import { CedesBuilds } from '../../../shared/model/vo/cedesBuilds.model';
import { HomeService } from '../../../shared/service/home.service';
import { WalletService } from '../../../shared/service/wallet.service';
import { ProjectsBuildsStatus } from '../../../shared/model/vo/projectsBuildsStatus';



@Component({
  selector: 'cm-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  single: any[];
  multi: any[];
  view: any[] = [1400, 180];
  viewChartLine: any[] = [600, 250];

  listCedesBuilds: CedesBuilds[] = [];
  listProjectBuildsStatus: ProjectsBuildsStatus[] = [];

  // options common
  showXAxis = true;
  showYAxis = true;
  showLegend = true;
  showXAxisLabel = false;
  xAxisLabel = '';
  showYAxisLabel = true;
  autoScale = true;

  // options cedes bar chart
  legendTitle = 'Status';
  yAxisLabel = 'Builds';

  // option project bar chart
  yAxisLabelProject = 'Project';

  colorScheme = { domain: ['#5AA454', '#ad4055', '#5b5b5a', '#AAAAAA', '#bbb'] };

  constructor(private _homeService: HomeService) {
   Object.assign(this, {single, multi});
  }

  ngOnInit() {
    this._homeService.getCedesBuilds().subscribe(data => this.listCedesBuilds = data);
    this._homeService.getProjectsBuildsStatus().subscribe(data => this.listProjectBuildsStatus = data);
  }

  onSelect(event) {
    console.log(event);
  }
}

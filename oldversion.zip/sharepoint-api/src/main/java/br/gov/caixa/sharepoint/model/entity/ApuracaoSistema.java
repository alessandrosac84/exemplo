package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;

/**
 * The persistent class for the apuracao_sistema database table.
 * 
 */
@Entity
@Table(name = "apuracao_sistema")
@NamedQueries({
		@NamedQuery(name = "ApuracaoSistema.findAllDataApuracao", query = "SELECT DISTINCT a.id.apuracao FROM ApuracaoSistema a ORDER BY a.id.apuracao DESC"),
		@NamedQuery(name = "ApuracaoSistema.findAll", query = "SELECT a FROM ApuracaoSistema a JOIN FETCH a.artefatoSistemas WHERE a.id.apuracao = :apuracao"),
})
public class ApuracaoSistema extends AuditedEntity implements Serializable, IEntity<ApuracaoSistemaPK> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ApuracaoSistemaPK id;

	// bi-directional many-to-one association to Sistema
	@ManyToOne
	@JoinColumn(name = "sistema", nullable = false, insertable = false, updatable = false)
	private Ativo sistema;
	
	@Column(length=500)
	private String observacao;
	
	@Column(name = "quantidade_implantacao")
	private Integer quantidadeImplantacao;

	@JsonIgnore
	// bi-directional many-to-one association to ArtefatoSistema
	@OneToMany(mappedBy = "apuracaoSistema")
	private Set<ArtefatoSistema> artefatoSistemas;

	public ApuracaoSistema() {
	}

	public ApuracaoSistemaPK getId() {
		return this.id;
	}

	public void setId(ApuracaoSistemaPK id) {
		this.id = id;
	}

	public Ativo getSistema() {
		return this.sistema;
	}

	public void setSistema(Ativo sistema) {
		this.sistema = sistema;
	}

	public Set<ArtefatoSistema> getArtefatoSistemas() {
		return this.artefatoSistemas;
	}

	public void setArtefatoSistemas(Set<ArtefatoSistema> artefatoSistemas) {
		this.artefatoSistemas = artefatoSistemas;
	}

	public ArtefatoSistema addArtefatoSistema(ArtefatoSistema artefatoSistema) {
		getArtefatoSistemas().add(artefatoSistema);
		artefatoSistema.setApuracaoSistema(this);

		return artefatoSistema;
	}

	public ArtefatoSistema removeArtefatoSistema(ArtefatoSistema artefatoSistema) {
		getArtefatoSistemas().remove(artefatoSistema);
		artefatoSistema.setApuracaoSistema(null);

		return artefatoSistema;
	}
	
	@Override
	public boolean isTheSameObject(IEntity<ApuracaoSistemaPK> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		ApuracaoSistema other = (ApuracaoSistema) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/**
	 * @return the observacao
	 */
	public String getObservacao() {
		return observacao;
	}

	/**
	 * @param observacao the observacao to set
	 */
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	/**
	 * @return the quantidadeImplantacao
	 */
	public Integer getQuantidadeImplantacao() {
		return quantidadeImplantacao;
	}

	/**
	 * @param quantidadeImplantacao the quantidadeImplantacao to set
	 */
	public void setQuantidadeImplantacao(Integer quantidadeImplantacao) {
		this.quantidadeImplantacao = quantidadeImplantacao;
	}

}
package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.FeedbackMediaDto;

public class FeedbackMediaResult extends BasicResult {

	private List<FeedbackMediaDto> list;
	private FeedbackMediaDto feedbackMediaDto;

	public List<FeedbackMediaDto> getList() {
		return list;
	}

	public void setList(List<FeedbackMediaDto> list) {
		this.list = list;
	}

	public FeedbackMediaDto getFeedbackMediaDto() {
		return feedbackMediaDto;
	}

	public void setFeedbackMediaDto(
			FeedbackMediaDto feedbackMediaDto) {
		this.feedbackMediaDto = feedbackMediaDto;
	}

}

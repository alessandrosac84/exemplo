/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Audit;
import br.gov.caixa.inovacao.continuousmanager.model.repository.AuditRepository;

/**
 * @author Fabio Iwakoshi
 *
 */
@Logged
@Stateless
public class AuditService {

	@Inject
	private AuditRepository auditRepository;

	@Transactional(value=TxType.REQUIRED)
	public Audit save(Audit auditoria) {
		return auditRepository.save(auditoria);
	}
}

package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;

import java.util.Set;

/**
 * The persistent class for the complemento_atividade database table.
 * 
 */
@Entity
@Table(name = "complemento_atividade")
@NamedQueries({
	@NamedQuery(name = "ComplementoAtividade.findByAKs", query = "SELECT c FROM ComplementoAtividade c WHERE c.id <> :id AND c.descricao = :descricao"),
	@NamedQuery(name = "ComplementoAtividade.findAll", query = "SELECT c FROM ComplementoAtividade c"),
	@NamedQuery(name = "ComplementoAtividade.findByReferencia", query = "SELECT c FROM ComplementoAtividade c INNER JOIN FETCH c.atividades WHERE c.id = :complementoAtividade")
})
public class ComplementoAtividade extends AuditedEntity implements Serializable, IEntity<Integer> {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@NotEmpty
	@Size(min = 5, max = 70)
	@Column(nullable = false, length = 70)
	private String descricao;

	@JsonIgnore
	// bi-directional many-to-one association to Atividade
	@OneToMany(mappedBy = "complementoAtividade")
	private Set<Atividade> atividades;

	public ComplementoAtividade() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescricao() {
		return this.descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Set<Atividade> getAtividades() {
		return this.atividades;
	}

	public void setAtividades(Set<Atividade> atividades) {
		this.atividades = atividades;
	}

	public Atividade addAtividade(Atividade atividade) {
		getAtividades().add(atividade);
		atividade.setComplementoAtividade(this);

		return atividade;
	}

	public Atividade removeAtividade(Atividade atividade) {
		getAtividades().remove(atividade);
		atividade.setComplementoAtividade(null);

		return atividade;
	}

	@Override
	public boolean isTheSameObject(IEntity<Integer> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		ComplementoAtividade other = (ComplementoAtividade) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((descricao == null) ? 0 : descricao.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof ComplementoAtividade))
			return false;
		ComplementoAtividade other = (ComplementoAtividade) obj;
		if (descricao == null) {
			if (other.descricao != null)
				return false;
		} else if (!descricao.equals(other.descricao))
			return false;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.filter.request;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.Principal;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.UriInfo;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab.UserGitLabVO;
import br.gov.caixa.inovacao.continuousmanager.service.integration.GitLabService;
import br.gov.caixa.inovacao.continuousmanager.service.integration.SharepointService;

/**
 * Classe de Teste de AuthenticationTokenRequestFilter
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ InitialContext.class })
@PowerMockIgnore({"javax.net.ssl.*", "javax.security.*"})
public class AuthenticationTokenRequestFilterTest {
	
	@Rule
	public MockitoRule mrule = MockitoJUnit.rule();

	@Mock
	private HttpServletRequest request;

	@Mock
	private ContainerRequestContext containerRequestContext;

	@Mock
	private UriInfo uriInfo;

	@Mock
	private Principal principal;
	
	@Mock
	private SharepointService sharepointService;
	
	@Mock
	private GitLabService gitLabService;
	
	@Mock
	private UserGitLabVO userGitLabVO;

	@InjectMocks
	private AuthenticationTokenRequestFilter authenticationTokenRequestFilter;

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws NamingException 
	 */
	@Test
	public void testFilter() throws IOException, NamingException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/auth/login");
		Mockito.when(containerRequestContext.hasEntity()).thenReturn(true);
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.when(request.getUserPrincipal()).thenReturn(principal);
		Mockito.when(containerRequestContext.getEntityStream()).thenReturn(new ByteArrayInputStream(
				"{\"username\":\"f771274\",\"password\":\"123456\"}".getBytes(StandardCharsets.UTF_8.name())));
		PowerMockito.mockStatic(InitialContext.class);
		PowerMockito.when(InitialContext.<SharepointService>doLookup("java:comp/SharepointService")).thenReturn(sharepointService);
		PowerMockito.when(InitialContext.<GitLabService>doLookup("java:comp/GitLabService")).thenReturn(gitLabService);
		Mockito.when(gitLabService.getUserByMatricula(Mockito.anyString())).thenReturn(userGitLabVO);
		Mockito.when(userGitLabVO.isAdmin()).thenReturn(false);

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws NamingException 
	 */
	@Test
	public void testFilterOptions() throws IOException, NamingException {
		Mockito.when(containerRequestContext.getMethod()).thenReturn("OPTIONS");
		
		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws ServletException 
	 */
	@Test
	public void testFilterExceptionToken() throws IOException, ServletException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/sistema");
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.doThrow(ServletException.class).when(request).login(Mockito.anyString(), Mockito.anyString());
		Mockito.when(containerRequestContext.getHeaderString("Authorization")).thenReturn(
				"Bearer eyJhbGciOiJSUzI1NiJ9.eyJleHAiOjE1MjUyNzM4MzksImp0aSI6IjVnSHpSV2VlZHlmR1RCdS0xVHFta"
				+ "EEiLCJpYXQiOjE1MjUyNzI5MzksInN1YiI6ImM4OTc4NTUiLCJlbWFpbCI6bnVsbCwicm9sZXMiOlsiQ1VDR0VT"
				+ "IiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiw"
				+ "iQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1"
				+ "VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR"
				+ "0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VT"
				+ "IiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIl0sIm90aGVycyI6IntcImF0aXZvc1wiOltdLFwiYWRtaW5cIjp"
				+ "mYWxzZX0ifQ.jiOaYiB-RFtjD1tAI8J6-lAbrAEGqTjzX9WOCV9Q6g9CW9UMu6nUbhVfYMU84luiN_yXAtPcz-D"
				+ "LwMleUuUTV7eNKUvjc5_gUUnSq7ruOFpBNM29MUIiWb_6j-g5LfGCbPJLSzWitgXzG08Ep_BTJx9LUeeVKUCMQU"
				+ "cH8cO2G4dSo24iVKzuMf6mP36yBMEdByRCB0mDCoYB0ZPvkJFmzyg7J1GpEogPzN-Q2vVx7Ev9_C--4jSirV_BC"
				+ "H84v0Ox4Oy3DYq-PFghycb_FvU4J3gW94k3qJs6TPpwG3H7laQ198ZO5QWTcJtgwR3mnuvRRWjgQvdqLIlgv95E_f1isw");

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilterExceptionLogin() throws IOException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/auth/login");
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilterAnyElsePath() throws IOException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.when(uriInfo.getPath()).thenReturn("/sistema");

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws NamingException 
	 */
	@Test
	public void testFilterAnyElsePathAuthorized() throws IOException, NamingException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/sistema");
		Mockito.when(request.getUserPrincipal()).thenReturn(principal);
		Mockito.when(principal.getName()).thenReturn("f771274");
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.when(containerRequestContext.getHeaderString("Authorization")).thenReturn(
				"Bearer eyJhbGciOiJSUzI1NiJ9.eyJleHAiOjE1MjUyNzM4MzksImp0aSI6IjVnSHpSV2VlZHlmR1RCdS0xVHFta"
				+ "EEiLCJpYXQiOjE1MjUyNzI5MzksInN1YiI6ImM4OTc4NTUiLCJlbWFpbCI6bnVsbCwicm9sZXMiOlsiQ1VDR0VT"
				+ "IiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiw"
				+ "iQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1"
				+ "VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR"
				+ "0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VT"
				+ "IiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIl0sIm90aGVycyI6IntcImF0aXZvc1wiOltdLFwiYWRtaW5cIjp"
				+ "mYWxzZX0ifQ.jiOaYiB-RFtjD1tAI8J6-lAbrAEGqTjzX9WOCV9Q6g9CW9UMu6nUbhVfYMU84luiN_yXAtPcz-D"
				+ "LwMleUuUTV7eNKUvjc5_gUUnSq7ruOFpBNM29MUIiWb_6j-g5LfGCbPJLSzWitgXzG08Ep_BTJx9LUeeVKUCMQU"
				+ "cH8cO2G4dSo24iVKzuMf6mP36yBMEdByRCB0mDCoYB0ZPvkJFmzyg7J1GpEogPzN-Q2vVx7Ev9_C--4jSirV_BC"
				+ "H84v0Ox4Oy3DYq-PFghycb_FvU4J3gW94k3qJs6TPpwG3H7laQ198ZO5QWTcJtgwR3mnuvRRWjgQvdqLIlgv95E_f1isw");

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws ServletException 
	 * @throws NamingException 
	 */
	@Test
	public void testFilterAnyElsePathAuthorizedFailed() throws IOException, ServletException, NamingException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/sistema");
		Mockito.when(request.getUserPrincipal()).thenReturn(principal);
		Mockito.when(principal.getName()).thenReturn("c771274");
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.when(containerRequestContext.getHeaderString("Authorization")).thenReturn(
				"Bearer eyJhbGciOiJSUzI1NiJ9.eyJleHAiOjE1MjUyNzM4MzksImp0aSI6IjVnSHpSV2VlZHlmR1RCdS0xVHFta"
				+ "EEiLCJpYXQiOjE1MjUyNzI5MzksInN1YiI6ImM4OTc4NTUiLCJlbWFpbCI6bnVsbCwicm9sZXMiOlsiQ1VDR0VT"
				+ "IiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiw"
				+ "iQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1"
				+ "VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR"
				+ "0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VT"
				+ "IiwiQ1VDR0VTIiwiQ1VDR0VTIiwiQ1VDR0VTIl0sIm90aGVycyI6IntcImF0aXZvc1wiOltdLFwiYWRtaW5cIjp"
				+ "mYWxzZX0ifQ.jiOaYiB-RFtjD1tAI8J6-lAbrAEGqTjzX9WOCV9Q6g9CW9UMu6nUbhVfYMU84luiN_yXAtPcz-D"
				+ "LwMleUuUTV7eNKUvjc5_gUUnSq7ruOFpBNM29MUIiWb_6j-g5LfGCbPJLSzWitgXzG08Ep_BTJx9LUeeVKUCMQU"
				+ "cH8cO2G4dSo24iVKzuMf6mP36yBMEdByRCB0mDCoYB0ZPvkJFmzyg7J1GpEogPzN-Q2vVx7Ev9_C--4jSirV_BC"
				+ "H84v0Ox4Oy3DYq-PFghycb_FvU4J3gW94k3qJs6TPpwG3H7laQ198ZO5QWTcJtgwR3mnuvRRWjgQvdqLIlgv95E_f1isw");

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws NamingException 
	 */
	@Test
	public void testFilterNoEntity() throws IOException, NamingException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/auth/login");
		Mockito.when(request.getUserPrincipal()).thenReturn(principal);
		Mockito.when(principal.getName()).thenReturn("f771274");
		Mockito.when(containerRequestContext.hasEntity()).thenReturn(false);
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		PowerMockito.mockStatic(InitialContext.class);
		PowerMockito.when(InitialContext.<SharepointService>doLookup("java:comp/SharepointService")).thenReturn(sharepointService);
		PowerMockito.when(InitialContext.<GitLabService>doLookup("java:comp/GitLabService")).thenReturn(gitLabService);
		Mockito.when(gitLabService.getUserByMatricula(Mockito.anyString())).thenReturn(userGitLabVO);
		Mockito.when(userGitLabVO.isAdmin()).thenReturn(false);

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws NamingException 
	 */
	@Test
	public void testFilterHasEntityEmpty() throws IOException, NamingException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/auth/login");
		Mockito.when(containerRequestContext.hasEntity()).thenReturn(true);
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.when(containerRequestContext.getEntityStream())
				.thenReturn(new ByteArrayInputStream("".getBytes(StandardCharsets.UTF_8.name())));
		Mockito.when(request.getUserPrincipal()).thenReturn(principal);
		PowerMockito.mockStatic(InitialContext.class);
		PowerMockito.when(InitialContext.<SharepointService>doLookup("java:comp/SharepointService")).thenReturn(sharepointService);
		PowerMockito.when(InitialContext.<GitLabService>doLookup("java:comp/GitLabService")).thenReturn(gitLabService);
		Mockito.when(gitLabService.getUserByMatricula(Mockito.anyString())).thenReturn(userGitLabVO);
		Mockito.when(userGitLabVO.isAdmin()).thenReturn(false);

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}
}

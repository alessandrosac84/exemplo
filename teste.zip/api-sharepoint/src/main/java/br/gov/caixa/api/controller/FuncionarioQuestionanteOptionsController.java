package br.gov.caixa.api.controller;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.result.FuncionarioQuestionanteOptionsResult;
import br.gov.caixa.api.services.FuncionarioQuestionanteOptionsService;

@RestController
public class FuncionarioQuestionanteOptionsController {
	
	@Inject
	FuncionarioQuestionanteOptionsService service;
	
	@RequestMapping(value="/api/funcionarioQuestionanteOptions/all", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public FuncionarioQuestionanteOptionsResult listAll() {
		
		return service.listAll();
	}
	                        
	@RequestMapping(value="/api/funcionarioQuestionanteOptions/listFuncionariosQuestionantesOptionsByQuestionarioId/{questionarioId}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public FuncionarioQuestionanteOptionsResult listFuncionariosQuestionantesOptionsByQuestionarioId(@PathVariable Long questionarioId) {
		
		return service.listFuncionariosQuestionantesOptionsByQuestionarioId(questionarioId);
	}
	
	
}

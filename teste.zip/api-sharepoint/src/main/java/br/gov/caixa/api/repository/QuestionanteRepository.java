package br.gov.caixa.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.Questionante;
import br.gov.caixa.api.model.Questionario;

public interface QuestionanteRepository extends	JpaRepository<Questionante, Long> {
	
	//List<Questionante> findByQuestionario(Questionario questionario);

	@Query("select distinct q from Questionante q join fetch q.funcionario f left join f.coordenacao c left join c.parent cp left join "
			+ "c.segmentoNegocio snA left join cp.segmentoNegocio snB where q.questionario = ?1" )
	List<Questionante> findByQuestionario(Questionario questionario);

	List<Questionante> findByFuncionario(Funcionario funcionario);
	
//	@Modifying
//	@Transactional
//	@Query("update Questionante a set a.participacao = ?1, a.option1 = ?2, a.option1 = ?3, a.option1 = ?4 where a.uid = ?2")
//	int setRespostar();
	
}

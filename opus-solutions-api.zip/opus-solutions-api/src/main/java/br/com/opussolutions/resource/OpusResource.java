/**
 * 
 */
package br.com.opussolutions.resource;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.opussolutions.service.OpusService;
import br.com.opussolutions.model.entity.Cliente;
import br.com.opussolutions.model.vo.TransacaoVO;


@Path("opus")
@RequestScoped
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class OpusResource {
	
	@Inject
	private OpusService opusService;

	@GET
	public Response getOpus() {
		return Response.ok(opusService.findById("")).build();
	}
	
	@GET
	@Path("{cliente:[a-z\\-]+}")
	public Response getCliente(@PathParam("cliente") String cliente) {
		return Response.ok(opusService.findById(cliente)).build();
	}
	
	/*@POST
	@Path("save-cliente")
	public Response saveCliente(@Valid Cliente cliente) {
		return Response.ok(opusService.saveCliente(cliente)).build();
		
	}*/
}

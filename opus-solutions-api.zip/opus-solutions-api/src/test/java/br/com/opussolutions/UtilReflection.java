/**
 * 
 */
package br.com.opussolutions;

import java.lang.reflect.Field;
import java.util.logging.Level;
import java.util.logging.Logger;


public class UtilReflection {
	
	private static Logger log = Logger.getAnonymousLogger();
	
	public static <E> void setField(E entity, String campo, Object valor) {
		Class<?> clazzEntidade = entity.getClass();
		Field field = null;
		try {
			field = clazzEntidade.getDeclaredField(campo);
		} catch (NoSuchFieldException | IllegalArgumentException e) {
			log.fine(() -> "Erro ao obter campo. Tentando superclass...");
			clazzEntidade = entity.getClass().getSuperclass();
			try {
				field = clazzEntidade.getDeclaredField(campo);
			} catch (NoSuchFieldException | SecurityException e1) {
				log.log(Level.SEVERE, e, () -> "Erro ao atribuir valor");
				return;
			}
		}
		try {
			field.setAccessible(true);
			field.set(entity, valor);
		} catch (IllegalArgumentException | IllegalAccessException e) {
			log.log(Level.SEVERE, e, () -> "Erro ao atribuir valor");
		}
	}

}

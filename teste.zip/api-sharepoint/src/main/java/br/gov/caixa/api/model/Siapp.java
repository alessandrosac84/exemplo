package br.gov.caixa.api.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.gov.caixa.api.dto.FerramentaDto;
import br.gov.caixa.api.dto.FuncionarioDto;
import br.gov.caixa.api.dto.SiappDto;

@Entity
@Table(name = "siapp")
public class Siapp {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "ORIGEM", nullable = true)
	private String origem;			

	@Column(name = "SISTEMA", nullable = false)
	private String sistema;
	
	@Column(name = "CARTEIRA", nullable = false)
	private String carteira;
	
	@Column(name = "DESCRICAO")
	private String descricao;
	
	@Column(name = "ALIAS")
	private String alias;
	
	@Column(name = "TIPO")
	private String tipo;
	
	@Column(name = "ESTADO")
	private String estado;
	
	@Column(name = "CODIGO", nullable = false)
	private Long codigo;	

	@Column(name = "COORDENACAO_PROJETO", nullable = false)
	private String coordenacaoProjeto;
	
	@Column(name = "COORDENACAO_TI", nullable = false)
	private String coordenacaoTi;
			
	@OneToMany(fetch = FetchType.EAGER, cascade=CascadeType.DETACH)	
	@JoinTable(name = "siapp_funcionario", joinColumns = @JoinColumn(name = "SIAPP_ID", referencedColumnName = "UID"), 
								inverseJoinColumns = @JoinColumn(name = "FUNCIONARIO_ID", referencedColumnName = "UID"))
	private Set<Funcionario> funcionarios = new HashSet<Funcionario>();

	@ManyToMany(fetch = FetchType.EAGER)	
	@JoinTable(name = "Ferramenta_Siapp", joinColumns = @JoinColumn(name = "SIAPP_ID", referencedColumnName = "UID"), 
								inverseJoinColumns = @JoinColumn(name = "FERRAMENTA_ID", referencedColumnName = "UID"))
	private Set<Ferramenta> ferramentas = new HashSet<Ferramenta>();

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public String getSistema() {
		return sistema;
	}

	public void setSistema(String sistema) {
		this.sistema = sistema;
	}

	public String getCarteira() {
		return carteira;
	}

	public void setCarteira(String carteira) {
		this.carteira = carteira;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}
	
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getCoordenacaoProjeto() {
		return coordenacaoProjeto;
	}

	public void setCoordenacaoProjeto(String coordenacaoProjeto) {
		this.coordenacaoProjeto = coordenacaoProjeto;
	}
	
	public String getCoordenacaoTi() {
		return coordenacaoTi;
	}

	public void setCoordenacaoTi(String coordenacaoTi) {
		this.coordenacaoTi = coordenacaoTi;
	}
	
	public Set<Funcionario> getFuncionarios() {
		return funcionarios;
	}

	public void setFuncionarios(Set<Funcionario> funcionarios) {
		this.funcionarios = funcionarios;
	}

	public Set<Ferramenta> getFerramentas() {
		return ferramentas;
	}

	public void setFerramentas(Set<Ferramenta> ferramentas) {
		this.ferramentas = ferramentas;
	}

	public Siapp fromDtoToSiapp(SiappDto siappDto) {
		Siapp siapp = new Siapp();
		
		siapp.setUid(siappDto.getUid());
		siapp.setOrigem(siappDto.getOrigem());
		siapp.setSistema(siappDto.getSistema());
		siapp.setCarteira(siappDto.getCarteira());
		siapp.setDescricao(siappDto.getDescricao());
		siapp.setAlias(siappDto.getAlias());
		siapp.setTipo(siappDto.getTipo());
		siapp.setEstado(siappDto.getEstado());
		siapp.setCodigo(siappDto.getCodigo());
		siapp.setCoordenacaoProjeto(siappDto.getCoordenacaoProjeto());
		siapp.setCoordenacaoTi(siappDto.getCoordenacaoTi());
		
		if(siappDto.getFuncionarios() != null){
			
			Set<Funcionario> funcionarios = new HashSet<Funcionario>();
			
			for (FuncionarioDto dto : siappDto.getFuncionarios()) {
				Funcionario funcionario = Funcionario.fromDtoToFuncionario(dto);
				funcionarios.add(funcionario);
			}
			
			siapp.setFuncionarios(funcionarios);
		}
				
		if(siappDto.getFerramentasDto() != null){
			Set<Ferramenta> ferramentas = new HashSet<Ferramenta>();
			
			for (FerramentaDto dto : siappDto.getFerramentasDto()) {
				Ferramenta ferramenta = Ferramenta.fromDtoToFerramenta(dto);
				ferramentas.add(ferramenta);
			}
			siapp.setFerramentas(ferramentas);
		}
		
		return siapp;
	}
}

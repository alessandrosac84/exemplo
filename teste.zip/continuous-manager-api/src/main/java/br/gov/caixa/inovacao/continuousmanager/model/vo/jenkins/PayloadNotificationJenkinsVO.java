package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe de representação do Payload de Notificacao do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class PayloadNotificationJenkinsVO implements Serializable {

	private static final long serialVersionUID = 8655334048330719465L;

	private String name;
	
	@JsonProperty("display_name")
	private String displayName;
	
	private String url;
	
	private BuildNotificationJenkinsVO build;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the build
	 */
	public BuildNotificationJenkinsVO getBuild() {
		return build;
	}

	/**
	 * @param build the build to set
	 */
	public void setBuild(BuildNotificationJenkinsVO build) {
		this.build = build;
	}
}

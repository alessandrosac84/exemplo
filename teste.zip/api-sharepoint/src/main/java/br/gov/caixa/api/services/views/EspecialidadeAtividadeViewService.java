package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.model.views.EspecialidadeAtividadeView;
import br.gov.caixa.api.repository.views.EspecialidadeAtividadeViewRepository;
import br.gov.caixa.api.result.views.EspecialidadeAtividadeViewResult;

@Named
public class EspecialidadeAtividadeViewService {
	
	@Inject
	EspecialidadeAtividadeViewRepository repository;
	
	public EspecialidadeAtividadeViewResult listAll() {

		EspecialidadeAtividadeViewResult result = new EspecialidadeAtividadeViewResult();
		try {
			List<EspecialidadeAtividadeView> lista = repository.findAll();

			if (lista != null) {
				result.setList(lista);
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma especialidadeAtividadeView.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}
	
	public EspecialidadeAtividadeViewResult listEspecialidadeAtividadeViewsByIdEspecialidade(Long idEspecialidade) {
		EspecialidadeAtividadeViewResult result = new EspecialidadeAtividadeViewResult();
		try {
						
			List<EspecialidadeAtividadeView> lista = repository.findByEspecialidadeId(idEspecialidade);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Atividade para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

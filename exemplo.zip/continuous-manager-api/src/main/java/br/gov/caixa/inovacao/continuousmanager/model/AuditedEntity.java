/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import br.gov.caixa.inovacao.continuousmanager.config.interceptor.AuditInterceptor;

/**
 * @author Fabio Iwakoshi
 *
 */
@MappedSuperclass
@EntityListeners(AuditInterceptor.class)
public abstract class AuditedEntity implements Serializable {
	/** * */
	private static final long serialVersionUID = -9210299262782006525L;

	@JsonIgnore
	@Column(name="user_insert", nullable=false, updatable=false, length=7)
	private String userInsert;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_at", nullable=false, updatable=false)
	private Calendar createdAt;

	@JsonIgnore
	@Column(name="user_update", length=7)
	private String userUpdate;
	
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_at")
	private Calendar updatedAt;

	@JsonIgnore
	public Calendar getUpdatedAt() {
		return this.updatedAt;
	}

	@JsonProperty
	public void setUpdatedAt(Calendar updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Calendar getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Calendar createdAt) {
		this.createdAt = createdAt;
	}

	@JsonIgnore
	public String getUserUpdate() {
		return this.userUpdate;
	}

	@JsonProperty
	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	@JsonIgnore
	public String getUserInsert() {
		return this.userInsert;
	}

	@JsonProperty
	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}
}

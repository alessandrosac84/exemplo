package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sharepoint.FuncionarioSharepointVO;

/**
 * @author Alessandro Carvalho
 *
 */

@Logged
@Stateless
public class LdapService {
	
	public static final String LDAP_AD_SERVER = "ldap://corp.caixa.gov.br:3268";
	public static final String LDAP_USER_SEARCH = "OU=CAIXA,DC=corp,DC=caixa,DC=gov,DC=br";
	public static final String LDAP_DEPTO_SEARCH = "OU=Empregados,OU=Usuarios,OU=CAIXA,DC=corp,DC=caixa,DC=gov,DC=br";
	
	private LdapContext ctx;
	
	@Inject
	private Logger log;
	
	@Inject
	private ParameterService parameterService;
	
	@PostConstruct
	public void init() {
		if (ctx == null) {
			synchronized (LdapService.class) {
				Hashtable<String, Object> env = new Hashtable<String, Object>();
				env.put(Context.SECURITY_AUTHENTICATION, "simple");
				env.put(Context.SECURITY_PRINCIPAL, getUserLdap().getPrincipal());
				env.put(Context.SECURITY_CREDENTIALS, getUserLdap().getCredential());
				env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
				env.put(Context.PROVIDER_URL, LDAP_AD_SERVER);
				env.put("java.naming.ldap.attributes.binary", "objectSID");
		
				try {					
					ctx = new InitialLdapContext(env, null);
					
					if (ctx instanceof javax.naming.directory.DirContext) {
						log.info("YES !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
					} else {
						log.info("#$@%*&@#**$@%$##$@%*&@#**$@%$##$@%*&@#**$@%$#");
					}
				} catch (Exception e) {
					throw new RuntimeException("Não foi possível criar a conexão com o LDAP!");
				}
			}
		}
	}
	
	public Parameter getUserLdap() {
				
		ParameterPK paramPk = new ParameterPK();
		paramPk.setEnvironment(Environment.DES);
		paramPk.setServerType(ServerType.LDAP);
		
		Parameter infoUserLdap = parameterService.findById(paramPk);
		
		return infoUserLdap;
	}
	
	public List<FuncionarioSharepointVO> getUser(String filter) {
		List<FuncionarioSharepointVO> userList = new ArrayList<>();
		
		String LDAP_USER_FILTER = "(&(objectClass=user)(sAMAccountName=f*)(|(sAMAccountName=*" + filter + "*)(mail=*" + filter + "*)(name=*" + filter + "*)))";
		try {
			List<SearchResult> ldapUsers = findAccountByFilter(LDAP_USER_SEARCH, LDAP_USER_FILTER, filter);
			
			if (ldapUsers.isEmpty()) {
				return null;
			}else {
				for (SearchResult searchResult : ldapUsers) {
					FuncionarioSharepointVO user = new FuncionarioSharepointVO();
					user.setMatricula(getAttr(searchResult, "sAMAccountName"));
					user.setEmail(getAttr(searchResult, "mail"));
					user.setNome(getAttr(searchResult, "name"));
					
					userList.add(user);
				}
			}
		} catch (NamingException e) {
			log.log(Level.SEVERE, "Erro obtendo atributos/parse do LDAP", e);
		}
		return userList;
	}
	
	private String getAttr(SearchResult srLdapUser, String attribute) throws NamingException {
		if (srLdapUser.getAttributes().get(attribute) != null)
			return (String) srLdapUser.getAttributes().get(attribute).get();
		return null;
	}
	
	private List<SearchResult> findAccountByFilter(String ldapSearchBase, String ldapFilterBase, String filter) throws NamingException {
		String searchFilter = ldapFilterBase;

		SearchControls searchControls = new SearchControls();
		searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		searchControls.setTimeLimit(300000);

		NamingEnumeration<SearchResult> results = ctx.search(ldapSearchBase, searchFilter, searchControls);

		List<SearchResult> searchResults = new ArrayList<>();
		if (results != null) {
			while (results.hasMoreElements()) {
				searchResults.add((SearchResult) results.nextElement());
			}
		}
		return searchResults;
	}
}

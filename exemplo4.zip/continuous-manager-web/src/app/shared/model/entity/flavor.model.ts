
export class Flavor {
  id: string;
  description: string;
  typeServer: string;
  version: string;
}

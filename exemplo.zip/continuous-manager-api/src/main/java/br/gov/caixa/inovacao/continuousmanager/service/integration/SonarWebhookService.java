/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Job;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JobPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ProjectPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Wallet;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BuildJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.JobJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ProjectJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.WalletJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.service.BuildService;
import br.gov.caixa.inovacao.continuousmanager.service.JenkinsService;
import br.gov.caixa.inovacao.continuousmanager.service.JobService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectService;
import br.gov.caixa.inovacao.continuousmanager.service.WalletService;

/**
 * Classe de servicos de Folder.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class SonarWebhookService {
	
	private static final String SKYNET_USER = "@SKYNET";

	@Inject
	private Logger log;

	@Inject
	private JenkinsService jenkinsService;
	
	@Inject
	private WalletService walletService;
	
	@Inject
	private ProjectService projectService;
	
	@Inject
	private JobService jobService;
	
	@Inject
	private BuildService buildService;

	public void checkNews() {
		checkWallets();
	}

	private void checkWallets() {
		log.fine("Checking wallets");
		List<WalletJenkinsVO> wallets = jenkinsService.listWallets();
		walletService.findAll(0, Integer.MAX_VALUE, "", "id", AscDesc.ASC);
		
		wallets.forEach(wallet -> {
			Wallet w = new Wallet();
			w.setId(wallet.getName());
			w.setName(wallet.getDisplayName());
			w.setCreatedAt(Calendar.getInstance());
			w.setUserInsert(SKYNET_USER);
			if (walletService.findById(w.getId()) == null) {
				w = walletService.save(w);
			}
			checkProjects(w);
		});
	}

	private void checkProjects(Wallet wallet) {
		log.fine("Checking projects");
		List<ProjectJenkinsVO> projects = jenkinsService.listProjects(wallet.getId());
		projectService.findAll(wallet.getId(), 0, Integer.MAX_VALUE, "", "id", AscDesc.ASC);
		
		projects.forEach(project -> {
			Project p = new Project();
			p.setId(new ProjectPK());
			p.getId().setId(project.getName());
			p.getId().setWallet(wallet.getId());
			p.setWallet(wallet);
			p.setName(project.getDisplayName());
			p.setCreatedAt(Calendar.getInstance());
			p.setUserInsert(SKYNET_USER);
			if (project.getClazz().equalsIgnoreCase("com.cloudbees.hudson.plugins.folder.Folder")) {
				if (projectService.findById(p.getId()) == null) {
					projectService.save(p);
				}
				checkJobs(p);
			}
		});
	}

	private void checkJobs(Project project) {
		log.fine("Checking jobs");
		List<JobJenkinsVO> jobs = jenkinsService.listJobs(project.getId().getWallet(), project.getId().getId());
		jobService.findAll(project.getId().getWallet(), project.getId().getId(), 0, Integer.MAX_VALUE, "", "id", AscDesc.ASC);
		
		jobs.forEach(job -> {
			Job j = new Job();
			j.setId(new JobPK());
			j.getId().setId(job.getName());
			j.getId().setWallet(project.getId().getWallet());
			j.getId().setProject(project.getId().getId());
			j.setProject(project);
			j.setName(job.getDisplayName());
			j.setCreatedAt(Calendar.getInstance());
			j.setUserInsert(SKYNET_USER);
			if (jobService.findById(j.getId()) == null) {
				jobService.save(j);
			}
			checkBuilds(j);
		});
	}

	private void checkBuilds(Job job) {
		log.fine("Checking builds");
		List<BuildJenkinsVO> builds = jenkinsService.listBuilds(job.getId().getWallet(), job.getId().getProject(), job.getId().getId());
		buildService.findAll(job.getId().getWallet(), job.getId().getProject(), job.getId().getId(), 0, Integer.MAX_VALUE, "", "id", AscDesc.ASC);
		
		builds.forEach(build -> {
			Build b = new Build();
			b.setId(new BuildPK());
			b.getId().setId(build.getNumber());
			b.getId().setWallet(job.getId().getWallet());
			b.getId().setProject(job.getId().getProject());
			b.getId().setJob(job.getId().getId());
			
			b.setCreatedAt(build.getTimestamp());
			b.setDescription(build.getDescription());
			b.setDuration(new Date(build.getDuration()));
			b.setEstimateDuration(new Date(build.getEstimatedDuration()));
			b.setJob(job);
			b.setResult(build.getResult());

			if (buildService.findById(b.getId()) == null) {
				b.setLog(jenkinsService.getLog(job.getId().getWallet(), job.getId().getProject(), job.getId().getId(), build.getNumber()));
				buildService.save(b);
			}
		});
	}
}

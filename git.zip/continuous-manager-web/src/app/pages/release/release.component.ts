import { Title } from '@angular/platform-browser';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgbModule, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

import { ToastrService } from 'ngx-toastr';

import { WalletService } from './../../shared/service/wallet.service';

import { ChangeSet } from './../../shared/model/changeset.model';
import { Project } from './../../shared/model/project.model';
import { Commit } from './../../shared/model/commit.model';
import { Build } from './../../shared/model/build.model';
import { Wallet } from './../../shared/model/wallet.model';

@Component({
  selector: 'jmw-release',
  templateUrl: './release.component.html',
  styleUrls: ['./release.component.scss']
})
export class ReleaseComponent implements OnInit {
  pageTitle = 'Release Manager';

  projectId: Project;
  walletId: Wallet;
  selectedItem: Commit;

  wallets: Wallet[];
  projects: Project[];
  builds: Build[];
  changeSets: ChangeSet[];

  page: number;
  total: number;

  constructor(
    private _title: Title,
    private _walletService: WalletService,
    private _modalService: NgbModal,
    private _toastr: ToastrService
  ) {}

  ngOnInit() {
    this._title.setTitle(this.pageTitle);
    this._walletService.getWallets().subscribe(data => {
      this.wallets = data;
    });
    this.page = 1;
  }

  chargeProjects() {
    this.projects = [];
    this.projectId = undefined;
    if (!!this.walletId) {
      this._walletService.getProjects(this.walletId.id).subscribe(data => {
        this.projects = data;
      });
    }
  }

  chargeBuilds() {
    this.builds = [];
    if (!!this.projectId) {
      this._walletService.getBuildsToRelease(this.walletId.id, this.projectId.id.id, this.page).subscribe((res) => {
        this.builds = res.body;
        this.builds.forEach(build => {
          build.changeSets.sort((a, b) => (a.commit.id.commit > b.commit.id.commit) ? -1 : 1);
        });
        this.total = +res.headers.get('Content-Range').substring(res.headers.get('Content-Range').indexOf('/') + 1);
      });
    }
  }

  pageChanged(event) {
    this.page = event;
    this.chargeBuilds();
  }

  deploy(commit: Commit) {
    this._walletService.deploy(this.walletId.id, this.projectId.id.id, commit.version).subscribe(data => {
        this._toastr.info('Sua solicitação foi enviada ao Servidor!', 'Info');
    });
  }

  openVersionModal(build: Build, content) {
     if (build) {
       this.selectedItem = Object.assign({}, build.changeSets[0].commit);
       this._modalService.open(content, { centered: true }).result.then((result) => {
        if (this.selectedItem) {
          this._walletService.version(this.walletId.id, this.projectId.id.id, this.selectedItem).subscribe(data => {
              this._toastr.info('Sua solicitação foi enviada ao Servidor!', 'Info');
          });
        }
       }, (reason) => {});
     }
  }
}

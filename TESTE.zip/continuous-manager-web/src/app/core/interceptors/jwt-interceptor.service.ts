import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse, HttpResponse } from '@angular/common/http';

import { Observable } from 'rxjs/Rx';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {

    constructor() { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        // Get the auth token from the service.
        const authToken = localStorage.getItem('jwt');

        // Clone the request and replace the original headers with
        // cloned headers, updated with the authorization.

        let authReq = req;
        if (authToken !== null) {
            authReq = req.clone({
                headers: req.headers.set('Authorization', 'Bearer ' + authToken)
            });
        }

        return next.handle(authReq).map(event => {
            if (event instanceof HttpResponse) {
                if (event.headers.get('jwt') !== null) {
                    localStorage.setItem('jwt', event.headers.get('jwt').substring(1, event.headers.get('jwt').length - 1));
                } else {
                    localStorage.removeItem('jwt');
                }
            }
            return event;
        });
    }
}

import { Wallet } from './wallet.model';

export class UserProject {
  id: string;
  name: string;
  photo: string;
  notificationBuild: boolean;
  notificationStage: boolean;
  wallet: Wallet;
}

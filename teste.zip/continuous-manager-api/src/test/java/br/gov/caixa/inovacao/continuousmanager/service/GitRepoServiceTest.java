/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.GitRepo;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.repository.GitRepoRepository;

/**
 * Classe de testes do GitRepoService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class GitRepoServiceTest {
	
	@Mock
	private GitRepoRepository gitRepoRepository;

	@InjectMocks
	private GitRepoService gitRepoService;

	private GitRepo gitRepo;
	
	@Before
	public void before() {
		gitRepo = null; // EntityBuilder.createProjects().get(0).getGitRepos().stream().findFirst().get();
		UtilReflection.setField(gitRepoService, "log", Logger.getLogger(AuditService.class.getName()));
	}
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(gitRepoRepository.save(Mockito.<GitRepo>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		
		// Act
		GitRepo savedGitRepo = gitRepoService.save(gitRepo);

		// Then
		Assert.assertNotNull(savedGitRepo);
	}
}

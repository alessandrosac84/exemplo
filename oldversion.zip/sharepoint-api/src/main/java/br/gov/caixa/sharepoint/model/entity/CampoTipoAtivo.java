package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the campo_tipo_ativo database table.
 * 
 */
@Entity
@Table(name="campo_tipo_ativo")
@NamedQueries({	
	@NamedQuery(name="CampoTipoAtivo.findAll", query="SELECT c FROM CampoTipoAtivo c"),
	@NamedQuery(name="CampoTipoAtivo.findByTipoAtivo", query="SELECT c FROM CampoTipoAtivo c WHERE c.tipoAtivo.id = :tipoAtivo"),
	@NamedQuery(name="CampoTipoAtivo.findByReferencia", query="SELECT c FROM CampoTipoAtivo c INNER JOIN c.ativoCampos ac WHERE c.id = :campoTipoAtivo")
})
public class CampoTipoAtivo extends AuditedEntity implements Serializable, IEntity<CampoTipoAtivoPK> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CampoTipoAtivoPK id;

	//bi-directional many-to-one association to CampoAdicional
	@ManyToOne
	@JoinColumn(name="campo", nullable=false, insertable=false, updatable=false)
	private CampoAdicional campoAdicional;

	//bi-directional one-to-one association to TipoAtivo
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="tipo_ativo", nullable=false, insertable=false, updatable=false)
	private TipoAtivo tipoAtivo;
	
	//bi-directional many-to-one association to AtivoCampo
	@JsonIgnore
	@OneToMany(mappedBy="campoTipoAtivo")
	private Set<AtivoCampo> ativoCampos;

	public CampoTipoAtivo() {
	}

	public CampoTipoAtivoPK getId() {
		return this.id;
	}

	public void setId(CampoTipoAtivoPK id) {
		this.id = id;
	}
	
	public CampoAdicional getCampoAdicional() {
		return this.campoAdicional;
	}

	public void setCampoAdicional(CampoAdicional campoAdicional) {
		this.campoAdicional = campoAdicional;
	}

	@JsonIgnore
	public TipoAtivo getTipoAtivo() {
		return this.tipoAtivo;
	}

	@JsonProperty
	public void setTipoAtivo(TipoAtivo tipoAtivo) {
		this.tipoAtivo = tipoAtivo;
	}
	public Set<AtivoCampo> getAtivoCampos() {
		return this.ativoCampos;
	}

	public void setAtivoCampos(Set<AtivoCampo> ativoCampos) {
		this.ativoCampos = ativoCampos;
	}

	public AtivoCampo addAtivoCampo(AtivoCampo ativoCampo) {
		getAtivoCampos().add(ativoCampo);
		ativoCampo.setCampoTipoAtivo(this);

		return ativoCampo;
	}

	public AtivoCampo removeAtivoCampo(AtivoCampo ativoCampo) {
		getAtivoCampos().remove(ativoCampo);
		ativoCampo.setCampoTipoAtivo(null);

		return ativoCampo;
	}

	@Override
	public boolean isTheSameObject(IEntity<CampoTipoAtivoPK> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		CampoTipoAtivo other = (CampoTipoAtivo) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof CampoTipoAtivo))
			return false;
		CampoTipoAtivo other = (CampoTipoAtivo) obj;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
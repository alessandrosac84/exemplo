import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { UserProject } from '../model/entity/userproject.model';

@Injectable({
  providedIn: 'root'
})
export class UserProjectService {

  constructor(private http: HttpClient) {}

  getUserProjects(): Observable<UserProject[]> {
    return this.http.get<UserProject[]>('../../../assets/file/user-projects.json');
  }
}

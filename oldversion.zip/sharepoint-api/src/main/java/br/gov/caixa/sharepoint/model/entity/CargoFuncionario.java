package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the cargo_funcionario database table.
 * 
 */
@Entity
@Table(name="cargo_funcionario")
@NamedQueries({
	@NamedQuery(name="CargoFuncionario.findAll", query="SELECT c FROM CargoFuncionario c"),
	@NamedQuery(name="CargoFuncionario.findByDescricao", query="SELECT c FROM CargoFuncionario c WHERE c.descricao = :descricao"),
	@NamedQuery(name="CargoFuncionario.findByAKs", query="SELECT c FROM CargoFuncionario c WHERE c.id <> :id AND c.descricao = :descricao")
})
public class CargoFuncionario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(nullable=false, length=50)
	private String descricao;

	@JsonIgnore
	//bi-directional many-to-one association to Funcionario
	@OneToMany(mappedBy="cargoFuncionario")
	private Set<Funcionario> funcionarios;
	
	@JsonIgnore
	//bi-directional many-to-one association to FuncionalidadeCargo
	@OneToMany(mappedBy="cargoFuncionario")
	private Set<FuncionalidadeCargo> funcionalidadeCargos;

	public CargoFuncionario() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescricao() {
		return this.descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Set<Funcionario> getFuncionarios() {
		return this.funcionarios;
	}

	public void setFuncionarios(Set<Funcionario> funcionarios) {
		this.funcionarios = funcionarios;
	}

	public Funcionario addFuncionario(Funcionario funcionario) {
		getFuncionarios().add(funcionario);
		funcionario.setCargoFuncionario(this);

		return funcionario;
	}

	public Funcionario removeFuncionario(Funcionario funcionario) {
		getFuncionarios().remove(funcionario);
		funcionario.setCargoFuncionario(null);

		return funcionario;
	}
	
	public Set<FuncionalidadeCargo> getFuncionalidadeCargos() {
		return this.funcionalidadeCargos;
	}

	public void setFuncionalidadeCargos(Set<FuncionalidadeCargo> funcionalidadeCargos) {
		this.funcionalidadeCargos = funcionalidadeCargos;
	}

	public FuncionalidadeCargo addFuncionalidadeCargo(FuncionalidadeCargo funcionalidadeCargo) {
		getFuncionalidadeCargos().add(funcionalidadeCargo);
		funcionalidadeCargo.setCargoFuncionario(this);

		return funcionalidadeCargo;
	}

	public FuncionalidadeCargo removeFuncionalidadeCargo(FuncionalidadeCargo funcionalidadeCargo) {
		getFuncionalidadeCargos().remove(funcionalidadeCargo);
		funcionalidadeCargo.setCargoFuncionario(null);

		return funcionalidadeCargo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CargoFuncionario other = (CargoFuncionario) obj;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
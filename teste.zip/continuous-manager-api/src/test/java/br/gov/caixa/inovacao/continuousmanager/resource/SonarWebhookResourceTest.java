package br.gov.caixa.inovacao.continuousmanager.resource;

import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.PayloadNotificationJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.service.integration.SonarWebhookService;

/**
 * Classe de testes do WalletResource.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class SonarWebhookResourceTest {

	@Mock
	private SonarWebhookService sonarWebhookService;

	@InjectMocks
	private SonarWebhookResource sonarWebhookResource;

	@Before
	public void before() {
		UtilReflection.setField(sonarWebhookResource, "log", Logger.getLogger(SonarWebhookResource.class.getName()));
	}
	
	/**
	 * Listar todas as Wallets.
	 * @throws InterruptedException 
	 */
	@Test
	public void testListAllWalletsDefault() throws InterruptedException {
		PayloadNotificationJenkinsVO payload = new PayloadNotificationJenkinsVO();
		
		// Act
		sonarWebhookResource.createJob(payload);
	}
}

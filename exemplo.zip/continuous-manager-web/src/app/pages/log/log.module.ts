/* Angular Imports */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

/* App Imports */
import { LogComponent } from './log.component';

/* Routing Module */
import { LogRoutingModule } from './log-routing.module';
import { JenkinsComponent } from './jenkins/jenkins.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    LogRoutingModule
  ],
  declarations: [
    LogComponent,
    JenkinsComponent
  ]
})
export class LogModule { }

package br.gov.caixa.api.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.gov.caixa.api.dto.QuestionanteDto;

@Entity
@Table(name = "questionante")
public class Questionante {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@ManyToOne
	@JoinColumn(name = "FUNCIONARIO_ID")
	private Funcionario funcionario;
	
	@ManyToOne
	@JoinColumn(name = "QUESTIONARIO_ID")
	private Questionario questionario;

	@Column(name = "PARTICIPACAO", columnDefinition = "boolean default false")
	private boolean participacao;

	@Column(length = 1, nullable = true)
	private String Option1;
	
	@Column(length = 1, nullable = true)
	private String Option2;
	
	@Column(length = 1, nullable = true)
	private String Option3;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public boolean isParticipacao() {
		return participacao;
	}

	public void setParticipacao(boolean participacao) {
		this.participacao = participacao;
	}
	
	public Questionario getQuestionario() {
		return questionario;
	}

	public void setQuestionario(Questionario questionario) {
		this.questionario = questionario;
	}
	
	public String getOption1() {
		return Option1;
	}

	public void setOption1(String option1) {
		Option1 = option1;
	}

	public String getOption2() {
		return Option2;
	}

	public void setOption2(String option2) {
		Option2 = option2;
	}

	public String getOption3() {
		return Option3;
	}

	public void setOption3(String option3) {
		Option3 = option3;
	}

	
	public static Questionante fromDtoToQuestionante(QuestionanteDto dto) {
		Questionante questionante = new Questionante();
		questionante.setUid(dto.getUid());
		questionante.setFuncionario(Funcionario.fromDtoToFuncionario(dto.getFuncionario()));
		questionante.setParticipacao(dto.isParticipacao());
		questionante.setQuestionario(Questionario.fromDtoToQuestionario(dto.getQuestionario()));
		questionante.setOption1(dto.getOption1());
		questionante.setOption2(dto.getOption2());
		questionante.setOption3(dto.getOption3());
		
		return questionante;
	}

	public static List<Questionante> fromDtoToListQuestionante(List<QuestionanteDto> questionantes) {
		List<Questionante> result = new ArrayList<Questionante>();
		
		for (QuestionanteDto dto : questionantes) {
			result.add(fromDtoToQuestionante(dto));
		}
		
		return result;
	}
}

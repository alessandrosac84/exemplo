
export class Parameter {
  id: string;
  valor: string;
}

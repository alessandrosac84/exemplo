import { LastBuiltRevisionJenkins } from './last-built-revision-jenkins.model';

export class Action {
  public lastBuiltRevision: LastBuiltRevisionJenkins;
}

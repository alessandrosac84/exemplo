package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the virtual_ip database table.
 * 
 */
@Entity
@Table(name="virtual_ip")
@NamedQuery(name="VirtualIp.findAll", query="SELECT v FROM VirtualIp v")
public class VirtualIp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private VirtualIpPK id;

	@Column(nullable=false, length=50)
	private String dns;

	//bi-directional many-to-one association to Server
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="server", nullable=false, insertable=false, updatable=false)
	private Server server;

	public VirtualIp() {
		/* class constructor intentionally left blank */
	}

	public VirtualIpPK getId() {
		return this.id;
	}

	public void setId(VirtualIpPK id) {
		this.id = id;
	}

	public String getDns() {
		return this.dns;
	}

	public void setDns(String dns) {
		this.dns = dns;
	}

	public Server getServer() {
		return this.server;
	}

	public void setServer(Server server) {
		this.server = server;
	}

}
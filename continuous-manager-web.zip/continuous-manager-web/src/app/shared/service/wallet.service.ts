import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';

import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { Wallet } from '../model/entity/wallet.model';
import { Project } from '../model/entity/project.model';
import { Job } from '../model/entity/job.model';
import { Build } from '../model/entity/build.model';
import { Stage } from '../model/vo/stage.model';

@Injectable({
  providedIn: 'root'
})
export class WalletService {
  // private walletUrl = `${environment.apis.continuous}/api/wallets`;
  // private projectsUrl = '/projects';
  // private jobUrl = '/jobs';
  // private buildUrl = '/builds';
  // private logUrl = '/log';
  // private logStagesUrl = '/log/stages';
  private limit = 10;

  constructor(private http: HttpClient) {}

  getProjects(): Observable<Project[]> {
    // return this.http.get<Project[]>(`${this.walletUrl}${this.projectsUrl}`);
    return this.http.get<Project[]>('../../../assets/file/project.json');
  }

  getBuilds(projectName: string, page: number): Observable<Build[]> {
    // const p = (page - 1) * this.limit;
    // return this.http.get<Build[]>(
    //   `${environment.apis.continuous}/projects/` +
    //     `${projectName}/builds?order=DESC&limit=${this.limit}&offset=${p}`
    // );
    return this.http.get<Build[]>('../../../assets/file/build.json');
  }

  // getWallets(): Observable<Wallet[]> {
  //   return this.http.get<Wallet[]>(`${this.walletUrl}`);
  // }

  // getWallet(walletName: string): Observable<Wallet> {
  //   return this.http.get<Wallet>(`${this.walletUrl}/${walletName}`);
  // }

  // getProjectsByWallet(walletName: string): Observable<Project[]> {
  //   return this.http.get<Project[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}`);
  // }

  // getProject(walletName: string, projectName: string): Observable<Project> {
  //   return this.http.get<Project>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}`);
  // }

  // getJobs(walletName: string, projectName: string): Observable<Job[]> {
  //   return this.http.get<Job[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}`);
  // }

  // getJob(walletName: string, projectName: string, jobName: string): Observable<Job> {
  //   return this.http.get<Job>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}/${jobName}`);
  // }

  // geDetailtBuild(walletName: string, projectName: string, jobName: string, build: number): Observable<any> {
  //   return this.http.get(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}/${jobName}` +
  //     `${this.buildUrl}/${build}`);
  // }

  // getLog(walletName: string, projectName: string, jobName: string, build: number): Observable<any> {
  //   return this.http.get(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}` +
  //     `${this.jobUrl}/${jobName}${this.buildUrl}/${build}${this.logUrl}`,
  //     { responseType: 'text' });
  // }

  // getLogStages(walletName: string, projectName: string, jobName: string, build: number): Observable<Stage[]> {
  //   return this.http.get<Stage[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}` +
  //     `${this.jobUrl}/${jobName}${this.buildUrl}/${build}${this.logStagesUrl}`);
  // }
}

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Fetch;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Build_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes de BuildRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BuildRepositoryTest {
	
	@Mock
	private EntityManager em;
	
	@Mock
	private CriteriaBuilder builder;
	
	@Mock
	private CriteriaQuery<Build> query;
	
	@Mock
	private CriteriaQuery<Long> queryCount;
	
	@Mock
	private Root<Build> from;
	
	@Mock
	private Expression<Long> expressionCount;
	
	@Mock
	private TypedQuery<Build> typedQuery;
	
	@Mock
	private TypedQuery<Long> typedQueryCount;
	
	@Mock
	private Path<BuildPK> path;

	@InjectMocks
	private BuildRepository buildRepository;

	@Mock
	private Fetch<Build, ChangeSet> fetchQuery;

	@Mock
	private Fetch<ChangeSet, Commit> fetchQuery2;
	
	private List<Build> builds;

	@Before
	public void before() {
		builds = EntityBuilder.createBuilds();
	}

	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Build>>any())).thenReturn(typedQuery);
		
		Mockito.when(builder.createQuery(Build.class)).thenReturn(query);
		
		Mockito.when(query.from(Build.class)).thenReturn(from);
		Mockito.when(from.get(Build_.id)).thenReturn(path);
		Mockito.when(query.select(from)).thenReturn(query);
		Mockito.when(from.fetch(Build_.changeSets, JoinType.LEFT)).thenReturn(fetchQuery);
		Mockito.when(fetchQuery.fetch(ChangeSet_.commit, JoinType.LEFT)).thenReturn(fetchQuery2);
		Mockito.when(query.where(Mockito.<Expression<Boolean>>any())).thenReturn(query);
		Mockito.when(typedQuery.getSingleResult()).thenReturn(builds.get(0));
		
		// Act
		Build retorno = buildRepository.findById(builds.get(0).getId());
		
		// Then
		Assert.assertNotNull(retorno.getId());
	}

	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Build>>any())).thenReturn(typedQuery);
		
		Mockito.when(builder.createQuery(Build.class)).thenReturn(query);
		
		Mockito.when(query.from(Build.class)).thenReturn(from);
		Mockito.when(from.get(Build_.id)).thenReturn(path);
		Mockito.when(query.select(from)).thenReturn(query);
		Mockito.when(query.distinct(true)).thenReturn(query);
		Mockito.when(from.fetch(Build_.changeSets, JoinType.LEFT)).thenReturn(fetchQuery);
		Mockito.when(fetchQuery.fetch(ChangeSet_.commit, JoinType.LEFT)).thenReturn(fetchQuery2);
		
		Mockito.when(query.where(Mockito.<Expression<Boolean>>any())).thenReturn(query);
		
		Mockito.when(typedQuery.setFirstResult(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setMaxResults(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(builds);
		
		// Act
		List<Build> retorno = buildRepository.findAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 0, 30, "", "id", AscDesc.ASC);
		
		// Then
		Assert.assertEquals(2, retorno.size());
	}

	@Test
	public void testFindAllDesc() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Build>>any())).thenReturn(typedQuery);
		
		Mockito.when(builder.createQuery(Build.class)).thenReturn(query);
		
		
		
		Mockito.when(query.from(Build.class)).thenReturn(from);
		Mockito.when(from.get(Build_.id)).thenReturn(path);
		Mockito.when(query.select(from)).thenReturn(query);
		Mockito.when(query.where(Mockito.<Expression<Boolean>>any())).thenReturn(query);
		Mockito.when(query.distinct(true)).thenReturn(query);
		Mockito.when(from.fetch(Build_.changeSets, JoinType.LEFT)).thenReturn(fetchQuery);
		Mockito.when(fetchQuery.fetch(ChangeSet_.commit, JoinType.LEFT)).thenReturn(fetchQuery2);
		
		Mockito.when(typedQuery.setFirstResult(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setMaxResults(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(builds);
		
		// Act
		List<Build> retorno = buildRepository.findAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 0, 30, "", "id", AscDesc.DESC);
		
		// Then
		Assert.assertEquals(2, retorno.size());
	}

	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Long>>any())).thenReturn(typedQueryCount);
		
		Mockito.when(builder.createQuery(Long.class)).thenReturn(queryCount);
		Mockito.when(builder.count(from)).thenReturn(expressionCount);
		
		Mockito.when(queryCount.from(Build.class)).thenReturn(from);
		Mockito.when(from.get(Build_.id)).thenReturn(path);
		Mockito.when(queryCount.select(expressionCount)).thenReturn(queryCount);
		Mockito.when(queryCount.where(Mockito.<Expression<Boolean>>any())).thenReturn(queryCount);
		
		Mockito.when(typedQueryCount.getSingleResult()).thenReturn((long) builds.size());
		
		// Act
		Long retorno = buildRepository.countAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", "");
		
		// Then
		Assert.assertEquals(2, retorno.longValue());
	}
	
	@Test
	public void testSave() {
		// Act
		Build save = buildRepository.save(builds.get(0));
		// Then
		Assert.assertEquals(builds.get(0).getId(), save.getId());
	}

}

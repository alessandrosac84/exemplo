package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.Questionante;


public class QuestionanteDto {

	private Long uid;
	private FuncionarioDto funcionario;
	private QuestionarioDto questionario;	
	private boolean participacao;
	private String Option1;
	private String Option2;	
	private String Option3;

	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public FuncionarioDto getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(FuncionarioDto funcionario) {
		this.funcionario = funcionario;
	}
		
	public boolean isParticipacao() {
		return participacao;
	}

	public void setParticipacao(boolean participacao) {
		this.participacao = participacao;
	}
		
	public QuestionarioDto getQuestionario() {
		return questionario;
	}

	public void setQuestionario(QuestionarioDto questionario) {
		this.questionario = questionario;
	}
	
	public String getOption1() {
		return Option1;
	}

	public void setOption1(String option1) {
		Option1 = option1;
	}

	public String getOption2() {
		return Option2;
	}

	public void setOption2(String option2) {
		Option2 = option2;
	}

	public String getOption3() {
		return Option3;
	}

	public void setOption3(String option3) {
		Option3 = option3;
	}
	
	public static QuestionanteDto fromQuestionanteToDto(Questionante questionante) {
		QuestionanteDto dto = new QuestionanteDto();
		dto.setUid(questionante.getUid());
		dto.setParticipacao(questionante.isParticipacao());
		dto.setFuncionario(FuncionarioDto.fromFuncionarioToDto(questionante.getFuncionario()));
		dto.setQuestionario(QuestionarioDto.fromQuestionarioToDto(questionante.getQuestionario()));
		dto.setOption1(questionante.getOption1());
		dto.setOption2(questionante.getOption2());
		dto.setOption3(questionante.getOption3());
		
		return dto;
	}

	public static List<QuestionanteDto> fromQuestionanteToListDto(List<Questionante> questionantes) {		
		List<QuestionanteDto> result = new ArrayList<QuestionanteDto>();		
		for (Questionante questionante : questionantes) {						
			result.add(fromQuestionanteToDto(questionante));
		}
		return result;
	}
}

import { DevComponent } from './dev.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { DevRoutingModule } from './dev-routing.module';

@NgModule({
  imports: [
    CommonModule,
    DevRoutingModule,
    FormsModule,
    NgbModule.forRoot()
  ],
  declarations: [
    DevComponent
  ]
})
export class DevModule { }

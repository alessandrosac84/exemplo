///**
// * 
// */
//package br.gov.caixa.inovacao.continuousmanager.service.impl;
//
//import java.util.List;
//import java.util.logging.Logger;
//
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.junit.MockitoJUnitRunner;
//
//import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
//import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsBuilder;
//import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.SistemaJenkinsVO;
//import br.gov.caixa.inovacao.continuousmanager.service.JenkinsService;
//import br.gov.caixa.inovacao.continuousmanager.service.WalletService;
//
///**
// * Classe de testes do WalletService.
// * 
// * @author Fabio Iwakoshi
// *
// */
//@RunWith(MockitoJUnitRunner.class)
//public class SistemaServiceTest {
//
//	@Mock
//	private JenkinsService jenkinsService;
//
//	@InjectMocks
//	private WalletService walletService;
//
//	private List<SistemaJenkinsVO> folders;
//
//	@Before
//	public void before() {
//		folders = JenkinsBuilder.createSistemas();
//		UtilReflection.setField(walletService, "log", Logger.getLogger(WalletService.class.getName()));
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.WalletService#findAll(int, int, java.lang.String, java.lang.String)}.
//	 */
//	@Test
//	public void testFindAll() {
//		// Arrange
//		Mockito.when(jenkinsService.listSistemas()).thenReturn(folders);
//
//		// Act
//		List<SistemaJenkinsVO> folderList = walletService.findAll(0, 0, "", "");
//
//		// Then
//		Assert.assertEquals(2, folderList.size());
//		Assert.assertNotNull(folderList.get(0).getDescription());
//		Assert.assertNotNull(folderList.get(0).getDisplayName());
//		Assert.assertNotNull(folderList.get(0).getFullName());
//		Assert.assertNotNull(folderList.get(0).getJobs());
//		Assert.assertNotNull(folderList.get(0).getName());
//
//		Assert.assertNotNull(folderList.get(0).getHealthReport().get(0).getDescription());
//		Assert.assertNotNull(folderList.get(0).getHealthReport().get(0).getIconUrl());
//		Assert.assertNotNull(folderList.get(0).getHealthReport().get(0).getScore());
//
//		Assert.assertNotNull(folderList.get(0).getJobs().get(0).getColor());
//		Assert.assertNotNull(folderList.get(0).getJobs().get(0).getFullName());
//		Assert.assertNotNull(folderList.get(0).getJobs().get(0).getName());
//		Assert.assertNotNull(folderList.get(0).getJobs().get(0).getBuildable());
//		Assert.assertNotNull(folderList.get(0).getJobs().get(0).getHealthReport());
//
//		Assert.assertNull(folderList.get(0).getJobs().get(0).getBuilds().get(0).getDescription());
//		Assert.assertNotNull(folderList.get(0).getJobs().get(0).getBuilds().get(0).getResult());
//		Assert.assertNotNull(folderList.get(0).getJobs().get(0).getBuilds().get(0).getDuration());
//		Assert.assertNotNull(folderList.get(0).getJobs().get(0).getBuilds().get(0).getEstimatedDuration());
//		Assert.assertNotNull(folderList.get(0).getJobs().get(0).getBuilds().get(0).getNumber());
//		Assert.assertNotNull(folderList.get(0).getJobs().get(0).getBuilds().get(0).getTimestamp());
//		
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.WalletService#countAll(java.lang.String)}.
//	 */
//	@Test
//	public void testCountAll() {
//		// Arrange
//		Mockito.when(jenkinsService.countAllSistemas()).thenReturn((long)folders.size());
//
//		// Act
//		long count = walletService.countAll("");
//
//		// Then
//		Assert.assertEquals(2, count);
//	}
//
//}

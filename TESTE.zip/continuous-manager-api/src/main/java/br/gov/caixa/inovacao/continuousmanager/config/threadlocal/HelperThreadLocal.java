package br.gov.caixa.inovacao.continuousmanager.config.threadlocal;

import java.util.List;

/**
 * @author Fabio Iwakoshi
 *
 */
public class HelperThreadLocal {
	
	private HelperThreadLocal() {}

	public static final ThreadLocal<String> IP = new ThreadLocal<>();
	public static final ThreadLocal<String> USER = new ThreadLocal<>();
	public static final ThreadLocal<List<Integer>> ATIVOS = new ThreadLocal<>();
	public static final ThreadLocal<Boolean> ADMIN = new ThreadLocal<>();
}

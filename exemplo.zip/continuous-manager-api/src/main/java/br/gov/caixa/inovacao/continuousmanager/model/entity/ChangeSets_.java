package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-01-30T16:53:57.794-0200")
@StaticMetamodel(ChangeSets.class)
public class ChangeSets_ {
	public static volatile SingularAttribute<ChangeSets, ChangeSetsPK> id;
	public static volatile SingularAttribute<ChangeSets, Build> builds;
	public static volatile SingularAttribute<ChangeSets, GitRepo> gitRepos;
}

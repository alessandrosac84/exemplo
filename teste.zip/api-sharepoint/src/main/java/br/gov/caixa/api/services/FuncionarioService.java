package br.gov.caixa.api.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.FuncionarioDto;
import br.gov.caixa.api.model.Coordenacao;
import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.StatusFuncionario;
import br.gov.caixa.api.model.views.FuncionarioCoordenacaoView;
import br.gov.caixa.api.repository.CoordenacaoRepository;
import br.gov.caixa.api.repository.FuncionarioRepository;
import br.gov.caixa.api.repository.views.FuncionarioCoordenacaoViewRepository;
import br.gov.caixa.api.result.FuncionarioResult;
import br.gov.caixa.api.result.views.FuncionarioCoordenacaoViewResult;

@Named
public class FuncionarioService {
	
	@Inject
	private FuncionarioRepository repository;
	
	@Inject
	private FuncionarioCoordenacaoViewRepository funcionarioCoordenacaoViewRepository;
		
	@Inject
	private CoordenacaoRepository coordenacaoRepository;
		
//	public FuncionarioResult listAllEx() {
//		List<Funcionario> lista = (repository.findAll());
//		FuncionarioResult result = new FuncionarioResult();
//		
//		result.setList(FuncionarioDto.fromFuncionarioToListDto(lista));
//		result.setMessage("Executado com sucesso.");
//		
//		return result;
//	}
	
	public FuncionarioCoordenacaoViewResult listAllEx() {
		
		FuncionarioCoordenacaoViewResult result = new FuncionarioCoordenacaoViewResult();
		
		List<FuncionarioCoordenacaoView> lista = funcionarioCoordenacaoViewRepository.findAll();
				
		result.setList(lista);
		result.setMessage("Executado com sucesso.");
				
		return result;
	}
	
	public FuncionarioResult listAll() {
		List<Funcionario> lista = (repository.findAll(StatusFuncionario.ATIVO));
		FuncionarioResult result = new FuncionarioResult();
		
		result.setList(FuncionarioDto.fromFuncionarioToListDto(lista));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}
	
	public FuncionarioResult listOne(Long uid) {
		Funcionario funcionario = (repository.findByUid(uid));
		FuncionarioResult result = new FuncionarioResult();
		
		result.setFuncionario(FuncionarioDto.fromFuncionarioToDto(funcionario));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}
	
	public Funcionario listOneByMatricula(String matricula) {
		return repository.findByMatricula(matricula);
	}
	
	public FuncionarioResult listFuncionariosPorCoordenacao(Long coordenacaoUid) {
		
		Coordenacao coordenacao = new Coordenacao();
		coordenacao.setUid(coordenacaoUid);
		
		List<Funcionario> lista = repository.findByCoordenacao(coordenacao);
		
		FuncionarioResult result = new FuncionarioResult();
		
		result.setList(FuncionarioDto.fromFuncionarioToListDto(lista));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}

	public FuncionarioResult listFuncionarioPorMatricula(String matricula) {
		Funcionario funcionario = repository.findByMatricula(matricula);		
		
		FuncionarioResult result;
		
		if (funcionario != null) {
			
			FuncionarioDto dto = FuncionarioDto.fromFuncionarioToDto(funcionario);
			
			result = new FuncionarioResult();		
			result.setFuncionario(dto);
			result.setMessage("Executado com sucesso.");
		}
		else {
			result = new FuncionarioResult();
			result.setMessage("Funcion�rio n�o Existe.");
		}		
		
		return result;
	}
	
	public FuncionarioResult salvar(FuncionarioDto dto) {
		
		Funcionario funcionario = repository.findByMatricula(dto.getMatricula());
		
		FuncionarioResult result;
		
		if (funcionario == null) {			
		
			funcionario = Funcionario.fromDtoToFuncionario(dto);
			
			if(dto.getStatusFuncionario() == null || dto.getStatusFuncionario() != StatusFuncionario.VISITANTE )
				funcionario.setStatusFuncionario(StatusFuncionario.ATIVO);
			else {
				funcionario.setStatusFuncionario(dto.getStatusFuncionario());
				funcionario.setTipoFuncionario(dto.getTipoFuncionario());
			}
			
			funcionario = repository.save(funcionario);
			dto.setUid(funcionario.getUid());
			
			result = new FuncionarioResult();		
			result.setFuncionario(dto);
			
			result.setMessage("Executado com sucesso.");
		}
		else
		{
			dto.setUid(funcionario.getUid());
						
			repository.setTipoFuncionario(dto.getTipoFuncionario(), dto.getUid());
			
			result = new FuncionarioResult();	
			result.setFuncionario(dto);			
			result.setMessage("Funcion�rio J� Existe.");
		}
		
		return result;
	}
	
//	public void atualizar(String nome, String cargo, String depto, String email, String fone, String celular, String empresa, 
//			String logradouro, String cidade, String uf, String cep, 
//			Long uid) {
//		
//		repository.updateFuncionario(nome, cargo, depto, email, fone, celular, empresa, logradouro, cidade, uf, cep, uid);
//		
//	}
	
	public FuncionarioResult excluiFuncionarioParaCoordenacao(FuncionarioDto dto) {
		
		FuncionarioResult result = new FuncionarioResult();	
		dto.setCoordenacaoDto(null);
		repository.save(Funcionario.fromDtoToFuncionario(dto));
		
		result.setFuncionario(dto);
		result.setMessage("Executado com sucesso.");
		
		return result;
	}
	
	public FuncionarioResult setaFuncionarioParaCoordenacao(Long funcioanarioId, Long coordenacaoId) {
		
		Funcionario funcionario = repository.findOne(funcioanarioId);		
		FuncionarioResult result = new FuncionarioResult();
		
		if (funcionario == null) {			
			result.setIsError(true);
			result.setMessage("N�o Existe.");
		}
		else
		{
			result = new FuncionarioResult();
			
			if(funcionario.getCoordenacao() == null)
			{	
				Coordenacao coordenacao = new Coordenacao();
				coordenacao = coordenacaoRepository.findByUid(coordenacaoId);
				
				funcionario.setCoordenacao(coordenacao);				
				repository.save(funcionario);								
				
				result.setMessage("Executado com sucesso.");
			}			
			else if(coordenacaoId == funcionario.getCoordenacao().getUid() )
			{			
				result.setIsError(true);
				result.setMessage("Ja Existe.");
			}
			else if(funcionario.getCoordenacao().getUid() != null )
			{	
				result.setIsError(true);
				result.setMessage(funcionario.getCoordenacao().getNome());
			}
		}
		
		return result;
	}

	
	public FuncionarioResult setaFuncionarioParaCoordenacao(FuncionarioDto dto) {
		
		Funcionario funcionario = repository.findByMatricula(dto.getMatricula());		
		FuncionarioResult result;
		
		if (funcionario == null) {			
		
			funcionario = Funcionario.fromDtoToFuncionario(dto);
			
			funcionario = repository.save(funcionario);
			dto.setUid(funcionario.getUid());
			
			result = new FuncionarioResult();		
			result.setFuncionario(dto);
			result.setMessage("Executado com sucesso.");
		}
		else
		{
			result = new FuncionarioResult();
			
			if(funcionario.getCoordenacao() == null)
			{	
				Coordenacao coordenacao = new Coordenacao();
				coordenacao = coordenacaoRepository.findByUid(dto.getCoordenacaoDto().getUid());
				
				funcionario.setCoordenacao(coordenacao);				
				repository.save(funcionario);
												
				dto = FuncionarioDto.fromFuncionarioToDto(funcionario);
				
				result.setFuncionario(dto);
				result.setMessage("Executado com sucesso.");
			}			
			else if(dto.getCoordenacaoDto().getUid() == funcionario.getCoordenacao().getUid() )
			{			
				result.setIsError(true);
				result.setMessage("Ja Existe.");
			}
			else if(funcionario.getCoordenacao().getUid() != null )
			{	
				result.setIsError(true);
				result.setMessage(funcionario.getCoordenacao().getNome());
			}
		}
		
		return result;
	}

	
	public FuncionarioResult deletar(Long funcionarioUid) {		
	
		FuncionarioResult result = new FuncionarioResult();
		try {			
			
			repository.delete(funcionarioUid);			
			result.setMessage("Funcion�rio Exclu�do.");
			
		} catch (Exception e) {
			e.printStackTrace();			
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}		
		
		return result; 

	}

	public FuncionarioResult obterFuncionariosPorNome(String nome) {
		FuncionarioResult result = new FuncionarioResult();
		
		List<String> nomes = new ArrayList<String>();
		nomes.add("Joao");
		nomes.add("Mota");		
		
		try {
			List<Funcionario> funcionarios = repository.findByNomeContainingIgnoreCase(nome);			
			
			if (funcionarios != null) {
				result.setList(FuncionarioDto.fromFuncionarioToListDto(funcionarios));
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhum Funcionario Encontrado.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}

	public void atualizar(List<Funcionario> funcionarios) {

		repository.save(funcionarios);
		
	}
	
	public void atualizar(Funcionario funcionario) {

		repository.save(funcionario);
		
	}

	public FuncionarioResult setStatus(Long funcionarioId, StatusFuncionario status, Date date, String detail) {
		FuncionarioResult result = new FuncionarioResult();
				
		try {						
			repository.setStatusFuncionario(status, funcionarioId, date, detail);			
			result.setMessage("Status Modificado.");
			
		} catch (Exception e) {
			e.printStackTrace();			
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}		
		
		return result;
	}
}

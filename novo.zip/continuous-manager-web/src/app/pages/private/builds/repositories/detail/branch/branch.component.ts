import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  trigger,
  transition,
  query,
  animate,
  stagger,
  style
} from '@angular/animations';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Branch } from '../../../../../../shared/model/entity/branch.model';
import { ProjectService } from '../../../../../../shared/service/project.service';

@Component({
  selector: 'cm-branch',
  templateUrl: './branch.component.html',
  styles: [],
  animations: [
    trigger('listStagger', [
      transition('* => *', [
        // each time the binding value changes
        query(
          ':enter',
          [
            style({ opacity: 0 }),
            stagger(200, [animate('0.5s', style({ opacity: 1 }))])
          ],
          { optional: true }
        ),
        query(
          ':leave',
          [stagger(200, [animate('0.5s', style({ opacity: 0 }))])],
          { optional: true }
        )
      ])
    ])
  ]
})
export class BranchComponent implements OnInit {

  @Output() branch = new EventEmitter();

  branches$: Observable<Branch[]>;
  branchesLength: number;
  repository: string;

  constructor(
    private route: ActivatedRoute,
    private _projectService: ProjectService
  ) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.repository = params['repository'];
      this.branches$ = this._projectService
        .getBranches(+localStorage.getItem('project'), this.repository)
        .pipe(
          map(data => {
            this.branchesLength = data.length;
            return data;
          })
        );
    });
  }

  emitBranch(branch: Branch) {
    this.branch.emit(branch);
  }
}

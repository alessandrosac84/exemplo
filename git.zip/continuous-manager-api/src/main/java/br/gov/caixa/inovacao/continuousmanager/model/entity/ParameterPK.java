package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import javax.persistence.*;

import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;

/**
 * The primary key class for the parameter database table.
 * 
 * @author Fabio Iwakoshi
 */
@Embeddable
public class ParameterPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Enumerated(EnumType.STRING)
	@Column(unique=true, nullable=false, length=3)
	private Environment environment;

	@Enumerated(EnumType.STRING)
	@Column(name="server_type", unique=true, nullable=false, length=7)
	private ServerType serverType;

	public ParameterPK() {
		/* class constructor intentionally left blank */
	}
	public Environment getEnvironment() {
		return this.environment;
	}
	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}
	public ServerType getServerType() {
		return this.serverType;
	}
	public void setServerType(ServerType serverType) {
		this.serverType = serverType;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ParameterPK)) {
			return false;
		}
		ParameterPK castOther = (ParameterPK)other;
		return 
			this.environment.equals(castOther.environment)
			&& this.serverType.equals(castOther.serverType);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.environment.hashCode();
		hash = hash * prime + this.serverType.hashCode();
		
		return hash;
	}
}
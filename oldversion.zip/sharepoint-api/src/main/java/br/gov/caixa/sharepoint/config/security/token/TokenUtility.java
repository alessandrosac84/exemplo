package br.gov.caixa.sharepoint.config.security.token;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.lang.JoseException;

import br.gov.caixa.sharepoint.config.security.subject.Principal;

public class TokenUtility {

	private static Logger logger = Logger.getLogger(TokenUtility.class.getName());

	public static String buildJWT(Principal principal) throws JoseException {
		JwtClaims claims = new JwtClaims();
		claims.setExpirationTimeMinutesInTheFuture(1440);
		claims.setGeneratedJwtId();
		claims.setIssuedAtToNow();
		claims.setSubject(principal.getUsername());
		claims.setStringClaim("cargo", principal.getCargo());
		claims.setStringListClaim("coordenacao",
				principal.getCoordenacao().stream().map(coordenacao -> coordenacao.toString()).collect(Collectors.toList()));

		JsonWebSignature jws = new JsonWebSignature();
		jws.setPayload(claims.toJson());
		jws.setKey(RsaKeyProducer.produce().getPrivateKey());
		jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);

		String jwt = null;
		try {
			jwt = jws.getCompactSerialization();
		} catch (JoseException ex) {
			logger.log(Level.SEVERE, null, ex);
		}

		logger.log(Level.INFO, "Claim:\n" + claims);
		logger.log(Level.FINE, "JWS:\n" + jws);
		logger.log(Level.INFO, "JWT:\n" + jwt);

		return jwt;
	}
}

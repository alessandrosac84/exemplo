package br.gov.caixa.api.repository.views;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.gov.caixa.api.model.views.FuncionarioCoordenacoesView;

@Repository
public interface FuncionarioCoordenacoesViewRepository extends JpaRepository<FuncionarioCoordenacoesView, Long> {

}

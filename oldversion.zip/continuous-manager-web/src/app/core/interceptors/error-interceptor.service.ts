
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';

import { ToastrService } from 'ngx-toastr';

import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

    constructor(private _toastr: ToastrService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(req).pipe(tap(event => {}, error => {
            console.log(error.error);
            if (error instanceof HttpErrorResponse && error.status === 500) {
                this._toastr.error(error.error.messages[0], '');
            }
            if (error instanceof HttpErrorResponse && error.status > 500) {
                this._toastr.error(error.error.messages[0], '');
            }
            if (error instanceof HttpErrorResponse && error.status === 401) {
                this._toastr.error('Login ou senha inválido!', '');
            }
            if (error instanceof HttpErrorResponse && error.status === 403) {
                this._toastr.error('Sessão inválida e/ou sem autorização de acesso!', '');
                localStorage.removeItem('jwt');
            }
            if (error instanceof HttpErrorResponse && error.status === 400) {
              error.error.messages.forEach(message => {
                this._toastr.error(message, 'Inválido!');
              });
            }
        }));
    }
}

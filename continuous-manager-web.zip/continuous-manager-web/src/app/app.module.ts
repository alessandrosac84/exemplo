/* Angular Imports */
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';

/* App and Service Imports */
import { AppComponent } from './app.component';
import { KeycloakService } from './core/keycloak/keycloak.service';
import { keycloackInitializer } from './core/keycloak/keycloack-initializer';
import { EventStackService } from './core/keycloak/event-stack.service';

/* Core Modules */
import { CoreModule } from './core/core.module';

/* Routing Module */
import { AppRoutingModule } from './app-routing.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule.forRoot()
  ],
  providers: [
    KeycloakService,
    {
      provide: APP_INITIALIZER,
      useFactory: keycloackInitializer,
      multi: true,
      deps: [ KeycloakService, EventStackService ]
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

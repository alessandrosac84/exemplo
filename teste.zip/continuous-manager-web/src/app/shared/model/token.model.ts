export class Token {
    public exp: string;
    public jti: string;
    public iat: string;
    public sub: string;
    public email: string;
    public roles: string[];
}

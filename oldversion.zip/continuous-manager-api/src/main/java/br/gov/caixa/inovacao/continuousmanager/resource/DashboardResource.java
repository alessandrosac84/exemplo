package br.gov.caixa.inovacao.continuousmanager.resource;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.validation.constraints.Max;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.service.DashboardService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectEnvironmentService;
import br.gov.caixa.inovacao.continuousmanager.util.Util;

/**
 * Classe responsavel pelas consultas relacionadas a DashBoard do sistema.
 * 
 * Todas as chamadas a classe são interceptadas pela classe LoggerInterceptor
 * atraves da anotacao @Interceptors.
 * 
 * Como estamos trabalhando com Rest, utilizar sempre o escopo @RequestScoped
 * para nao sobrecarregar o servidor desnecessariamente.
 * 
 * @author Alessandro Carvalho
 *
 */
@Path("dashboards")
@RequestScoped
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class DashboardResource {

	@Inject
	private DashboardService dashboardService;
	
	@Inject
	private ProjectEnvironmentService projectEnvironmentService;

	@GET
	@Path("projects")
	@JsonView(ViewJson.SonarView.class)
	public Response getProjects(@QueryParam("offset") @DefaultValue(value = "0") int offset,
			@QueryParam("limit") @Max(value = 100) @DefaultValue(value = "100") int limit,
			@QueryParam("search") @DefaultValue(value = "") String search,
			@QueryParam("sort") @DefaultValue(value = "id") String sort,
			@QueryParam("order") @DefaultValue(value = "ASC") AscDesc order) {

		return Util.paginacao(dashboardService.countAll(search),
				dashboardService.findAll(offset, limit, search, sort, order), offset, limit);
	}

	@GET
	@JsonView(ViewJson.ResultVO.class)
	@Path("wallets/{carteira:[a-z\\-]+}/projects/{projeto:[a-z\\-]+}")
	public Response getProjectBuildsById(@PathParam("carteira") String carteira, @PathParam("projeto") String projeto) {
		return Response.ok(dashboardService.findBuildsById(carteira, projeto)).build();
	}
	
	@GET
	@JsonView(ViewJson.SonarView.class)
	@Path("wallets/{carteira:[a-z\\-]+}/projects/{projeto:[a-z\\-]+}/commit/{commit:[a-zA-Z_0-9\\-]+}")
	public Response getProjectDetailById(@PathParam("carteira") String carteira, @PathParam("projeto") String projeto, @PathParam("commit") String commit) {
		return Response.ok(dashboardService.findById(carteira, projeto, commit)).build();
	}
	
	@GET
	@JsonView(ViewJson.VersionProjectVO.class)
	@Path("wallets/{carteira:[a-z\\-]+}/projects/{projeto:[a-z\\-]+}/environments")
	public Response getVersions(@PathParam("carteira") String carteira, @PathParam("projeto") String projeto) {
		return Response.ok(projectEnvironmentService.findByEnviroment(carteira, projeto)).build();
	}
}

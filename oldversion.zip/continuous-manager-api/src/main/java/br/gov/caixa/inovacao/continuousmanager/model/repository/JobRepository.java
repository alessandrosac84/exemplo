package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Job;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JobPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JobPK_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Job_;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de acesso ao banco de dados da entidade Job.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class JobRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Metodo responsavel pela consulta paginada de Jobs no banco de dados
	 * 
	 * @param projeto
	 * @return Project
	 */
	public Job findById(JobPK id) {
		return entityManager.find(Job.class, id);
	}

	/**
	 * Lista Jobs por paginacao
	 * 
	 * @param offset
	 * @param limit
	 * @param search
	 * @param sort
	 * @param order
	 * @return Todos os Jobs por paginacao
	 */
	public List<Job> findAll(String carteira, String projeto, int offset, int limit, String search, String sort, AscDesc order) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Job> query = builder.createQuery(Job.class);
		Root<Job> from = query.from(Job.class);

		Predicate predicate = builder.like(builder.lower(from.get(Job_.id).get(JobPK_.id)), "%" + search.toLowerCase() + "%");
		predicate = builder.or(predicate, builder.like(builder.lower(from.get(Job_.name)), "%" + search.toLowerCase() + "%"));
		predicate = builder.and(predicate, builder.equal(from.get(Job_.id).get(JobPK_.wallet), carteira));
		predicate = builder.and(predicate, builder.equal(from.get(Job_.id).get(JobPK_.project), projeto));

		Order ascDesc = builder.asc(from.get(Job_.id).get(sort));
		if (order != AscDesc.ASC) {
			ascDesc = builder.desc(from.get(Job_.id).get(sort));
		}

		return entityManager.createQuery(query.select(from).where(predicate).orderBy(ascDesc)).setFirstResult(offset)
				.setMaxResults(limit).getResultList();
	}

	/**
	 * Obtem o total de projetos
	 * @param search 
	 * @return Total de projetos
	 */
	public Long countAll(String carteira, String projeto, String search) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);
		
		Root<Job> from = query.from(Job.class);

		Predicate predicate = builder.like(builder.lower(from.get(Job_.id).get(JobPK_.id)), "%" + search.toLowerCase() + "%");
		predicate = builder.or(predicate, builder.like(builder.lower(from.get(Job_.name)), "%" + search.toLowerCase() + "%"));
		predicate = builder.and(predicate, builder.equal(from.get(Job_.id).get(JobPK_.wallet), carteira));
		predicate = builder.and(predicate, builder.equal(from.get(Job_.id).get(JobPK_.project), projeto));

		return entityManager.createQuery(query.select(builder.count(from)).where(predicate)).getSingleResult();
	}

	/**
	 * Salva projeto
	 * 
	 * @param job
	 * @return project
	 */
	public Job save(Job job) {
		entityManager.persist(job);
		return job;
	}
}

import { NgModule } from '@angular/core';
import { BuildsRoutingModule } from './builds-routing.module';

import { BuildsComponent } from './builds.component';
import { RepositoryComponent } from './repositories/repositories.component';
import { DetailComponent } from './repositories/detail/detail.component';
import { BranchComponent } from './repositories/detail/branch/branch.component';
import { BuildComponent } from './repositories/detail/build/build.component';
import { BuildLogComponent } from './repositories/detail/build/build-log/build-log.component';
import { BuildListComponent } from './repositories/detail/build-list/build-list.component';
import { SharedModule } from '../../../shared/shared.module';

@NgModule({
  imports: [
    SharedModule,
    BuildsRoutingModule,
  ],
  declarations: [
    BuildsComponent,
    RepositoryComponent,
    BranchComponent,
    BuildComponent,
    BuildLogComponent,
    DetailComponent,
    BuildListComponent
  ]
})
export class BuildsModule { }

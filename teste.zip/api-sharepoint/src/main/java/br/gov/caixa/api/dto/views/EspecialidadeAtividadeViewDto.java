package br.gov.caixa.api.dto.views;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeAtividadeView;

public class EspecialidadeAtividadeViewDto {

	private Long uid;	
	private String atividade;
	private Long especialidadeId;
	private String especialidade;
	private Integer rating;
	private Long especialidadeAtividadeId;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public String getAtividade() {
		return atividade;
	}

	public void setAtividade(String atividade) {
		this.atividade = atividade;
	}

	public Long getEspecialidadeId() {
		return especialidadeId;
	}

	public void setEspecialidadeId(Long especialidadeId) {
		this.especialidadeId = especialidadeId;
	}

	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}


	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}
	
	public Long getEspecialidadeAtividadeId() {
		return especialidadeAtividadeId;
	}

	public void setEspecialidadeAtividadeId(Long especialidadeAtividadeId) {
		this.especialidadeAtividadeId = especialidadeAtividadeId;
	}

	public static EspecialidadeAtividadeViewDto fromEspecialidadeAtividadeViewToDto(EspecialidadeAtividadeView especialidadeAtividadeView) {
		EspecialidadeAtividadeViewDto dto = new EspecialidadeAtividadeViewDto();
		
		dto.setUid(especialidadeAtividadeView.getUid());
		dto.setAtividade(especialidadeAtividadeView.getAtividade());
		dto.setEspecialidade(especialidadeAtividadeView.getEspecialidade());
		dto.setEspecialidadeId(especialidadeAtividadeView.getEspecialidadeId());
		dto.setEspecialidadeAtividadeId(especialidadeAtividadeView.getEspecialidadeAtividadeId());
		dto.setRating(especialidadeAtividadeView.getRating());
		
		return dto;
	}
	
	public static List<EspecialidadeAtividadeViewDto> fromEspecialidadeAtividadeViewToListDto(List<EspecialidadeAtividadeView> especialidadeAtividadeViews) {
		List<EspecialidadeAtividadeViewDto> returnList = new ArrayList<EspecialidadeAtividadeViewDto>();
		
		for (EspecialidadeAtividadeView especialidadeAtividadeView : especialidadeAtividadeViews) {
			
			returnList.add(fromEspecialidadeAtividadeViewToDto(especialidadeAtividadeView) );
		}
		return returnList;
	}
}

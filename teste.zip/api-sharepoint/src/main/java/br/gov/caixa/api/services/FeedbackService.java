package br.gov.caixa.api.services;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.FeedbackDto;
import br.gov.caixa.api.model.Feedback;
import br.gov.caixa.api.repository.FeedbackRepository;
import br.gov.caixa.api.result.FeedbackResult;

@Named
public class FeedbackService {

	@Inject
	FeedbackRepository repository;
	
	public FeedbackResult save(FeedbackDto dto) {
		Feedback feedback = Feedback.froDtoToFeedback(dto);
		repository.save(feedback);
		FeedbackResult result = new FeedbackResult();
		result.setMessage("Executado com sucesso.");
		return result;
	}
}
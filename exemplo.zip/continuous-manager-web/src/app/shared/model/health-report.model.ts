export class HealthReport {
  public description: string;
  public iconUrl: string;
  public score: number;
}

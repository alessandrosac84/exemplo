package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildLog;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildLogPK;

/**
 * Classe de acesso ao banco de dados da entidade BuildLog.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class BuildLogRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Metodo responsavel pela consulta paginada de BuildLog no banco de dados
	 * 
	 * @param BuildLogId
	 * @return BuildLog
	 */
	public BuildLog findById(BuildLogPK id) {
		return entityManager.find(BuildLog.class, id);
	}
	
	/**
	 * Salva BuildLog
	 * 
	 * @param BuildLog
	 * @return BuildLog
	 */
	public BuildLog save(BuildLog buildLog) {
		entityManager.persist(buildLog);
		return buildLog;
	}

	/**
	 * Atualiza BuildLog
	 * 
	 * @param buildLog
	 * @return BuildLog
	 */
	public BuildLog update(BuildLog buildLog) {
		return entityManager.merge(buildLog);
	}
}

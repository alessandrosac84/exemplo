package br.gov.caixa.portalinovacao.config.rest;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class JaxRsActivatorTest {

	@Test
	public void testCreateJaxRsActivator() {
		assertNotNull(new JaxRsActivator());
	}
}

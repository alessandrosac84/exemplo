package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.Measures;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de acesso ao banco de dados da entidade Parameter.
 * 
 * @author Alessandro Carvalho
 *
 */
@ApplicationScoped
public class MeasuresRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Lista dashboards por paginacao
	 * 
	 * @param offset
	 * @param limit
	 * @param search
	 * @param sort
	 * @param order
	 * @return Todas as dashboards por paginacao
	 */
	public List<Measures> findAll(int offset, int limit, String search, String sort, AscDesc order) {
		return entityManager.createQuery(
				"SELECT m FROM Measures m JOIN FETCH m.commit c JOIN FETCH c.project p WHERE c.committedDate = (SELECT MAX(cx.committedDate)"
						+ "FROM Commit cx  WHERE cx.id.wallet = c.id.wallet AND cx.id.project = c.id.project)",
				Measures.class).getResultList();
	}

	/**
	 * Obtem o total de dashboards
	 * 
	 * @param search
	 * @return Total de Dashboards
	 */
	public Long countAll(String search) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);

		Root<Measures> from = query.from(Measures.class);

		return entityManager.createQuery(query.select(builder.count(from))).getSingleResult();
	}

	/**
	 * Metodo responsavel pela consulta paginada de Folders no banco de dados
	 * 
	 * @param environment
	 * @return Parameter
	 */
	public Measures findById(String wallet, String project, String commit) {
		return entityManager.createQuery(
				"SELECT m FROM Measures m JOIN FETCH m.commit c JOIN FETCH c.project p WHERE m.id.commit =:commit AND m.id.wallet =:wallet AND m.id.project =:project",
				Measures.class).setParameter("wallet", wallet).setParameter("project", project)
				.setParameter("commit", commit).getSingleResult();
	}

	/**
	 * Salva Sonar
	 * 
	 * @param Sonar
	 * @return Sonar
	 */
	public Measures save(Measures measures) {
		entityManager.persist(measures);
		return measures;
	}
}

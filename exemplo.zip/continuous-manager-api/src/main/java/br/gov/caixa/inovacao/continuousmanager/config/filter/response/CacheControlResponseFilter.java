package br.gov.caixa.inovacao.continuousmanager.config.filter.response;

import java.io.IOException;
import java.util.logging.Logger;

import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.ext.Provider;

/**
 * Filtro para validação de token
 * 
 * @author Fabio Iwakoshi
 *
 */
@Provider
@Priority(Priorities.HEADER_DECORATOR)
public class CacheControlResponseFilter implements ContainerResponseFilter {

	@Override
	public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext)
			throws IOException {
		Logger log = Logger.getLogger(this.getClass().getName());
		log.fine("Executando Cache Control Filter... ");
		if (requestContext.getMethod().equals("GET")) {
			CacheControl cc = new CacheControl();
			cc.setMaxAge(100);
			responseContext.getHeaders().add("Cache-Control", cc);
		}
		responseContext.getHeaders().add("Access-Control-Max-Age", "0"); //
		responseContext.getHeaders().add("Cache-Control", "no-cache, no-store, must-revalidate");
		responseContext.getHeaders().add("Pragma", "no-cache");
		responseContext.getHeaders().add("Expires", "0");
	}

}

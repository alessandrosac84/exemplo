package br.gov.caixa.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import br.gov.caixa.api.model.CategoriaProcesso;
import br.gov.caixa.api.model.Processo;

public interface ProcessoRepository extends JpaRepository<Processo, Long>  {

	List<Processo> findByCategoriaProcesso(CategoriaProcesso categoriaProcesso);	
	
	@Query("select a from Processo a where a.categoriaProcesso = ?1 order by a.uid")
	public List<Processo> findByCategoriaProcessoOrder(CategoriaProcesso categoriaProcesso);
	
	@Modifying
	@Transactional
	@Query("update Processo f set f.ativo = ?1 where f.uid = ?2")
	int setAtivo(Boolean ativo, Long uid);
		
	@Query("select a from Processo a where a.ativo = true order by a.uid")
	public List<Processo> findAllAtivas();
	
	public Processo findByNome(String nome);

}

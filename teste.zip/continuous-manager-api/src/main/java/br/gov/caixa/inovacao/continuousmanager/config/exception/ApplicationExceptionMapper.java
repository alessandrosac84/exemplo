package br.gov.caixa.inovacao.continuousmanager.config.exception;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJBException;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 * @author Fabio IWakoshi
 *
 */
@Provider
public class ApplicationExceptionMapper implements ExceptionMapper<Exception> {

	private ResourceBundle bundle = ResourceBundle.getBundle("messages", new Locale("pt", "BR"));

	private static final int UNKNOWN = 1;
	private static final int DATABASE = 2;
	private static final int VALIDATION = 3;
	private static final int BUSINESS = 4;
	private static final int PERMITION = 5;

	@Override
	public Response toResponse(Exception exception) {
		Logger.getAnonymousLogger().log(Level.SEVERE, "", exception);
		if (exception instanceof WebApplicationException) {
			return responseBuilder((WebApplicationException) exception);
		} else if (exception instanceof EJBException) {
			return responseBuilder((EJBException) exception);
		}
		return build(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), UNKNOWN, Arrays.asList(bundle.getString("br.gov.caixa.message.error.internal_server_error")));
	}

	private Response responseBuilder(EJBException exception) {
		int code = 0;
		List<String> messages = new ArrayList<>();
		
		if(exception.getMessage().lastIndexOf("javax.validation.ConstraintViolationException:") > -1) {  
			code = VALIDATION;
			for(String line : exception.getMessage().split("\n")) {
				if (line.contains("message: ")) {
					messages.add(line.substring(line.indexOf("message: ") + 9));
				}
			}
			return build(Response.Status.BAD_REQUEST.getStatusCode(), code, messages);
		} else if (exception.getMessage().contains("JDBC")) {
			code = DATABASE;
			messages.add(bundle.getString("br.gov.caixa.message.error.service_unavailable"));
		} else if (exception.getMessage().contains("WFLYEJB0364")) {
			code = PERMITION;
			messages.add("Você não possui permissão de acesso a esta URL!");
			return build(Response.Status.FORBIDDEN.getStatusCode(), code, messages);
		} else if (exception.getMessage().contains("javax.ws.rs.")) {
			code = BUSINESS;
			messages.add(exception.getMessage().substring(exception.getMessage().indexOf(": ") + 2));
		} else {
			code = UNKNOWN;
			messages.add(bundle.getString("br.gov.caixa.message.error.service_unavailable"));
		}
		return build(Response.Status.SERVICE_UNAVAILABLE.getStatusCode(), code, messages);
	}
	

	private Response responseBuilder(WebApplicationException exception) {
		return build(exception.getResponse().getStatus(), 0, Arrays.asList(exception.getMessage()));
	}
	
	private Response build(int status, int codeApplication, List<String> message) {
		ErrorEntity entity = new ErrorEntity().status(status).code(codeApplication)
				.messages(message).link("api/page-codes");
		
		return Response.status(status).entity(entity).type(MediaType.APPLICATION_JSON).build();
	}

}

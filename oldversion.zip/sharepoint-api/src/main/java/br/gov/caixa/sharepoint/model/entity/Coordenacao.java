package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;
import br.gov.caixa.sharepoint.model.ViewJson;

/**
 * The persistent class for the coordenacao database table.
 * 
 */
@Entity
@Table(name = "coordenacao")
@NamedQueries({
		@NamedQuery(name = "Coordenacao.findAll", query = "SELECT DISTINCT c FROM Coordenacao c"),
		@NamedQuery(name = "Coordenacao.findCoordenacaoSuperiorById", query = "SELECT c.coordenacaoSuperior FROM Coordenacao c WHERE c.id = :id"),
		@NamedQuery(name = "Coordenacao.findSubCoordenacoesById", query = "SELECT DISTINCT c FROM Coordenacao c LEFT JOIN FETCH c.funcionarios WHERE c.coordenacaoSuperior.id = :id"),
		@NamedQuery(name = "Coordenacao.findByAKs", query = "SELECT c FROM Coordenacao c WHERE c.id <> :id AND c.tipoCoordenacao.id = :tipo AND c.grupo = :grupo"),
		@NamedQuery(name = "Coordenacao.findMaster", query = "SELECT c FROM Coordenacao c WHERE c.tipoCoordenacao.id = 1"),
		@NamedQuery(name = "Coordenacao.findByReferencia", query = "SELECT c FROM Coordenacao c INNER JOIN c.coordenacoes cs WHERE c.id = :coordenacao"),
		@NamedQuery(name = "Coordenacao.findCoordenadorById", query = "SELECT c.coordenador FROM Coordenacao c WHERE c.id = :id"),
		@NamedQuery(name = "Coordenacao.findCoordenacoesByCoordenador", query = "SELECT c FROM Coordenacao c WHERE c.coordenador.matricula = :matricula"),
		//@NamedQuery(name = "Coordenacao.findByGrupoAndType", query = "SELECT c FROM Coordenacao c WHERE c.grupo = :grupo AND c.tipoCoordenacao.id = :tipo"),
})

public class Coordenacao extends AuditedEntity implements Serializable, IEntity<Integer> {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Integer id;

	@NotNull
	@Size(min = 2, max = 255)
	@Column(length = 255)
	private String descricao;

	@NotNull
	@Pattern(regexp="CEDESSP[0-9]{3}")
	@Column(nullable = false, length = 10)
	private String grupo;

	@Column(columnDefinition = "TEXT")
	private String foto;

	@NotNull
	@Size(min = 2, max = 150)
	@Column(nullable = false, length = 150)
	private String nome;

	@JsonIgnore
	@JsonView(ViewJson.Coordenacao.class)
	// bi-directional many-to-one association to SegmentoNegocio
	@ManyToOne
	@JoinColumn(name = "segmento_negocio")
	private SegmentoNegocio segmentoNegocio;

	@JsonIgnore
	@JsonView(ViewJson.Coordenacao.class)
	// bi-directional many-to-one association to TipoCoordenacao
	@ManyToOne
	@JoinColumn(name = "tipo_coordenacao", nullable = false)
	private TipoCoordenacao tipoCoordenacao;

	@JsonIgnore
	// bi-directional many-to-one association to Funcionario
	@ManyToOne(optional=true, fetch=FetchType.LAZY)
	@JoinColumn(name = "coordenador")
	@JsonProperty("coordenador")
	private Funcionario coordenador;

	@JsonIgnore
	// bi-directional many-to-one association to Coordenacao
	@ManyToOne(optional=true, fetch=FetchType.LAZY)
	@JoinColumn(name = "coordenacao_superior")
	private Coordenacao coordenacaoSuperior;

	@JsonIgnore
	// bi-directional many-to-one association to Coordenacao
	@OneToMany(mappedBy = "coordenacaoSuperior")
	private Set<Coordenacao> coordenacoes;

	@JsonIgnore
	// bi-directional many-to-one association to Funcionario
	@OneToMany(mappedBy = "coordenacao")
	private Set<Funcionario> funcionarios;

	@JsonIgnore
	//bi-directional many-to-one association to Sistema
	@OneToMany(mappedBy="coordenacao")
	private Set<Ativo> ativos;
	
	@AssertTrue(message = "{br.gov.caixa.siref.validation.constraints.ti_project}")
	private boolean isCoordenacaoDeTI() {
		if (tipoCoordenacao == null) {
			return true;
		}
		if (tipoCoordenacao.getId() == null) {
			return true;
		}
		if (tipoCoordenacao.getId().equals(2)) {
			return true;
		}
		return coordenacaoSuperior != null;
	}
	
	@AssertTrue(message = "{br.gov.caixa.siref.validation.constraints.ti_project}")
	private boolean isSegmentoDeNegocio() {
		if (tipoCoordenacao == null) {
			return true;
		}
		if (tipoCoordenacao.getId() == null) {
			return true;
		}
		if (tipoCoordenacao.getId().equals(3)) {
			return true;
		}
		return segmentoNegocio != null;
	}

	public Coordenacao() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescricao() {
		return this.descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getGrupo() {
		return this.grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	@JsonIgnore
	public Coordenacao getCoordenacaoSuperior() {
		return this.coordenacaoSuperior;
	}

	@JsonProperty
	public void setCoordenacaoSuperior(Coordenacao coordenacaoSuperior) {
		this.coordenacaoSuperior = coordenacaoSuperior;
	}

	public Coordenacao addCoordenacao(Coordenacao coordenacao) {
		getCoordenacoes().add(coordenacao);
		coordenacao.setCoordenacaoSuperior(this);

		return coordenacao;
	}

	public Coordenacao removeCoordenacao(Coordenacao coordenacao) {
		getCoordenacoes().remove(coordenacao);
		coordenacao.setCoordenacaoSuperior(null);

		return coordenacao;
	}

	@JsonIgnore
	public Funcionario getCoordenador() {
		return this.coordenador;
	}

	@JsonProperty
	public void setCoordenador(Funcionario coordenador) {
		this.coordenador = coordenador;
	}

	//@JsonIgnore
	//@JsonView(ViewJson.Coordenacao.class)
	public SegmentoNegocio getSegmentoNegocio() {
		return this.segmentoNegocio;
	}

	@JsonProperty
	public void setSegmentoNegocio(SegmentoNegocio segmentoNegocio) {
		this.segmentoNegocio = segmentoNegocio;
	}

	//@JsonIgnore
	//@JsonView(ViewJson.Coordenacao.class)
	public TipoCoordenacao getTipoCoordenacao() {
		return this.tipoCoordenacao;
	}

	@JsonProperty
	public void setTipoCoordenacao(TipoCoordenacao tipoCoordenacao) {
		this.tipoCoordenacao = tipoCoordenacao;
	}

	@JsonIgnore
	public Set<Funcionario> getFuncionarios() {
		return this.funcionarios;
	}

	@JsonProperty
	public void setFuncionarios(Set<Funcionario> funcionarios) {
		this.funcionarios = funcionarios;
	}

	public Funcionario addFuncionario(Funcionario funcionario) {
		getFuncionarios().add(funcionario);
		funcionario.setCoordenacao(this);

		return funcionario;
	}

	public Funcionario removeFuncionario(Funcionario funcionario) {
		getFuncionarios().remove(funcionario);
		funcionario.setCoordenacao(null);

		return funcionario;
	}

	@JsonIgnore
	public Set<Coordenacao> getCoordenacoes() {
		return coordenacoes;
	}

	@JsonProperty
	public void setCoordenacoes(Set<Coordenacao> coordenacoes) {
		this.coordenacoes = coordenacoes;
	}

	@JsonIgnore
	public Set<Ativo> getAtivos() {
		return this.ativos;
	}

	@JsonProperty
	public void setAtivos(Set<Ativo> ativos) {
		this.ativos = ativos;
	}

	public Ativo addAtivo(Ativo ativo) {
		getAtivos().add(ativo);
		ativo.setCoordenacao(this);

		return ativo;
	}

	public Ativo removeAtivo(Ativo ativo) {
		getAtivos().remove(ativo);
		ativo.setCoordenacao(null);

		return ativo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((coordenacaoSuperior == null) ? 0 : coordenacaoSuperior.hashCode());
		result = prime * result + ((coordenador == null) ? 0 : coordenador.hashCode());
		result = prime * result + ((descricao == null) ? 0 : descricao.hashCode());
		result = prime * result + ((foto == null) ? 0 : foto.hashCode());
		result = prime * result + ((grupo == null) ? 0 : grupo.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((segmentoNegocio == null) ? 0 : segmentoNegocio.hashCode());
		result = prime * result + ((tipoCoordenacao == null) ? 0 : tipoCoordenacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coordenacao other = (Coordenacao) obj;
		if (coordenacaoSuperior == null) {
			if (other.coordenacaoSuperior != null)
				return false;
		} else if (!coordenacaoSuperior.equals(other.coordenacaoSuperior))
			return false;
		if (coordenador == null) {
			if (other.coordenador != null)
				return false;
		} else if (!coordenador.equals(other.coordenador))
			return false;
		if (descricao == null) {
			if (other.descricao != null)
				return false;
		} else if (!descricao.equals(other.descricao))
			return false;
		if (foto == null) {
			if (other.foto != null)
				return false;
		} else if (!foto.equals(other.foto))
			return false;
		if (grupo == null) {
			if (other.grupo != null)
				return false;
		} else if (!grupo.equals(other.grupo))
			return false;
		if (id == null) {
			return false;
		} else if (!id.equals(other.id))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (segmentoNegocio == null) {
			if (other.segmentoNegocio != null)
				return false;
		} else if (!segmentoNegocio.equals(other.segmentoNegocio))
			return false;
		if (tipoCoordenacao == null) {
			if (other.tipoCoordenacao != null)
				return false;
		} else if (!tipoCoordenacao.equals(other.tipoCoordenacao))
			return false;
		return true;
	}

	@Override
	public boolean isTheSameObject(IEntity<Integer> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		Coordenacao other = (Coordenacao) object;
		if (id == null) {
			return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.RatingProcesso;

public class RatingProcessoDto {

	private Long uid;
	private Integer rating;
	private boolean conhecer;
	private boolean conheco;
	private boolean multiplicador;
	private ProcessoDto processo;
	private FuncionarioDto funcionario;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public boolean isConhecer() {
		return conhecer;
	}

	public void setConhecer(boolean conhecer) {
		this.conhecer = conhecer;
	}
	
	public boolean isConheco() {
		return conheco;
	}

	public void setConheco(boolean conheco) {
		this.conheco = conheco;
	}

	public boolean isMultiplicador() {
		return multiplicador;
	}

	public void setMultiplicador(boolean multiplicador) {
		this.multiplicador = multiplicador;
	}

	public ProcessoDto getProcesso() {
		return processo;
	}

	public void setProcesso(ProcessoDto processo) {
		this.processo = processo;
	}

	public FuncionarioDto getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(FuncionarioDto funcionario) {
		this.funcionario = funcionario;
	}

	public static RatingProcessoDto fromRatingProcessoDto(RatingProcesso ratingProcesso) {
		RatingProcessoDto dto = new RatingProcessoDto();
		dto.setUid(ratingProcesso.getUid());
		dto.setRating(ratingProcesso.getRating());
		dto.setConhecer(ratingProcesso.isConhecer());
		dto.setConheco(ratingProcesso.isConheco());
		dto.setMultiplicador(ratingProcesso.isMultiplicador());
		dto.setProcesso(ProcessoDto.fromProcessoToDto(ratingProcesso.getProcesso()));
		dto.setFuncionario(FuncionarioDto.fromFuncionarioToDto(ratingProcesso.getFuncionario()));
		return dto;
	}
	
	public static List<RatingProcessoDto> fromRatingProcessoToListDto(List<RatingProcesso> ratingProcessos) {
		List<RatingProcessoDto> returnList = new ArrayList<RatingProcessoDto>();
		for (RatingProcesso ratingProcesso : ratingProcessos) {
			RatingProcessoDto dto = new RatingProcessoDto();
			dto.setUid(ratingProcesso.getUid());
			dto.setRating(ratingProcesso.getRating());
			dto.setConhecer(ratingProcesso.isConhecer());
			dto.setConheco(ratingProcesso.isConheco());
			dto.setMultiplicador(ratingProcesso.isMultiplicador());
			dto.setProcesso(ProcessoDto.fromProcessoToDto(ratingProcesso.getProcesso()));
			dto.setFuncionario(FuncionarioDto.fromFuncionarioToDto(ratingProcesso.getFuncionario()));
			returnList.add(dto);
		}
		return returnList;
	}	

}

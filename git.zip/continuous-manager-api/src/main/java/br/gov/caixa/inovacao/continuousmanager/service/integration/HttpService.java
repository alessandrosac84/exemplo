/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.net.ssl.SSLContext;
import javax.validation.constraints.NotNull;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.ssl.SSLContexts;

import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpMethod;

/**
 * Classe de servicos do Jenkins.
 * 
 * @author Fabio IWakoshi
 *
 */
@Stateless
public class HttpService {

	private HttpService() { }
	
	public static IHost httpMethod(@NotNull HttpMethod httpMethod) {
		return new HttpService.Builder(httpMethod);
	}
	
	public interface IHost {
        IPath host(@NotNull String host);
	}
	
	public interface IPath {
        IQuery path(@NotNull String path);
	}
	
	public interface IQuery {
		IHeader query(@NotNull String queryParam, @NotNull String query);
		IHeader queries(@NotNull Map<String, String> queries);
	}
	
	public interface IHeader extends IQuery {
        IEntity header(@NotNull String field, @NotNull String value);
	}
	
	public interface IEntity extends IBuild, IHeader {
		IBuild entity(Entity<?> entity);
	}
	
	public interface IBuild {
		Response build();
    }
	
	private static class Builder implements IHost, IPath, IQuery, IHeader, IEntity, IBuild {

		private class HttpVO {
			HttpMethod httpMethod;
			String host;
			String path;
			Map<String, String> headers = new HashMap<>();
			Map<String, String> queries = new HashMap<>();
			Entity<?> entity;
		}
		
		private static Logger log = Logger.getAnonymousLogger();
		
		private HttpVO instance = new HttpVO();

		public Builder(@NotNull HttpMethod httpMethod) {
			instance.httpMethod = httpMethod;
		}

		@Override
		public IPath host(@NotNull String host) {
			instance.host = host;
			return this;
		}

		@Override
		public IQuery path(@NotNull String path) {
			instance.path = path;
			return this;
		}

		@Override
		public IHeader query(@NotNull String queryParam, @NotNull String query) {
			instance.queries.put(queryParam, query);
			return this;
		}

		@Override
		public IHeader queries(Map<String, String> queries) {
			instance.queries = queries;
			return this;
		}

		@Override
		public IEntity header(@NotNull String field, @NotNull String value) {
			if (!field.isEmpty())
				instance.headers.put(field, value);
			return this;
		}
		
		@Override
		public IBuild entity(Entity<?> entity) {
			instance.entity = entity;
			return this;
		}

		@Override
		public Response build() {
			return callHttp();
		}
		
		private Response callHttp() {
			log.log(Level.FINE, "Chamando :: {0}", instance.host);
			
			ClientBuilder builder = ClientBuilder.newBuilder();
			if (instance.host.startsWith("https")) {
				TrustStrategy trustStrategy = new TrustSelfSignedStrategy();
				SSLContext sslContext;
				try {
					sslContext = SSLContexts.custom().loadTrustMaterial(trustStrategy).build();
				} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
					log.log(Level.SEVERE, "Erro ao gerar certificado de acesso!", e);
					throw new ServiceUnavailableException("Erro ao acessar o servidor!");
				}
				
				builder = builder.hostnameVerifier(NoopHostnameVerifier.INSTANCE).sslContext(sslContext);
			}
			WebTarget target = builder.build().target(instance.host).path(instance.path);
			if (instance.queries != null) {
				for (Map.Entry<String, String> q : instance.queries.entrySet()) {
					target = target.queryParam(q.getKey(), q.getValue());
				}
			}
			javax.ws.rs.client.Invocation.Builder request = target.request(MediaType.APPLICATION_JSON);
			
			if (instance.headers != null) {
				for (Map.Entry<String, String> q : instance.headers.entrySet()) {
					request = request.header(q.getKey(), q.getValue());
				}
			}
			
			switch (instance.httpMethod) {
			case GET:
				return request.get();
				
			case POST:
				return request.post(instance.entity);
				
			case PUT:
				return request.put(instance.entity);
				
			case DELETE:
				return request.delete();
			}
			
			throw new IllegalArgumentException("Parametros inválidos!");
		}
	}
}

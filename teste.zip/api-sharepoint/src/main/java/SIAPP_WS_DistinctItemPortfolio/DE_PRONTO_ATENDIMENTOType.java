/**
 * DE_PRONTO_ATENDIMENTOType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package SIAPP_WS_DistinctItemPortfolio;

@SuppressWarnings({ "rawtypes", "serial", "unchecked" })
public class DE_PRONTO_ATENDIMENTOType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected DE_PRONTO_ATENDIMENTOType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _value1 = "5x8";
    public static final java.lang.String _value2 = "5x12";
    public static final java.lang.String _value3 = "5x14";
    public static final java.lang.String _value4 = "5x15";
    public static final java.lang.String _value5 = "5x24";
    public static final java.lang.String _value6 = "6x12";
    public static final java.lang.String _value7 = "6x24";
    public static final java.lang.String _value8 = "7x8";
    public static final java.lang.String _value9 = "7x12";
    public static final java.lang.String _value10 = "7x24";
    public static final java.lang.String _value11 = "N/A";
    public static final DE_PRONTO_ATENDIMENTOType value1 = new DE_PRONTO_ATENDIMENTOType(_value1);
    public static final DE_PRONTO_ATENDIMENTOType value2 = new DE_PRONTO_ATENDIMENTOType(_value2);
    public static final DE_PRONTO_ATENDIMENTOType value3 = new DE_PRONTO_ATENDIMENTOType(_value3);
    public static final DE_PRONTO_ATENDIMENTOType value4 = new DE_PRONTO_ATENDIMENTOType(_value4);
    public static final DE_PRONTO_ATENDIMENTOType value5 = new DE_PRONTO_ATENDIMENTOType(_value5);
    public static final DE_PRONTO_ATENDIMENTOType value6 = new DE_PRONTO_ATENDIMENTOType(_value6);
    public static final DE_PRONTO_ATENDIMENTOType value7 = new DE_PRONTO_ATENDIMENTOType(_value7);
    public static final DE_PRONTO_ATENDIMENTOType value8 = new DE_PRONTO_ATENDIMENTOType(_value8);
    public static final DE_PRONTO_ATENDIMENTOType value9 = new DE_PRONTO_ATENDIMENTOType(_value9);
    public static final DE_PRONTO_ATENDIMENTOType value10 = new DE_PRONTO_ATENDIMENTOType(_value10);
    public static final DE_PRONTO_ATENDIMENTOType value11 = new DE_PRONTO_ATENDIMENTOType(_value11);
    public java.lang.String getValue() { return _value_;}
    public static DE_PRONTO_ATENDIMENTOType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        DE_PRONTO_ATENDIMENTOType enumeration = (DE_PRONTO_ATENDIMENTOType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static DE_PRONTO_ATENDIMENTOType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DE_PRONTO_ATENDIMENTOType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_PRONTO_ATENDIMENTOType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}

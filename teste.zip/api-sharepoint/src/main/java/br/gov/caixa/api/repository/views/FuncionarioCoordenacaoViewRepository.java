package br.gov.caixa.api.repository.views;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.gov.caixa.api.model.views.FuncionarioCoordenacaoView;

@Repository
public interface FuncionarioCoordenacaoViewRepository extends JpaRepository<FuncionarioCoordenacaoView, Long> {

}

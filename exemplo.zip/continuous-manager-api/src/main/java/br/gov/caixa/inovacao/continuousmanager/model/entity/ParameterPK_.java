package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-01-30T16:53:57.807-0200")
@StaticMetamodel(ParameterPK.class)
public class ParameterPK_ {
	public static volatile SingularAttribute<ParameterPK, Environment> environment;
	public static volatile SingularAttribute<ParameterPK, ServerType> serverType;
}

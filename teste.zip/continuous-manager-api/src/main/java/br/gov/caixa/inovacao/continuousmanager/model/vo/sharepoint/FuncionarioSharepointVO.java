package br.gov.caixa.inovacao.continuousmanager.model.vo.sharepoint;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;


/**
 * The persistent class for the funcionario database table.
 * 
 */
public class FuncionarioSharepointVO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@JsonView(ViewJson.FuncionarioView.class)
	private String matricula;

	private String anotacoes;

	private Integer cep;

	private String cidade;

	private Calendar dataAdmissao;

	private Calendar dataCedes;

	private String depto;

	@JsonView(ViewJson.FuncionarioView.class)
	private String email;

	private String empresa;

	private String foto;

	private Date horaEntrada;

	private Date horaSaida;

	private String logradouro;

	@JsonView(ViewJson.FuncionarioView.class)
	private String nome;

	private String qualificacoes;
	
	private Calendar atualizacaoCadastral;

	private String uf;
	
	private Calendar statusDate;
	
	private String statusDetail;
	
	private transient Object status;
	
	private transient Object cargoFuncionario;
	
	public FuncionarioSharepointVO() {
		/* class constructor intentionally left blank */
	}

	/**
	 * @return the matricula
	 */
	public String getMatricula() {
		return matricula;
	}

	/**
	 * @param matricula the matricula to set
	 */
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	/**
	 * @return the anotacoes
	 */
	public String getAnotacoes() {
		return anotacoes;
	}

	/**
	 * @param anotacoes the anotacoes to set
	 */
	public void setAnotacoes(String anotacoes) {
		this.anotacoes = anotacoes;
	}

	/**
	 * @return the cep
	 */
	public Integer getCep() {
		return cep;
	}

	/**
	 * @param cep the cep to set
	 */
	public void setCep(Integer cep) {
		this.cep = cep;
	}

	/**
	 * @return the cidade
	 */
	public String getCidade() {
		return cidade;
	}

	/**
	 * @param cidade the cidade to set
	 */
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	/**
	 * @return the dataAdmissao
	 */
	public Calendar getDataAdmissao() {
		return dataAdmissao;
	}

	/**
	 * @param dataAdmissao the dataAdmissao to set
	 */
	public void setDataAdmissao(Calendar dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	/**
	 * @return the dataCedes
	 */
	public Calendar getDataCedes() {
		return dataCedes;
	}

	/**
	 * @param dataCedes the dataCedes to set
	 */
	public void setDataCedes(Calendar dataCedes) {
		this.dataCedes = dataCedes;
	}

	/**
	 * @return the depto
	 */
	public String getDepto() {
		return depto;
	}

	/**
	 * @param depto the depto to set
	 */
	public void setDepto(String depto) {
		this.depto = depto;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the empresa
	 */
	public String getEmpresa() {
		return empresa;
	}

	/**
	 * @param empresa the empresa to set
	 */
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	/**
	 * @return the foto
	 */
	public String getFoto() {
		return foto;
	}

	/**
	 * @param foto the foto to set
	 */
	public void setFoto(String foto) {
		this.foto = foto;
	}

	/**
	 * @return the horaEntrada
	 */
	public Date getHoraEntrada() {
		return horaEntrada;
	}

	/**
	 * @param horaEntrada the horaEntrada to set
	 */
	public void setHoraEntrada(Date horaEntrada) {
		this.horaEntrada = horaEntrada;
	}

	/**
	 * @return the horaSaida
	 */
	public Date getHoraSaida() {
		return horaSaida;
	}

	/**
	 * @param horaSaida the horaSaida to set
	 */
	public void setHoraSaida(Date horaSaida) {
		this.horaSaida = horaSaida;
	}

	/**
	 * @return the logradouro
	 */
	public String getLogradouro() {
		return logradouro;
	}

	/**
	 * @param logradouro the logradouro to set
	 */
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the qualificacoes
	 */
	public String getQualificacoes() {
		return qualificacoes;
	}

	/**
	 * @param qualificacoes the qualificacoes to set
	 */
	public void setQualificacoes(String qualificacoes) {
		this.qualificacoes = qualificacoes;
	}

	/**
	 * @return the uf
	 */
	public String getUf() {
		return uf;
	}

	/**
	 * @param uf the uf to set
	 */
	public void setUf(String uf) {
		this.uf = uf;
	}

	/**
	 * @return the statusDate
	 */
	public Calendar getStatusDate() {
		return statusDate;
	}

	/**
	 * @param statusDate the statusDate to set
	 */
	public void setStatusDate(Calendar statusDate) {
		this.statusDate = statusDate;
	}

	/**
	 * @return the statusDetail
	 */
	public String getStatusDetail() {
		return statusDetail;
	}

	/**
	 * @param statusDetail the statusDetail to set
	 */
	public void setStatusDetail(String statusDetail) {
		this.statusDetail = statusDetail;
	}

	/**
	 * @return the status
	 */
	public Object getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Object status) {
		this.status = status;
	}

	/**
	 * @return the cargoFuncionario
	 */
	public Object getCargoFuncionario() {
		return cargoFuncionario;
	}

	/**
	 * @param cargoFuncionario the cargoFuncionario to set
	 */
	public void setCargoFuncionario(Object cargoFuncionario) {
		this.cargoFuncionario = cargoFuncionario;
	}

	/**
	 * @return the atualizacaoCadastral
	 */
	public Calendar getAtualizacaoCadastral() {
		return atualizacaoCadastral;
	}

	/**
	 * @param atualizacaoCadastral the atualizacaoCadastral to set
	 */
	public void setAtualizacaoCadastral(Calendar atualizacaoCadastral) {
		this.atualizacaoCadastral = atualizacaoCadastral;
	}
	
}
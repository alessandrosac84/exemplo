package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Project;


/**
 * The persistent class for the project_branch database table.
 * 
 */
@Entity
@Table(name="project_branch")
@NamedQuery(name="ProjectBranch.findAll", query="SELECT p FROM ProjectBranch p")
public class ProjectBranch extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ProjectBranchPK id;

	//bi-directional many-to-one association to BranchInstance
	@JsonView(ViewJson.JenkisfileView.class)
	@OneToMany(mappedBy="projectBranch", fetch = FetchType.LAZY)
	private Set<BranchInstance> branchInstances;

	//bi-directional many-to-one association to BranchParameter
	@JsonView(ViewJson.JenkisfileView.class)
	@OneToMany(mappedBy="projectBranch", fetch = FetchType.LAZY)
	private Set<BranchParameter> branchParameters;

	//bi-directional many-to-one association to Project
	@JsonView(ViewJson.JenkisfileView.class)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="project", referencedColumnName="id", nullable=false, insertable=false, updatable=false)
		})
	private Project project;

	public ProjectBranch() {
		/* class constructor intentionally left blank */
	}

	public ProjectBranchPK getId() {
		return this.id;
	}

	public void setId(ProjectBranchPK id) {
		this.id = id;
	}

	public Set<BranchInstance> getBranchInstances() {
		return this.branchInstances;
	}

	public void setBranchInstances(Set<BranchInstance> branchInstances) {
		this.branchInstances = branchInstances;
	}

	public Set<BranchParameter> getBranchParameters() {
		return this.branchParameters;
	}

	public void setBranchParameters(Set<BranchParameter> branchParameters) {
		this.branchParameters = branchParameters;
	}

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

}
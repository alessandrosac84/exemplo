/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe de representação do Build do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class ActionJenkinsVO implements Serializable {

	private static final long serialVersionUID = 3381635580774841468L;
	
	@JsonProperty("_class")
	private String clazz;
	
	private List<String> remoteUrls;
	
	private LastBuiltRevisionJenkinsVO lastBuiltRevision;

	/**
	 * @return the clazz
	 */
	public String getClazz() {
		return clazz;
	}

	/**
	 * @param clazz the clazz to set
	 */
	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	/**
	 * @return the remoteUrls
	 */
	public List<String> getRemoteUrls() {
		return remoteUrls;
	}

	/**
	 * @param remoteUrls the remoteUrls to set
	 */
	public void setRemoteUrls(List<String> remoteUrls) {
		this.remoteUrls = remoteUrls;
	}

	/**
	 * @return the lastBuiltRevision
	 */
	public LastBuiltRevisionJenkinsVO getLastBuiltRevision() {
		return lastBuiltRevision;
	}

	/**
	 * @param lastBuiltRevision the lastBuiltRevision to set
	 */
	public void setLastBuiltRevision(LastBuiltRevisionJenkinsVO lastBuiltRevision) {
		this.lastBuiltRevision = lastBuiltRevision;
	}

}

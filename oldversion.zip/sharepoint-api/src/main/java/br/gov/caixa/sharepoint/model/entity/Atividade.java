package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the atividade database table.
 * 
 */
@Entity
@Table(name="atividade")
@NamedQueries ({
	@NamedQuery(name="Atividade.findBySubgrupoAtividade", query = "SELECT DISTINCT a FROM Atividade a LEFT JOIN FETCH a.complementoAtividade WHERE a.subgrupoAtividade.id = :subgrupoAtividade"),
	@NamedQuery(name="Atividade.findByAKs", query = "SELECT a FROM Atividade a WHERE a.id <> :id AND a.nome = :nome"),
	@NamedQuery(name="Atividade.findAll", query="SELECT DISTINCT a FROM Atividade a LEFT JOIN FETCH a.complementoAtividade"),
	@NamedQuery(name="Atividade.findByReferencia", query="SELECT a FROM Atividade a INNER JOIN FETCH a.ratingAtividades WHERE a.id = :atividade"),
	@NamedQuery(name="Atividade.findByGrupoAtividade", query="SELECT a FROM Atividade a WHERE a.subgrupoAtividade.grupoAtividade.id = :grupoAtividade")
})
public class Atividade extends AuditedEntity implements Serializable, IEntity<Integer> {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@NotNull
	@Column(nullable=false)
	private Boolean ativo;

	@NotEmpty
	@Size(min=1, max=100)
	@Column(nullable=false, length=100)
	private String nome;
	
	//bi-directional many-to-one association to ComplementoAtividade
	@ManyToOne
	@JoinColumn(name="complemento")
	private ComplementoAtividade complementoAtividade;

	@JsonIgnore
	//bi-directional many-to-one association to SubgrupoAtividade
	@ManyToOne
	@JoinColumn(name="subgrupo", nullable=false)
	private SubgrupoAtividade subgrupoAtividade;

	@JsonIgnore
	//bi-directional many-to-one association to RatingAtividade
	@OneToMany(mappedBy="atividade")
	private List<RatingAtividade> ratingAtividades;

	@JsonIgnore
	//bi-directional many-to-one association to ConhecimentoAtivo
	@OneToMany(mappedBy="atividade")
	private Set<ConhecimentoAtivo> conhecimentoAtivos;
	
	@JsonIgnore
	//bi-directional many-to-one association to AtividadeFuncionario
	@OneToMany(mappedBy="atividade")
	private Set<AtividadeFuncionario> atividadeFuncionarios;
	
	@JsonIgnore
	//bi-directional many-to-one association to TreinamentoAtividade
	@OneToMany(mappedBy="atividade")
	private Set<TreinamentoAtividade> treinamentoAtividades;

	public Atividade() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getAtivo() {
		return this.ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@JsonIgnore
	public SubgrupoAtividade getSubgrupoAtividade() {
		return this.subgrupoAtividade;
	}

	@JsonProperty
	public void setSubgrupoAtividade(SubgrupoAtividade subgrupoAtividade) {
		this.subgrupoAtividade = subgrupoAtividade;
	}

	public List<RatingAtividade> getRatingAtividades() {
		return this.ratingAtividades;
	}

	public void setRatingAtividades(List<RatingAtividade> ratingAtividades) {
		this.ratingAtividades = ratingAtividades;
	}

	public RatingAtividade addRatingAtividade(RatingAtividade ratingAtividade) {
		getRatingAtividades().add(ratingAtividade);
		ratingAtividade.setAtividade(this);

		return ratingAtividade;
	}

	public RatingAtividade removeRatingAtividade(RatingAtividade ratingAtividade) {
		getRatingAtividades().remove(ratingAtividade);
		ratingAtividade.setAtividade(null);

		return ratingAtividade;
	}
	
	public ComplementoAtividade getComplementoAtividade() {
		return this.complementoAtividade;
	}

	public void setComplementoAtividade(ComplementoAtividade complementoAtividade) {
		this.complementoAtividade = complementoAtividade;
	}
	
	public Set<ConhecimentoAtivo> getConhecimentoAtivos() {
		return this.conhecimentoAtivos;
	}

	public void setConhecimentoAtivos(Set<ConhecimentoAtivo> conhecimentoAtivos) {
		this.conhecimentoAtivos = conhecimentoAtivos;
	}

	public ConhecimentoAtivo addConhecimentoAtivo(ConhecimentoAtivo conhecimentoAtivo) {
		getConhecimentoAtivos().add(conhecimentoAtivo);
		conhecimentoAtivo.setAtividade(this);

		return conhecimentoAtivo;
	}

	public ConhecimentoAtivo removeConhecimentoAtivo(ConhecimentoAtivo conhecimentoAtivo) {
		getConhecimentoAtivos().remove(conhecimentoAtivo);
		conhecimentoAtivo.setAtividade(null);

		return conhecimentoAtivo;
	}
	
	public Set<AtividadeFuncionario> getAtividadeFuncionarios() {
		return this.atividadeFuncionarios;
	}

	public void setAtividadeFuncionarios(Set<AtividadeFuncionario> atividadeFuncionarios) {
		this.atividadeFuncionarios = atividadeFuncionarios;
	}

	public AtividadeFuncionario addAtividadeFuncionario(AtividadeFuncionario atividadeFuncionario) {
		getAtividadeFuncionarios().add(atividadeFuncionario);
		atividadeFuncionario.setAtividade(this);

		return atividadeFuncionario;
	}

	public AtividadeFuncionario removeAtividadeFuncionario(AtividadeFuncionario atividadeFuncionario) {
		getAtividadeFuncionarios().remove(atividadeFuncionario);
		atividadeFuncionario.setAtividade(null);

		return atividadeFuncionario;
	}
	
	public Set<TreinamentoAtividade> getTreinamentoAtividades() {
		return this.treinamentoAtividades;
	}

	public void setTreinamentoAtividades(Set<TreinamentoAtividade> treinamentoAtividades) {
		this.treinamentoAtividades = treinamentoAtividades;
	}

	public TreinamentoAtividade addTreinamentoAtividade(TreinamentoAtividade treinamentoAtividade) {
		getTreinamentoAtividades().add(treinamentoAtividade);
		treinamentoAtividade.setAtividade(this);

		return treinamentoAtividade;
	}

	public TreinamentoAtividade removeTreinamentoAtividade(TreinamentoAtividade treinamentoAtividade) {
		getTreinamentoAtividades().remove(treinamentoAtividade);
		treinamentoAtividade.setAtividade(null);

		return treinamentoAtividade;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Atividade other = (Atividade) obj;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public boolean isTheSameObject(IEntity<Integer> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		Atividade other = (Atividade) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
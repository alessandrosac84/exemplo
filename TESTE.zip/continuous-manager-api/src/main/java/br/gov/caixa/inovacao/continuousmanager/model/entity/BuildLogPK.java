package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the build database table.
 * 
 * @author Fabio Iwakoshi
 */
@Embeddable
public class BuildLogPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private Integer build;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String project;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String wallet;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=50)
	private String job;

	public BuildLogPK() {
		/* class constructor intentionally left blank */
	}
	public Integer getBuild() {
		return this.build;
	}
	public void setBuild(Integer build) {
		this.build = build;
	}
	public String getProject() {
		return this.project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getWallet() {
		return this.wallet;
	}
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}
	public String getJob() {
		return this.job;
	}
	public void setJob(String job) {
		this.job = job;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof BuildLogPK)) {
			return false;
		}
		BuildLogPK castOther = (BuildLogPK)other;
		return 
			this.build.equals(castOther.build)
			&& this.project.equals(castOther.project)
			&& this.wallet.equals(castOther.wallet)
			&& this.job.equals(castOther.job);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.build.hashCode();
		hash = hash * prime + this.project.hashCode();
		hash = hash * prime + this.wallet.hashCode();
		hash = hash * prime + this.job.hashCode();
		
		return hash;
	}
}
import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../shared/service/user.service';
import { User } from '../../../../shared/model/entity/user.model';
import { ReposUser } from '../../../../shared/model/entity/reposuser.model';
import { ReposUserService } from '../../../../shared/service/repos-user.service';

@Component({
  selector: 'cm-profile',
  templateUrl: './profile.component.html',
  styles: []
})
export class ProfileComponent implements OnInit {
user: User;
reposUser: ReposUser[];

  constructor(private _userService: UserService,
              private _reposUserService: ReposUserService) { }

  ngOnInit() {
    this._userService.getUser().subscribe(data => this.user = data);
    this._reposUserService.getReposUser().subscribe(data => this.reposUser = data);
  }

}

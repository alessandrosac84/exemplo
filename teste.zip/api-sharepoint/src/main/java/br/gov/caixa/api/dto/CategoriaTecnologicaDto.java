package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.CategoriaTecnologica;

public class CategoriaTecnologicaDto {

	private Long uid;
	private String nome;
	private CoordenacaoDto coordenacaoDto;
	private List<FuncionarioDto> funcionariosDto;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public CoordenacaoDto getCoordenacaoDto() {
		return coordenacaoDto;
	}

	public void setCoordenacaoDto(CoordenacaoDto coordenacaoDto) {
		this.coordenacaoDto = coordenacaoDto;
	}
	
	public List<FuncionarioDto> getFuncionariosDto() {
		return funcionariosDto;
	}

	public void setFuncionariosDto(List<FuncionarioDto> funcionariosDto) {
		this.funcionariosDto = funcionariosDto;
	}
		
	public static CategoriaTecnologicaDto fromCategoriaTecnologicaToDto(CategoriaTecnologica categoriaTecnologica){
		CategoriaTecnologicaDto dto = new CategoriaTecnologicaDto();
		dto.setUid(categoriaTecnologica.getUid());
		dto.setNome(categoriaTecnologica.getNome());
		
		if(categoriaTecnologica.getCoordenacao() != null){
			CoordenacaoDto coordenacaoDto = CoordenacaoDto.fromCoordenacaoToDto(categoriaTecnologica.getCoordenacao());
			dto.setCoordenacaoDto(coordenacaoDto);
		}
		
		if(categoriaTecnologica.getFuncionarios() != null){
			List<FuncionarioDto> funcionariosDto = FuncionarioDto.fromFuncionarioToListDto(categoriaTecnologica.getFuncionarios());
			dto.setFuncionariosDto(funcionariosDto);
		}
		
		return dto;
	}

	public static List<CategoriaTecnologicaDto> fromCategoriaTecnologicaToListDto(List<CategoriaTecnologica> lista) {
		List<CategoriaTecnologicaDto> list = new ArrayList<CategoriaTecnologicaDto>();
		
		for (CategoriaTecnologica categoriaTecnologica : lista) {
			CategoriaTecnologicaDto dto = new CategoriaTecnologicaDto();
			dto.setUid(categoriaTecnologica.getUid());
			dto.setNome(categoriaTecnologica.getNome());
			
			if(categoriaTecnologica.getCoordenacao() != null){
				CoordenacaoDto coordenacaoDto = CoordenacaoDto.fromCoordenacaoToDto(categoriaTecnologica.getCoordenacao());
				dto.setCoordenacaoDto(coordenacaoDto);
			}
			
			if(categoriaTecnologica.getFuncionarios() != null){
				List<FuncionarioDto> funcionariosDto = FuncionarioDto.fromFuncionarioToListDto(categoriaTecnologica.getFuncionarios());
				dto.setFuncionariosDto(funcionariosDto);
			}
			
			list.add(dto);
		}
		return list;
	}
}

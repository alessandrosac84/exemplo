package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * The persistent class for the build database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name = "change_sets")
@NamedQuery(name = "ChangeSet.findAll", query = "SELECT c FROM ChangeSet c")
public class ChangeSet implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonView({ViewJson.BuildView.class, ViewJson.ChangeSetView.class})
	private ChangeSetPK id;

	// bi-directional many-to-one association to Project
	@JsonView(ViewJson.ChangeSetView.class)
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "build", referencedColumnName = "id", nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "job", referencedColumnName = "job", nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "project", referencedColumnName = "project", nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "wallet", referencedColumnName = "wallet", nullable = false, insertable = false, updatable = false) })
	private Build build;

	// bi-directional many-to-one association to Project
	@JsonView({ViewJson.BuildView.class, ViewJson.ChangeSetView.class})
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="commit", referencedColumnName="commit", nullable=false, insertable = false, updatable = false),
		@JoinColumn(name="project", referencedColumnName="project", nullable=false, insertable = false, updatable = false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable = false, updatable = false)
	})
	private GitRepo gitRepo;

	public ChangeSet() {
		/* class constructor intentionally left blank */
	}

	public ChangeSetPK getId() {
		return this.id;
	}

	public void setId(ChangeSetPK id) {
		this.id = id;
	}

	public Build getBuild() {
		return build;
	}

	public void setBuild(Build build) {
		this.build = build;
	}

	public GitRepo getGitRepo() {
		return gitRepo;
	}

	public void setGitRepo(GitRepo gitRepo) {
		this.gitRepo = gitRepo;
	}
}
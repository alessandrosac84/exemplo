import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { Project } from '../model/entity/project.model';
import { Repository } from '../model/entity/repository.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

    constructor(private http: HttpClient) { }


    getProject(project: number): Observable<Project> {
        // return this.http.get<Project[]>(`${this.walletUrl}${this.projectsUrl}`);
        return this.http.get<Project>('../../../assets/file/project.json');
    }

    getProjects(): Observable<Project[]> {
        // return this.http.get<Project[]>(`${this.walletUrl}${this.projectsUrl}`);
        return this.http.get<Project[]>('../../../assets/file/projects.json');
    }

    getProjectWeekStatus(project: Project): Observable<Project[]> {
    // return this.http.get<Project[]>(`${this.walletUrl}${this.projectsUrl}`);
    return this.http.get<Project[]>('../../../assets/file/projectWeekStatus.json');
    }

    getProjectInfoSonar(project: Project): Observable<Project[]> {
    // return this.http.get<Project[]>(`${this.walletUrl}${this.projectsUrl}`);
    return this.http.get<Project[]>('../../../assets/file/projectInfoSonar.json');
    }

    getRepositories(project: number): Observable<Repository[]> {
    return this.http.get<Repository[]>('../../../assets/file/repositories.json');
    }
}



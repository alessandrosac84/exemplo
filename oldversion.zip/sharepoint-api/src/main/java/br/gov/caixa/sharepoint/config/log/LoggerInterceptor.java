package br.gov.caixa.sharepoint.config.log;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

import br.gov.caixa.sharepoint.config.security.subject.PrincipalThreadLocal;

@Logged
@Interceptor
public class LoggerInterceptor {

	@Inject
	private Logger logger;

	@AroundInvoke
	public Object intercept(InvocationContext ic) throws Exception {
		logger.log(Level.INFO, ">> user {0} invoced the method {1}.{2}({3})",
				new Object[] { PrincipalThreadLocal.USER.get().getUsername(),
						ic.getTarget().getClass().getSimpleName(), ic.getMethod().getName(),
						Arrays.deepToString(ic.getParameters()) });
		try {
			return ic.proceed();
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Erro no LoggerInterceptor chamando o proceed :: ", e);
			logger.log(Level.INFO, "<< End invoced method {0}.{1}({2})",
					new Object[] { ic.getTarget().getClass().getSimpleName(), ic.getMethod().getName(),
							Arrays.deepToString(ic.getParameters()) });
			throw e;
		}
	}
}
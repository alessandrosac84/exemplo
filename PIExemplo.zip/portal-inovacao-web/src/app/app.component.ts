import { Component } from '@angular/core';

@Component({
  selector: 'pi-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'pi';
  opened = false;

  resizeNav(opened: boolean) {
    this.opened = opened;
  }
}

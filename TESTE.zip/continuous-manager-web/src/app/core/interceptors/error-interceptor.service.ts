
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';

import { Observable } from 'rxjs/Rx';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

    constructor(private _toastr: ToastrService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (next.handle(req).do) {
            return next.handle(req).do(event => { }, error => {
                console.log(error.error);
                if (error instanceof HttpErrorResponse && error.status === 500) {
                    this._toastr.error(error.error.message, 'Ops!');
                }
                if (error instanceof HttpErrorResponse && error.status > 500) {
                    this._toastr.error(error.error.message, 'Ops!');
                }
                if (error instanceof HttpErrorResponse && error.status === 401) {
                    this._toastr.error('Login ou senha inválido!', 'Ops!');
                }
                if (error instanceof HttpErrorResponse && error.status === 403) {
                    this._toastr.error('Sessão inválida! Efetue um novo Login!', 'Ops!');
                    localStorage.removeItem('jwt');
                }
            });
        }
        // return next.handle(req).map(event => {
        //     return event;
        // });
        return next.handle(req).catch((error, caught) => {
            // intercept the respons error and displace it to the console
            console.log(error);
            // return the error to the method that called it
            return Observable.throw(error);
        }) as any;
    }
}

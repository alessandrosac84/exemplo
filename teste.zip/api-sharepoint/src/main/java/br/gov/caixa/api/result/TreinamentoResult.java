package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.TreinamentoDto;

public class TreinamentoResult extends BasicResult {

	private List<TreinamentoDto> list;
	private TreinamentoDto treinamento;

	public List<TreinamentoDto> getList() {
		return list;
	}

	public void setList(List<TreinamentoDto> list) {
		this.list = list;
	}

	public TreinamentoDto getTreinamento() {
		return treinamento;
	}

	public void setTreinamento(TreinamentoDto treinamento) {
		this.treinamento = treinamento;
	}
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jmw-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  pageTitle = 'Dashboard';
  options;
  data;

  constructor() { }

  ngOnInit() {
    this.options = {
      chart: {
        type: 'pieChart',
        height: 150,
        x: function (d) { return d.key; },
        y: function (d) { return d.y; },
        showLabels: false,
        color: ['#28a745', '#D54C53', '#eedd82'],
        duration: 500,
        labelThreshold: 0.01,
        labelSunbeamLayout: true,
        margin: {
          left: -25,
        },
        legend: {
          margin: {
            top: 2,
            right: 15,
            bottom: 0,
            left: -15
          }
        }
      }
    };

    this.data = [
      {
        key: 'Success',
        y: 5
      },
      {
        key: 'Fail',
        y: 2
      },
      {
        key: 'Abort',
        y: 9
      }
    ];
  }
}

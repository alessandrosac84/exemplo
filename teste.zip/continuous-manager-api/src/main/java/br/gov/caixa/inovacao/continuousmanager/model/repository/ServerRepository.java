package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.gov.caixa.inovacao.continuousmanager.model.entity.server.Server;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.TypeServer;

@ApplicationScoped
public class ServerRepository {

	@Inject
	private EntityManager entityManager;

	
	public List<Server> findAll(TypeServer typeServer) {
		
		return entityManager.createQuery("SELECT distinct s FROM Server s JOIN fetch s.flavor f JOIN fetch s.instances WHERE s.flavor.typeServer =:typeServer",Server.class)
				.setParameter("typeServer", typeServer).getResultList();
	}
	
}

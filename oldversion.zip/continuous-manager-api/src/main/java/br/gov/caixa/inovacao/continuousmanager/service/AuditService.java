/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Audit;
import br.gov.caixa.inovacao.continuousmanager.model.repository.AuditRepository;

/**
 * @author Fabio Iwakoshi
 *
 */
@Logged
@Stateless
public class AuditService {
	
	@Inject
	private Logger log;

	@Inject
	private AuditRepository auditRepository;

	@Transactional(value=TxType.REQUIRES_NEW)
	public Audit save(@Valid Audit auditoria) {
		log.log(Level.FINE, "Salvando Audit :: {0}", auditoria.getFunctionality());
		return auditRepository.save(auditoria);
	}
}

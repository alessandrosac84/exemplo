import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { ProjectService } from '../../../../../shared/service/project.service';
import { Repository } from '../../../../../shared/model/entity/repository.model';
import { Branch } from '../../../../../shared/model/entity/branch.model';
import { FormControl } from '@angular/forms';
import { Build } from '../../../../../shared/model/entity/build.model';

@Component({
  selector: 'cm-detail',
  templateUrl: './detail.component.html',
  styles: []
})
export class DetailComponent implements OnInit {

  repository: Repository;
  branch: Branch;
  build: Build;
  selectedTab = new FormControl(0);

  constructor(
    private _projectService: ProjectService,
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit() {
    if (localStorage.getItem('project') != null) {
      this._projectService.getRepository(+localStorage.getItem('project'), this._activatedRoute.snapshot.params['repository'])
        .subscribe(data => this.repository = data);
    } else {
      this._router.navigateByUrl('/projects');
    }
  }

  loadBuildTab(branch) {
    this.branch = branch;
    this.selectedTab.setValue(2);
  }
}

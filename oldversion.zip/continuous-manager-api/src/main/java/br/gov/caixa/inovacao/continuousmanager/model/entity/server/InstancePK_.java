package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-14T14:54:20.995-0300")
@StaticMetamodel(InstancePK.class)
public class InstancePK_ {
	public static volatile SingularAttribute<InstancePK, String> server;
	public static volatile SingularAttribute<InstancePK, String> name;
}

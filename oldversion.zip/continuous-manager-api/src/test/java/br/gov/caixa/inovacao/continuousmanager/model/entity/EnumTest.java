package br.gov.caixa.inovacao.continuousmanager.model.entity;

import org.junit.Test;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsPhase;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.EditType;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.LocalError;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGateEnum;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;


/**
 * Classe para testes superficiais de Enums
 * 
 * @author Fabio Iwakoshi
 *
 */
public class EnumTest {

	/**
	 * Listar todas as Wallets.
	 */
	@Test
	public void testListAllWalletsDefault() {
		// Act
		UtilReflection.superficialEnumCodeCoverage(Action.class);
		UtilReflection.superficialEnumCodeCoverage(AscDesc.class);
		UtilReflection.superficialEnumCodeCoverage(Environment.class);
		UtilReflection.superficialEnumCodeCoverage(JenkinsResult.class);
		UtilReflection.superficialEnumCodeCoverage(JenkinsPhase.class);
		UtilReflection.superficialEnumCodeCoverage(ServerType.class);
		UtilReflection.superficialEnumCodeCoverage(EditType.class);
		UtilReflection.superficialEnumCodeCoverage(LocalError.class);
		UtilReflection.superficialEnumCodeCoverage(QualityGateEnum.class);
		Environment.DES.getDescription();
		ServerType.JENKINS.getDescription();
		JenkinsResult.SUCCESS.getDescription();
		JenkinsPhase.FINALIZED.getDescription();
		QualityGateEnum.OK.getDescription();
		EditType.fromString("add");
		LocalError.fromString("Sonar");
	}
	
}

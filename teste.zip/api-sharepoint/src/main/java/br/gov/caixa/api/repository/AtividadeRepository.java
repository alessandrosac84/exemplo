package br.gov.caixa.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import br.gov.caixa.api.model.Atividade;
import br.gov.caixa.api.model.Disciplina;

public interface AtividadeRepository extends JpaRepository<Atividade, Long> {
	public List<Atividade> findByDisciplina(Disciplina disciplina);
	
	@Query("select a from Atividade a where a.disciplina = ?1 order by a.uid")	
	public List<Atividade> findByDisciplinaOrder(Disciplina disciplina);
	
	@Query("select a from Atividade a join fetch a.disciplina d")
	public List<Atividade> findAll();
	
	@Query("select a from Atividade a join fetch a.disciplina d where a.ativo = true")
	public List<Atividade> findAllAtivas();
	
	@Query("select a from Atividade a join fetch a.disciplina d where a.ativo = true order by a.nome")
	public List<Atividade> findAllAlfaAtivas();
	
	@Modifying
	@Transactional
	@Query("update Atividade a set a.ativo = ?1 where a.uid = ?2")
	int setAtivo(Boolean ativo, Long uid);
		
	@Modifying
	@Transactional
	@Query("update Atividade a set a.complemento.uid = ?1 where a.uid = ?2")
	int setComplemento(Long complementoUid , Long uid);
	
	public Atividade findByNome(String nome);
	
}

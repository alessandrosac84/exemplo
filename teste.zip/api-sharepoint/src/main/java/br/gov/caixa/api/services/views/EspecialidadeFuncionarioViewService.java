package br.gov.caixa.api.services.views;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.model.views.EspecialidadeFuncionarioView;
import br.gov.caixa.api.repository.views.EspecialidadeFuncionarioFerramentaViewRepository;
import br.gov.caixa.api.repository.views.EspecialidadeFuncionarioViewRepository;
import br.gov.caixa.api.result.views.EspecialidadeFuncionarioViewResult;

@Named
public class EspecialidadeFuncionarioViewService {
	
	@Inject
	EspecialidadeFuncionarioViewRepository repository;
	
	@Inject
	EspecialidadeFuncionarioFerramentaViewRepository ferramentaRepository;
	
	public EspecialidadeFuncionarioViewResult listAll() {

		EspecialidadeFuncionarioViewResult result = new EspecialidadeFuncionarioViewResult();
		try {
			List<EspecialidadeFuncionarioView> lista = repository.findAll();

			if (lista != null) {
				result.setList(lista);
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma especialidadeView.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}
	

	public EspecialidadeFuncionarioViewResult listEspecialidadeFuncionarioViewByEspecialidadeId(Long idEspecialidade) {
		EspecialidadeFuncionarioViewResult result = new EspecialidadeFuncionarioViewResult();
		try {
			
			//List<EspecialidadeFuncionarioBase> listaGeral = new ArrayList<EspecialidadeFuncionarioBase>() ;			
			List<EspecialidadeFuncionarioView> lista = new ArrayList<EspecialidadeFuncionarioView>();
			
			lista = repository.findByEspecialidadeId(idEspecialidade);
					
			//listaGeral.addAll(lista1);
						
			result.setList(lista);					
			result.setMessage("Executado com sucesso.");
			
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

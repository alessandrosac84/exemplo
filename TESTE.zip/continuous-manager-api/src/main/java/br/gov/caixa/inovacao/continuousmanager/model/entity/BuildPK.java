package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * The primary key class for the build database table.
 * 
 * @author Fabio Iwakoshi
 */
@Embeddable
public class BuildPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@JsonView({ViewJson.BuildView.class, ViewJson.CommitView.class})
	@Column(unique=true, nullable=false)
	private Integer id;

	@JsonView(ViewJson.BuildView.class)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String project;

	@JsonView(ViewJson.BuildView.class)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String wallet;

	@JsonView({ViewJson.BuildView.class, ViewJson.CommitView.class})
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=50)
	private String job;

	public BuildPK() {
		/* class constructor intentionally left blank */
	}
	public Integer getId() {
		return this.id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProject() {
		return this.project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getWallet() {
		return this.wallet;
	}
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}
	public String getJob() {
		return this.job;
	}
	public void setJob(String job) {
		this.job = job;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof BuildPK)) {
			return false;
		}
		BuildPK castOther = (BuildPK)other;
		return 
			this.id.equals(castOther.id)
			&& this.project.equals(castOther.project)
			&& this.wallet.equals(castOther.wallet)
			&& this.job.equals(castOther.job);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.id.hashCode();
		hash = hash * prime + this.project.hashCode();
		hash = hash * prime + this.wallet.hashCode();
		hash = hash * prime + this.job.hashCode();
		
		return hash;
	}
}
package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.EspecialidadeAtividade;

public class EspecialidadeAtividadeDto {

	private Long uid;
	private Integer rating;	
	private EspecialidadeDto especialidadeDto;
	private AtividadeDto atividadeDto;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public EspecialidadeDto getEspecialidadeDto() {
		return especialidadeDto;
	}

	public void setEspecialidadeDto(EspecialidadeDto especialidadeDto) {
		this.especialidadeDto = especialidadeDto;
	}

	public AtividadeDto getAtividadeDto() {
		return atividadeDto;
	}

	public void setAtividadeDto(AtividadeDto atividadeDto) {
		this.atividadeDto = atividadeDto;
	}


	public static EspecialidadeAtividadeDto fromEspecialidadeAtividadeDto(EspecialidadeAtividade especialidadeAtividade) {
		EspecialidadeAtividadeDto dto = new EspecialidadeAtividadeDto();
		
		dto.setUid(especialidadeAtividade.getUid());
		dto.setRating(especialidadeAtividade.getRating());
		dto.setEspecialidadeDto(EspecialidadeDto.fromEspecialidadeToDto(especialidadeAtividade.getEspecialidade()));
		dto.setAtividadeDto(AtividadeDto.fromAtividadeToDto(especialidadeAtividade.getAtividade()));	
		
		return dto;
	}
	
	public static List<EspecialidadeAtividadeDto> fromEspecialidadeAtividadeToListDto(List<EspecialidadeAtividade> especialidadeAtividades) {
		List<EspecialidadeAtividadeDto> returnList = new ArrayList<EspecialidadeAtividadeDto>();
		
		for (EspecialidadeAtividade especialidadeAtividade : especialidadeAtividades) {
			
			returnList.add(fromEspecialidadeAtividadeDto(especialidadeAtividade) );
		}
		return returnList;
	}	

}

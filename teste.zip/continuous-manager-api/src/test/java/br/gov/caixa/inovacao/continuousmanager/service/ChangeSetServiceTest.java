/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.repository.ChangeSetRepository;

/**
 * Classe de testes do ChangeSetService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ChangeSetServiceTest {
	
	@Mock
	private ChangeSetRepository changeSetRepository;

	@InjectMocks
	private ChangeSetService changeSetService;

	private ChangeSet changeSet;
	
	@Before
	public void before() {
		changeSet = EntityBuilder.createBuilds().get(0).getChangeSets().stream().findFirst().get();
		UtilReflection.setField(changeSetService, "log", Logger.getLogger(AuditService.class.getName()));
	}
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(changeSetRepository.save(Mockito.<ChangeSet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		
		// Act
		ChangeSet savedChangeSet = changeSetService.save(changeSet);

		// Then
		Assert.assertNotNull(savedChangeSet);
	}
}

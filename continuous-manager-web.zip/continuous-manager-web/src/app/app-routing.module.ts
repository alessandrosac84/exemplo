import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppAuthGuard } from './app.auth.guard';

const routes: Routes = [
  { path: '', loadChildren: './pages/public/home/home.module#HomeModule', pathMatch: 'full' },
  { path: 'projects', loadChildren: './pages/public/projects/projects.module#ProjectsModule', data: { preload: true, state: 'projects' } },
  { path: 'dashboard', loadChildren: './pages/private/dashboard/dashboard.module#DashboardModule', data: { state: 'dashboard' } },
  { path: 'info', loadChildren: './pages/public/info/info.module#InfoModule', data: { state: 'info' } },
  { path: 'builds', loadChildren: './pages/private/builds/builds.module#BuildsModule', data: { state: 'builds' } },
  { path: 'stage', loadChildren: './pages/private/stage/stage.module#StageModule', data: { state: 'stage' } },
  { path: 'settings', loadChildren: './pages/private/settings/settings.module#SettingsModule', data: { state: 'settings' } },
  { path: '**', redirectTo: '' }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

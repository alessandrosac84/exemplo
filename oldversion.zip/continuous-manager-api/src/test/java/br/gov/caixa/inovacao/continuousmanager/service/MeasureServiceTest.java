package br.gov.caixa.inovacao.continuousmanager.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.Measures;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.MeasuresPK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.MeasuresRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes do MeasureService.
 * 
 * @author Alessandro Carvalho
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class MeasureServiceTest {
	
	@Mock
	private MeasuresRepository measuresRepository;
	
	@InjectMocks
	private MeasuresService measuresService;
	
	private Measures measure = new Measures();
	
	private List<Measures> listMeasures = new ArrayList<>();
	
	
	@Before
	public void before() {
		UtilReflection.setField(measuresService, "log", Logger.getLogger(AuditService.class.getName()));
		measure.setBugs(0);
		measure.setCodeSmells(0);;
		measure.setCommentLines(0);
		measure.setCommentLinesPercent(BigDecimal.ZERO);
		measure.setCommit(new Commit());
		measure.setComplexity(0);
		measure.setCoverage(BigDecimal.ZERO);
		measure.setDuplicatedLines(0);
		measure.setDuplicatedLinesPercent(BigDecimal.ZERO);
		measure.setFiles(0);
		measure.setId(new MeasuresPK());
		measure.setLines(1000000);
		measure.setNewBugs(0);
		measure.setNewCodeSmells(0);
		measure.setNewCoverage(BigDecimal.ZERO);
		measure.setNewDuplicatedLines(0);
		measure.setNewDuplicatedLinesPercent(BigDecimal.ZERO);
		measure.setNewLines(1000);
		measure.setNewMaintainabilityRating(BigDecimal.ZERO);
		measure.setNewReliabilityRating(BigDecimal.ZERO);
		measure.setNewSecurityRating(BigDecimal.ZERO);
		measure.setNewViolations(0);
		measure.setNewVulnerabilities(0);
		measure.setReliabilityRating(BigDecimal.ZERO);
		measure.setSecurityRating(BigDecimal.ZERO);
		measure.setSqaleRating(BigDecimal.ZERO);
		measure.setUnitTests(1000);
		measure.setViolations(0);
		measure.setVulnerabilities(0);
	}

	@Test
	public void testSave() {
		// Arrange
		Mockito.when(measuresRepository.save(Mockito.<Measures>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		
		// Act
		measuresService.save(measure);

		// Then
		Assert.assertNotNull(measure);
	}
	
	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(measuresRepository.findById("inovacao", "continuous-manager-web", "jhsdjkasjkd")).thenReturn(measure);
		
		// Act
		Measures ms = measuresService.findById("inovacao", "continuous-manager-web", "jhsdjkasjkd");

		// Then
		Assert.assertNotNull(ms);
		Assert.assertEquals(0, ms.getBugs().intValue());
		Assert.assertEquals(0, ms.getCodeSmells().intValue());
		Assert.assertEquals(0, ms.getCommentLines().intValue());
		Assert.assertEquals(0, ms.getCommentLinesPercent().intValue());
		Assert.assertNotNull(ms.getCommit());
		Assert.assertEquals(0, ms.getComplexity().intValue());
		Assert.assertEquals(0, ms.getCoverage().intValue());
		Assert.assertEquals(0, ms.getDuplicatedLines().intValue());
		Assert.assertEquals(0, ms.getDuplicatedLinesPercent().intValue());
		Assert.assertEquals(0, ms.getFiles().intValue());
		Assert.assertEquals(1000000, ms.getLines().intValue());
		Assert.assertEquals(0, ms.getNewBugs().intValue());
		Assert.assertEquals(0, ms.getNewCodeSmells().intValue());
		Assert.assertEquals(0, ms.getNewCoverage().intValue());
		Assert.assertEquals(0, ms.getNewDuplicatedLines().intValue());
		Assert.assertEquals(0, ms.getNewDuplicatedLinesPercent().intValue());
		Assert.assertEquals(1000, ms.getNewLines().intValue());
		Assert.assertEquals(0, ms.getNewMaintainabilityRating().intValue());
		Assert.assertEquals(0, ms.getNewReliabilityRating().intValue());
		Assert.assertEquals(0, ms.getNewSecurityRating().intValue());
		Assert.assertEquals(0, ms.getNewViolations().intValue());
		Assert.assertEquals(0, ms.getNewVulnerabilities().intValue());
		Assert.assertEquals(0, ms.getReliabilityRating().intValue());
		Assert.assertEquals(0, ms.getSecurityRating().intValue());
		Assert.assertEquals(0, ms.getSqaleRating().intValue());
		Assert.assertEquals(1000, ms.getUnitTests().intValue());
		Assert.assertEquals(0, ms.getViolations().intValue());
		Assert.assertEquals(0, ms.getVulnerabilities().intValue());
	}
	
	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(measuresRepository.findAll(0, Integer.MAX_VALUE, "", "id", AscDesc.ASC)).thenReturn(new ArrayList<Measures>());
		
		// Act
		List<Measures> listMeasures = measuresService.findAll(0, Integer.MAX_VALUE, "", "id", AscDesc.ASC);

		// Then
		Assert.assertEquals(0, listMeasures.size());
	}
	
	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(measuresRepository.countAll("")).thenReturn((long) listMeasures.size());
		
		// Act
		Long contMeasure = measuresService.countAll("");

		// Then
		Assert.assertEquals(0, contMeasure.longValue());
	}
}

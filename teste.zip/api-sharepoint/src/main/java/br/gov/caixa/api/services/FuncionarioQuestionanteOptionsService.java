package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.FuncionarioQuestionanteOptionsDto;
import br.gov.caixa.api.model.FuncionarioQuestionanteOptions;
import br.gov.caixa.api.repository.FuncionarioQuestionanteOptionsRepository;
import br.gov.caixa.api.result.FuncionarioQuestionanteOptionsResult;

@Named
public class FuncionarioQuestionanteOptionsService {
	
	@Inject
	private FuncionarioQuestionanteOptionsRepository repository;
	
	public FuncionarioQuestionanteOptionsResult listAll() {
		List<FuncionarioQuestionanteOptions> lista = (repository.findAll());
		FuncionarioQuestionanteOptionsResult result = new FuncionarioQuestionanteOptionsResult();
		
		result.setList(FuncionarioQuestionanteOptionsDto.fromFuncionarioQuestionanteOptionsToListDto(lista));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}

	public FuncionarioQuestionanteOptionsResult listFuncionariosQuestionantesOptionsByQuestionarioId(Long questionarioId) {
		List<FuncionarioQuestionanteOptions> lista = repository.findByQuestionarioByQuestionarioId(questionarioId);
		
		FuncionarioQuestionanteOptionsResult result = new FuncionarioQuestionanteOptionsResult();
		
		result.setList(FuncionarioQuestionanteOptionsDto.fromFuncionarioQuestionanteOptionsToListDto(lista));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}	
	
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpResponse } from '@angular/common/http';
import { Title } from '@angular/platform-browser';

import { ToastrService } from 'ngx-toastr';

import { WalletService } from './../../shared/service/wallet.service';

import { ChangeSet } from './../../shared/model/changeset.model';
import { Project } from './../../shared/model/project.model';
import { Commit } from './../../shared/model/commit.model';
import { Wallet } from './../../shared/model/wallet.model';

@Component({
  selector: 'jmw-dev',
  templateUrl: './dev.component.html',
  styleUrls: ['./dev.component.scss']
})
export class DevComponent implements OnInit {
  pageTitle = 'Dev Manager';

  projectId: Project;
  walletId: Wallet;

  wallets: Wallet[];
  projects: Project[];
  commits: Commit[];
  changeSets: ChangeSet[];

  page: number;
  total: number;

  constructor(
    private _title: Title,
    private _walletService: WalletService,
    private _toastr: ToastrService
  ) {}

  ngOnInit() {
    this._title.setTitle(this.pageTitle);
    this._walletService.getWallets().subscribe(data => {
      this.wallets = data;
    });
    this.page = 1;
  }

  chargeProjects() {
    this.projects = [];
    this.projectId = undefined;
    if (!!this.walletId) {
      this._walletService.getProjects(this.walletId.id).subscribe(data => {
        this.projects = data;
      });
    }
  }

  chargeCommits() {
    this.commits = [];
    if (!!this.projectId) {
      this._walletService.getCommitsSuccess(this.walletId.id, this.projectId.id.id, this.page).subscribe(res => {
          this.commits = res.body;
          this.commits.forEach(commit => {
            commit.changeSets.sort((a, b) => (a.build.id.id > b.build.id.id ? -1 : 1));
          });
          this.total = +res.headers.get('Content-Range').substring(res.headers.get('Content-Range').indexOf('/') + 1);
        });
    }
  }

  rebuild(commit: Commit) {
    this._walletService
      .rebuild(
        this.walletId.id,
        this.projectId.id.id,
        commit.changeSets[0].build.id.job,
        commit.changeSets[0].build.id.id,
        commit.id.commit
      )
      .subscribe(data => {
        this._toastr.info('Sua solicitação foi enviada ao Servidor!', 'Info');
      });
  }

  pageChanged(event) {
    this.page = event;
    this.chargeCommits();
  }
}

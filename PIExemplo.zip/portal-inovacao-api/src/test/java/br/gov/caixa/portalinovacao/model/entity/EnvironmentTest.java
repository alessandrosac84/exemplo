package br.gov.caixa.portalinovacao.model.entity;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class EnvironmentTest {

	@Test
	public void testGetDescription() {
		Environment env1 = Environment.DESENVOLVIMENTO;
		Environment env2 = Environment.HOMOLOGACAO;
		Environment env3 = Environment.PRODUCAO;
		Environment env4 = Environment.TESTE_QUALIDADE_SOFTWARE;
		
		assertEquals(Environment.DESENVOLVIMENTO.getDescription(), env1.getDescription());
		assertEquals(Environment.HOMOLOGACAO.getDescription(), env2.getDescription());
		assertEquals(Environment.PRODUCAO.getDescription(), env3.getDescription());
		assertEquals(Environment.TESTE_QUALIDADE_SOFTWARE.getDescription(), env4.getDescription());		
	}

}

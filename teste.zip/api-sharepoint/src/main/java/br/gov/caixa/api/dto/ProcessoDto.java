package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.Processo;

public class ProcessoDto {

	private Long uid;
	private String nome;
	private Boolean ativo;
	private CategoriaProcessoDto categoriaProcesso;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

	public CategoriaProcessoDto getCategoriaProcesso() {
		return categoriaProcesso;
	}

	public void setCategoriaProcesso(
			CategoriaProcessoDto categoriaProcesso) {
		this.categoriaProcesso = categoriaProcesso;
	}
	
	public static ProcessoDto fromProcessoToDto(Processo processo){
		ProcessoDto dto = new ProcessoDto();
		dto.setUid(processo.getUid());
		dto.setNome(processo.getNome());
		dto.setAtivo(processo.getAtivo());
		
		if(processo.getCategoriaProcesso() != null){
			dto.setCategoriaProcesso(CategoriaProcessoDto.fromCategoriaProcessoToDto(processo.getCategoriaProcesso()));
		}
		return dto;
	}

	public static List<ProcessoDto> fromProcessoToListDto(List<Processo> lista) {
		List<ProcessoDto> list = new ArrayList<ProcessoDto>();
		
		for (Processo processo : lista) {
			ProcessoDto dto = new ProcessoDto();
			dto.setUid(processo.getUid());
			dto.setNome(processo.getNome());
			dto.setAtivo(processo.getAtivo());
			
			dto.setCategoriaProcesso(CategoriaProcessoDto.fromCategoriaProcessoToDto(processo.getCategoriaProcesso()));
			list.add(dto);
		}
		return list;
	}
}

package br.gov.caixa.api.repository.views;

import org.springframework.data.jpa.repository.JpaRepository;

import br.gov.caixa.api.model.views.AtivosPercentualConhecimentoView;

public interface AtivosPercentualConhecimentoViewRepository extends JpaRepository<AtivosPercentualConhecimentoView, Long> {
	

}

package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the funcionalidade database table.
 * 
 */
@Entity
@Table(name="funcionalidade")
@NamedQuery(name="Funcionalidade.findAll", query="SELECT f FROM Funcionalidade f")
public class Funcionalidade implements Serializable, IEntity<String>  {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(nullable=false, length=50)
	private String nome;

	@JsonIgnore
	//bi-directional many-to-one association to FuncionarioFuncionalidade
	@OneToMany(mappedBy="funcionalidade")
	private Set<FuncionarioFuncionalidade> funcionarioFuncionalidades;

	@JsonIgnore
	//bi-directional many-to-one association to FuncionalidadeCargo
	@OneToMany(mappedBy="funcionalidade")
	private Set<FuncionalidadeCargo> funcionalidadeCargos;

	@JsonIgnore
	//bi-directional many-to-one association to UrlFuncionalidade
	@OneToMany(mappedBy="funcionalidade")
	private Set<UrlFuncionalidade> urlFuncionalidades;

	public Funcionalidade() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Set<FuncionarioFuncionalidade> getFuncionarioFuncionalidades() {
		return this.funcionarioFuncionalidades;
	}

	public void setFuncionarioFuncionalidades(Set<FuncionarioFuncionalidade> funcionarioFuncionalidades) {
		this.funcionarioFuncionalidades = funcionarioFuncionalidades;
	}

	public FuncionarioFuncionalidade addFuncionarioFuncionalidade(FuncionarioFuncionalidade funcionarioFuncionalidade) {
		getFuncionarioFuncionalidades().add(funcionarioFuncionalidade);
		funcionarioFuncionalidade.setFuncionalidade(this);

		return funcionarioFuncionalidade;
	}

	public FuncionarioFuncionalidade removeFuncionarioFuncionalidade(FuncionarioFuncionalidade funcionarioFuncionalidade) {
		getFuncionarioFuncionalidades().remove(funcionarioFuncionalidade);
		funcionarioFuncionalidade.setFuncionalidade(null);

		return funcionarioFuncionalidade;
	}

	public Set<FuncionalidadeCargo> getFuncionalidadeCargos() {
		return this.funcionalidadeCargos;
	}

	public void setFuncionalidadeCargos(Set<FuncionalidadeCargo> funcionalidadeCargos) {
		this.funcionalidadeCargos = funcionalidadeCargos;
	}

	public FuncionalidadeCargo addFuncionalidadeCargo(FuncionalidadeCargo funcionalidadeCargo) {
		getFuncionalidadeCargos().add(funcionalidadeCargo);
		funcionalidadeCargo.setFuncionalidade(this);

		return funcionalidadeCargo;
	}

	public FuncionalidadeCargo removeFuncionalidadeCargo(FuncionalidadeCargo funcionalidadeCargo) {
		getFuncionalidadeCargos().remove(funcionalidadeCargo);
		funcionalidadeCargo.setFuncionalidade(null);

		return funcionalidadeCargo;
	}

	public Set<UrlFuncionalidade> getUrlFuncionalidades() {
		return this.urlFuncionalidades;
	}

	public void setUrlFuncionalidades(Set<UrlFuncionalidade> urlFuncionalidades) {
		this.urlFuncionalidades = urlFuncionalidades;
	}

	public UrlFuncionalidade addUrlFuncionalidade(UrlFuncionalidade urlFuncionalidade) {
		getUrlFuncionalidades().add(urlFuncionalidade);
		urlFuncionalidade.setFuncionalidade(this);

		return urlFuncionalidade;
	}

	public UrlFuncionalidade removeUrlFuncionalidade(UrlFuncionalidade urlFuncionalidade) {
		getUrlFuncionalidades().remove(urlFuncionalidade);
		urlFuncionalidade.setFuncionalidade(null);

		return urlFuncionalidade;
	}

	@Override
	public boolean isTheSameObject(IEntity<String> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		Funcionalidade other = (Funcionalidade) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Funcionalidade other = (Funcionalidade) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;
	}

}
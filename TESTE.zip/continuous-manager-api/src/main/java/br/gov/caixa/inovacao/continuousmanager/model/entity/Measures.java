package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * The persistent class for the measures database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name="measures")
@NamedQuery(name="Measures.findAll", query="SELECT s FROM Measures s")
public class Measures implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonView(ViewJson.SonarView.class)
	@EmbeddedId
	private MeasuresPK id;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(nullable=false)
	private Integer complexity;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(nullable=false)
	private Integer lines;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(nullable=false)
	private Integer bugs;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(nullable=false)
	private Integer vulnerabilities;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="code_smells", nullable=false)
	private Integer codeSmells;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(nullable=false, precision=4, scale=1)
	private BigDecimal coverage;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="unit_tests", nullable=false)
	private Integer unitTests;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="duplicated_lines", nullable=false, precision=4, scale=1)
	private BigDecimal duplicatedLines;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_code_smells", nullable=false)
	private Integer newCodeSmells;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_coverage", nullable=false, precision=4, scale=1)
	private BigDecimal newCoverage;

	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_lines", nullable=false)
	private Integer newLines;

	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_vulnerabilities", nullable=false)
	private Integer newVulnerabilities;

	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_bugs", nullable=false)
	private Integer newBugs;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="comment_lines", nullable=false, precision=4, scale=1)
	private BigDecimal commentLines;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="comment_lines_density", nullable=false, precision=4, scale=1)
	private BigDecimal commentLinesPercent;

	@JsonView(ViewJson.SonarView.class)
	@Column(name="duplicated_lines_density", nullable=false, precision=4, scale=1)
	private BigDecimal duplicatedLinesPercent;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_duplicated_lines", nullable=false, precision=4, scale=1)
	private BigDecimal newDuplicatedLines;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_duplicated_lines_density", nullable=false, precision=4, scale=1)
	private BigDecimal newDuplicatedLinesPercent;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(nullable=false)
	private Integer violations;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_violations", nullable=false)
	private Integer newViolations;

	@JsonView(ViewJson.SonarView.class)
	@Column(name="sqale_rating", nullable=false, precision=1, scale=0)
	private BigDecimal sqaleRating;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_maintainability_rating", nullable=false, precision=1, scale=0)
	private BigDecimal newMaintainabilityRating;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="security_rating", nullable=false, precision=1, scale=0)
	private BigDecimal securityRating;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_security_rating", nullable=false, precision=1, scale=0)
	private BigDecimal newSecurityRating;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="reliability_rating", nullable=false, precision=1, scale=0)
	private BigDecimal reliabilityRating;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_reliability_rating", nullable=false, precision=1, scale=0)
	private BigDecimal newReliabilityRating;

	@JsonView(ViewJson.SonarView.class)
	@Column(nullable=false)
	private Integer files;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="quality_gate", nullable=false)
	private String qualityGate;

	@JsonView(ViewJson.SonarView.class)
	@Column(nullable=false)
	private String version;
	
	//bi-directional many-to-one association to QualityGate
	@OneToMany(mappedBy = "measures")
	private Set<QualityGate> qualityGates;
	
	
	//bi-directional one-to-one association to Project
	@JsonView(ViewJson.SonarView.class)
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="project", referencedColumnName="project", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="commit", referencedColumnName="commit", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private Commit commit;

	public Measures() {
		/* class constructor intentionally left blank */
	}

	public MeasuresPK getId() {
		return this.id;
	}

	public void setId(MeasuresPK id) {
		this.id = id;
	}

	public Integer getBugs() {
		return this.bugs;
	}

	public void setBugs(Integer bugs) {
		this.bugs = bugs;
	}

	public Integer getCodeSmells() {
		return this.codeSmells;
	}

	public void setCodeSmells(Integer codeSmells) {
		this.codeSmells = codeSmells;
	}

	public Integer getLines() {
		return this.lines;
	}

	public void setLines(Integer lines) {
		this.lines = lines;
	}

	public Integer getUnitTests() {
		return this.unitTests;
	}

	public void setUnitTests(Integer unitTests) {
		this.unitTests = unitTests;
	}

	public Integer getVulnerabilities() {
		return this.vulnerabilities;
	}

	public void setVulnerabilities(Integer vulnerabilities) {
		this.vulnerabilities = vulnerabilities;
	}

	public Commit getCommit() {
		return this.commit;
	}

	public void setCommit(Commit commit) {
		this.commit = commit;
	}

	/**
	 * @return the coverage
	 */
	public BigDecimal getCoverage() {
		return coverage;
	}

	/**
	 * @param coverage the coverage to set
	 */
	public void setCoverage(BigDecimal coverage) {
		this.coverage = coverage;
	}

	/**
	 * @return the duplicatedLines
	 */
	public BigDecimal getDuplicatedLines() {
		return duplicatedLines;
	}

	/**
	 * @param duplicatedLines the duplicatedLines to set
	 */
	public void setDuplicatedLines(BigDecimal duplicatedLines) {
		this.duplicatedLines = duplicatedLines;
	}

	/**
	 * @return the newCodeSmells
	 */
	public Integer getNewCodeSmells() {
		return newCodeSmells;
	}

	/**
	 * @param newCodeSmells the newCodeSmells to set
	 */
	public void setNewCodeSmells(Integer newCodeSmells) {
		this.newCodeSmells = newCodeSmells;
	}

	/**
	 * @return the newCoverage
	 */
	public BigDecimal getNewCoverage() {
		return newCoverage;
	}

	/**
	 * @param newCoverage the newCoverage to set
	 */
	public void setNewCoverage(BigDecimal newCoverage) {
		this.newCoverage = newCoverage;
	}

	/**
	 * @return the newLines
	 */
	public Integer getNewLines() {
		return newLines;
	}

	/**
	 * @param newLines the newLines to set
	 */
	public void setNewLines(Integer newLines) {
		this.newLines = newLines;
	}

	/**
	 * @return the newVulnerabilities
	 */
	public Integer getNewVulnerabilities() {
		return newVulnerabilities;
	}

	/**
	 * @param newVulnerabilities the newVulnerabilities to set
	 */
	public void setNewVulnerabilities(Integer newVulnerabilities) {
		this.newVulnerabilities = newVulnerabilities;
	}

	/**
	 * @return the newBugs
	 */
	public Integer getNewBugs() {
		return newBugs;
	}

	/**
	 * @param newBugs the newBugs to set
	 */
	public void setNewBugs(Integer newBugs) {
		this.newBugs = newBugs;
	}

	/**
	 * @return the commentLines
	 */
	public BigDecimal getCommentLines() {
		return commentLines;
	}

	/**
	 * @param commentLines the commentLines to set
	 */
	public void setCommentLines(BigDecimal commentLines) {
		this.commentLines = commentLines;
	}

	/**
	 * @return the commentLinesPercent
	 */
	public BigDecimal getCommentLinesPercent() {
		return commentLinesPercent;
	}

	/**
	 * @param commentLinesPercent the commentLinesPercent to set
	 */
	public void setCommentLinesPercent(BigDecimal commentLinesPercent) {
		this.commentLinesPercent = commentLinesPercent;
	}

	/**
	 * @return the duplicatedLinesPercent
	 */
	public BigDecimal getDuplicatedLinesPercent() {
		return duplicatedLinesPercent;
	}

	/**
	 * @param duplicatedLinesPercent the duplicatedLinesPercent to set
	 */
	public void setDuplicatedLinesPercent(BigDecimal duplicatedLinesPercent) {
		this.duplicatedLinesPercent = duplicatedLinesPercent;
	}

	/**
	 * @return the newDuplicatedLines
	 */
	public BigDecimal getNewDuplicatedLines() {
		return newDuplicatedLines;
	}

	/**
	 * @param newDuplicatedLines the newDuplicatedLines to set
	 */
	public void setNewDuplicatedLines(BigDecimal newDuplicatedLines) {
		this.newDuplicatedLines = newDuplicatedLines;
	}

	/**
	 * @return the newDuplicatedLinesPercent
	 */
	public BigDecimal getNewDuplicatedLinesPercent() {
		return newDuplicatedLinesPercent;
	}

	/**
	 * @param newDuplicatedLinesPercent the newDuplicatedLinesPercent to set
	 */
	public void setNewDuplicatedLinesPercent(BigDecimal newDuplicatedLinesPercent) {
		this.newDuplicatedLinesPercent = newDuplicatedLinesPercent;
	}

	/**
	 * @return the violations
	 */
	public Integer getViolations() {
		return violations;
	}

	/**
	 * @param violations the violations to set
	 */
	public void setViolations(Integer violations) {
		this.violations = violations;
	}

	/**
	 * @return the newViolations
	 */
	public Integer getNewViolations() {
		return newViolations;
	}

	/**
	 * @param newViolations the newViolations to set
	 */
	public void setNewViolations(Integer newViolations) {
		this.newViolations = newViolations;
	}

	/**
	 * @return the sqaleRating
	 */
	public BigDecimal getSqaleRating() {
		return sqaleRating;
	}

	/**
	 * @param sqaleRating the sqaleRating to set
	 */
	public void setSqaleRating(BigDecimal sqaleRating) {
		this.sqaleRating = sqaleRating;
	}

	/**
	 * @return the newMaintainabilityRating
	 */
	public BigDecimal getNewMaintainabilityRating() {
		return newMaintainabilityRating;
	}

	/**
	 * @param newMaintainabilityRating the newMaintainabilityRating to set
	 */
	public void setNewMaintainabilityRating(BigDecimal newMaintainabilityRating) {
		this.newMaintainabilityRating = newMaintainabilityRating;
	}

	/**
	 * @return the securityRating
	 */
	public BigDecimal getSecurityRating() {
		return securityRating;
	}

	/**
	 * @param securityRating the securityRating to set
	 */
	public void setSecurityRating(BigDecimal securityRating) {
		this.securityRating = securityRating;
	}

	/**
	 * @return the newSecurityRating
	 */
	public BigDecimal getNewSecurityRating() {
		return newSecurityRating;
	}

	/**
	 * @param newSecurityRating the newSecurityRating to set
	 */
	public void setNewSecurityRating(BigDecimal newSecurityRating) {
		this.newSecurityRating = newSecurityRating;
	}

	/**
	 * @return the reliabilityRating
	 */
	public BigDecimal getReliabilityRating() {
		return reliabilityRating;
	}

	/**
	 * @param reliabilityRating the reliabilityRating to set
	 */
	public void setReliabilityRating(BigDecimal reliabilityRating) {
		this.reliabilityRating = reliabilityRating;
	}

	/**
	 * @return the newReliabilityRating
	 */
	public BigDecimal getNewReliabilityRating() {
		return newReliabilityRating;
	}

	/**
	 * @param newReliabilityRating the newReliabilityRating to set
	 */
	public void setNewReliabilityRating(BigDecimal newReliabilityRating) {
		this.newReliabilityRating = newReliabilityRating;
	}

	/**
	 * @return the files
	 */
	public Integer getFiles() {
		return files;
	}

	/**
	 * @param files the files to set
	 */
	public void setFiles(Integer files) {
		this.files = files;
	}

	/**
	 * @return the complexity
	 */
	public Integer getComplexity() {
		return complexity;
	}

	/**
	 * @param complexity the complexity to set
	 */
	public void setComplexity(Integer complexity) {
		this.complexity = complexity;
	}

	/**
	 * @return the qualityGate
	 */
	public String getQualityGate() {
		return qualityGate;
	}

	/**
	 * @param qualityGate the qualityGate to set
	 */
	public void setQualityGate(String qualityGate) {
		this.qualityGate = qualityGate;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

}
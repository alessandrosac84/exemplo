/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.provider;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import br.gov.caixa.inovacao.continuousmanager.config.provider.EntityProvider;

/**
 * Classe de teste de LogProvider
 * 
 * @author Fabio Iwakoshi
 *
 */
public class EntityProviderTest {
	
	@Test
	public void entityProviderTest() {
		assertNotNull(new EntityProvider());
	}

}

# Continuous Manager

Interface em Angular para administracao de CI/CD CAIXA!

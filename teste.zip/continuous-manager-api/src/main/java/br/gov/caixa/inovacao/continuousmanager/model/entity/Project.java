package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * The persistent class for the project database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name = "project")
@NamedQuery(name = "Project.findAll", query = "SELECT p FROM Project p")
public class Project extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonView(ViewJson.ProjectView.class)
	private ProjectPK id;

	@Column(name = "git_repo", length = 150)
	private String gitRepo;

	@JsonView(ViewJson.ProjectView.class)
	@Column(nullable = false, length = 50)
	private String name;

	// bi-directional many-to-one association to GitRepo
	/*@OneToMany(mappedBy = "project")
	private Set<GitRepo> gitRepos;*/

	// bi-directional many-to-one association to Job
	/*@OneToMany(mappedBy = "project")
	private Set<Job> jobs;*/

	// bi-directional many-to-one association to Wallet
	/*@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "wallet", nullable = false, insertable = false, updatable = false)
	private Wallet wallet;*/

	// bi-directional one-to-one association to Sonar
	/*@OneToMany(mappedBy = "project", fetch = FetchType.LAZY)
	private  Set<Sonar> sonars;*/

	public Project() {
		/* class constructor intentionally left blank */
	}

	public ProjectPK getId() {
		return this.id;
	}

	public void setId(ProjectPK id) {
		this.id = id;
	}

	public String getGitRepo() {
		return this.gitRepo;
	}

	public void setGitRepo(String gitRepo) {
		this.gitRepo = gitRepo;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/*public Set<GitRepo> getGitRepos() {
		return this.gitRepos;
	}

	public void setGitRepos(Set<GitRepo> gitRepos) {
		this.gitRepos = gitRepos;
	}

	public GitRepo addGitRepo(GitRepo gitRepo) {
		getGitRepos().add(gitRepo);
		gitRepo.setProject(this);

		return gitRepo;
	}

	public GitRepo removeGitRepo(GitRepo gitRepo) {
		getGitRepos().remove(gitRepo);
		gitRepo.setProject(null);

		return gitRepo;
	}

	public Set<Job> getJobs() {
		return this.jobs;
	}

	public void setJobs(Set<Job> jobs) {
		this.jobs = jobs;
	}

	public Job addJob(Job job) {
		getJobs().add(job);
		job.setProject(this);

		return job;
	}

	public Job removeJob(Job job) {
		getJobs().remove(job);
		job.setProject(null);

		return job;
	}

	public Wallet getWallet() {
		return this.wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	public Set<Sonar> getSonars() {
		return this.sonars;
	}

	public void setSonars(Set<Sonar> sonars) {
		this.sonars = sonars;
	}*/

}
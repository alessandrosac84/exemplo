package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.ParameterRepository;

/**
 * Classe de servicos do Jenkins.
 * 
 * @author Fabio IWakoshi
 *
 */
@Stateless
public class ParameterService {

	@Inject
	private Logger log;
	
	@Inject
	private ParameterRepository parameterRepository;
	
	/**
	 * Obter parametros por ambiente
	 * 
	 * @param id
	 * @return Parameter
	 */
	public Parameter findById(ParameterPK id) {
		log.fine("Obtendo Parameter");
		return parameterRepository.findById(id);
	}
}

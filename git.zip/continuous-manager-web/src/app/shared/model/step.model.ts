export class Step {
    public name: string;
    public lines: string;
    public openStep: Boolean = false;
}

package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Job;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JobPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.ProjectEnvironment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.ProjectEnvironmentPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.ProjectPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Wallet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildLog;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildLogPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSetPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.EditType;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.LocalError;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Path;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.PathPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.Measures;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.MeasuresPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGate;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGatePK;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.Comparator;

public class EntityBuilder {

	public static List<Wallet> createWallets() {
		List<Wallet> wallets = new ArrayList<>();
		Wallet w = new Wallet();
		w.setId("inovacao");
		w.setCreatedAt(Calendar.getInstance());
		w.setName("Inovação");
		w.setProjects(new HashSet<>(createProjects(w)));
		w.setUpdatedAt(Calendar.getInstance());
		w.setUserInsert("f771274");
		w.setUserUpdate("f771274");
		wallets.add(w);
		
		Wallet w2 = new Wallet();
		w2.setId("backoffice");
		w2.setCreatedAt(Calendar.getInstance());
		w2.setName("Backoffice");
		w2.setProjects(new HashSet<>(createProjects(w)));
		w2.setUpdatedAt(Calendar.getInstance());
		w2.setUserInsert("f771274");
		w2.setUserUpdate("f771274");
		wallets.add(w2);
		
		return wallets;
	}

	public static List<Project> createProjects() {
		return createProjects(null);
	}

	public static List<Project> createProjects(Wallet wallet) {
		List<Project> projects = new ArrayList<>();
		Project p = new Project();
		p.setId(new ProjectPK());
		p.getId().setId("portal-inovacao");
		p.getId().setWallet("inovacao");
		p.setCreatedAt(Calendar.getInstance());
		p.setGitRepo("http://gitlab.gov.caixa/inovacao/portal-inovacao.git");
		p.setCommits(new HashSet<>(createCommits(p)));
		p.setJobs(new HashSet<>(createJobs(p)));
		p.setName("Portal Inovação");
		p.setUpdatedAt(Calendar.getInstance());
		p.setUserInsert("f771274");
		p.setUserUpdate("f771274");
		p.setWallet(wallet);
		p.setQualityGates(new HashSet<>(createQualityGates(p)));
		projects.add(p);
		
		Project p2 = new Project();
		p2.setId(new ProjectPK());
		p2.getId().setId("jenkinsman");
		p2.getId().setWallet("inovacao");
		p2.setCreatedAt(Calendar.getInstance());
		p2.setGitRepo("http://gitlab.gov.caixa/inovacao/jenkinsman.git");
		p2.setCommits(new HashSet<>(createCommits(p)));
		p2.setJobs(new HashSet<>(createJobs(p)));
		p2.setName("Jenkinsman");
		p2.setUpdatedAt(Calendar.getInstance());
		p2.setUserInsert("f771274");
		p2.setUserUpdate("f771274");
		p.setWallet(wallet);
		projects.add(p2);
		p2.setQualityGates(new HashSet<>(createQualityGates(p2)));
		p2.getId().equals(p.getId());
		p2.getId().hashCode();
		
		return projects;
	}
	
	public static List<Job> createJobs() {
		return createJobs(null);
	}

	public static List<Job> createJobs(Project project) {
		List<Job> jobs = new ArrayList<>();
		Job j = new Job();
		j.setId(new JobPK());
		j.getId().setId("portal-inovacao-api-ci-dev");
		j.getId().setProject("portal-inovacao");
		j.getId().setWallet("inovacao");
		j.setBuilds(new HashSet<>(createBuilds(j)));
		j.setCreatedAt(Calendar.getInstance());
		j.setName("Portal Inovacao - CI Dev");
		j.setProject(project);
		j.setUpdatedAt(Calendar.getInstance());
		j.setUserInsert("f771274");
		j.setUserUpdate("f771274");
		jobs.add(j);
		
		Job j2 = new Job();
		j2.setId(new JobPK());
		j2.getId().setId("portal-inovacao-api-cd-tqs");
		j2.getId().setProject("portal-inovacao");
		j2.getId().setWallet("inovacao");
		j2.setBuilds(new HashSet<>(createBuilds(j)));
		j2.setCreatedAt(Calendar.getInstance());
		j2.setName("Portal Inovacao - CD TQS");
		j2.setProject(project);
		j2.setUpdatedAt(Calendar.getInstance());
		j2.setUserInsert("f771274");
		j2.setUserUpdate("f771274");
		jobs.add(j2);
		j2.getId().equals(j.getId());
		j2.getId().hashCode();
		
		return jobs;
	}
	
	public static List<Build> createBuilds() {
		return createBuilds(null);
	}

	public static List<Build> createBuilds(Job job) {
		List<Build> builds = new ArrayList<>();
		
		Build b = new Build();
		b.setId(new BuildPK());
		b.getId().setId(1);
		b.getId().setWallet("inovacao");
		b.getId().setProject("continuous-manager-web");
		b.getId().setJob("continuous-manager-web-ci-dev");
		b.setChangeSets(new HashSet<>(createChangeSets(b)));
		b.setCreatedAt(Calendar.getInstance());
		b.setDescription("description");
		b.setDuration(new Date());
		b.setEstimateDuration(new Date());
		b.setJob(job);
		b.setBuildLogs(new HashSet<>(createBuildLogs(b)));
		b.setProjectEnvironments(new HashSet<>(createProjectEnvironments(b)));
		b.setResult(JenkinsResult.SUCCESS);
		builds.add(b);
		
		Build b2 = new Build();
		b2.setId(new BuildPK());
		b2.getId().setId(2);
		b2.getId().setWallet("inovacao");
		b2.getId().setProject("continuous-manager-web");
		b2.getId().setJob("continuous-manager-web-ci-tqs");
		b2.setChangeSets(new HashSet<>(createChangeSets(b)));
		b2.setCreatedAt(Calendar.getInstance());
		b2.setDescription("description");
		b2.setDuration(new Date());
		b2.setEstimateDuration(new Date());
		b2.setLocalError(LocalError.SONAR);
		b2.setJob(job);
		b2.setBuildLogs(new HashSet<>(createBuildLogs(b2)));
		b2.setProjectEnvironments(new HashSet<>(createProjectEnvironments(b)));
		b2.setResult(JenkinsResult.SUCCESS);
		builds.add(b2);
		b2.getId().equals(b.getId());
		b2.getId().hashCode();
		
		return builds;
	}

	public static List<BuildLog> createBuildLogs(Build build) {
		List<BuildLog> changeSet = new ArrayList<>();
		BuildLog c = new BuildLog();
		c.setId(new BuildLogPK());
		c.getId().setBuild(build.getId().getId());
		c.getId().setJob(build.getId().getJob());
		c.getId().setProject(build.getId().getProject());
		c.getId().setWallet(build.getId().getWallet());
		c.setBuild(build);
		c.setLog(
				"Started by GitLab push by Fabio Luis Iwakoshi da SIlva\n" +
						"Obtained Jenkinsfile-CI-DEV from git http://f771274@10.1.32.241/SUPORTE/JENKINSFILE/jenkins-manager-api.git\n" +
						"[Pipeline] node\n" +
						"Running on master in /opt/jenkins/workspace/jenkins-manager/jenkins-manager-api-ci-dev\n" +
						"[Pipeline] {\n" +
						"[Pipeline] stage\n" +
						"[Pipeline] { (Checkout)\n" +
						"[Pipeline] git\n" +
						"Cloning the remote Git repository\n" +
						"Cloning repository http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git\n" +
						" > git init /opt/jenkins/workspace/jenkins-manager/jenkins-manager-api-ci-dev # timeout=10\n" +
						"Fetching upstream changes from http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git\n" +
						" > git --version # timeout=10\n" +
						"using GIT_ASKPASS to set credentials GitLab\n" +
						" > git fetch --tags --progress http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git +refs/heads/*:refs/remotes/origin/*\n" +
						" > git config remote.origin.url http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git # timeout=10\n" +
						" > git config --add remote.origin.fetch +refs/heads/*:refs/remotes/origin/* # timeout=10\n" +
						" > git config remote.origin.url http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git # timeout=10\n" +
						"Fetching upstream changes from http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git\n" +
						"using GIT_ASKPASS to set credentials GitLab\n" +
						" > git fetch --tags --progress http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git +refs/heads/*:refs/remotes/origin/*\n" +
						"skipping resolution of commit e9d4e58767b2811346497981e7f6b4bd2f35adc8, since it originates from another repository\n" +
						" > git rev-parse refs/remotes/origin/master^{commit} # timeout=10\n" +
						" > git rev-parse refs/remotes/origin/origin/master^{commit} # timeout=10\n" +
						"Checking out Revision e9d4e58767b2811346497981e7f6b4bd2f35adc8 (refs/remotes/origin/master)\n" +
						"Commit message: \"Configuração Inicial\"\n" +
						" > git config core.sparsecheckout # timeout=10\n" +
						" > git checkout -f e9d4e58767b2811346497981e7f6b4bd2f35adc8\n" +
						" > git branch -a -v --no-abbrev # timeout=10\n" +
						" > git checkout -b master e9d4e58767b2811346497981e7f6b4bd2f35adc8\n" +
						"First time build. Skipping changelog.\n" +
						"[Pipeline] }\n" +
						"[Pipeline] // stage\n" +
						"[Pipeline] stage\n" +
						"[Pipeline] { (Setup)\n" +
						"[Pipeline] readMavenPom\n" +
						"[Pipeline] tool\n" +
						"[Pipeline] tool\n" +
						"[Pipeline] withEnv\n" +
						"[Pipeline] {\n" +
						"[Pipeline] isUnix\n" +
						"[Pipeline] sh\n" +
						"[jenkins-manager-api-ci-dev] Running shell script\n" +
						"+ mvn -B -V -U -e clean\n" +
						"Apache Maven 3.5.0 (ff8f5e7444045639af65f6095c62210b5713f426; 2017-04-03T16:39:06-03:00)\n" +
						"Maven home: /opt/maven/apache-maven-3.5.0\n" +
						"Java version: 1.8.0_141, vendor: Oracle Corporation\n" +
						"Java home: /opt/java/jdk1.8.0_141/jre\n" +
						"Default locale: en_US, platform encoding: UTF-8\n" +
						"OS name: \"linux\", version: \"2.6.32-696.1.1.el6.x86_64\", arch: \"amd64\", family: \"unix\"\n" +
						"[INFO] Error stacktraces are turned on.\n" +
						"[INFO] Scanning for projects...\n" +
						"[INFO] \n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] Building jenkins-manager-api 0.0.1-SNAPSHOT\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] \n" +
						"[INFO] --- maven-clean-plugin:2.5:clean (default-clean) @ jenkins-manager-api ---\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] BUILD SUCCESS\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] Total time: 1.108 s\n" +
						"[INFO] Finished at: 2017-08-23T17:56:41-03:00\n" +
						"[INFO] Final Memory: 9M/303M\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[Pipeline] }\n" +
						"[Pipeline] // withEnv\n" +
						"[Pipeline] }\n" +
						"[Pipeline] // stage\n" +
						"[Pipeline] stage\n" +
						"[Pipeline] { (Compile Application)\n" +
						"[Pipeline] tool\n" +
						"[Pipeline] tool\n" +
						"[Pipeline] withEnv\n" +
						"[Pipeline] {\n" +
						"[Pipeline] isUnix\n" +
						"[Pipeline] sh\n" +
						"[jenkins-manager-api-ci-dev] Running shell script\n" +
						"+ mvn -B -V -U -e package -Dmaven.test.skip=true\n" +
						"Apache Maven 3.5.0 (ff8f5e7444045639af65f6095c62210b5713f426; 2017-04-03T16:39:06-03:00)\n" +
						"Maven home: /opt/maven/apache-maven-3.5.0\n" +
						"Java version: 1.8.0_141, vendor: Oracle Corporation\n" +
						"Java home: /opt/java/jdk1.8.0_141/jre\n" +
						"Default locale: en_US, platform encoding: UTF-8\n" +
						"OS name: \"linux\", version: \"2.6.32-696.1.1.el6.x86_64\", arch: \"amd64\", family: \"unix\"\n" +
						"[INFO] Error stacktraces are turned on.\n" +
						"[INFO] Scanning for projects...\n" +
						"[INFO] " +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] BUILD SUCCESS\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] Total time: 1.108 s\n" +
						"[INFO] Finished at: 2017-08-23T17:56:41-03:00\n" +
						"[INFO] Final Memory: 9M/303M\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[Pipeline] }" +
						"[Pipeline] // withCredentials" +
						"[Pipeline] }" +
						"[Pipeline] // withEnv" +
						"[Pipeline] }" +
						"[Pipeline] // withSonarQubeEnv" +
						"[Pipeline] }" +
						"[Pipeline] // stage" +
						"[Pipeline] stage" +
						"[Pipeline] { (SonarQube Quality Gate)" +
						"[Pipeline] timeout" +
						"Timeout set to expire in 1 hr 0 min" +
						"[Pipeline] {" +
						"[Pipeline] waitForQualityGate" +
						"Checking status of SonarQube task 'AWMsZR7HorV0KED3ChF6' on server 'SonarQube'" +
						"SonarQube task 'AWMsZR7HorV0KED3ChF6' status is 'IN_PROGRESS'" +
						"[Pipeline] }" +
						"[Pipeline] // timeout" +
						"[Pipeline] }" +
						"[Pipeline] // stage" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] BUILD SUCCESS\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] Total time: 1.108 s\n" +
						"[INFO] Finished at: 2017-08-23T17:56:41-03:00\n" +
						"[INFO] Final Memory: 9M/303M\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[Pipeline] stage" +
						"[Pipeline] { (Distribute Binary)" +
						"[Pipeline] echo" +
						"Copiando arquivo..." +
						"[Pipeline] sh");
		changeSet.add(c);
		
		BuildLog c2 = new BuildLog();
		c2.setId(new BuildLogPK());
		c2.getId().setBuild(build.getId().getId());
		c2.getId().setJob(build.getId().getJob());
		c2.getId().setProject(build.getId().getProject());
		c2.getId().setWallet(build.getId().getWallet());
		c2.setBuild(build);
		c2.setLog(
				"Started by GitLab push by Fabio Luis Iwakoshi da SIlva\n" +
						"Obtained Jenkinsfile-CI-DEV from git http://f771274@10.1.32.241/SUPORTE/JENKINSFILE/jenkins-manager-api.git\n" +
						"[Pipeline] node\n" +
						"Running on master in /opt/jenkins/workspace/jenkins-manager/jenkins-manager-api-ci-dev\n" +
						"[Pipeline] {\n" +
						"[Pipeline] stage\n" +
						"[Pipeline] { (Checkout)\n" +
						"[Pipeline] git\n" +
						"Cloning the remote Git repository\n" +
						"Cloning repository http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git\n" +
						" > git init /opt/jenkins/workspace/jenkins-manager/jenkins-manager-api-ci-dev # timeout=10\n" +
						"Fetching upstream changes from http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git\n" +
						" > git --version # timeout=10\n" +
						"using GIT_ASKPASS to set credentials GitLab\n" +
						" > git fetch --tags --progress http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git +refs/heads/*:refs/remotes/origin/*\n" +
						" > git config remote.origin.url http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git # timeout=10\n" +
						" > git config --add remote.origin.fetch +refs/heads/*:refs/remotes/origin/* # timeout=10\n" +
						" > git config remote.origin.url http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git # timeout=10\n" +
						"Fetching upstream changes from http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git\n" +
						"using GIT_ASKPASS to set credentials GitLab\n" +
						" > git fetch --tags --progress http://f771274@10.1.32.241/SUPORTE/jenkins-manager-api.git +refs/heads/*:refs/remotes/origin/*\n" +
						"skipping resolution of commit e9d4e58767b2811346497981e7f6b4bd2f35adc8, since it originates from another repository\n" +
						" > git rev-parse refs/remotes/origin/master^{commit} # timeout=10\n" +
						" > git rev-parse refs/remotes/origin/origin/master^{commit} # timeout=10\n" +
						"Checking out Revision e9d4e58767b2811346497981e7f6b4bd2f35adc8 (refs/remotes/origin/master)\n" +
						"Commit message: \"Configuração Inicial\"\n" +
						" > git config core.sparsecheckout # timeout=10\n" +
						" > git checkout -f e9d4e58767b2811346497981e7f6b4bd2f35adc8\n" +
						" > git branch -a -v --no-abbrev # timeout=10\n" +
						" > git checkout -b master e9d4e58767b2811346497981e7f6b4bd2f35adc8\n" +
						"First time build. Skipping changelog.\n" +
						"[Pipeline] }\n" +
						"[Pipeline] // stage\n" +
						"[Pipeline] stage\n" +
						"[Pipeline] { (Setup)\n" +
						"[Pipeline] readMavenPom\n" +
						"[Pipeline] tool\n" +
						"[Pipeline] tool\n" +
						"[Pipeline] withEnv\n" +
						"[Pipeline] {\n" +
						"[Pipeline] isUnix\n" +
						"[Pipeline] sh\n" +
						"[jenkins-manager-api-ci-dev] Running shell script\n" +
						"+ mvn -B -V -U -e clean\n" +
						"Apache Maven 3.5.0 (ff8f5e7444045639af65f6095c62210b5713f426; 2017-04-03T16:39:06-03:00)\n" +
						"Maven home: /opt/maven/apache-maven-3.5.0\n" +
						"Java version: 1.8.0_141, vendor: Oracle Corporation\n" +
						"Java home: /opt/java/jdk1.8.0_141/jre\n" +
						"Default locale: en_US, platform encoding: UTF-8\n" +
						"OS name: \"linux\", version: \"2.6.32-696.1.1.el6.x86_64\", arch: \"amd64\", family: \"unix\"\n" +
						"[INFO] Error stacktraces are turned on.\n" +
						"[INFO] Scanning for projects...\n" +
						"[INFO] \n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] Building jenkins-manager-api 0.0.1-SNAPSHOT\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] \n" +
						"[INFO] --- maven-clean-plugin:2.5:clean (default-clean) @ jenkins-manager-api ---\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] BUILD SUCCESS\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[INFO] Total time: 1.108 s\n" +
						"[INFO] Finished at: 2017-08-23T17:56:41-03:00\n" +
						"[INFO] Final Memory: 9M/303M\n" +
						"[INFO] ------------------------------------------------------------------------\n" +
						"[Pipeline] }\n" +
						"[Pipeline] // withEnv\n" +
						"[Pipeline] }\n" +
						"[Pipeline] // stage\n" +
						"[Pipeline] stage\n" +
						"[Pipeline] { (Compile Application)\n" +
						"[Pipeline] tool\n" +
						"[Pipeline] tool\n" +
						"[Pipeline] withEnv\n" +
						"[Pipeline] {\n" +
						"[Pipeline] isUnix\n" +
						"[Pipeline] sh\n" +
						"[jenkins-manager-api-ci-dev] Running shell script\n" +
						"+ mvn -B -V -U -e compile\n" +
						"Apache Maven 3.5.0 (ff8f5e7444045639af65f6095c62210b5713f426; 2017-04-03T16:39:06-03:00)\n" +
						"Maven home: /opt/maven/apache-maven-3.5.0\n" +
						"Java version: 1.8.0_141, vendor: Oracle Corporation\n" +
						"Java home: /opt/java/jdk1.8.0_141/jre\n" +
						"Default locale: en_US, platform encoding: UTF-8\n" +
						"OS name: \"linux\", version: \"2.6.32-696.1.1.el6.x86_64\", arch: \"amd64\", family: \"unix\"\n" +
						"[INFO] Error stacktraces are turned on.\n" +
						"[INFO] Scanning for projects...\n" +
						"[INFO] " +
						"[Pipeline] }" +
						"[Pipeline] // withCredentials" +
						"[Pipeline] }" +
						"[Pipeline] // withEnv" +
						"[Pipeline] }" +
						"[Pipeline] // withSonarQubeEnv" +
						"[Pipeline] }" +
						"[Pipeline] // stage" +
						"[Pipeline] stage" +
						"[Pipeline] { (SonarQube Quality Gate)" +
						"[Pipeline] timeout" +
						"Timeout set to expire in 1 hr 0 min" +
						"[Pipeline] {" +
						"[Pipeline] waitForQualityGate" +
						"Checking status of SonarQube task 'AWMsZR7HorV0KED3ChF6' on server 'SonarQube'" +
						"SonarQube task 'AWMsZR7HorV0KED3ChF6' status is 'IN_PROGRESS'" +
						"[Pipeline] }" +
						"[Pipeline] // timeout" +
						"[Pipeline] }" +
						"[Pipeline] // stage" +
						"[Pipeline] stage" +
						"[Pipeline] { (Distribute Binary)" +
						"[Pipeline] echo" +
						"Copiando arquivo..." +
						"[Pipeline] sh");
		changeSet.add(c2);
		
		c2.getId().equals(c.getId());
		c2.getId().hashCode();
		
		return changeSet;
	}

	private static List<ChangeSet> createChangeSets(Build build) {
		List<ChangeSet> changeSet = new ArrayList<>();
		ChangeSet c = new ChangeSet();
		c.setId(new ChangeSetPK());
		c.getId().setBuild(build.getId().getId());
		c.getId().setCommit("nashdkashdkaghsdkhaksjdghkas");
		c.getId().setJob(build.getId().getJob());
		c.getId().setProject(build.getId().getProject());
		c.getId().setWallet(build.getId().getWallet());
		changeSet.add(c);

		ChangeSet c2 = new ChangeSet();
		c2.setId(new ChangeSetPK());
		c2.getId().setBuild(build.getId().getId());
		c2.getId().setCommit("kjdgfhjgfgsjdfgjhsdgfhsdfg");
		c2.getId().setJob(build.getId().getJob());
		c2.getId().setProject(build.getId().getProject());
		c2.getId().setWallet(build.getId().getWallet());
		changeSet.add(c2);
		c2.getId().equals(c.getId());
		c2.getId().hashCode();
		
		return changeSet;
	}

	private static List<ProjectEnvironment> createProjectEnvironments(Build build) {
		List<ProjectEnvironment> projectEnvironments = new ArrayList<>();
		ProjectEnvironment p = new ProjectEnvironment();
		p.setBuild(build);
		p.setCreatedAt(Calendar.getInstance());
		p.setId(new ProjectEnvironmentPK());
		p.getId().setBuild(build.getId().getId());
		p.getId().setEnvironment(Environment.DES);
		p.getId().setJob(build.getId().getJob());
		p.getId().setProject(build.getId().getProject());
		p.getId().setWallet(build.getId().getWallet());
		p.setUpdatedAt(Calendar.getInstance());
		p.setUserInsert("f771274");
		p.setUserUpdate("f771274");
		projectEnvironments.add(p);
		
		ProjectEnvironment p2 = new ProjectEnvironment();
		p2.setBuild(build);
		p2.setCreatedAt(Calendar.getInstance());
		p2.setId(new ProjectEnvironmentPK());
		p2.getId().setBuild(build.getId().getId());
		p2.getId().setEnvironment(Environment.DES);
		p2.getId().setJob(build.getId().getJob());
		p2.getId().setProject(build.getId().getProject());
		p2.getId().setWallet(build.getId().getWallet());
		p2.setUpdatedAt(Calendar.getInstance());
		p2.setUserInsert("f771274");
		p2.setUserUpdate("f771274");
		p2.getId().equals(p.getId());
		p2.getId().hashCode();
		projectEnvironments.add(p2);
		
		return projectEnvironments;
	}

	private static List<Measures> createMeasures(Commit commit) {
		List<Measures> measures = new ArrayList<>();
		Measures s = new Measures();
		s.setBugs(1);
		s.setCodeSmells(2);
		s.setCoverage(new BigDecimal(89.6));
		s.setDuplicatedLines(10);
		s.setId(new MeasuresPK());
		s.getId().setWallet(commit.getId().getWallet());
		s.getId().setProject(commit.getId().getProject());
		s.getId().setCommit(commit.getId().getCommit());
		s.setLines(123124);
		s.setUnitTests(123);
		s.setVulnerabilities(0);
		measures.add(s);
		
		Measures s2 = new Measures();
		s2.setBugs(1);
		s2.setCodeSmells(2);
		s2.setCoverage(new BigDecimal(89.6));
		s2.setDuplicatedLines(100);
		s2.setId(new MeasuresPK());
		s2.getId().setWallet(commit.getId().getWallet());
		s2.getId().setProject(commit.getId().getProject());
		s2.getId().setCommit(commit.getId().getCommit());
		s2.setLines(123124);
		s2.setUnitTests(123);
		s2.setVulnerabilities(0);
		s2.getId().equals(s.getId());
		s2.getId().hashCode();
		measures.add(s2);
		
		
		return measures;
	}

	private static List<QualityGate> createQualityGates(Project p) {
		List<QualityGate> qgs = new ArrayList<>();
		
		QualityGate qg = new QualityGate();
		qg.setComparator(Comparator.GT);
		qg.setErrorThreshold("0");
		qg.setId(new QualityGatePK());
		qg.getId().setMetricKey("");
		qg.getId().setProject(p.getId().getId());
		qg.getId().setWallet(p.getId().getWallet());
		qgs.add(qg);
		
		QualityGate qg2 = new QualityGate();
		qg2.setComparator(Comparator.GT);
		qg2.setErrorThreshold("0");
		qg2.setId(new QualityGatePK());
		qg2.getId().setMetricKey("");
		qg2.getId().setProject(p.getId().getId());
		qg2.getId().setWallet(p.getId().getWallet());
		qg2.getId().equals(qg.getId());
		qg2.getId().hashCode();
		qgs.add(qg2);
		return qgs;
	}

	private static List<Commit> createCommits(Project project) {
		List<Commit> commits = new ArrayList<>();
		Commit g = new Commit();
		g.setAuthoredDate(Calendar.getInstance());
		g.setAuthorEmail("f771274@mail.caixa");
		g.setAuthorName("f771274");
		g.setChangeSets(new HashSet<>(createChangeSets(createBuilds().get(0))));
		g.setCommittedDate(Calendar.getInstance());
		g.setCommitterEmail("f771274@mail.caixa");
		g.setCommitterName("f771274");
		g.setId(new CommitPK());
		g.getId().setCommit("465a4sda4s6d54asd6654asd");
		g.getId().setProject(project.getId().getId());
		g.getId().setWallet(project.getId().getWallet());
		g.setMessage("Mensagem");
		g.setProject(project);
		g.setTitle("Titulo");
		g.setVersion("1.2.3");
		g.setVersionedAt(Calendar.getInstance());
		g.setVersionerUser("f771274");
		g.setPaths(new HashSet<>(createPaths(g)));
		g.setMeasures(new HashSet<>(createMeasures(g)));
		commits.add(g);

		Commit g2 = new Commit();
		g2.setAuthoredDate(Calendar.getInstance());
		g2.setAuthorEmail("f771274@mail.caixa");
		g2.setAuthorName("f771274");
		g2.setChangeSets(new HashSet<>(createChangeSets(createBuilds().get(0))));
		g2.setCommittedDate(Calendar.getInstance());
		g2.setCommitterEmail("f771274@mail.caixa");
		g2.setCommitterName("f771274");
		g2.setId(new CommitPK());
		g2.getId().setCommit("4d64fads54f4s6df4sf4as6d5f");
		g2.getId().setProject(project.getId().getId());
		g2.getId().setWallet(project.getId().getWallet());
		g2.setMessage("Mensagem");
		g2.setProject(project);
		g2.setTitle("Titulo");
		g2.setVersion("1.2.3");
		g2.setVersionedAt(Calendar.getInstance());
		g2.setVersionerUser("f771274");
		g2.getId().equals(g.getId());
		g2.getId().hashCode();
		g2.setPaths(new HashSet<>(createPaths(g)));
		g2.setMeasures(new HashSet<>(createMeasures(g2)));
		commits.add(g2);
		
		return commits;
	}

	private static List<Path> createPaths(Commit g) {
		List<Path> paths = new ArrayList<>();
		Path p = new Path();
		p.setEditType(EditType.ADD);
		p.setCommit(g);
		p.setId(new PathPK());
		p.getId().setCommit("4d64fads54f4s6df4sf4as6d5f");
		p.getId().setFile("src/tmp.txt");
		p.getId().setProject("portal-inovacao");
		p.getId().setWallet("inovacao");
		paths.add(p);

		Path p2 = new Path();
		p2.setEditType(EditType.ADD);
		p2.setCommit(g);
		p2.setId(new PathPK());
		p2.getId().setCommit("4d64fads54f4s6df4sf4as6d5f");
		p2.getId().setFile("src/tmp.txt");
		p2.getId().setProject("portal-inovacao");
		p2.getId().setWallet("inovacao");
		paths.add(p2);
		p2.getId().equals(p.getId());
		p2.getId().hashCode();
		
		return paths;
	}
	
	public static List<Measures> createMeasures() {
		List<Measures> measures = new ArrayList<>();
		Measures m = new Measures();
		m.setBugs(1);
		measures.add(m);
		
		Measures m2 = new Measures();
		m.setCodeSmells(1);
		measures.add(m2);
		
		return measures;
	}
	
	public static List<ChangeSet> createChangeSet() {
		return createChangeSets(null);
	}
	
	public static List<ChangeSet> creaChangeSets() {
		List<ChangeSet> listChangeSet = new ArrayList<>();
		
		ChangeSet cs = new ChangeSet();
		cs.setBuild(new Build());
		cs.setCommit(new Commit());
		cs.setId(new ChangeSetPK());
		listChangeSet.add(cs);
		
		ChangeSet cs2 = new ChangeSet();
		cs2.setBuild(new Build());
		cs2.setCommit(new Commit());
		cs2.setId(new ChangeSetPK());
		listChangeSet.add(cs2);
		
		return listChangeSet;
	}
}

package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.gov.caixa.api.model.Questionario;

public class QuestionarioDto {
	private Long uid;
	private String questao;	
	private String questionario;	
	private Date dataEntrada;
	private Date dataSaida;
	private Date dataQuestionario;
	
	public Long getUid() {
		return uid;
	}
	
	public void setUid(Long uid) {
		this.uid = uid;
	}	

	public String getQuestao() {
		return questao;
	}
	
	public void setQuestao(String questao) {
		this.questao = questao;
	}	
		
	public String getQuestionario() {
		return questionario;
	}
	
	public void setQuestionario(String questionario) {
		this.questionario = questionario;
	}
	
	public Date getDataQuestionario() {
		return dataQuestionario;
	}

	public void setDataQuestionario(Date dataQuestionario) {
		this.dataQuestionario = dataQuestionario;
	}

	public Date getDataEntrada() {
		return dataEntrada;
	}

	public void setDataEntrada(Date dataEntrada) {
		this.dataEntrada = dataEntrada;
	}

	public Date getDataSaida() {
		return dataSaida;
	}

	public void setDataSaida(Date dataSaida) {
		this.dataSaida = dataSaida;
	}
		
	public static QuestionarioDto fromQuestionarioToDto(Questionario questionario) {
		
		QuestionarioDto dto = new QuestionarioDto();
		
		dto.setUid(questionario.getUid());
		dto.setQuestao(questionario.getQuestao());
		dto.setQuestionario(questionario.getQuestionario());
		dto.setDataEntrada(questionario.getDataEntrada());
		dto.setDataSaida(questionario.getDataSaida());
		dto.setDataQuestionario(questionario.getDataQuestionario());		
			
		return dto;
	}

	public static List<QuestionarioDto> fromQuestionarioToListDto(List<Questionario> list) {
		
		List<QuestionarioDto> returnList = new ArrayList<QuestionarioDto>();
		
		for (Questionario questionario   : list) {
			
			QuestionarioDto dto = new QuestionarioDto();			
			dto = fromQuestionarioToDto(questionario);
		
			returnList.add(dto);
		}
		
		return returnList;
	}
}
package br.gov.caixa.inovacao.continuousmanager.resource;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.service.JenkisfileService;

/**
 * Classe responsavel por receber as requisicoes dos jenkins para obtencao de
 * informações sobre um determinado repositorio.
 * 
 * Todas as chamadas a classe são interceptadas pela classe LoggerInterceptor
 * atraves da anotacao @Interceptors.
 * 
 * Como estamos trabalhando com Rest, utilizar sempre o escopo @RequestScoped
 * para nao sobrecarregar o servidor desnecessariamente.
 * 
 * @author Fabio Iwakoshi
 *
 */
@Path("jenkinsfiles")
@RequestScoped
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class JenkisfileResource {

	@Inject
	private JenkisfileService jenkisfileService;
	
	@GET
	@JsonView(ViewJson.JenkisfileView.class)
	@Path("{repository:[a-zA-Z0-9\\%-\\.]+}/{environment:(DES|TQS|HMP|PRD)}")
	public Response getWallets(@QueryParam("branch") @DefaultValue(value = "") String branch,
			@PathParam("repository") String repository, @PathParam("environment") Environment environment) {
		return Response.ok(jenkisfileService.getJenkinsfile(repository, environment, branch)).build();
	}
}

package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeAtividadeView;
import br.gov.caixa.api.result.BasicResult;

public class EspecialidadeAtividadeViewResult extends BasicResult {
	private List<EspecialidadeAtividadeView> list;
	private EspecialidadeAtividadeView especialidadeAtividadeView;

	public List<EspecialidadeAtividadeView> getList() {
		return list;
	}

	public void setList(List<EspecialidadeAtividadeView> list) {
		this.list = list;
	}

	public EspecialidadeAtividadeView getEspecialidadeAtividadeView() {
		return especialidadeAtividadeView;
	}

	public void setEspecialidadeAtividadeView(EspecialidadeAtividadeView especialidadeAtividadeView) {
		this.especialidadeAtividadeView = especialidadeAtividadeView;
	}
}
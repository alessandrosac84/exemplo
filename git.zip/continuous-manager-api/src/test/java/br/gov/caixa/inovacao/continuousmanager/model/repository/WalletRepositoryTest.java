/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Wallet;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes de WalletRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class WalletRepositoryTest {
	
	@Mock
	private EntityManager em;
	
	@Mock
	private CriteriaBuilder builder;
	
	@Mock
	private CriteriaQuery<Wallet> query;
	
	@Mock
	private CriteriaQuery<Long> queryCount;
	
	@Mock
	private Root<Wallet> from;
	
	@Mock
	private Expression<Long> expressionCount;
	
	@Mock
	private TypedQuery<Wallet> typedQuery;
	
	@Mock
	private TypedQuery<Long> typedQueryCount;

	@InjectMocks
	private WalletRepository walletRepository;
	
	private List<Wallet> wallets;

	@Before
	public void before() {
		wallets = EntityBuilder.createWallets();
	}

	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(em.find(Wallet.class, wallets.get(0).getId())).thenReturn(wallets.get(0));
		
		// Act
		Wallet retorno = walletRepository.findById(wallets.get(0).getId());
		
		// Then
		Assert.assertNotNull(retorno.getId());
	}

	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Wallet>>any())).thenReturn(typedQuery);
		
		Mockito.when(builder.createQuery(Wallet.class)).thenReturn(query);
		
		Mockito.when(query.from(Wallet.class)).thenReturn(from);
		Mockito.when(query.select(from)).thenReturn(query);
		Mockito.when(query.where(Mockito.<Expression<Boolean>>any())).thenReturn(query);
		
		Mockito.when(typedQuery.setFirstResult(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setMaxResults(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(wallets);
		
		// Act
		List<Wallet> retorno = walletRepository.findAll(0, 30, "", "id", AscDesc.ASC);
		
		// Then
		Assert.assertEquals(2, retorno.size());
	}

	@Test
	public void testFindAllDesc() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Wallet>>any())).thenReturn(typedQuery);
		
		Mockito.when(builder.createQuery(Wallet.class)).thenReturn(query);
		
		Mockito.when(query.from(Wallet.class)).thenReturn(from);
		Mockito.when(query.select(from)).thenReturn(query);
		Mockito.when(query.where(Mockito.<Expression<Boolean>>any())).thenReturn(query);
		
		Mockito.when(typedQuery.setFirstResult(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setMaxResults(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(wallets);
		
		// Act
		List<Wallet> retorno = walletRepository.findAll(0, 30, "", "id", AscDesc.DESC);
		
		// Then
		Assert.assertEquals(2, retorno.size());
	}

	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Long>>any())).thenReturn(typedQueryCount);
		
		Mockito.when(builder.createQuery(Long.class)).thenReturn(queryCount);
		Mockito.when(builder.count(from)).thenReturn(expressionCount);
		
		Mockito.when(queryCount.from(Wallet.class)).thenReturn(from);
		Mockito.when(queryCount.select(expressionCount)).thenReturn(queryCount);
		Mockito.when(queryCount.where(Mockito.<Expression<Boolean>>any())).thenReturn(queryCount);
		
		Mockito.when(typedQueryCount.getSingleResult()).thenReturn((long) wallets.size());
		
		// Act
		Long retorno = walletRepository.countAll("");
		
		// Then
		Assert.assertEquals(2, retorno.longValue());
	}
	
	@Test
	public void testSave() {
		// Act
		Wallet save = walletRepository.save(wallets.get(0));
		// Then
		Assert.assertEquals(wallets.get(0).getId(), save.getId());
	}
}

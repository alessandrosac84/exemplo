package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author Alessandro Carvalho
 * 
 */
public class MeasureVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3375621878821093047L;
	
	/**
	 * 
	 */
	private String metric;
	
	/**
	 * 
	 */
	private String value;
	
	/**
	 * 
	 */
	private List<PeriodsVO> periods;

	/**
	 * @return the metric
	 */
	public String getMetric() {
		return metric;
	}

	/**
	 * @param metric the metric to set
	 */
	public void setMetric(String metric) {
		this.metric = metric;
	}


	/**
	 * @return the periods
	 */
	public List<PeriodsVO> getPeriods() {
		return periods;
	}

	/**
	 * @param periods the periods to set
	 */
	public void setPeriods(List<PeriodsVO> periods) {
		this.periods = periods;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	
}

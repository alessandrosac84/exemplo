package br.gov.caixa.api.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import br.gov.caixa.api.model.Coordenacao;
import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.StatusFuncionario;
import br.gov.caixa.api.model.TipoFuncionario;

public interface FuncionarioRepository extends JpaRepository<Funcionario, Long> {
	
	public Funcionario findByMatricula(String matricula);
	
	public Funcionario findByUid(Long uid);

	public List<Funcionario> findByCoordenacao(Coordenacao coordenacao);
	
	@Query("select f from Funcionario f where f.statusFuncionario = ?1 order by f.uid")
	public List<Funcionario> findAll(StatusFuncionario statusFuncionario);
	
	public List<Funcionario> findByNomeContainingIgnoreCase(String nome);
	
	@Modifying
	@Transactional
	@Query("update Funcionario f set f.tipoFuncionario = ?1 where f.uid = ?2")
	int setTipoFuncionario(TipoFuncionario tipo, Long funcionarioId);
	
	@Modifying
	@Transactional
	@Query("update Funcionario f set f.statusFuncionario = ?1, f.statusDate = ?3, statusDetail = ?4 where f.uid = ?2")
	int setStatusFuncionario(StatusFuncionario status, Long funcionarioId, Date date, String detail);
	
	@Modifying
	@Transactional
	@Query("update Funcionario f set f.nome = ?1, f.cargo = ?2, f.depto = ?3, f.email = ?4, f.fone = ?5, f.celular = ?6, f.empresa = ?7, "
			+ "f.logradouro = ?8, f.cidade = ?9, f.uf = ?10,  f.cep = ?11 "
			+ "where f.uid = ?12")

	int updateFuncionario(String nome, String cargo, String depto, String email, String fone, String celular, String empresa, 
			String logradouro, String cidade, String uf, String cep, 
			Long uid);

}




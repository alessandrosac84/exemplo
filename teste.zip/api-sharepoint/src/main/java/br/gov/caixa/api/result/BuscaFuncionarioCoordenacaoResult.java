package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.BuscaFuncionarioCoordenacaoDto;

public class BuscaFuncionarioCoordenacaoResult extends BasicResult {

	private List<BuscaFuncionarioCoordenacaoDto> list;
	private BuscaFuncionarioCoordenacaoDto buscaFuncionarioCoordenacaoDto;

	public List<BuscaFuncionarioCoordenacaoDto> getList() {
		return list;
	}

	public void setList(List<BuscaFuncionarioCoordenacaoDto> list) {
		this.list = list;
	}

	public BuscaFuncionarioCoordenacaoDto getBuscaFuncionarioCoordenacaoDto() {
		return buscaFuncionarioCoordenacaoDto;
	}

	public void setBuscaFuncionarioCoordenacaoDto(
			BuscaFuncionarioCoordenacaoDto buscaFuncionarioCoordenacaoDto) {
		this.buscaFuncionarioCoordenacaoDto = buscaFuncionarioCoordenacaoDto;
	}

}

package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;
import java.util.List;

/**
 * Classe de representação do Last Built Revision do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class LastBuiltRevisionJenkinsVO implements Serializable {

	private static final long serialVersionUID = 8472438626182237977L;
	
	private List<BranchJenkinsVO> branch;

	/**
	 * @return the branch
	 */
	public List<BranchJenkinsVO> getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(List<BranchJenkinsVO> branch) {
		this.branch = branch;
	}

}

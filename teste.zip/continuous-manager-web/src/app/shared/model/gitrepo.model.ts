import { Project } from './project.model';
export class GitRepo {
    public id: { commit: string, project: string, wallet: string };
    public authorEmail: string;
    public authorName: string;
    public authoredDate: Date;
    public committedDate: Date;
    public committerEmail: string;
    public committerName: string;
    public message: string;
    public title: string;
    public version: string;
    public versionedAt: Date;
    public versionerUser: string;
    public project: Project;
}

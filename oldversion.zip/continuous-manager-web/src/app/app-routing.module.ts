import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CoreModule } from './core/core.module';
import { AuthGuard } from './guards/auth.guard';
import { DevComponent } from './pages/dev/dev.component';
import { LoginComponent } from './pages/login/login.component';

const routes: Routes = [
  { path: '', redirectTo: 'log', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', loadChildren: 'app/pages/dashboard/dashboard.module#DashboardModule' },
  { path: 'log', loadChildren: 'app/pages/log/log.module#LogModule' },
  { path: 'info', loadChildren: 'app/pages/info/info.module#InfoModule' },
  { path: 'dev', loadChildren: 'app/pages/dev/dev.module#DevModule', canActivate: [AuthGuard] },
  { path: 'release', loadChildren: 'app/pages/release/release.module#ReleaseModule', canActivate: [AuthGuard] },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

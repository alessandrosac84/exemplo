import { Build } from '../model/build.model';
import { Job } from '../model/job.model';
import { Folder } from '../model/folder.model';
import { Observable } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';

import { environment } from '../../../environments/environment';

@Injectable()
export class JenkinsService {

  private folderUrl = `${environment.apiBaseUrl}api/sistemas`;
  private jobUrl = '/jobs';
  private buildUrl = '/builds';
  private logUrl = '/log';
  private currentBuildsUrl = '/currentBuilds';

  constructor(private http: HttpClient) { }

  getFolders(): Observable<Folder[]> {
    return this.http.get<Folder[]>(`${this.folderUrl}`);
  }

  getJobs(folderName: string): Observable<Job[]> {
    return this.http.get<Job[]>(`${this.folderUrl}/${folderName}${this.jobUrl}`);
  }

  getBuilds(folderName: string, jobName: string): Observable<Build[]> {
    return this.http.get<Build[]>(`${this.folderUrl}/${folderName}${this.jobUrl}/${jobName}${this.buildUrl}`);
  }

  geDetailtBuild(folderName: string, jobName: string, build: number): Observable<any> {
    return this.http.get(`${this.folderUrl}/${folderName}${this.jobUrl}/${jobName}${this.buildUrl}/${build}`);
  }

  getLog(folderName: string, jobName: string, build: number): Observable<any> {
    return this.http.get(`${this.folderUrl}/${folderName}${this.jobUrl}/${jobName}${this.buildUrl}/${build}${this.logUrl}`,
      { responseType: 'text' });
  }

  getCurrentBuilds(folderName: string): Observable<Build[]> {
    return this.http.get<Build[]>(`${this.folderUrl}/${folderName}${this.currentBuildsUrl}`);
  }

  getJSON(): Observable<any> {
    return this.http.get('../../../assets/files/commits.json')
      .map((response: Response) => {
        const data = response;
        return data;
      });
  }
}

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Audit;
import br.gov.caixa.inovacao.continuousmanager.model.repository.AuditRepository;

/**
 * Classe de testes do ProjectService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class AuditServiceTest {
	
	@Mock
	private AuditRepository auditRepository;

	@InjectMocks
	private AuditService auditService;
	
	@Before
	public void before() {
		UtilReflection.setField(auditService, "log", Logger.getLogger(AuditService.class.getName()));
	}
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(auditRepository.save(Mockito.<Audit>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Audit audit = new Audit();
		audit.setFunctionality("Wallet");
		
		// Act
		Audit savedAudit = auditService.save(audit);

		// Then
		Assert.assertNotNull(savedAudit);
	}
}

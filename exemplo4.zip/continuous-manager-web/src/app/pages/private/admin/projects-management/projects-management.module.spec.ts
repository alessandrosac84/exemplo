import { ProjectsManagementModule } from './projects-management.module';

describe('ProjectsManagementModule', () => {
  let projectsManagementModule: ProjectsManagementModule;

  beforeEach(() => {
    projectsManagementModule = new ProjectsManagementModule();
  });

  it('should create an instance', () => {
    expect(projectsManagementModule).toBeTruthy();
  });
});

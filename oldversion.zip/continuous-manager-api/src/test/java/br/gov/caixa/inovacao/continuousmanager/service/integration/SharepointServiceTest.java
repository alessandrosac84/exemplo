package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.util.logging.Logger;

import javax.ws.rs.NotFoundException;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.ssl.SSLContexts;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;
import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;

/**
 * Classe de testes do JenkinsService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ SSLContexts.class, ClientBuilder.class })
@PowerMockIgnore("javax.net.ssl.*")
public class SharepointServiceTest {
	
	@Rule
	public MockitoRule mrule = MockitoJUnit.rule();
	
	@Mock
	private ParameterService parameterService;
	
	@Mock
	private Response response;
	
	@Mock
	private ClientBuilder clientBuilder;
	
	@Mock
	private Client client;

	@Mock
	private WebTarget target;
	
	@Mock 
	private Invocation.Builder builder;
	
	@InjectMocks
	private SharepointService sharepointService;
	
	private Parameter parameter;
	
	@Before
	public void before() {
		parameter = new Parameter();
		parameter.setId(new ParameterPK());
		parameter.getId().setEnvironment(Environment.DES);
		parameter.getId().setServerType(ServerType.SHAREPOINT);
		parameter.setCredential("");
		parameter.setHost("https://sharepoint.caixa");
		parameter.setPrincipal("Sharepoint");
		UtilReflection.setField(sharepointService, "log", Logger.getLogger(SharepointService.class.getName()));
	}

	@Test(expected=NotFoundException.class)
	public void testNullParameters() {		
		// Act
		sharepointService.getFuncionario("f771274");
	}

	@Test(expected=ServiceUnavailableException.class)
	public void testGetFuncionarioException() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class)).thenReturn("[]");
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		sharepointService.getFuncionario("f771274");
	}

	@Test(expected=NotFoundException.class)
	public void testAtivos201() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class)).thenReturn("[]");
		Mockito.when(response.getStatus()).thenReturn(201);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		sharepointService.getAtivos("f771274");
	}

	@Test
	public void testAtivos() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class)).thenReturn("[]");
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		sharepointService.getAtivos("f771274");
	}

	@Test
	public void testGetFuncionario() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class)).thenReturn("{\"matricula\":\"f771274\",\"anotacoes\":null,"
				+ "\"cep\":5802140,\"cidade\":\"SAO PAULO\",\"dataAdmissao\":null,\"dataCedes\":null,\"depto\":\"CEDES - CN DESENVOLVIMENTO TI SAO PAULO, SP\","
				+ "\"email\":\"f771274@mail.caixa\",\"empresa\":\"CONSORCIO CTMONSI QUALIDADE EM SUPORTE\",\"foto\":null,\"horaEntrada\":null,"
				+ "\"horaSaida\":null,\"logradouro\":\"AV. GUIDO CALOI, 1000 BL. 9 - 2.ANDAR\",\"nome\":\"Fabio Luis Iwakoshi da Silva\","
				+ "\"qualificacoes\":null,\"uf\":\"SP\",\"statusDate\":1522119600000,\"statusDetail\":\"Fábrica\",\"status\":\"FABRICA\","
				+ "\"atualizacaoCadastral\":null,\"cargoFuncionario\":{\"id\":2,\"descricao\":\"FABRICA\"}}");
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		sharepointService.getFuncionario("f771274");
	}
}

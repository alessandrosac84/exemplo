package br.gov.caixa.inovacao.continuousmanager.resource;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.Measures;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.service.DashboardService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectEnvironmentService;

/**
 * Classe de testes do DashboardResource.
 * 
 * @author Alessandro Carvalho
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DashboardResourceTest {
	
	@Mock
	private Response response;

	@Mock
	private ResponseBuilder responseBuilder;
	
	@Mock
	private DashboardService dashboardService;
	
	@Mock
	private ProjectEnvironmentService projectEnvironmentService;
	
	@InjectMocks
	private DashboardResource dashboardResource;
	
	private List<Measures> measures;
	
	@Before
	public void before() {
		measures = EntityBuilder.createMeasures();
		
	}
	
	/**
	 * Listar todas as Projects.
	 */
	@Test
	public void testListAllWalletsDefault() {
		// Arrange
		Mockito.when(dashboardService.findAll(0, 30, "", "id", AscDesc.ASC)).thenReturn(measures);
		Mockito.when(dashboardService.countAll("")).thenReturn((long) measures.size());

		// Act
		Response response = dashboardResource.getProjects(0, 30, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertEquals("rows 1-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}
	
	@Test
	public void testGetProjectBuildsById() {

		// Act
		Response response = dashboardResource.getProjectBuildsById("inovacao", "continuous-manager-web");

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
	}
	
	@Test
	public void testGetProjectDetailById() {

		// Act
		Response response = dashboardResource.getProjectDetailById("inovacao", "continuous-manager-web", "sdasadasdas");

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
	}
	
	@Test
	public void testGetVersions() {

		// Act
		Response response = dashboardResource.getVersions("inovacao", "continuous-manager-web");

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
	}

	
}

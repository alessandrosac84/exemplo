package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.gov.caixa.inovacao.continuousmanager.model.entity.GitRepo;
import br.gov.caixa.inovacao.continuousmanager.model.entity.GitRepoPK;

/**
 * Classe de acesso ao banco de dados da entidade GitRepo.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class GitRepoRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Salva GitRepo
	 * 
	 * @param GitRepo
	 * @return GitRepo
	 */
	public GitRepo save(GitRepo gitRepo) {
		entityManager.persist(gitRepo);
		return gitRepo;
	}

	public GitRepo findById(GitRepoPK id) {
		return entityManager.find(GitRepo.class, id);
	}

	public Integer maxSequence(String wallet, String project) {
		return entityManager.createQuery(
				"SELECT MAX(g.sequential) FROM GitRepo g WHERE g.id.wallet = :wallet AND g.id.project = :project",
				Integer.class).setParameter("wallet", wallet).setParameter("project", project).getSingleResult();
	}

	public GitRepo update(GitRepo gitRepo) {
		return entityManager.merge(gitRepo);
	}
}

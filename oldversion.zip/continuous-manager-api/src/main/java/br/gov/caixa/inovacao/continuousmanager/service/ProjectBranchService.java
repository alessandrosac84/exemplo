/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.NoResultException;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ProjectBranch;
import br.gov.caixa.inovacao.continuousmanager.model.repository.ProjectBranchRepository;

/**
 * Classe de servicos de Job.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class ProjectBranchService {

	@Inject
	private Logger log;

	@Inject
	private ProjectBranchRepository projectBranchRepository;

	public ProjectBranch findByRepository(String repository, Environment environment, String branch) {
		log.fine("Obtendo Project by Repository");
		try {
			return projectBranchRepository.findByRepository(repository, environment, branch);
		} catch (NoResultException e) {
			log.log(Level.SEVERE, "Não foi possível obter o projeto através do repositório {0} e branch {1} para {2}",
					new Object[] { repository, branch, environment });
			return null;
		}
	}
}

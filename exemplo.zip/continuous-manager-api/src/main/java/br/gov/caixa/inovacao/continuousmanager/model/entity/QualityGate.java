package br.gov.caixa.inovacao.continuousmanager.model.entity;

/**
 * Enum de Tipos de Servidores
 * 
 * @author Fabio Iwakoshi
 */
public enum QualityGate {

	OK("Passou"), NOK("Não Passou");
	
	private String description;
	
	private QualityGate(String description) {
		this.description = description;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
}

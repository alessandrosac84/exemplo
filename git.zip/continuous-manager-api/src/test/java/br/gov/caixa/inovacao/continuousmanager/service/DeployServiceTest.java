package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;

/**
 * Classe de testes do DeployService.
 * 
 * @author Alessandro Carvalho
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DeployServiceTest {

	
	@InjectMocks
	private DeployService deployService;
	
	@Mock
	private JenkinsService jenkinsService;
	
	@Before
	public void before() {
		UtilReflection.setField(deployService, "log", Logger.getLogger(AuditService.class.getName()));
	}
	
	@Test
	public void deploy() {
					
		// Act
		deployService.deploy("inovacao", "continuous-manager-web", "0.0.1");
	}

}

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe de representação do Build do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class ChangeSetJenkinsVO implements Serializable {

	private static final long serialVersionUID = 8801957575617252193L;

	@JsonProperty("_class")
	private String clazz;
	
	private List<ItemJenkinsVO> items;

	/**
	 * @return the clazz
	 */
	public String getClazz() {
		return clazz;
	}

	/**
	 * @param clazz the clazz to set
	 */
	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	/**
	 * @return the items
	 */
	public List<ItemJenkinsVO> getItems() {
		return items;
	}

	/**
	 * @param items the items to set
	 */
	public void setItems(List<ItemJenkinsVO> items) {
		this.items = items;
	}
}

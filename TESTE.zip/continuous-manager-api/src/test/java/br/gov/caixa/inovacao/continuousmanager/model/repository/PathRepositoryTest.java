/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Path;

/**
 * Classe de testes de ChangeSetRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class PathRepositoryTest {

	@Mock
	private EntityManager em;

	@InjectMocks
	private PathRepository pathRepository;

	private Path path;

	@Before
	public void before() {
		path = null; // EntityBuilder.createProjects().get(0).getCommits().stream().findAny().get().getPaths().stream().findFirst().get();
	}

	@Test
	public void testSave() {
		// Act
		Path save = pathRepository.save(path);
		// Then
		Assert.assertEquals(path.getId(), save.getId());
	}

}

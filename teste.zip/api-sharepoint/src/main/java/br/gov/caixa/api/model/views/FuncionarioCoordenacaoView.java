package br.gov.caixa.api.model.views;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.gov.caixa.api.model.StatusFuncionario;

@Entity
@Table(name = "funcionario_coordenacao_view")
public class FuncionarioCoordenacaoView {

	@Id
	@Column(name = "UID")
	private Long uid;

	@Column(name = "NOME", nullable = false)
	private String nome;

	@Column(name = "MATRICULA", nullable = false)
	private String matricula;

	@Column(name = "CARGO", nullable = true)
	private String cargo;	
	
	@Column(name = "STATUS_FUNCIONARIO", nullable = true, columnDefinition = "int default 1")
	private StatusFuncionario statusFuncionario;
	
	@Column(name = "STATUS_DATE", nullable = true)
	private Date statusDate;

	@Column(name = "STATUS_DETAIL", nullable = true)
	private String statusDetail;	

	@Column(name = "FONE", nullable = true)
	private String fone;
	
	@Column(name = "CELULAR", nullable = true)
	private String celular;
	
	@OneToMany(mappedBy="funcionarioCoordenacaoView", fetch=FetchType.EAGER)
	private List<FuncionarioCoordenacoesView> funcionarioCoordenacoesView = new ArrayList<FuncionarioCoordenacoesView>();
		
	public List<FuncionarioCoordenacoesView> getFuncionarioCoordenacoesView() {
		return funcionarioCoordenacoesView;
	}

	public void setFuncionarioCoordenacoesView(List<FuncionarioCoordenacoesView> funcionarioCoordenacoesView) {
		this.funcionarioCoordenacoesView = funcionarioCoordenacoesView;
	}

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}	

	public StatusFuncionario getStatusFuncionario() {
		return statusFuncionario;
	}

	public void setStatusFuncionario(StatusFuncionario statusFuncionario) {
		this.statusFuncionario = statusFuncionario;
	}

	public Date getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(Date statusDate) {
		this.statusDate = statusDate;
	}

	public String getStatusDetail() {
		return statusDetail;
	}

	public void setStatusDetail(String statusDetail) {
		this.statusDetail = statusDetail;
	}

	public String getFone() {
		return fone;
	}

	public void setFone(String fone) {
		this.fone = fone;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}
	
}
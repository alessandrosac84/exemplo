package br.gov.caixa.portalinovacao.resource;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.ws.rs.core.Response;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.portalinovacao.model.vo.TransacaoVO;
import br.gov.caixa.portalinovacao.service.TransacaoService;

@RunWith(MockitoJUnitRunner.class)
public class TransacaoResourceTest {
	
	@Mock
	private TransacaoService transacaoService;
	
	@InjectMocks
	private TransacaoResource transacaoResource;

	@Test
	public void testSend() {
		TransacaoVO transacao = new TransacaoVO();
		Mockito.when(transacaoService.send(transacao)).thenReturn("Test");
		
		Response response = transacaoResource.send(transacao);
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertNotNull(response.getEntity());
	}

}

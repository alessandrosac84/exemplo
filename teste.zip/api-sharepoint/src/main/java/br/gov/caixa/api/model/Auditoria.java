package br.gov.caixa.api.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.gov.caixa.api.dto.AuditoriaDto;

@Entity
@Table(name = "auditoria")
public class Auditoria {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;		

	@Column(name = "FUNCIONARIO_ID")
	private Long funcionario_id;
	
	@Column(name = "COORDENACAO_ID")
	private Long coordenacao_id; 
	
	@Column(name = "DETALHE")
	private String detalhe;
	
	@Column(name = "ACAO")
	private String acao;	
	
	@Column(name = "DATA")
	private Date data;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public Long getFuncionario_id() {
		return funcionario_id;
	}

	public void setFuncionario_id(Long funcionario_id) {
		this.funcionario_id = funcionario_id;
	}

	public Long getCoordenacao_id() {
		return coordenacao_id;
	}

	public void setCoordenacao_id(Long coordenacao_id) {
		this.coordenacao_id = coordenacao_id;
	}

	public String getDetalhe() {
		return detalhe;
	}

	public void setDetalhe(String detalhe) {
		this.detalhe = detalhe;
	}	
	
	public String getAcao() {
		return acao;
	}

	public void setAcao(String acao) {
		this.acao = acao;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}	
	
	public static Auditoria fromDtoToAuditoria(AuditoriaDto dto) {
		
		Auditoria auditoria = new Auditoria();
		
		auditoria.setUid(dto.getUid());		
		auditoria.setDetalhe(dto.getDetalhe());
		
		if (dto.getCoordenacaoDto() != null) {	 
			
			auditoria.setCoordenacao_id(dto.getCoordenacaoDto().getUid());			
		}
		
		if (dto.getFuncionarioDto() != null) {	 
			
			auditoria.setFuncionario_id(dto.getFuncionarioDto().getUid());			
		}
		
		auditoria.setAcao(dto.getAcao());		
		auditoria.setData(dto.getData());		
		
		return auditoria;
	}
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { ReposUser } from '../model/entity/reposuser.model';

@Injectable({
  providedIn: 'root'
})
export class ReposUserService {

  constructor(private http: HttpClient) {}

  getReposUser(): Observable<ReposUser[]> {
    return this.http.get<ReposUser[]>('../../../assets/file/repos-user.json');
  }
}

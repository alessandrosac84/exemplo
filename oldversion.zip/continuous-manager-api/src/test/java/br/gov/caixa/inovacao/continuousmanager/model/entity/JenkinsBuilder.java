/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.EditType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ActionJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.AuthorJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BranchJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BuildJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ChangeSetJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ItemJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.JobJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.LastBuiltRevisionJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.PathJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ProjectJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.WalletJenkinsVO;

/**
 * Classe para criação de informações do Jenkins.
 * 
 * @author Fabio IWakoshi
 *
 */
public class JenkinsBuilder {
	
	public static List<WalletJenkinsVO> createWallets() {
		// Folder 1
		List<WalletJenkinsVO> wallets = new ArrayList<>();
		
		WalletJenkinsVO walletJenkinsVO1 = new WalletJenkinsVO();
		walletJenkinsVO1.setDisplayName("Inovacao");
		walletJenkinsVO1.setName("inovacao");
		walletJenkinsVO1.setClazz("com.cloudbees.hudson.plugins.folder.Folder");
		wallets.add(walletJenkinsVO1);
		
		WalletJenkinsVO walletJenkinsVO2 = new WalletJenkinsVO();
		walletJenkinsVO2.setDisplayName("Sharepoint");
		walletJenkinsVO2.setName("sharepoint");
		walletJenkinsVO2.setClazz("com.cloudbees.hudson.plugins.folder.Folder");
		wallets.add(walletJenkinsVO2);
		
		return wallets;
	}

	public static List<ProjectJenkinsVO> createProjects() {
		// Folder 1
		List<ProjectJenkinsVO> projects = new ArrayList<>();
		
		ProjectJenkinsVO projectJenkinsVO1 = new ProjectJenkinsVO();
		projectJenkinsVO1.setDisplayName("Continuous Manager WEB");
		projectJenkinsVO1.setName("continuous-manager-web");
		projectJenkinsVO1.setClazz("com.cloudbees.hudson.plugins.folder.Folder");
		projects.add(projectJenkinsVO1);
		
		ProjectJenkinsVO projectJenkinsVO2 = new ProjectJenkinsVO();
		projectJenkinsVO2.setDisplayName("Continuous Manager API");
		projectJenkinsVO2.setName("continuous-manager-api");
		projectJenkinsVO2.setClazz("com.cloudbees.hudson.plugins.folder.Folder");
		projects.add(projectJenkinsVO2);
		
		return projects;
	}
		
	public static List<JobJenkinsVO> createJobs() {
		// Job 1
		List<JobJenkinsVO> jobs = new ArrayList<>();
		
		JobJenkinsVO jobJenkinsVO1 = new JobJenkinsVO();
		jobJenkinsVO1.setName("continuous-manager-web-ci-dev");
		jobJenkinsVO1.setDisplayName("Continuous Manager WEB - CI DEV");
		jobJenkinsVO1.setClazz("com.cloudbees.hudson.plugins.job.Job");
		jobs.add(jobJenkinsVO1);
		
		JobJenkinsVO jobJenkinsVO2 = new JobJenkinsVO();
		jobJenkinsVO2.setName("continuous-manager-web-ci-tqs");
		jobJenkinsVO2.setDisplayName("Continuous Manager WEB - CI TQS");
		jobJenkinsVO2.setClazz("com.cloudbees.hudson.plugins.job.Job");
		jobs.add(jobJenkinsVO2);
		
		return jobs;
	}
		
	public static List<BuildJenkinsVO> createBuilds() {
		List<BuildJenkinsVO> buildJenkinsVOs = new ArrayList<>();
		
		buildJenkinsVOs.add(createBuild(169168, 169811, 18, JenkinsResult.SUCCESS, 1504025849835l, null));
		buildJenkinsVOs.add(createBuild(3919, 169811, 17, JenkinsResult.SUCCESS, 1504025707889l, null));
		buildJenkinsVOs.add(createBuild(22739, 169811, 16, JenkinsResult.SUCCESS, 1504020675573l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(158769, 169811, 15, JenkinsResult.SUCCESS, 1503058673217l, null));
		buildJenkinsVOs.add(createBuild(181495, 169811, 14, JenkinsResult.SUCCESS, 1502971639390l, null));
		buildJenkinsVOs.add(createBuild(144102, 169811, 13, JenkinsResult.FAILURE, 1502971420388l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(85885, 169811, 12, JenkinsResult.FAILURE, 1502971043985l, null));
		buildJenkinsVOs.add(createBuild(48477, 169811, 11, JenkinsResult.FAILURE, 1502970611439l, null));
		buildJenkinsVOs.add(createBuild(51294, 169811, 10, JenkinsResult.FAILURE, 1502969915716l, null));
		buildJenkinsVOs.add(createBuild(68887, 169811, 9, JenkinsResult.FAILURE, 1502913580294l, null));
		buildJenkinsVOs.add(createBuild(50614, 169811, 8, JenkinsResult.FAILURE, 1502913331800l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(53687, 169811, 7, JenkinsResult.FAILURE, 1502912481760l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(148160, 169811, 6, JenkinsResult.FAILURE, 1502911761721l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(138044, 169811, 5, JenkinsResult.FAILURE, 1502911486703l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(143778, 169811, 4, JenkinsResult.FAILURE, 1502910888307l, null));
		buildJenkinsVOs.add(createBuild(149176, 169811, 3, JenkinsResult.FAILURE, 1502910571658l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(140672, 169811, 2, JenkinsResult.SUCCESS, 1502907018727l, null));
		buildJenkinsVOs.add(createBuild(212945, 169811, 1, JenkinsResult.SUCCESS, 1502895775627l, "Started by GitLab push by Alessandro Santos Antunes de Carvalho"));
		
		return buildJenkinsVOs;
	}

	private static BuildJenkinsVO createBuild (long duration, long estimated, int number, JenkinsResult result, long timestamp, String description) {
		BuildJenkinsVO buildJenkinsVO = new BuildJenkinsVO();
		buildJenkinsVO.setDescription(description);
		buildJenkinsVO.setDuration(duration);
		buildJenkinsVO.setEstimatedDuration(estimated);
		buildJenkinsVO.setNumber(number);
		buildJenkinsVO.setResult(result);
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp);
		buildJenkinsVO.setTimestamp(calendar);
		buildJenkinsVO.setChangeSets(createChangeSets());
		buildJenkinsVO.setActions(createActions());

		return buildJenkinsVO;
	}
	
	private static List<ActionJenkinsVO> createActions() {
		List<ActionJenkinsVO> actionJenkinsVOs = new ArrayList<>();
		ActionJenkinsVO actionJenkinsVO = new ActionJenkinsVO();
		actionJenkinsVO.setRemoteUrls(new ArrayList<>(Arrays.asList("https://gitlab.caixa/project/teste")));
		LastBuiltRevisionJenkinsVO lastBuiltRevisionJenkinsVO = new LastBuiltRevisionJenkinsVO();
		lastBuiltRevisionJenkinsVO.setBranch(createBranches());
		actionJenkinsVO.setLastBuiltRevision(lastBuiltRevisionJenkinsVO);
		actionJenkinsVOs.add(actionJenkinsVO);
		
		return actionJenkinsVOs;
	}

	private static List<BranchJenkinsVO> createBranches() {
		List<BranchJenkinsVO> branchJenkinsVOs = new ArrayList<>();
		BranchJenkinsVO branchJenkinsVO = new BranchJenkinsVO();
		branchJenkinsVO.setName("develop");
		branchJenkinsVO.setSha1("1e1641qe1213er42364r65r2");
		
		branchJenkinsVOs.add(branchJenkinsVO);
		return branchJenkinsVOs;
	}

	private static List<ChangeSetJenkinsVO> createChangeSets() {
		List<ChangeSetJenkinsVO> changeSetJenkinsVOs = new ArrayList<>();
		ChangeSetJenkinsVO changeSetJenkinsVO = new ChangeSetJenkinsVO();
		changeSetJenkinsVO.setItems(createItems());
		changeSetJenkinsVOs.add(changeSetJenkinsVO);
		
		return changeSetJenkinsVOs;
	}
	
	private static List<ItemJenkinsVO> createItems() {
		List<ItemJenkinsVO> itemJenkinsVOs = new ArrayList<>();
		itemJenkinsVOs.add(createItem());
		itemJenkinsVOs.add(createItem());
		itemJenkinsVOs.add(createItem());
		itemJenkinsVOs.add(createItem());
		itemJenkinsVOs.add(createItem());
		itemJenkinsVOs.add(createItem());
		
		return itemJenkinsVOs;
	}

	private static ItemJenkinsVO createItem() {
		ItemJenkinsVO itemJenkinsVO = new ItemJenkinsVO();
		itemJenkinsVO.setAuthor(new AuthorJenkinsVO());
		itemJenkinsVO.getAuthor().setFullName("Fabio Iwakoshi");
		itemJenkinsVO.setAuthorEmail("f771274@mail.caixa");
		itemJenkinsVO.setComment("commit de fix");
		itemJenkinsVO.setId("d59d722ca1988c1253ff75bf4251cb0f4f4ddf6b");
		itemJenkinsVO.setMsg("commit de fix");
		itemJenkinsVO.setPaths(createPaths());
		itemJenkinsVO.setTimestamp(Calendar.getInstance());
		
		return itemJenkinsVO;
	}

	private static List<PathJenkinsVO> createPaths() {
		List<PathJenkinsVO> pathJenkinsVOs = new ArrayList<>();

		pathJenkinsVOs.add(createPath());
		pathJenkinsVOs.add(createPath());
		
		return pathJenkinsVOs;
	}

	private static PathJenkinsVO createPath() {
		PathJenkinsVO pathJenkinsVO = new PathJenkinsVO();
		pathJenkinsVO.setEditType(EditType.ADD);
		pathJenkinsVO.setFile("src/tmp.txt");
		return pathJenkinsVO;
	}
}

///**
// * 
// */
//package br.gov.caixa.inovacao.continuousmanager.service.impl;
//
//import java.util.List;
//import java.util.logging.Logger;
//
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.junit.MockitoJUnitRunner;
//
//import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
//import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsBuilder;
//import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BuildJenkinsVO;
//import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.SistemaJenkinsVO;
//import br.gov.caixa.inovacao.continuousmanager.service.BuildService;
//import br.gov.caixa.inovacao.continuousmanager.service.JenkinsService;
//import br.gov.caixa.inovacao.continuousmanager.service.WalletService;
//
///**
// * Classe de testes do BuildService.
// * 
// * @author Fabio Iwakoshi
// *
// */
//@RunWith(MockitoJUnitRunner.class)
//public class BuildServiceTest {
//
//	@InjectMocks
//	private BuildService buildService;
//
//	@Mock
//	private JenkinsService jenkinsService;
//	
//	private List<SistemaJenkinsVO> folders;
//
//	@Before
//	public void before() {
//		folders = JenkinsBuilder.createSistemas();
//		UtilReflection.setField(buildService, "log", Logger.getLogger(WalletService.class.getName()));
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.BuildService#getBuilds(java.lang.String, java.lang.String, int, int, java.lang.String, java.lang.String)}.
//	 */
//	@Test
//	public void testFindAll() {
//		// Arrange
//		String nomeSistema = "sharepoint";
//		String nomeJob = "sharepoint-api-cd-tqs";
//		Mockito.when(jenkinsService.listBuilds("sharepoint", "sharepoint-api-cd-tqs")).thenReturn(folders.get(0).getJobs().get(0).getBuilds());
//
//		// Act
//		List<BuildJenkinsVO> folderList = buildService.listBuilds(nomeSistema, nomeJob);
//
//		// Then
//		Assert.assertEquals(12, folderList.size());
//		Assert.assertNotNull(folderList.get(0).getTimestamp());
//		
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.BuildService#countAll(java.lang.String, java.lang.String)}.
//	 */
//	@Test
//	public void testCountAll() {
//		// Arrange
//		Mockito.when(jenkinsService.countAllBuilds("sharepoint", "sharepoint-api-cd-tqs")).thenReturn((long)folders.get(0).getJobs().get(0).getBuilds().size());
//
//		// Act
//		long count = buildService.countAll("sharepoint", "sharepoint-api-cd-tqs", "");
//
//		// Then
//		Assert.assertEquals(12, count);
//	}
//
//	/**
//	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.service.BuildService#getLog(java.lang.String, java.lang.String, int)}.
//	 */
//	@Test
//	public void testGetLog() {
//		// Arrange
//		String folderName = "sharepoint";
//		String jobName = "sharepoint-api-cd-tqs";
//		int build = 2;
//		Mockito.when(buildService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt())).thenReturn("Log do Jenkins");
//
//		// Act
//		String log = buildService.getLog(folderName, jobName, build);
//
//		// Then
//		Assert.assertEquals("Log do Jenkins", log);
//	}
//}

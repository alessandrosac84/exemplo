/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Fetch;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.SetJoin;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSet_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit_;

/**
 * Classe de testes de ChangeSetRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CommitRepositoryTest {

	@Mock
	private EntityManager em;
	
	@Mock
	private CriteriaBuilder builder;
	
	@Mock
	private CriteriaQuery<Commit> query;
	
	@Mock
	private CriteriaQuery<Long> queryCount;
	
	@Mock
	private Root<Commit> from;
	
	@Mock
	private TypedQuery<Commit> typedQuery;
	
	@Mock
	private Path<CommitPK> path;
	
	@Mock
	private Fetch<Commit, ChangeSet> fetchQuery;

	@Mock
	private Fetch<ChangeSet, Build> fetchQuery2;

	@InjectMocks
	private CommitRepository commitRepository;

	private List<Commit> commits;

	@Mock
	private SetJoin<Commit, ChangeSet> setJoin;

	@Mock
	private Join<ChangeSet, Build> setJoin2;

	@Mock
	private Predicate predicated;

	@Mock
	private Path<BuildPK> path2;

	@Mock
	private Order order;
	
	@Mock
	private Expression<Long> expressionCount;

	@Mock
	private TypedQuery<Long> typedQueryCount;

	@Before
	public void before() {
		commits = new ArrayList<>(EntityBuilder.createProjects().get(0).getCommits());
	}

	@Test
	public void testSave() {
		// Act
		Commit save = commitRepository.save(commits.get(0));
		// Then
		Assert.assertEquals(commits.get(0).getId(), save.getId());
	}

	@Test
	public void testUpdate() {
		// Arrange
		Mockito.when(em.merge(Mockito.<Project>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		// Act
		Commit update = commitRepository.update(commits.get(0));
		// Then
		Assert.assertEquals(commits.get(0).getId(), update.getId());
	}

	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(em.find(Commit.class, commits.get(0).getId())).thenReturn(commits.get(0));
		
		// Act
		Commit retorno = commitRepository.findById(commits.get(0).getId());
		
		// Then
		Assert.assertNotNull(retorno.getId());
	}

	@Test
	public void testFindByStatus() {
		// Arrange
		Mockito.when(em.createQuery(Mockito.anyString(), Mockito.<Class<Commit>>any())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setFirstResult(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setMaxResults(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(commits);
		// Act
		List<Commit> retorno = commitRepository.findByStatus("inovacao", "continuous-manager-web", JenkinsResult.SUCCESS, 0, 30);
		
		// Then
		Assert.assertTrue(retorno.size() > 0);
	}
	
	@Test
	public void testFindByVersionOrCommit() {
		Commit commit = new Commit();
		commit.setId(new CommitPK());
		commit.setVersion("2.0.0");
		
		// Arrange
		Mockito.when(em.createQuery(Mockito.anyString(), Mockito.<Class<Commit>>any())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(commits);
		
		// Act
		List<Commit> retorno = commitRepository.findByVersionOrCommit("inovacao", "continuous-manager-web", commit);
		
		// Then
		Assert.assertTrue(retorno.size() > 0);
	}
	
	@Test
	public void testCountByStatus() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(builder.createQuery(Long.class)).thenReturn(queryCount);
		Mockito.when(queryCount.from(Commit.class)).thenReturn(from);

		Mockito.when(from.join(Commit_.changeSets, JoinType.INNER)).thenReturn(setJoin);
		Mockito.when(setJoin.join(ChangeSet_.build, JoinType.INNER)).thenReturn(setJoin2);

		Mockito.when(from.get(Commit_.id)).thenReturn(path);
		Mockito.when(setJoin2.get(Build_.id)).thenReturn(path2);
		Mockito.when(builder.equal(Mockito.<Expression<String>>any(), Mockito.<JenkinsResult>any())).thenReturn(predicated);
		Mockito.when(builder.and(predicated, predicated)).thenReturn(predicated);
		Mockito.when(builder.like(Mockito.<Expression<String>>any(), Mockito.anyString())).thenReturn(predicated);
		
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Long>>any())).thenReturn(typedQueryCount);
		Mockito.when(builder.countDistinct(from)).thenReturn(expressionCount);
		Mockito.when(queryCount.select(expressionCount)).thenReturn(queryCount);
		Mockito.when(queryCount.where(Mockito.<Expression<Boolean>>any())).thenReturn(queryCount);
		Mockito.when(typedQueryCount.getSingleResult()).thenReturn((long) commits.size());
		
		// Act
		Long retorno = commitRepository.countByStatus("inovacao", "continuous-manager-web", JenkinsResult.SUCCESS);
		
		// Then
		Assert.assertTrue(retorno > 0);
	}

}

package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.model.views.ProfilePercentualPreenchimentoView;
import br.gov.caixa.api.repository.views.ProfilePercentualPreenchimentoViewRepository;
import br.gov.caixa.api.result.views.ProfilePercentualPreenchimentoViewResult;

@Named
public class ProfilePercentualPreenchimentoViewService {
	
	@Inject
	ProfilePercentualPreenchimentoViewRepository  repository;
			
	public ProfilePercentualPreenchimentoViewResult listAll() {
		
		ProfilePercentualPreenchimentoViewResult result = new ProfilePercentualPreenchimentoViewResult();
		
		try {
						
			List<ProfilePercentualPreenchimentoView> lista = repository.findAll();				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Resgistro.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

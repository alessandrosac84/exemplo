/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.interceptor;

import java.security.Principal;

import javax.ejb.SessionContext;
import javax.naming.InitialContext;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Audit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Job;
import br.gov.caixa.inovacao.continuousmanager.service.AuditService;

/**
 * Classe de testes do LoggerInterceptor.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ InitialContext.class, AuditInterceptor.class })
@PowerMockIgnore("javax.security.*")
public class AuditInterceptorTest {
	
	@Mock
	private Principal principal;

	@Mock
	private InitialContext initialContext;

	@Mock
	private AuditService auditService;

	@InjectMocks
	private AuditInterceptor auditInterceptor;

	@Test
	public void testOnPrePersist() throws Exception {
		SessionContext sessionContext = Mockito.mock(SessionContext.class);
		UtilReflection.setField(auditInterceptor, "context", sessionContext);
		Mockito.when(sessionContext.getCallerPrincipal()).thenReturn(principal);
		Mockito.when(principal.getName()).thenReturn("f771274");

		AuditedEntity entity = new Job();

		auditInterceptor.onPrePersist(entity);
	}

	@Test
	public void testOnPreUpdateRemove() throws Exception {
		SessionContext sessionContext = Mockito.mock(SessionContext.class);
		UtilReflection.setField(auditInterceptor, "context", sessionContext);
		Mockito.when(sessionContext.getCallerPrincipal()).thenReturn(principal);
		Mockito.when(principal.getName()).thenReturn("f771274");

		AuditedEntity entity = new Job();

		auditInterceptor.onPreUpdateRemove(entity);
	}

	@Test
	public void testOnPostPersist() throws Exception {
		SessionContext sessionContext = Mockito.mock(SessionContext.class);
		UtilReflection.setField(auditInterceptor, "context", sessionContext);
		Mockito.when(sessionContext.getCallerPrincipal()).thenReturn(principal);
		Mockito.when(principal.getName()).thenReturn("f771274");

		PowerMockito.whenNew(InitialContext.class).withAnyArguments().thenReturn(initialContext);
		Mockito.when(initialContext.lookup(Mockito.anyString())).thenReturn(auditService);
		Mockito.when(auditService.save(Mockito.any())).thenReturn(new Audit());

		AuditedEntity entity = new Job();

		auditInterceptor.onPostPersist(entity);
	}

	@Test
	public void testOnPostUpdate() throws Exception {
		SessionContext sessionContext = Mockito.mock(SessionContext.class);
		UtilReflection.setField(auditInterceptor, "context", sessionContext);
		Mockito.when(sessionContext.getCallerPrincipal()).thenReturn(principal);
		Mockito.when(principal.getName()).thenReturn("f771274");

		PowerMockito.whenNew(InitialContext.class).withAnyArguments().thenReturn(initialContext);
		Mockito.when(initialContext.lookup(Mockito.anyString())).thenReturn(auditService);
		Mockito.when(auditService.save(Mockito.any())).thenReturn(new Audit());

		AuditedEntity entity = new Job();

		auditInterceptor.onPostUpdate(entity);
	}

	@Test
	public void testOnPostRemove() throws Exception {
		SessionContext sessionContext = Mockito.mock(SessionContext.class);
		UtilReflection.setField(auditInterceptor, "context", sessionContext);
		Mockito.when(sessionContext.getCallerPrincipal()).thenReturn(principal);
		Mockito.when(principal.getName()).thenReturn("f771274");

		PowerMockito.whenNew(InitialContext.class).withAnyArguments().thenReturn(initialContext);
		Mockito.when(initialContext.lookup(Mockito.anyString())).thenReturn(auditService);
		Mockito.when(auditService.save(Mockito.any())).thenReturn(new Audit());

		AuditedEntity entity = new Job();

		auditInterceptor.onPostRemove(entity);
	}

}

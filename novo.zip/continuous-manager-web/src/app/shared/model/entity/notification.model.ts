
export class Notification {
  id: { username: string, id: number };
  type: string;
  description: string;
  startDate: Date;
  read: Boolean;
  endDate: Date;
}

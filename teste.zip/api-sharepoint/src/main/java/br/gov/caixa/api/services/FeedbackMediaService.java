package br.gov.caixa.api.services;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.FeedbackMediaDto;
import br.gov.caixa.api.model.FeedbackMedia;
import br.gov.caixa.api.repository.FeedbackMediaRepository;
import br.gov.caixa.api.result.FeedbackMediaResult;

@Named
public class FeedbackMediaService {
	
	@Inject
	private FeedbackMediaRepository repository;
	
	public FeedbackMediaResult findByTurma(Long id){
		
		FeedbackMediaResult result = new FeedbackMediaResult();
		FeedbackMedia feedbackMedia = repository.findByTurmaId(id);
		
		if (feedbackMedia == null) {
			result.setIsError(true);
			result.setMessage("Nenhum Feedback Preenchido.");
		}
		else
		{			
			result.setFeedbackMediaDto(FeedbackMediaDto.fromFeedbackMediaToDto(feedbackMedia));
			result.setMessage("Executado com sucesso.");			
		}
		return result;
	}
}

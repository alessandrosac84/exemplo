package br.gov.caixa.api.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.gov.caixa.api.dto.NotificacaoDto;

@Entity
@Table(name = "notificacao")
public class Notificacao {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@ManyToOne
	@JoinColumn(name = "FUNCIONARIO_ID")
	private Funcionario funcionario;

	@Column(name = "TIPO_NOTIFICACAO", columnDefinition = "int default 0")
	private TipoNotificacao tipoNotificacao;
	
	@Column(name = "ID_ORIGEM", nullable = true)
	private Long idOrigem;

	@Enumerated(EnumType.ORDINAL)
	private TipoNotificacao TipoNotificacao() {
		return tipoNotificacao;
	}

	@Column(name = "DATA_EXPIRACAO", nullable = true)
	private Date dataExpiracao;

	@Column(name = "LIDO", columnDefinition = "boolean default false")
	private Boolean lido;

	@Column(name = "QUANTIDADE")
	private Integer quantidade;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public TipoNotificacao getTipoNotificacao() {
		return tipoNotificacao;
	}

	public void setTipoNotificacao(TipoNotificacao tipoNotificacao) {
		this.tipoNotificacao = tipoNotificacao;
	}

	public Date getDataExpiracao() {
		return dataExpiracao;
	}

	public void setDataExpiracao(Date dataExpiracao) {
		this.dataExpiracao = dataExpiracao;
	}

	public Boolean getLido() {
		return lido;
	}

	public void setLido(Boolean lido) {
		this.lido = lido;
	}

	public Integer getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

	public enum TipoNotificacao {
		OUTROS(0), TREINAMENTO(1), FEEDBACK(2), ATUALIZA_PERFIL(3), PERFIL_DESATUALIZADO(4), QUESTIONARIO_ENQUETE(5);

		private final int codigo;

		TipoNotificacao(int codigo) {
			this.codigo = codigo;
		}

		int codigo() {
			return codigo;
		}

		public static TipoNotificacao porCodigo(int codigo) {
			for (TipoNotificacao tipoNotificacao : TipoNotificacao.values()) {
				if (codigo == tipoNotificacao.codigo())
					return tipoNotificacao;
			}
			throw new IllegalArgumentException("tipo invalido");
		}
	}
		
	
	public Long getIdOrigem() {
		return idOrigem;
	}

	public void setIdOrigem(Long idOrigem) {
		this.idOrigem = idOrigem;
	}

	public static Notificacao fromDtoToNotificacao(NotificacaoDto dto){
		Notificacao notificacao = new Notificacao();
		notificacao.setUid(dto.getUid());
		notificacao.setFuncionario(Funcionario.fromDtoToFuncionario(dto.getFuncionario()));
		notificacao.setTipoNotificacao(dto.getTipoNotificacao());
		notificacao.setIdOrigem(dto.getIdOrigem());
		notificacao.setDataExpiracao(dto.getDataExpiracao());
		notificacao.setLido(dto.getLido());
		notificacao.setQuantidade(dto.getQuantidade());
		return notificacao;
	}
	
	public static List<Notificacao> fromDtoToListNotificacao(List<NotificacaoDto> notificacoes) {
		List<Notificacao> result = new ArrayList<Notificacao>();
		
		for (NotificacaoDto dto : notificacoes) {
			result.add(fromDtoToNotificacao(dto));
		}
		
		return result;
	}
	
	
}
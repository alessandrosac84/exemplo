package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Measures;


/**
 * The persistent class for the quality_gate database table.
 * 
 */
@Entity
@Table(name="quality_gate")
@NamedQuery(name="QualityGate.findAll", query="SELECT q FROM QualityGate q")
public class QualityGate implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private QualityGatePK id;

	@Column(name="actual_value", precision=4, scale=1)
	private BigDecimal actualValue;

	@Column(length=2)
	private String comparator;

	@Column(name="error_threshold")
	private Integer errorThreshold;

	@Column(name="period_index")
	private Integer periodIndex;

	@Column(nullable=false, length=3)
	private String status;

	//bi-directional many-to-one association to Measure
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="commit", referencedColumnName="commit", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="project", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="project", nullable=false, insertable=false, updatable=false)
		})
	private Measures measures;

	public QualityGate() {
	}

	public QualityGatePK getId() {
		return this.id;
	}

	public void setId(QualityGatePK id) {
		this.id = id;
	}

	public BigDecimal getActualValue() {
		return this.actualValue;
	}

	public void setActualValue(BigDecimal actualValue) {
		this.actualValue = actualValue;
	}

	public String getComparator() {
		return this.comparator;
	}

	public void setComparator(String comparator) {
		this.comparator = comparator;
	}

	public Integer getErrorThreshold() {
		return this.errorThreshold;
	}

	public void setErrorThreshold(Integer errorThreshold) {
		this.errorThreshold = errorThreshold;
	}

	public Integer getPeriodIndex() {
		return this.periodIndex;
	}

	public void setPeriodIndex(Integer periodIndex) {
		this.periodIndex = periodIndex;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Measures getMeasures() {
		return this.measures;
	}

	public void setMeasures(Measures measures) {
		this.measures = measures;
	}

}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cm-dashboard',
  templateUrl: './dashboard.component.html',
  styles: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.BuscaMediaFerramentaFuncionario;

public class BuscaMediaFerramentaFuncionarioDto {

	private Long ferramenta_id;
	private Long funcionario_id;
	private Long multiplicador;
	private Long conhecer;
	private Long total_rating;
	private Double media_rating;
	private String nome;
	private String matricula;

	public Long getFerramenta_id() {
		return ferramenta_id;
	}

	public void setFerramenta_id(Long ferramenta_id) {
		this.ferramenta_id = ferramenta_id;
	}

	public Long getFuncionario_id() {
		return funcionario_id;
	}

	public void setFuncionario_id(Long funcionario_id) {
		this.funcionario_id = funcionario_id;
	}

	public Long getMultiplicador() {
		return multiplicador;
	}

	public void setMultiplicador(Long multiplicador) {
		this.multiplicador = multiplicador;
	}

	public Long getConhecer() {
		return conhecer;
	}

	public void setConhecer(Long conhecer) {
		this.conhecer = conhecer;
	}

	public Long getTotal_rating() {
		return total_rating;
	}

	public void setTotal_rating(Long total_rating) {
		this.total_rating = total_rating;
	}

	public Double getMedia_rating() {
		return media_rating;
	}

	public void setMedia_rating(Double media_rating) {
		this.media_rating = media_rating;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public static BuscaMediaFerramentaFuncionarioDto fromBuscaMediaFerramentaFuncionarioToDto(BuscaMediaFerramentaFuncionario media) {
		BuscaMediaFerramentaFuncionarioDto dto = new BuscaMediaFerramentaFuncionarioDto();
		
		dto.setFerramenta_id(media.getKey().getFerramenta_id());
		dto.setFuncionario_id(media.getKey().getFuncionario_id());
		dto.setMultiplicador(media.getMultiplicador());
		dto.setConhecer(media.getConhecer());
		dto.setTotal_rating(media.getTotal_rating());
		dto.setMedia_rating(media.getMedia_rating());
		dto.setNome(media.getNome());
		dto.setMatricula(media.getMatricula());
		return dto;
	}
	
	public static List<BuscaMediaFerramentaFuncionarioDto> fromBuscaMediaFerramentaFuncionarioToListDto(List<BuscaMediaFerramentaFuncionario> lista){
		List<BuscaMediaFerramentaFuncionarioDto> listaRetorno = new ArrayList<BuscaMediaFerramentaFuncionarioDto>();
		
		for (BuscaMediaFerramentaFuncionario media : lista) {
			
			BuscaMediaFerramentaFuncionarioDto dto = new BuscaMediaFerramentaFuncionarioDto();
			
			dto.setFerramenta_id(media.getKey().getFerramenta_id());
			dto.setFuncionario_id(media.getKey().getFuncionario_id());
			dto.setMultiplicador(media.getMultiplicador());
			dto.setConhecer(media.getConhecer());
			dto.setTotal_rating(media.getTotal_rating());
			dto.setMedia_rating(media.getMedia_rating());
			dto.setNome(media.getNome());
			dto.setMatricula(media.getMatricula());
			listaRetorno.add(dto);
		}
		return listaRetorno;
	}
}
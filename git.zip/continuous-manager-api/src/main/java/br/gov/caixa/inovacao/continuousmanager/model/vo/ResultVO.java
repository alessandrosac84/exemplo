package br.gov.caixa.inovacao.continuousmanager.model.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;

public class ResultVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4718422041772913513L;

	
	@JsonView(ViewJson.ResultVO.class)
	private JenkinsResult result;
	
	@JsonView(ViewJson.ResultVO.class)
	private Long quantidade;
	
	public ResultVO(JenkinsResult result, Long quantidade) {
		this.result = result;
		this.quantidade = quantidade;
	}

	/**
	 * @return the result
	 */
	public JenkinsResult getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(JenkinsResult result) {
		this.result = result;
	}

	/**
	 * @return the quantidade
	 */
	public Long getQuantidade() {
		return quantidade;
	}

	/**
	 * @param quantidade the quantidade to set
	 */
	public void setQuantidade(Long quantidade) {
		this.quantidade = quantidade;
	}
}

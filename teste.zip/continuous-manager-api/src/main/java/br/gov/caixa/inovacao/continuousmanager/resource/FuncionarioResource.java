package br.gov.caixa.inovacao.continuousmanager.resource;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.service.FuncionarioService;

/**
 * Classe responsavel por receber as requisicoes de consulta de usuários
 * 
 * Todas as chamadas a classe são interceptadas pela classe LoggerInterceptor
 * atraves da anotacao @Interceptors.
 * 
 * Como estamos trabalhando com Rest, utilizar sempre o escopo @RequestScoped
 * para nao sobrecarregar o servidor desnecessariamente.
 * 
 * @author Alessandro Carvalho
 *
 */

@Path("funcionarios")
@RequestScoped
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class FuncionarioResource {
	
	@Inject
	private FuncionarioService funcionarioService;

	@GET
	@JsonView(ViewJson.FuncionarioView.class)
	@Path("{filter:[a-zA-Z0-9@\\.\\-_%]+}")
	public Response obterFuncionario(@PathParam("filter") String filter) {
		return Response.ok(funcionarioService.findById(filter)).build();
	}
}

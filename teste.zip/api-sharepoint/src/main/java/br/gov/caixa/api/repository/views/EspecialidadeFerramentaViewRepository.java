package br.gov.caixa.api.repository.views;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.views.EspecialidadeFerramentaView;

public interface EspecialidadeFerramentaViewRepository extends JpaRepository<EspecialidadeFerramentaView, Long> {

		
	@Query("select a from EspecialidadeFerramentaView a where (a.especialidadeId = ?1 or a.especialidadeId is null)")
	List<EspecialidadeFerramentaView> findByEspecialidadeId(Long especialidadeId);

}

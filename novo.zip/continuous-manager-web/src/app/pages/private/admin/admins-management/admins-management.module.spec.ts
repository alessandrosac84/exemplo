import { AdminsManagementModule } from './admins-management.module';

describe('AdminsManagementModule', () => {
  let adminsManagementModule: AdminsManagementModule;

  beforeEach(() => {
    adminsManagementModule = new AdminsManagementModule();
  });

  it('should create an instance', () => {
    expect(adminsManagementModule).toBeTruthy();
  });
});

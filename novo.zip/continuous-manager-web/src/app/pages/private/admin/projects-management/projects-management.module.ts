import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectsManagementRoutingModule } from './projects-management-routing.module';
import { ProjectsManagementComponent } from './projects-management.component';
import { MaterialModule } from '../../../../core/material/material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatPaginator, MatPaginatorModule, MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { AddProjectComponent } from './add-project/add-project.component';
import { PipeModule } from '../../../../shared/pipe/pipe.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatListModule } from '@angular/material/list';
import { AddRepositoryComponent } from './add-project/add-repository/add-repository.component';

@NgModule({
  imports: [
    CommonModule,
    ProjectsManagementRoutingModule,
    MaterialModule,
    FlexLayoutModule,
    MatPaginatorModule,
    PipeModule,
    FormsModule,
    ReactiveFormsModule,
    MatListModule,
    MatDialogModule
  ],
  declarations: [ProjectsManagementComponent, AddProjectComponent, AddRepositoryComponent],
  entryComponents: [
    AddProjectComponent, AddRepositoryComponent
  ],
  providers: [{
    provide: MatDialogRef,
    useValue: {}
  }, {
    provide: MAT_DIALOG_DATA,
    useValue: {}
  }]
})
export class ProjectsManagementModule { }

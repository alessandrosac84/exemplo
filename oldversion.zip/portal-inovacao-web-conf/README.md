# Projeto de arquivos jenkins.

## Arquivo de pipeline

- Jenkinsfile-CI-DEV
- Jenkinsfile-CD-TQS
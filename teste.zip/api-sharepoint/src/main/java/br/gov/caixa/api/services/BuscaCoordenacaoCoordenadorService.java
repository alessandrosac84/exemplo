package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.data.domain.Sort;

import br.gov.caixa.api.dto.BuscaCoordenacaoCoordenadorDto;
import br.gov.caixa.api.model.BuscaCoordenacaoCoordenador;
import br.gov.caixa.api.repository.BuscaCoordenacaoCoordenadorRepository;
import br.gov.caixa.api.result.BuscaCoordenacaoCoordenadorResult;


@Named
public class BuscaCoordenacaoCoordenadorService {
	
	@Inject
	private BuscaCoordenacaoCoordenadorRepository repository;	
	
	public BuscaCoordenacaoCoordenadorResult findAll(){
				
		List<BuscaCoordenacaoCoordenador> lista = repository.findAll(new Sort(Sort.Direction.ASC, "tipo"));			
		
		BuscaCoordenacaoCoordenadorResult result = new BuscaCoordenacaoCoordenadorResult();
		result.setList(BuscaCoordenacaoCoordenadorDto.fromBuscaCoordenacaoCoordenadorToListDto(lista));
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public BuscaCoordenacaoCoordenadorResult findAll2(){
		
		List<BuscaCoordenacaoCoordenador> lista = repository.findAll(new Sort(Sort.Direction.DESC, "nome"));			
		
		BuscaCoordenacaoCoordenadorResult result = new BuscaCoordenacaoCoordenadorResult();
		result.setList(BuscaCoordenacaoCoordenadorDto.fromBuscaCoordenacaoCoordenadorToListDto(lista));
		result.setMessage("Executado com sucesso.");
		return result;
	}
	

}

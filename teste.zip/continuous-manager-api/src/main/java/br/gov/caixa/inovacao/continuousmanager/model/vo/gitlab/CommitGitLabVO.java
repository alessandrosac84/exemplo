package br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab;

import java.io.Serializable;
import java.util.Calendar;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe de representação do Commit do GitLab
 * 
 * @author Fabio Iwakoshi
 *
 */
public class CommitGitLabVO implements Serializable {

	private static final long serialVersionUID = -2723556172428546056L;

	private String id;

	@JsonProperty("short_id")
	private String shortId;

	@JsonProperty("parent_ids")
	private String[] parentIds;

	private String title;

	@JsonProperty("author_name")
	private String authorName;

	@JsonProperty("author_email")
	private String authorEmail;

	@JsonProperty("committer_name")
	private String committerName;

	@JsonProperty("committer_email")
	private String committerEmail;
	
	@JsonProperty("created_at")
	private String createdAt;

	private String message;

	@JsonProperty("committed_date")
	private Calendar committedDate;

	@JsonProperty("authored_date")
	private Calendar authoredDate;
	
	private transient Object stats;
	
	private transient Object status;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the authorName
	 */
	public String getAuthorName() {
		return authorName;
	}

	/**
	 * @param authorName the authorName to set
	 */
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	/**
	 * @return the authorEmail
	 */
	public String getAuthorEmail() {
		return authorEmail;
	}

	/**
	 * @param authorEmail the authorEmail to set
	 */
	public void setAuthorEmail(String authorEmail) {
		this.authorEmail = authorEmail;
	}

	/**
	 * @return the committerName
	 */
	public String getCommitterName() {
		return committerName;
	}

	/**
	 * @param committerName the committerName to set
	 */
	public void setCommitterName(String committerName) {
		this.committerName = committerName;
	}

	/**
	 * @return the committerEmail
	 */
	public String getCommitterEmail() {
		return committerEmail;
	}

	/**
	 * @param committerEmail the committerEmail to set
	 */
	public void setCommitterEmail(String committerEmail) {
		this.committerEmail = committerEmail;
	}

	/**
	 * @return the createdAt
	 */
	public String getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the committedDate
	 */
	public Calendar getCommittedDate() {
		return committedDate;
	}

	/**
	 * @param committedDate the committedDate to set
	 */
	public void setCommittedDate(Calendar committedDate) {
		this.committedDate = committedDate;
	}

	/**
	 * @return the authoredDate
	 */
	public Calendar getAuthoredDate() {
		return authoredDate;
	}

	/**
	 * @param authoredDate the authoredDate to set
	 */
	public void setAuthoredDate(Calendar authoredDate) {
		this.authoredDate = authoredDate;
	}

	/**
	 * @return the shortId
	 */
	public String getShortId() {
		return shortId;
	}

	/**
	 * @param shortId the shortId to set
	 */
	public void setShortId(String shortId) {
		this.shortId = shortId;
	}

	/**
	 * @return the parentIds
	 */
	public String[] getParentIds() {
		return parentIds;
	}

	/**
	 * @param parentIds the parentIds to set
	 */
	public void setParentIds(String[] parentIds) {
		this.parentIds = parentIds;
	}

	/**
	 * @return the stats
	 */
	public Object getStats() {
		return stats;
	}

	/**
	 * @param stats the stats to set
	 */
	public void setStats(Object stats) {
		this.stats = stats;
	}

	/**
	 * @return the status
	 */
	public Object getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Object status) {
		this.status = status;
	}
}

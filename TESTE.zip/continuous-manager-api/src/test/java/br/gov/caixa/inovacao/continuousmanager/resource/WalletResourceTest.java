package br.gov.caixa.inovacao.continuousmanager.resource;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Job;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Wallet;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.service.BuildLogService;
import br.gov.caixa.inovacao.continuousmanager.service.BuildService;
import br.gov.caixa.inovacao.continuousmanager.service.JobService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectService;
import br.gov.caixa.inovacao.continuousmanager.service.WalletService;

/**
 * Classe de testes do WalletResource.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class WalletResourceTest {

	@Mock
	private Response response;

	@Mock
	private ResponseBuilder responseBuilder;

	@Mock
	private WalletService walletService;

	@Mock
	private ProjectService projectService;

	@Mock
	private JobService jobService;
	
	@Mock
	private BuildService buildService;
	
	@Mock
	private BuildLogService buildLogService;

	@InjectMocks
	private WalletResource walletResource;

	private List<Wallet> wallets;

	private List<Project> projects;

	private List<Job> jobs;

	private List<Build> builds;

	@Before
	public void before() {
		wallets = EntityBuilder.createWallets();
		projects = EntityBuilder.createProjects();
		jobs = EntityBuilder.createJobs();
		builds = EntityBuilder.createBuilds();
	}

	/**
	 * Listar todas as Wallets.
	 */
	@Test
	public void testListAllWalletsDefault() {
		// Arrange
		Mockito.when(walletService.findAll(0, 30, "", "id", AscDesc.ASC)).thenReturn(wallets);
		Mockito.when(walletService.countAll("")).thenReturn((long) wallets.size());

		// Act
		Response response = walletResource.getWallets(0, 30, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertEquals("rows 0-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Listar a primeira página da lista de Sistemas
	 */
	@Test
	public void testListAllWalletsPagination() {
		// Arrange
		Mockito.when(walletService.findAll(0, 1, "", "id", AscDesc.ASC)).thenReturn(wallets.subList(0, 1));
		Mockito.when(walletService.countAll("")).thenReturn((long) wallets.size());

		// Act
		Response response = walletResource.getWallets(0, 1, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.PARTIAL_CONTENT.getStatusCode(), response.getStatus());
		assertEquals("rows 0-1/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Listar a segunda página da lista de Wallets
	 */
	@Test
	public void testListAllWalletsPaginationPage2() {
		// Arrange
		Mockito.when(walletService.findAll(1, 1, "", "id", AscDesc.ASC)).thenReturn(wallets.subList(1, 2));
		Mockito.when(walletService.countAll("")).thenReturn((long) wallets.size());

		// Act
		Response response = walletResource.getWallets(1, 1, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.PARTIAL_CONTENT.getStatusCode(), response.getStatus());
		assertEquals("rows 1-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Listar a primeira página da lista de Jobs
	 */
	@Test
	public void testListAllProjectsPagination() {
		// Arrange
		Mockito.when(projectService.findAll("inovacao", 0, 30, "", "id", AscDesc.ASC)).thenReturn(projects);
		Mockito.when(projectService.countAll("inovacao", "")).thenReturn((long) projects.size());

		// Act
		Response response = walletResource.getProjects("inovacao", 0, 30, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertEquals("rows 0-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Listar a primeira página da lista de Jobs
	 */
	@Test
	public void testListAllJobsPagination() {
		// Arrange
		Mockito.when(jobService.findAll("inovacao", "portal-inovacao", 0, 30, "", "id", AscDesc.ASC)).thenReturn(jobs);
		Mockito.when(jobService.countAll("inovacao", "portal-inovacao", "")).thenReturn((long) jobs.size());

		// Act
		Response response = walletResource.getJobs("inovacao", "portal-inovacao", 0, 30, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertEquals("rows 0-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Listar a primeira página da lista de Builds
	 */
	@Test
	public void testListAllBuildsPagination() {
		// Arrange
		Mockito.when(buildService.findAll("inovacao", "portal-inovacao", "portal-inovacao-ci-dev", 0, 30, "", "id", AscDesc.ASC)).thenReturn(builds);
		Mockito.when(buildService.countAll("inovacao", "portal-inovacao", "portal-inovacao-ci-dev", "")).thenReturn((long) builds.size());

		// Act
		Response response = walletResource.getBuilds("inovacao", "portal-inovacao", "portal-inovacao-ci-dev", 0, 30, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertEquals("rows 0-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Obtem um Build por Id
	 */
	@Test
	public void testgetBuildById() {
		// Arrange
		Mockito.when(buildService.findById("inovacao", "portal-inovacao", "portal-inovacao-ci-dev", 1)).thenReturn(builds.get(0));

		// Act
		Response response = walletResource.getBuild("inovacao", "portal-inovacao", "portal-inovacao-ci-dev", 1);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertNotNull(response.getEntity());
	}
	
	@Test
	public void testGetBuildLog() {
		// Arrange
		Mockito.when(buildLogService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt())).thenReturn("log ypsilon\nbuild 42");
		String carteira = "inovacao";
		String projeto = "sharepoint";
		String job = "sharepoint-api-cd-tqs";
		int build = 2;

		// Act
		Response response = walletResource.getLog(carteira, projeto, job, build);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertNotNull(response.getEntity());
	}
}

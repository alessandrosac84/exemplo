package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-01-30T16:53:57.805-0200")
@StaticMetamodel(Parameter.class)
public class Parameter_ {
	public static volatile SingularAttribute<Parameter, ParameterPK> id;
	public static volatile SingularAttribute<Parameter, String> credential;
	public static volatile SingularAttribute<Parameter, String> host;
	public static volatile SingularAttribute<Parameter, String> principal;
}

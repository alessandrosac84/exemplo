package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildPK_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Build_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Project;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de acesso ao banco de dados da entidade Build.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class BuildRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Metodo responsavel pela consulta paginada de Builds no banco de dados
	 * 
	 * @param Build
	 * @return Build
	 */
	public Build findById(BuildPK id) {
		return entityManager.find(Build.class, id);
	}

	/**
	 * Lista Builds por paginacao
	 * 
	 * @param offset
	 * @param limit
	 * @param search
	 * @param sort
	 * @param order
	 * @return Todos os Builds por paginacao
	 */
	public List<Build> findAll(String carteira, String projeto, String job, int offset, int limit, String search, String sort, AscDesc order) { //NOSONAR
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Build> query = builder.createQuery(Build.class);
		Root<Build> from = query.from(Build.class);

		Predicate predicate = builder.like(builder.lower(from.get(Build_.description)), "%" + search.toLowerCase() + "%");
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.wallet), carteira));
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.project), projeto));
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.job), job));

		Order ascDesc = builder.asc(from.get(sort));
		if (order != AscDesc.ASC) {
			ascDesc = builder.desc(from.get(sort));
		}

		return entityManager.createQuery(query.select(from).where(predicate).orderBy(ascDesc)).setFirstResult(offset)
				.setMaxResults(limit).getResultList();
	}

	/**
	 * Obtem o total de projetos
	 * @param search 
	 * @return Total de projetos
	 */
	public Long countAll(String carteira, String projeto, String job, String search) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);
		
		Root<Build> from = query.from(Build.class);

		Predicate predicate = builder.like(builder.lower(from.get(Build_.description)), "%" + search.toLowerCase() + "%");
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.wallet), carteira));
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.project), projeto));
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.job), job));

		return entityManager.createQuery(query.select(builder.count(query.from(Project.class))).where(predicate)).getSingleResult();
	}

	/**
	 * Salva Build
	 * 
	 * @param Build
	 * @return Build
	 */
	public Build save(Build build) {
		entityManager.persist(build);
		return build;
	}
}

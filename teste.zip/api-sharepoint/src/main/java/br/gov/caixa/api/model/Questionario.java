package br.gov.caixa.api.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.gov.caixa.api.dto.QuestionarioDto;

@Entity
@Table(name = "questionario")
public class Questionario {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "QUESTAO")
	private String questao;	
		
	@Column(name = "QUESTIONARIO", length = 99000)
	private String questionario;
	
	@Column(name = "DATA_ENTRADA", nullable = true)
	private Date dataEntrada;
	
	@Column(name = "DATA_SAIDA", nullable = true)
	private Date dataSaida;
	
	@Column(name = "DATA_PROFILE", nullable = true)
	private Date dataQuestionario;
	
	@OneToMany(mappedBy="questionario", cascade=CascadeType.REMOVE, orphanRemoval=true )
    private Set<Questionante> ratingAtividades = new HashSet<Questionante>();

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public String getQuestao() {
		return questao;
	}

	public void setQuestao(String questao) {
		this.questao = questao;
	}
	
	public String getQuestionario() {
		return questionario;
	}

	public void setQuestionario(String questionario) {
		this.questionario = questionario;
	}		
			
	public Date getDataEntrada() {
		return dataEntrada;
	}

	public void setDataEntrada(Date dataEntrada) {
		this.dataEntrada = dataEntrada;
	}

	public Date getDataSaida() {
		return dataSaida;
	}

	public void setDataSaida(Date dataSaida) {
		this.dataSaida = dataSaida;
	}
	
	public Date getDataQuestionario() {
		return dataQuestionario;
	}

	public void setDataQuestionario(Date dataQuestionario) {
		this.dataQuestionario = dataQuestionario;
	}

	public static Questionario fromDtoToQuestionario(QuestionarioDto dto) {
		
		Questionario questionario = new Questionario();
		
		questionario.setUid(dto.getUid());
		questionario.setQuestao(dto.getQuestao());
		questionario.setQuestionario(dto.getQuestionario());
		questionario.setDataEntrada(dto.getDataEntrada());
		questionario.setDataSaida(dto.getDataSaida());
		questionario.setDataQuestionario(dto.getDataQuestionario());
				
		return questionario;
	}

}
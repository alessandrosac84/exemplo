package br.gov.caixa.api.model.views;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ativos_funcionario_detalhes_view")
public class AtivosFuncionarioDetalhesView {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;	
		
	@Column(name = "NOME")
	private String nome;
	
	@Column(name = "MATRICULA")
	private String matricula;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "ATIVO_ID")
	private Long ativoId;
	
	@Column(name = "CONHECO")
	private boolean naoConheco;
	
	@Column(name = "CONHECER")
	private boolean queroConhecer;
	
	@Column(name = "RATING")
	private Integer rating;	
	
	@Column(name = "FUNCIONARIO_ID")
	private Long funcionarioId;
	
	@Column(name = "GRUPO")
	private String grupo;
	
	@Column(name = "TIPO")
	private String tipo;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getAtivoId() {
		return ativoId;
	}

	public void setAtivoId(Long ativoId) {
		this.ativoId = ativoId;
	}

	public boolean isNaoConheco() {
		return naoConheco;
	}

	public void setNaoConheco(boolean naoConheco) {
		this.naoConheco = naoConheco;
	}

	public boolean isQueroConhecer() {
		return queroConhecer;
	}

	public void setQueroConhecer(boolean queroConhecer) {
		this.queroConhecer = queroConhecer;
	}

	public Long getFuncionarioId() {
		return funcionarioId;
	}
	
	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public void setFuncionarioId(Long funcionarioId) {
		this.funcionarioId = funcionarioId;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}	
		
}

import { Step } from './step.model';
export class Stage {
    public name: string;
    public steps: Step[];
}

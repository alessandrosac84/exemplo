/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsResult;

/**
 * Classe de representação do Build do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class BuildJenkinsVO implements Serializable {

	private static final long serialVersionUID = 3381635580774841468L;
	
	@JsonProperty("_class")
	private String clazz;
	
	private String description;
	
	private Long duration;
	
	private Long estimatedDuration;
	
	private Integer number;
	
	private JenkinsResult result;
	
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd'T'HH:mm:ss.SSSZ", timezone="America/Sao_Paulo")
	private Calendar timestamp;
	
	private List<ChangeSetJenkinsVO> changeSets;
	
	private List<ActionJenkinsVO> actions;

	/**
	 * @return the clazz
	 */
	public String getClazz() {
		return clazz;
	}

	/**
	 * @param clazz the clazz to set
	 */
	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	/**
	 * @return the changeSets
	 */
	public List<ChangeSetJenkinsVO> getChangeSets() {
		return changeSets;
	}

	/**
	 * @param changeSets the changeSets to set
	 */
	public void setChangeSets(List<ChangeSetJenkinsVO> changeSets) {
		this.changeSets = changeSets;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the duration
	 */
	public Long getDuration() {
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(Long duration) {
		this.duration = duration;
	}

	/**
	 * @return the estimatedDuration
	 */
	public Long getEstimatedDuration() {
		return estimatedDuration;
	}

	/**
	 * @param estimatedDuration the estimatedDuration to set
	 */
	public void setEstimatedDuration(Long estimatedDuration) {
		this.estimatedDuration = estimatedDuration;
	}

	/**
	 * @return the number
	 */
	public Integer getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(Integer number) {
		this.number = number;
	}

	/**
	 * @return the result
	 */
	public JenkinsResult getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(JenkinsResult result) {
		this.result = result;
	}

	/**
	 * @return the timestamp
	 */
	public Calendar getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(Calendar timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the actions
	 */
	public List<ActionJenkinsVO> getActions() {
		return actions;
	}

	/**
	 * @param actions the actions to set
	 */
	public void setActions(List<ActionJenkinsVO> actions) {
		this.actions = actions;
	}
}

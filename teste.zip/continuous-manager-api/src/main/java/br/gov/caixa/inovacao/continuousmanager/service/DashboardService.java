package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.Measures;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.model.vo.ResultVO;

/**
 * Classe de servicos do Sonar.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class DashboardService {

	@Inject
	private Logger log;
	
	@Inject
	private BuildService buildService;
	
	@Inject
	private MeasuresService measuresService;

	public List<Measures> findAll(int offset, int limit, String search, String sort, AscDesc order) {
		log.log(Level.FINE,
				"Listando Dashboards : offset :: {0} :: limit :: {1} :: search :: {2} :: sort :: {3} :: order :: {4}",
				new Object[] { offset, limit, search, sort, order });
		return measuresService.findAll(offset, limit, search, sort, order);
	}
	
	public Long countAll(String search) {
		log.log(Level.FINE, "Contando Dashboards:: search :: {0}", search);
		return measuresService.countAll(search);
	}
	
	public Measures findById(String wallet, String projeto, String commit) {
		log.fine("Obtendo detail item dashboard");
		return measuresService.findById(wallet, projeto, commit);
	}
	
	public List<ResultVO> findBuildsById(String wallet, String projeto) {
		log.fine("Obtendo detail item dashboard");
		return buildService.findBuildsById(wallet, projeto);
	}
}
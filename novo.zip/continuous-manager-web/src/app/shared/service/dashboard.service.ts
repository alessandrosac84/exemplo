import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';

import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { Wallet } from '../model/entity/wallet.model';
import { Project } from '../model/entity/project.model';
import { Job } from '../model/entity/job.model';
import { Build } from '../model/entity/build.model';
import { Stage } from '../model/vo/stage.model';
import { CedesBuilds } from '../model/vo/cedesBuilds.model';
import { ProjectsBuildsStatus } from '../model/vo/projectsBuildsStatus';
import { Repository } from '../model/entity/repository.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

    constructor(private http: HttpClient) { }


    getProject(project: number): Observable<Project> {
        // return this.http.get<Project[]>(`${this.walletUrl}${this.projectsUrl}`);
        return this.http.get<Project>('../../../assets/file/project.json');
    }

    getProjects(): Observable<Project[]> {
        // return this.http.get<Project[]>(`${this.walletUrl}${this.projectsUrl}`);
        return this.http.get<Project[]>('../../../assets/file/projects.json');
    }

    getProjectWeekStatus(project: Project): Observable<Project[]> {
    // return this.http.get<Project[]>(`${this.walletUrl}${this.projectsUrl}`);
    return this.http.get<Project[]>('../../../assets/file/projectWeekStatus.json');
    }

    getProjectInfoSonar(project: Project): Observable<Project[]> {
    // return this.http.get<Project[]>(`${this.walletUrl}${this.projectsUrl}`);
    return this.http.get<Project[]>('../../../assets/file/projectInfoSonar.json');
    }

    getRepositories(project: number): Observable<Repository[]> {
    return this.http.get<Repository[]>('../../../assets/file/repositories.json');
    }
}



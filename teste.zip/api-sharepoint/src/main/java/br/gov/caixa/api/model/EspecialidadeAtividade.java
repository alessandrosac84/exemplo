package br.gov.caixa.api.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.gov.caixa.api.dto.EspecialidadeAtividadeDto;

@Entity
@Table(name = "especialidade_atividade")
public class EspecialidadeAtividade {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "rating")
	private Integer rating;

	@ManyToOne
	@JoinColumn(name = "ESPECIALIDADE_ID")
	private Especialidade especialidade;
	
	@ManyToOne
	@JoinColumn(name = "ATIVIDADE_ID")
	private Atividade atividade;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public Especialidade getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(Especialidade especialidade) {
		this.especialidade = especialidade;
	}
	
	public Atividade getAtividade() {
		return atividade;
	}

	public void setAtividade(Atividade atividade) {
		this.atividade = atividade;
	}
	
	public static EspecialidadeAtividade fromDtoToEspecialidadeAtividade(EspecialidadeAtividadeDto dto) {
		EspecialidadeAtividade especialidadeAtividade = new EspecialidadeAtividade();
		
		especialidadeAtividade.setUid(dto.getUid());
		especialidadeAtividade.setRating(dto.getRating());
		especialidadeAtividade.setEspecialidade(Especialidade.fromDtoToEspecialidade(dto.getEspecialidadeDto()));
		especialidadeAtividade.setAtividade(Atividade.fromDtoToAtividade(dto.getAtividadeDto()));
		
		return especialidadeAtividade;
	}
	
	public static List<EspecialidadeAtividade> fromDtoAtividadeToListEspecialidadeAtividade(List<EspecialidadeAtividadeDto> especialidadeAtividades) {
		List<EspecialidadeAtividade> returnList = new ArrayList<EspecialidadeAtividade>();
		
		for (EspecialidadeAtividadeDto dto : especialidadeAtividades) {		    						
			returnList.add(fromDtoToEspecialidadeAtividade(dto));		
		}
		
		return returnList;
	}	
}

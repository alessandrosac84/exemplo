package br.gov.caixa.api.result;


import java.util.List;

import br.gov.caixa.api.dto.BuscaMediaFerramentaFuncionarioDto;

public class BuscaMediaFerramentaFuncionarioResult extends BasicResult {

	private List<BuscaMediaFerramentaFuncionarioDto> list;
	private BuscaMediaFerramentaFuncionarioDto buscaMediaFuncionarioDto;

	public List<BuscaMediaFerramentaFuncionarioDto> getList() {
		return list;
	}

	public void setList(List<BuscaMediaFerramentaFuncionarioDto> list) {
		this.list = list;
	}

	public BuscaMediaFerramentaFuncionarioDto getBuscaMediaFerramentaFuncionarioDto() {
		return buscaMediaFuncionarioDto;
	}

	public void setBuscaMediaFerramentaFuncionarioDto(
			BuscaMediaFerramentaFuncionarioDto buscaMediaFuncionarioDto) {
		this.buscaMediaFuncionarioDto = buscaMediaFuncionarioDto;
	}

}

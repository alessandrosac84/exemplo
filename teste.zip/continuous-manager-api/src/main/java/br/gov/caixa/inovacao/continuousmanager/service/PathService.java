/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Path;
import br.gov.caixa.inovacao.continuousmanager.model.repository.PathRepository;

/**
 * Classe de servicos de Path.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class PathService {

	@Inject
	private Logger log;

	@Inject
	private PathRepository pathRepository;

	public Path save(@Valid Path path) {
		log.log(Level.FINE, "Salvando Path :: {0}", path.getId());
		return pathRepository.save(path);
	}
}

package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;


/**
 * The persistent class for the git_repo database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name="commit")
@NamedQuery(name="Commit.findAll", query="SELECT g FROM Commit g")
public class Commit implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonView({ViewJson.BuildView.class, ViewJson.CommitView.class})
	@EmbeddedId
	private CommitPK id;

	@Column(name="author_email", nullable=false, length=70)
	private String authorEmail;

	@Column(name="author_name", nullable=false, length=100)
	private String authorName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="authored_date", nullable=false)
	private Calendar authoredDate;

	@Temporal(TemporalType.TIMESTAMP)
	@JsonView({ViewJson.BuildView.class, ViewJson.CommitView.class})
	@Column(name="committed_date", nullable=false)
	private Calendar committedDate;

	@JsonView(ViewJson.CommitView.class)
	@Column(name="committer_email", nullable=false, length=70)
	private String committerEmail;

	@JsonView(ViewJson.CommitView.class)
	@Column(name="committer_name", nullable=false, length=100)
	private String committerName;
	
	@JsonView(ViewJson.CommitView.class)
	@Column(columnDefinition = "TEXT")
	private String message;

	@JsonView({ViewJson.BuildView.class, ViewJson.CommitView.class})
	@Column(nullable=false, length=255)
	private String title;

	@JsonView(ViewJson.CommitView.class)
	@Column(length=20)
	private String version;

	@JsonView(ViewJson.CommitView.class)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="versioned_at")
	private Calendar versionedAt;

	@JsonView(ViewJson.CommitView.class)
	@Column(name="versioner_user", length=7)
	private String versionerUser;
	
	//bi-directional one-to-one association to Path
	@OneToMany(mappedBy="commit", fetch=FetchType.LAZY)
	private Set<Path> paths;
	
	//bi-directional many-to-many association to Commit
	@JsonView(ViewJson.CommitView.class)
	@OneToMany(mappedBy="commit", fetch=FetchType.LAZY)
	private Set<ChangeSet> changeSets;

	//bi-directional many-to-one association to Project
	@JsonView(ViewJson.SonarView.class)
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="project", referencedColumnName="id", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private Project project;

	// bi-directional one-to-one association to Sonar
	@OneToMany(mappedBy = "commit", fetch = FetchType.LAZY)
	private  Set<Measures> measures;

	public Commit() {
		/* class constructor intentionally left blank */
	}

	public CommitPK getId() {
		return this.id;
	}

	public void setId(CommitPK id) {
		this.id = id;
	}

	public String getAuthorEmail() {
		return this.authorEmail;
	}

	public void setAuthorEmail(String authorEmail) {
		this.authorEmail = authorEmail;
	}

	public String getAuthorName() {
		return this.authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Calendar getAuthoredDate() {
		return this.authoredDate;
	}

	public void setAuthoredDate(Calendar authoredDate) {
		this.authoredDate = authoredDate;
	}

	public Calendar getCommittedDate() {
		return this.committedDate;
	}

	public void setCommittedDate(Calendar committedDate) {
		this.committedDate = committedDate;
	}

	public String getCommitterEmail() {
		return this.committerEmail;
	}

	public void setCommitterEmail(String committerEmail) {
		this.committerEmail = committerEmail;
	}

	public String getCommitterName() {
		return this.committerName;
	}

	public void setCommitterName(String committerName) {
		this.committerName = committerName;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Calendar getVersionedAt() {
		return this.versionedAt;
	}

	public void setVersionedAt(Calendar versionedAt) {
		this.versionedAt = versionedAt;
	}

	public String getVersionerUser() {
		return this.versionerUser;
	}

	public void setVersionerUser(String versionerUser) {
		this.versionerUser = versionerUser;
	}

	public Set<ChangeSet> getChangeSets() {
		return this.changeSets;
	}

	public void setChangeSets(Set<ChangeSet> changeSets) {
		this.changeSets = changeSets;
	}

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public void setPaths(Set<Path> paths) {
		this.paths = paths;
	}

	public Set<Path> getPaths() {
		return paths;
	}

	/**
	 * @return the measures
	 */
	public Set<Measures> getMeasures() {
		return measures;
	}

	/**
	 * @param measures the measures to set
	 */
	public void setMeasures(Set<Measures> measures) {
		this.measures = measures;
	}
}
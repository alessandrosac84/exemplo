export class Commit {
    public id: string;
    public shortId: string;
    public title: string;
    public createdAt: string;
    public message: string;
    public authorName: string;
    public authorEmail: string;
    public authoredDate: string;
    public committerName: string;
    public committerEmail: string;
    public committedDate: string;
}

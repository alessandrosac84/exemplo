package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-02-07T10:04:21.406-0200")
@StaticMetamodel(Path.class)
public class Path_ {
	public static volatile SingularAttribute<Path, PathPK> id;
	public static volatile SingularAttribute<Path, EditType> editType;
	public static volatile SingularAttribute<Path, GitRepo> gitRepo;
}

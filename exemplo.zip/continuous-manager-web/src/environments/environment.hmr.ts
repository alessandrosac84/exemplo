export const environment = {
  production: false,
  apiBaseUrl: 'http://10.1.32.240:8092/continuous-manager-api/',
  hmr: true
};

package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-04-18T09:30:24.830-0300")
@StaticMetamodel(ChangeSet.class)
public class ChangeSet_ {
	public static volatile SingularAttribute<ChangeSet, ChangeSetPK> id;
	public static volatile SingularAttribute<ChangeSet, Build> build;
	public static volatile SingularAttribute<ChangeSet, GitRepo> gitRepo;
}

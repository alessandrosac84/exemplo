package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-19T15:03:11.721-0300")
@StaticMetamodel(Flavor.class)
public class Flavor_ {
	public static volatile SingularAttribute<Flavor, Integer> id;
	public static volatile SingularAttribute<Flavor, String> description;
	public static volatile SingularAttribute<Flavor, String> javaVersion;
	public static volatile SingularAttribute<Flavor, String> pathHome;
	public static volatile SingularAttribute<Flavor, String> ownerId;
	public static volatile SingularAttribute<Flavor, TypeServer> typeServer;
	public static volatile SingularAttribute<Flavor, String> version;
	public static volatile SetAttribute<Flavor, Server> servers;
}

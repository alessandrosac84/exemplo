package br.gov.caixa.api.dto.views;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeProcessoView;

public class EspecialidadeProcessoViewDto {

	private Long uid;	
	private String processo;
	private Long especialidadeId;
	private String especialidade;
	private Integer rating;
	private Long especialidadeProcessoId;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public String getProcesso() {
		return processo;
	}

	public void setProcesso(String processo) {
		this.processo = processo;
	}

	public Long getEspecialidadeId() {
		return especialidadeId;
	}

	public void setEspecialidadeId(Long especialidadeId) {
		this.especialidadeId = especialidadeId;
	}

	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}


	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}
	
	public Long getEspecialidadeProcessoId() {
		return especialidadeProcessoId;
	}

	public void setEspecialidadeProcessoId(Long especialidadeProcessoId) {
		this.especialidadeProcessoId = especialidadeProcessoId;
	}

	public static EspecialidadeProcessoViewDto fromEspecialidadeProcessoViewToDto(EspecialidadeProcessoView especialidadeProcessoView) {
		EspecialidadeProcessoViewDto dto = new EspecialidadeProcessoViewDto();
		
		dto.setUid(especialidadeProcessoView.getUid());
		dto.setProcesso(especialidadeProcessoView.getProcesso());
		dto.setEspecialidade(especialidadeProcessoView.getEspecialidade());
		dto.setEspecialidadeId(especialidadeProcessoView.getEspecialidadeId());
		dto.setEspecialidadeProcessoId(especialidadeProcessoView.getEspecialidadeProcessoId());
		dto.setRating(especialidadeProcessoView.getRating());
		
		return dto;
	}
	
	public static List<EspecialidadeProcessoViewDto> fromEspecialidadeProcessoViewToListDto(List<EspecialidadeProcessoView> especialidadeProcessoViews) {
		List<EspecialidadeProcessoViewDto> returnList = new ArrayList<EspecialidadeProcessoViewDto>();
		
		for (EspecialidadeProcessoView especialidadeProcessoView : especialidadeProcessoViews) {
			
			returnList.add(fromEspecialidadeProcessoViewToDto(especialidadeProcessoView) );
		}
		return returnList;
	}
}

package br.gov.caixa.inovacao.continuousmanager.model.vo;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * Classe de representação dos Steps do Build
 * 
 * @author Fabio Iwakoshi
 *
 */
public class Step {

	@JsonView(ViewJson.LogStageView.class)
	private String name;
	
	@JsonView(ViewJson.LogStageView.class)
	private String lines;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the lines
	 */
	public String getLines() {
		return lines;
	}

	/**
	 * @param lines the lines to set
	 */
	public void setLines(String lines) {
		this.lines = lines;
	}
}

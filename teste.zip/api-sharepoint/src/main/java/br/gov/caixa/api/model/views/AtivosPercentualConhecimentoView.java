package br.gov.caixa.api.model.views;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ativo_percentuais_conhecimento_view")
public class AtivosPercentualConhecimentoView {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "GRUPO")
	private String grupo;
	
	@Column(name = "TIPO")
	private String tipo;	
	
	@Column(name = "NOME")
	private String nome;
	
	@Column(name = "ATIVO_ID")
	private Long ativoId;
	
	@Column(name = "TOTAL")
	private Long total;
	
	@Column(name = "NAO_CONHECO")
	private Long naoConheco;
	
	@Column(name = "QUERO_CONHECER")
	private Long queroConhecer;
	
	@Column(name = "QUERO_CONHECER_NAO_CONHECO_NADA")
	private Long queroConhecerNaoConhecoNada;

	@Column(name = "RATEOU")
	private Long rateou;
	
	@Column(name = "NAO_RATEOU")
	private Long naoRateou;

	public final Long getUid() {
		return uid;
	}

	public final void setUid(Long uid) {
		this.uid = uid;
	}	

	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public final String getTipo() {
		return tipo;
	}

	public final void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final Long getTotal() {
		return total;
	}

	public final void setTotal(Long total) {
		this.total = total;
	}

	public final Long getNaoConheco() {
		return naoConheco;
	}

	public final void setNaoConheco(Long naoConheco) {
		this.naoConheco = naoConheco;
	}

	public final Long getQueroConhecer() {
		return queroConhecer;
	}

	public final void setQueroConhecer(Long queroConhecer) {
		this.queroConhecer = queroConhecer;
	}

	public final Long getQueroConhecerNaoConhecoNada() {
		return queroConhecerNaoConhecoNada;
	}

	public final void setQueroConhecerNaoConhecoNada(Long queroConhecerNaoConhecoNada) {
		this.queroConhecerNaoConhecoNada = queroConhecerNaoConhecoNada;
	}

	public final Long getRateou() {
		return rateou;
	}

	public final void setRateou(Long rateou) {
		this.rateou = rateou;
	}

	public final Long getNaoRateou() {
		return naoRateou;
	}

	public final void setNaoRateou(Long naoRateou) {
		this.naoRateou = naoRateou;
	}

	public Long getAtivoId() {
		return ativoId;
	}

	public void setAtivoId(Long ativoId) {
		this.ativoId = ativoId;
	}	
	
}

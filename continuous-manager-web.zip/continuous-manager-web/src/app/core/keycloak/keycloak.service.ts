import { Injectable } from '@angular/core';

import { Observable, Observer, from, Subject } from 'rxjs';

import { environment } from '../../../environments/environment';
import { KeycloakEvent, KeycloakEventType } from './keycloak-event';

import './keycloak';

@Injectable()
export class KeycloakService {
  private keycloak: KeycloakModule.KeycloakClient;
  private _userProfile: KeycloakModule.KeycloakProfile;
  private _keycloakEvents$: Subject<KeycloakEvent>;

  constructor() {
    this._keycloakEvents$ = new Subject<KeycloakEvent>();
  }

  init(options: KeycloakModule.InitOptions = {}) {
    return new Promise(async (resolve, reject) => {
      this.keycloak = new Keycloak(environment.keycloak);
      this.bindsKeycloakEvents();
      this.keycloak
      .init(options)
      .success(async authenticated => {
        console.log('Autenticado :: ' + authenticated);
        resolve(authenticated);
      })
      .error(error => {
        reject('Um erro aconteceu durante a inicialização do Keycloak.');
      });
    });
  }

  isLoggedIn(): boolean {
    return this.keycloak.authenticated;
  }

  login(): Observable<any> {
    return this.from(this.keycloak.login());
  }

  logout(redirectUri?: string): Observable<any> {
    return from(new Promise((resolve, reject) => {
      const options: any = {
        redirectUri
      };
      this.keycloak
        .logout(options)
        .success(() => {
          this._userProfile = null;
          resolve();
        })
        .error(error => {
          reject('Um erro aconteceu durante o logout.');
        });
    }));
  }

  getUserRoles(allRoles: boolean = true): string[] {
    let roles: string[] = [];
    if (this.keycloak.resourceAccess) {
      for (const key in this.keycloak.resourceAccess) {
        if (this.keycloak.resourceAccess.hasOwnProperty(key)) {
          const resourceAccess: any = this.keycloak.resourceAccess[key];
          const clientRoles = resourceAccess['roles'] || [];
          roles = roles.concat(clientRoles);
        }
      }
    }
    if (allRoles && this.keycloak.realmAccess) {
      const realmRoles = this.keycloak.realmAccess['roles'] || [];
      roles.push(...realmRoles);
    }
    return roles;
  }

  loadUserProfile(forceReload: boolean = false): Observable<KeycloakModule.KeycloakProfile> {
    return from(new Promise(async (resolve, reject) => {
      if (this._userProfile && !forceReload) {
        resolve(this._userProfile);
        return;
      }

      if (!this.isLoggedIn()) {
        reject('O usuário não está logado. Seu profile não foi carregado.');
        return;
      }

      this.keycloak
        .loadUserProfile()
        .success(result => {
          this._userProfile = result as KeycloakModule.KeycloakProfile;
          resolve(this._userProfile);
        })
        .error(err => {
          reject('O profile do usuário não pode ser carregado.');
        });
    }));
  }

  getToken(): Observable<string> {
    return from(new Promise(async (resolve, reject) => {
      try {
        await this.updateToken(10);
        resolve(this.keycloak.token);
      } catch (error) {
        this.login();
      }
    }));
  }

  get keycloakEvents$(): Subject<KeycloakEvent> {
    return this._keycloakEvents$;
  }

  private bindsKeycloakEvents(): void {
    if (!this.keycloak) {
      console.warn(
        'Eventos do Keycloak Angular não podem ser registrados por que uma instancia do keycloak não foi definida.'
      );
      return;
    }

    this.keycloak.onAuthError = errorData => {
      console.error('Keycloak! :: ' + errorData);
      this._keycloakEvents$.next({ args: {error: errorData, authenticated: this.isLoggedIn()}, type: KeycloakEventType.OnAuthError });
    };

    this.keycloak.onAuthLogout = () => {
      console.log('Keycloak! :: On Auth Logout');
      this._keycloakEvents$.next({ args: {authenticated: this.isLoggedIn()}, type: KeycloakEventType.OnAuthLogout });
    };

    this.keycloak.onAuthRefreshError = () => {
      console.log('Keycloak! :: On Auth Refresh Error');
      this._keycloakEvents$.next({ args: {authenticated: this.isLoggedIn()}, type: KeycloakEventType.OnAuthRefreshError });
    };

    this.keycloak.onAuthSuccess = () => {
      console.log('Keycloak! :: On Auth Success');
      this._keycloakEvents$.next({ args: {authenticated: this.isLoggedIn()}, type: KeycloakEventType.OnAuthSuccess });
    };

    this.keycloak.onTokenExpired = () => {
      console.log('Keycloak! :: On Token Expired');
      this._keycloakEvents$.next({ args: {authenticated: this.isLoggedIn()}, type: KeycloakEventType.OnTokenExpired });
    };

    this.keycloak.onReady = authenticated => {
      console.log('Keycloak! :: On Ready');
      this._keycloakEvents$.next({ args: {authenticated: authenticated}, type: KeycloakEventType.OnReady });
    };
  }

  private updateToken(minValidity: number = 10): Promise<boolean> {
    return new Promise(async (resolve, reject) => {
      if (!this.keycloak) {
        reject();
        return;
      }
      this.keycloak
        .updateToken(minValidity)
        .success(refreshed => {
          resolve(refreshed);
        })
        .error(error => {
          reject('Falha ao atualizar o token, ou a sessão está expirada!');
        });
    });
  }

  private from(promisse: KeycloakModule.Promise): Observable<any> {
    return Observable.create(
      async (observer: Observer<boolean>) => {
        promisse.success(data => observer.next(data));
        promisse.error(data => observer.error(data));
      }
    );
  }
}

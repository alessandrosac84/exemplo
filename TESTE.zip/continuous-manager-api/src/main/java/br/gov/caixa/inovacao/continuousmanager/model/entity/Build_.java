package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.util.Calendar;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-05-18T12:45:44.022-0300")
@StaticMetamodel(Build.class)
public class Build_ {
	public static volatile SingularAttribute<Build, BuildPK> id;
	public static volatile SingularAttribute<Build, Calendar> createdAt;
	public static volatile SingularAttribute<Build, String> description;
	public static volatile SingularAttribute<Build, Date> duration;
	public static volatile SingularAttribute<Build, Date> estimateDuration;
	public static volatile SingularAttribute<Build, LocalError> localError;
	public static volatile SingularAttribute<Build, JenkinsResult> result;
	public static volatile SingularAttribute<Build, JenkinsPhase> phase;
	public static volatile SingularAttribute<Build, Job> job;
	public static volatile SetAttribute<Build, ChangeSet> changeSets;
	public static volatile SetAttribute<Build, BuildLog> buildLogs;
	public static volatile SetAttribute<Build, ProjectEnvironment> projectEnvironments;
}

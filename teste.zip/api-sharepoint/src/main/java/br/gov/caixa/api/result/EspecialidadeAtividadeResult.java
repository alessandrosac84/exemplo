package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.EspecialidadeAtividadeDto;

public class EspecialidadeAtividadeResult extends BasicResult {
	private List<EspecialidadeAtividadeDto> list;
	private EspecialidadeAtividadeDto especialidadeAtividade;

	public List<EspecialidadeAtividadeDto> getList() {
		return list;
	}

	public void setList(List<EspecialidadeAtividadeDto> list) {
		this.list = list;
	}

	public EspecialidadeAtividadeDto getEspecialidadeAtividade() {
		return especialidadeAtividade;
	}

	public void setEspecialidadeAtividade(EspecialidadeAtividadeDto especialidadeAtividade) {
		this.especialidadeAtividade = especialidadeAtividade;
	}
}
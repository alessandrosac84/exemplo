package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;

/**
 * 
 * @author Alessandro Carvalho
 * 
 */
public class InfoSonarVO  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4603359087959882676L;
	
	/**
	 * 
	 */
	private TaskVO task;

	/**
	 * @return the task
	 */
	public TaskVO getTask() {
		return task;
	}

	/**
	 * @param task the task to set
	 */
	public void setTask(TaskVO task) {
		this.task = task;
	}

}

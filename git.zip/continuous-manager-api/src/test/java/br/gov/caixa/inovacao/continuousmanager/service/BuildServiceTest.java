/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import br.gov.caixa.inovacao.continuousmanager.model.repository.BuildRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes do BuildService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BuildServiceTest {
	
	@Mock
	private BuildRepository buildRepository;

	@InjectMocks
	private BuildService buildService;

	private List<Build> builds;
	
	@Before
	public void before() {
		builds = EntityBuilder.createBuilds();
		UtilReflection.setField(buildService, "log", Logger.getLogger(BuildService.class.getName()));
	}
	
	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(buildRepository.findById(builds.get(0).getId())).thenReturn(builds.get(0));
		
		// Act
		Build build = buildService.findById(builds.get(0).getId());

		// Then
		Assert.assertEquals(1, build.getId().getId().intValue());
		Assert.assertEquals("continuous-manager-web-ci-dev", build.getId().getJob());
		Assert.assertEquals("continuous-manager-web", build.getId().getProject());
		Assert.assertEquals("inovacao", build.getId().getWallet());
		Assert.assertNotNull(build.getChangeSets());
		Assert.assertNotNull(build.getCreatedAt());
		Assert.assertEquals("description", build.getDescription());
		Assert.assertNotNull(build.getDuration());
		Assert.assertNotNull(build.getEstimateDuration());
		Assert.assertNull(build.getJob());
		Assert.assertNotNull(build.getProjectEnvironments());
		Assert.assertEquals(JenkinsResult.SUCCESS, build.getResult());
	}
	
	@Test
	public void testFindById2() {
		// Arrange
		Mockito.when(buildRepository.findById(builds.get(0).getId())).thenReturn(builds.get(0));
		
		// Act
		Build build = buildService.findById(builds.get(0).getId().getWallet(), builds.get(0).getId().getProject(), builds.get(0).getId().getJob(), builds.get(0).getId().getId());

		// Then
		Assert.assertEquals(1, build.getId().getId().intValue());
		Assert.assertEquals("continuous-manager-web-ci-dev", build.getId().getJob());
		Assert.assertEquals("continuous-manager-web", build.getId().getProject());
		Assert.assertEquals("inovacao", build.getId().getWallet());
		Assert.assertNotNull(build.getChangeSets());
		Assert.assertNotNull(build.getCreatedAt());
		Assert.assertEquals("description", build.getDescription());
		Assert.assertNotNull(build.getDuration());
		Assert.assertNotNull(build.getEstimateDuration());
		Assert.assertNull(build.getJob());
		Assert.assertNotNull(build.getProjectEnvironments());
		Assert.assertEquals(JenkinsResult.SUCCESS, build.getResult());
	}
	
	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(buildRepository.findAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 0, 30, "id", AscDesc.ASC)).thenReturn(builds);
		
		// Act
		List<Build> listBuilds = buildService.findAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 0, 30, "id", AscDesc.ASC);

		// Then
		Assert.assertEquals(2, listBuilds.size());
	}
	
	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(buildRepository.countAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev")).thenReturn((long) builds.size());
		
		// Act
		Long contBuilds = buildService.countAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev");

		// Then
		Assert.assertEquals(2, contBuilds.longValue());
	}
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(buildRepository.save(builds.get(0))).thenReturn(builds.get(0));
		
		// Act
		Build build = buildService.save(builds.get(0));

		// Then
		Assert.assertEquals(builds.get(0).getId(), build.getId());
	}
	
	@Test
	public void testUpdate() {
		// Arrange
		Mockito.when(buildRepository.update(builds.get(0))).thenReturn(builds.get(0));
		
		// Act
		Build build = buildService.update(builds.get(0));

		// Then
		Assert.assertEquals(builds.get(0).getId(), build.getId());
	}
	
	@Test
	public void testFindAllToRelease() {
		// Arrange
		Mockito.when(buildRepository.findAllToRelease(Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(new ArrayList<>(EntityBuilder.createBuilds()));

		// Act
		List<Build> savedCommits = buildService.findAllToRelease("inovacao", "continuous-manager-web", JenkinsResult.SUCCESS, 0, 30);

		// Then
		Assert.assertNotNull(savedCommits);
	}

	@Test
	public void testCountToReleaseAll() {
		// Arrange
		Mockito.when(buildRepository.countToReleaseAll(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(1L);

		// Act
		Long commits = buildService.countToReleaseAll("inovacao", "continuous-manager-web", JenkinsResult.SUCCESS);

		// Then
		Assert.assertEquals(1L, commits.longValue());
	}
}

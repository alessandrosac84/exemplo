package br.gov.caixa.api.model.views;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "funcionario_coordenacoes_view")
public class FuncionarioCoordenacoesView {

	@Id
	@Column(name = "UID")
	private Long uid;
	
//	public Long getUid() {
//		return uid;
//	}
//
//	public void setUid(Long uid) {
//		this.uid = uid;
//	}

//	public FuncionarioCoordenacaoView getFuncionarioCoordenacaoView() {
//		return funcionarioCoordenacaoView;
//	}
//
//	public void setFuncionarioCoordenacaoView(FuncionarioCoordenacaoView funcionarioCoordenacaoView) {
//		this.funcionarioCoordenacaoView = funcionarioCoordenacaoView;
//	}

	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	@ManyToOne
    @JoinColumn(name="FUNCIONARIO_ID")
    private FuncionarioCoordenacaoView funcionarioCoordenacaoView;

	@Column(name = "GRUPO", nullable = false)
	private String grupo;
	
}
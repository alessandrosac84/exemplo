package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the atividade_funcionario database table.
 * 
 */
@Embeddable
public class AtividadeFuncionarioPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private Integer atividade;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=7)
	private String funcionario;

	public AtividadeFuncionarioPK() {
	}
	public Integer getAtividade() {
		return this.atividade;
	}
	public void setAtividade(Integer atividade) {
		this.atividade = atividade;
	}
	public String getFuncionario() {
		return this.funcionario;
	}
	public void setFuncionario(String funcionario) {
		this.funcionario = funcionario;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AtividadeFuncionarioPK)) {
			return false;
		}
		AtividadeFuncionarioPK castOther = (AtividadeFuncionarioPK)other;
		return 
			this.atividade.equals(castOther.atividade)
			&& this.funcionario.equals(castOther.funcionario);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.atividade.hashCode();
		hash = hash * prime + this.funcionario.hashCode();
		
		return hash;
	}
}
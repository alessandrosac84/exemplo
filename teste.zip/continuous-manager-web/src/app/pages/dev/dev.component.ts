import { ActivatedRoute, Router } from '@angular/router';
import { CommitBuild } from './../../shared/model/commit-build.model';
import { ChangeSet } from './../../shared/model/changeset.model';
import { Project } from './../../shared/model/project.model';
import { ViewCommitsBuilds } from './../../shared/model/view-commits-builds.model';
import { Build } from './../../shared/model/build.model';
import { Commit } from './../../shared/model/commit.model';
import { JenkinsService } from './../../shared/service/jenkins.service';
import { Wallet } from './../../shared/model/wallet.model';
import { Job } from './../../shared/model/job.model';
import { Title } from '@angular/platform-browser';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jmw-dev',
  templateUrl: './dev.component.html',
  styleUrls: ['./dev.component.scss']
})
export class DevComponent implements OnInit {
  pageTitle = 'Dev Manager';
  listaWallets: Wallet[] = [];
  listaProjects: Project[] = [];
  projectId: Project;
  listaViewDev: ViewCommitsBuilds[] = [];
  listaJobs: Job[] = [];
  walletId: Wallet;
  jobId: Job;
  page: number;
  updated: Date;
  total: number;
  listBuilds = null;

  statusBuildDevLiberada: Boolean = false;

  constructor(private title: Title, private route: ActivatedRoute,
    private router: Router, private jenkinsService: JenkinsService) { }

  ngOnInit() {
    this.title.setTitle(this.pageTitle);
    this.jenkinsService.getWallets().subscribe(data => {
      this.listaWallets = data;
    });
    this.page = 1;

    /*this.jenkinsService.getJSON().subscribe(data => {
     this.listaCommits = data;
   });*/
  }

  public chargeProjects() {
    this.listaProjects = [];
    this.projectId = undefined;
    this.jobId = undefined;
    if (!!this.walletId) {
      this.jenkinsService.getProjects(this.walletId.id).subscribe(data => {
        this.listaProjects = data;
      });
    }
  }

  public chargeJobs() {
    this.listaJobs = [];
    this.jobId = undefined;
    if (!!this.projectId) {
      this.jenkinsService.getJobs(this.walletId.id, this.projectId.id.id).subscribe(data => {
        this.listaJobs = data;
      });
    }
  }

  public chargeChangeSets() {
    this.listaViewDev = [];
    if (!!this.jobId) {
      this.jenkinsService.getChangeSets(this.walletId.id, this.projectId.id.id, this.jobId.id.id, this.page).subscribe((res: any) => {
        console.log(res);

        res.body.forEach(commit => {
          const item: ViewCommitsBuilds = new ViewCommitsBuilds;
          item.id_commit = commit.id.commit;
          item.id_short_commit = commit.id.commit.substring(0, 8);
          item.author_commit = commit.gitRepo.authorName;
          item.author_email_commit = commit.gitRepo.authorEmail;
          item.message_commit = commit.gitRepo.title.substring(0, 25) + '...';
          item.versao_release_build = null;
          item.build_number = commit.id.build;
          item.build_result = commit.build.result;

          const dateCommitString = commit.gitRepo.committedDate;
          const dateCommitDate = new Date(dateCommitString);
          item.committed_date_commit = dateCommitDate;

          if (this.listaViewDev.length === 0) {
            item.list_view_builds = [];
            item.list_view_builds.push(this.addItemBuild(commit));
            this.listaViewDev.push(item);
          } else {
            let found: ViewCommitsBuilds;
            this.listaViewDev.forEach(i => {
              if (i.id_short_commit === item.id_short_commit) {
                found = i;
              }
            });
            if (found) {
              if (found.list_view_builds) {
                found.list_view_builds.push(this.addItemBuild(commit));
              }
            } else {
              item.list_view_builds = [];
              item.list_view_builds.push(this.addItemBuild(commit));
              this.listaViewDev.push(item);
            }
          }
        });
        this.total = res.headers.get('Content-Range').substring(res.headers.get('Content-Range').indexOf('/') + 1);
        this.updated = new Date();
      });
    }
  }

  public addItemBuild(commit: ChangeSet) {
    const commitBuild = new CommitBuild;
    commitBuild.build = commit.id.build;
    commitBuild.commit = commit.id.commit;
    commitBuild.result = commit.build.result;
    const dataBuild = new Date(commit.build.createdAt);
    commitBuild.data_hora_build = dataBuild;

    return commitBuild;
  }

  public rebuild(itemCommit: ViewCommitsBuilds) {

    this.jenkinsService.rebuild(this.walletId.id, this.projectId.id.id, this.jobId.id.id,
      itemCommit.build_number, itemCommit.id_commit).subscribe(data => {
        return data;
      });
  }

  pageChanged(event) {
    if ((this.updated.getTime() + 500) < new Date().getTime()) {
      this.page = event;
      this.chargeChangeSets();
    }
  }
}

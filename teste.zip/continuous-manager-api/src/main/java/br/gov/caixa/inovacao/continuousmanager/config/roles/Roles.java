package br.gov.caixa.inovacao.continuousmanager.config.roles;

public interface Roles { //NOSONAR
	public static final String ADMIN = "ADMIN";
	public static final String CAIXA = "CAIXA";
	public static final String FABRICA = "FABRICA";
	public static final String AUTHENTICATED = "AUTHENTICATED";
}

package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-15T12:12:48.418-0300")
@StaticMetamodel(Server.class)
public class Server_ {
	public static volatile SingularAttribute<Server, String> ip;
	public static volatile SingularAttribute<Server, String> dns;
	public static volatile SingularAttribute<Server, Environment> environment;
	public static volatile SetAttribute<Server, Instance> instances;
	public static volatile SingularAttribute<Server, Flavor> flavor;
	public static volatile SetAttribute<Server, VirtualIp> virtualIps;
}

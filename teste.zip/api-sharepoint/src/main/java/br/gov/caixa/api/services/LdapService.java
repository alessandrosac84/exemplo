package br.gov.caixa.api.services;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.inject.Inject;

import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.stereotype.Service;

import br.gov.caixa.api.dto.PersonDto;
import br.gov.caixa.api.dto.PersonGroupsDto;
import br.gov.caixa.api.dto.ldapMapper.PersonAttributesMapper;
import br.gov.caixa.api.dto.ldapMapper.PersonGroupsAttributesMapper;
import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.StatusFuncionario;
import br.gov.caixa.api.result.LdapResult;

@Service
public class LdapService {

	@Inject
	private LdapTemplate ldapTemplate;
	
	@Inject 
	private FuncionarioService funcionarioService;
		
	public LdapResult obterGruposUsuario(String matricula) {
		LdapQuery ldapQuery = query().base("OU=CAIXA,DC=corp,DC=caixa,DC=gov,DC=br").filter("(&(objectClass=User)(sAMAccountName=" + matricula + "))");
	    
		List<PersonGroupsDto> persons = ldapTemplate.search(ldapQuery, new PersonGroupsAttributesMapper());
		
		LdapResult result = new LdapResult();
		result.setList(persons);
		
		return result;
	}
	
	public LdapResult obterDadosUsuario(String matricula) {
		LdapQuery ldapQuery = query().base("OU=CAIXA,DC=corp,DC=caixa,DC=gov,DC=br").filter("(&(objectClass=User)(sAMAccountName=" + matricula + "))");
		
		List<PersonDto> persons = ldapTemplate.search(ldapQuery, new PersonAttributesMapper());
		
		LdapResult result = new LdapResult();
		result.setList(persons);
		
		return result;
	}
	
	public LdapResult obterTodosUsuariosPorGrupo(String grupo) {
		LdapQuery ldapQuery = query()
				.base("OU=CAIXA, DC=corp,DC=caixa,DC=gov,DC=br")
				.filter("memberOf=CN=" + grupo + ",OU=Outros,OU=Usuarios,OU=CAIXA,DC=corp,DC=caixa,DC=gov,DC=br");					

		List<PersonGroupsDto> persons = ldapTemplate.search(ldapQuery, new PersonGroupsAttributesMapper());
		
		LdapResult result = new LdapResult();
		result.setList(persons);
		
		return result;
	}
	
	public LdapResult obterTodosUsuariosPorDepartamento(String departamento) {
		
		LdapQuery ldapQuery = query().base("OU=Empregados, OU=Usuarios, OU=CAIXA, DC=corp,DC=caixa,DC=gov,DC=br").filter("(&(objectClass=User)(department=" + departamento + "))");

		List<PersonGroupsDto> persons = ldapTemplate.search(ldapQuery, new PersonGroupsAttributesMapper());
		
		LdapResult result = new LdapResult();
		result.setList(persons);
		
		return result;
	}
	
	public LdapResult obterUsuariosPorGrupo(String grupo) {
		LdapQuery ldapQuery = query()
				.base("OU=Usuarios, OU=CAIXA, DC=corp,DC=caixa,DC=gov,DC=br")
				.filter("memberOf=CN=" + grupo + ",OU=SP,OU=Grupos,OU=CAIXA,DC=corp,DC=caixa,DC=gov,DC=br");
		
		List<PersonGroupsDto> persons = ldapTemplate.search(ldapQuery, new PersonGroupsAttributesMapper());
		
		LdapResult result = new LdapResult();
		result.setList(persons);
		
		return result;
	}

	public void atualizarFuncionarios(List<PersonGroupsDto> personsGroupsDto) {
				
		Iterator<PersonGroupsDto> itr = personsGroupsDto.iterator();
		
		List<Funcionario> funcionarios = new ArrayList<Funcionario>();
		
		while (itr.hasNext()) {
			PersonGroupsDto personGroupsDto = itr.next();					
			
			Funcionario funcionario; 
			
			funcionario = funcionarioService.listOneByMatricula(personGroupsDto.getsAMAccountName());
						
			if(funcionario == null) {
				
				funcionario = new Funcionario();				
				funcionario.setUid((long) 0);
				funcionario.setMatricula(personGroupsDto.getsAMAccountName());
				
				funcionario.setNome(personGroupsDto.getName()); 
				funcionario.setCargo(personGroupsDto.getTitle());
				funcionario.setDepto(personGroupsDto.getDepartment());
				funcionario.setEmail(personGroupsDto.getMail());
				funcionario.setFone(personGroupsDto.getTelephonenumber());
				funcionario.setCelular(personGroupsDto.getMobile() == null ? "" : personGroupsDto.getMobile());
				funcionario.setEmpresa(personGroupsDto.getCompany());
				funcionario.setLogradouro(personGroupsDto.getStreet());
				funcionario.setCidade(personGroupsDto.getCity());
				funcionario.setUf(personGroupsDto.getSt());
				funcionario.setCep(personGroupsDto.getPostalCode());
				funcionario.setDataAtualizacao(personGroupsDto.getLastUpdate());
				
				if(funcionario.getCargo().equalsIgnoreCase("FABRICA") )
					funcionario.setStatusFuncionario(StatusFuncionario.FABRICA);
				
				funcionarioService.atualizar(funcionario);
				
			} 
			else if (funcionario.getDataAtualizacao() == null || personGroupsDto.getLastUpdate().after(funcionario.getDataAtualizacao()) ) {
								
				try {
					
					funcionario.setNome(personGroupsDto.getName()); 
					funcionario.setCargo(personGroupsDto.getTitle());					
					funcionario.setDepto(personGroupsDto.getDepartment());
					funcionario.setEmail(personGroupsDto.getMail());
					funcionario.setFone(personGroupsDto.getTelephonenumber());
					funcionario.setCelular(personGroupsDto.getMobile() == null ? "" : personGroupsDto.getMobile());
					funcionario.setEmpresa(personGroupsDto.getCompany());
					funcionario.setLogradouro(personGroupsDto.getStreet());
					funcionario.setCidade(personGroupsDto.getCity());
					funcionario.setUf(personGroupsDto.getSt());
					funcionario.setCep(personGroupsDto.getPostalCode());
					funcionario.setDataAtualizacao(personGroupsDto.getLastUpdate());
					
					if(funcionario.getCargo().equalsIgnoreCase("FABRICA") )
						funcionario.setStatusFuncionario(StatusFuncionario.FABRICA);
					
					funcionarios.add(funcionario);				
				}
			
				catch (Exception x) {
					funcionario = null;
				}		
			}			
		}
		
		funcionarioService.atualizar(funcionarios);
	}

	
}

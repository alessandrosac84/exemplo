package br.gov.caixa.api.controller;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.result.BuscaCoordenacaoCoordenadorResult;
import br.gov.caixa.api.services.BuscaCoordenacaoCoordenadorService;

@RestController
public class BuscaCoordenacaoCoordenadorController {
	
	@Inject
	private BuscaCoordenacaoCoordenadorService service;
	
	@RequestMapping(value="/api/buscaCoordenacaoCoordenador/all", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public BuscaCoordenacaoCoordenadorResult listAll() {
		return service.findAll();
	}
	
	@RequestMapping(value="/api/buscaCoordenacaoCoordenador/all2", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public BuscaCoordenacaoCoordenadorResult listAll2() {
		return service.findAll2();
	}

}

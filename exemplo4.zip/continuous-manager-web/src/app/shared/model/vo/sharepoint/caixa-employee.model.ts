export class CaixaEmployee {
  public matricula: string;
  public cargoDescricao: string;
  public cargoId: number;
  public coordenacaoGrupo: string;
  public coordenacaoId: number;
  public status: string;
  public email: string;
  public nome: string;
}

package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.BuscaFuncionarioCoordenacao;

public class BuscaFuncionarioCoordenacaoDto {

	private Long coordencaoId;	
	private Long funcionarioId;
	private String funcionario;	
	private String matricula;
	private String nome;
	private String cargo;

	public Long getCoordencaoId() {
		return coordencaoId;
	}
	public void setCoordencaoId(Long coordencaoId) {
		this.coordencaoId = coordencaoId;
	}
	public Long getFuncionarioId() {
		return funcionarioId;
	}	
	public void setFuncionarioId(Long funcionarioId) {
		this.funcionarioId = funcionarioId;
	}
	public String getFuncionario() {
		return funcionario;
	}
	public void setFuncionario(String funcionario) {
		this.funcionario = funcionario;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	public static List<BuscaFuncionarioCoordenacaoDto> fromBuscaFuncionarioCoordenacaoToListDto(List<BuscaFuncionarioCoordenacao> lista) {
		
		List<BuscaFuncionarioCoordenacaoDto> listaRetorno = new ArrayList<BuscaFuncionarioCoordenacaoDto>();
		
		for (BuscaFuncionarioCoordenacao buscaFuncionarioCoordenacao : lista) {
			BuscaFuncionarioCoordenacaoDto dto = new BuscaFuncionarioCoordenacaoDto();
			
			dto.setCoordencaoId(buscaFuncionarioCoordenacao.getBuscaFuncionarioCoordencaoId().getCoordenacao_id());
			dto.setFuncionarioId(buscaFuncionarioCoordenacao.getBuscaFuncionarioCoordencaoId().getFuncionario_id());
			dto.setFuncionario(buscaFuncionarioCoordenacao.getFuncionario());
			dto.setMatricula(buscaFuncionarioCoordenacao.getMatricula());
			dto.setNome(buscaFuncionarioCoordenacao.getNome());
			dto.setCargo(buscaFuncionarioCoordenacao.getCargo());
			
			listaRetorno.add(dto);
		}
		return listaRetorno;
	}
}
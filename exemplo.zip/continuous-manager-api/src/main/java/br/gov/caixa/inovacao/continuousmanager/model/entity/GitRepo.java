package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the git_repo database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Table(name="git_repo")
@NamedQuery(name="GitRepo.findAll", query="SELECT g FROM GitRepo g")
public class GitRepo implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private GitRepoPK id;

	@Column(name="author_email", nullable=false, length=70)
	private String authorEmail;

	@Column(name="author_name", nullable=false, length=100)
	private String authorName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="authored_date", nullable=false)
	private Calendar authoredDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="committed_date", nullable=false)
	private Calendar committedDate;

	@Column(name="committer_email", nullable=false, length=70)
	private String committerEmail;

	@Column(name="committer_name", nullable=false, length=100)
	private String committerName;

	@Column(columnDefinition = "TEXT")
	private String message;

	@Column(nullable=false, length=72)
	private String title;

	@Column(length=20)
	private String version;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="versioned_at")
	private Calendar versionedAt;

	@Column(name="versioner_user", length=7)
	private String versionerUser;
	
	//bi-directional many-to-many association to GitRepo
	@OneToMany(mappedBy="gitRepos")
	private Set<ChangeSets> changeSets;

	//bi-directional many-to-one association to Project
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="project", referencedColumnName="id", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private Project project;

	public GitRepo() {
		/* class constructor intentionally left blank */
	}

	public GitRepoPK getId() {
		return this.id;
	}

	public void setId(GitRepoPK id) {
		this.id = id;
	}

	public String getAuthorEmail() {
		return this.authorEmail;
	}

	public void setAuthorEmail(String authorEmail) {
		this.authorEmail = authorEmail;
	}

	public String getAuthorName() {
		return this.authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Calendar getAuthoredDate() {
		return this.authoredDate;
	}

	public void setAuthoredDate(Calendar authoredDate) {
		this.authoredDate = authoredDate;
	}

	public Calendar getCommittedDate() {
		return this.committedDate;
	}

	public void setCommittedDate(Calendar committedDate) {
		this.committedDate = committedDate;
	}

	public String getCommitterEmail() {
		return this.committerEmail;
	}

	public void setCommitterEmail(String committerEmail) {
		this.committerEmail = committerEmail;
	}

	public String getCommitterName() {
		return this.committerName;
	}

	public void setCommitterName(String committerName) {
		this.committerName = committerName;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Calendar getVersionedAt() {
		return this.versionedAt;
	}

	public void setVersionedAt(Calendar versionedAt) {
		this.versionedAt = versionedAt;
	}

	public String getVersionerUser() {
		return this.versionerUser;
	}

	public void setVersionerUser(String versionerUser) {
		this.versionerUser = versionerUser;
	}

	public Set<ChangeSets> getChangeSets() {
		return this.changeSets;
	}

	public void setChangeSets(Set<ChangeSets> changeSets) {
		this.changeSets = changeSets;
	}

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

}
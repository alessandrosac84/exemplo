import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { InfoRoutingModule } from './info-routing.module';
import { InfoComponent } from './info.component';

@NgModule({
  imports: [
    CommonModule,
    InfoRoutingModule,
    NgbModule.forRoot()
  ],
  declarations: [InfoComponent]
})
export class InfoModule { }

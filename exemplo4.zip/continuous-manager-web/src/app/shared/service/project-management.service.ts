import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';

import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { Wallet } from '../model/entity/wallet.model';
import { Project } from '../model/entity/project.model';
import { Job } from '../model/entity/job.model';
import { Build } from '../model/entity/build.model';
import { TypeRepository } from '../model/vo/typeRepository.model';
import { Server } from '../model/entity/server.model';


@Injectable({
  providedIn: 'root'
})
export class ProjectManagementService {

    constructor(private http: HttpClient) { }

    getTypeRepository(): Observable<TypeRepository[]> {
        return this.http.get<TypeRepository[]>('../../../assets/file/typeRepository.json');
    }

    getServers(): Observable<Server[]> {
        return this.http.get<Server[]>('../../../assets/file/servers.json');
    }
}



/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.filter.request;

import java.io.IOException;

import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ResourceInfo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.resource.WalletResource;

/**
 * Classe de Teste de AuthenticationTokenRequestFilter
 * 
 * @author Fabio Iwakoshi
 *
 */
@PermitAll
@RunWith(MockitoJUnitRunner.class)
public class AuthorizationTokenRequestFilterTest {

	@Mock
	private ResourceInfo resourceInfo;
	
	@Mock
	private HttpServletRequest request;

	@Mock
	private ContainerRequestContext containerRequestContext;

	@InjectMocks
	private AuthorizationTokenRequestFilter authorizationTokenRequestFilter;

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthorizationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws SecurityException 
	 * @throws NoSuchMethodException 
	 */
	@Test
	@PermitAll
	public void testFilterWithPermitAll() throws IOException, NoSuchMethodException, SecurityException {

		Mockito.when(resourceInfo.getResourceMethod()).thenReturn(this.getClass().getMethod("testFilterWithPermitAll"));
		Mockito.<Class<?>>when(resourceInfo.getResourceClass()).thenReturn(WalletResource.class);

		authorizationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthorizationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws SecurityException 
	 * @throws NoSuchMethodException 
	 */
	@Test
	public void testFilterWithoutPermitAll() throws IOException, NoSuchMethodException, SecurityException {

		Mockito.when(resourceInfo.getResourceMethod()).thenReturn(this.getClass().getMethod("testFilterWithoutPermitAll"));
		Mockito.<Class<?>>when(resourceInfo.getResourceClass()).thenReturn(AuthorizationTokenRequestFilterTest.class);

		authorizationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthorizationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws SecurityException 
	 * @throws NoSuchMethodException 
	 */
	@Test
	@DenyAll
	public void testFilterWithDenyAll() throws IOException, NoSuchMethodException, SecurityException {

		Mockito.when(resourceInfo.getResourceMethod()).thenReturn(this.getClass().getMethod("testFilterWithDenyAll"));
		Mockito.<Class<?>>when(resourceInfo.getResourceClass()).thenReturn(WalletResource.class);

		authorizationTokenRequestFilter.filter(containerRequestContext);
	}
}

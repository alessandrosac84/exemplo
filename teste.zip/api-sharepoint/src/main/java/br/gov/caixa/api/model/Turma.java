package br.gov.caixa.api.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.gov.caixa.api.dto.TurmaDto;

@Entity
@Table(name = "turma")
public class Turma {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "nome")
	private String nome;

	@Column(name = "DATA")
	private Date data;
	
	@Column(name = "DATA2")
	private Date data2;
	
	@Column(name = "CARGA")
	private Integer carga;

	@Column(name = "INSTRUTOR")
	private String instrutor;

	@Column(name = "LOCAL")
	private String local;
	
	@Column(name = "HORA_ENTRADA", nullable = true)
	private String horaEntrada;
	
	@Column(name = "HORA_SAIDA", nullable = true)
	private String horaSaida;

	@Column(name = "NIVEL")
	private Integer nivel;
	
	@Column(name = "VAGAS")
	private Integer vagas;

	@Column(name = "DETALHE", length=5000)
	private String detalhe;

	@ManyToOne
	@JoinColumn(name = "TREINAMENTO_ID")
	private Treinamento treinamento;
	
	@OneToMany(mappedBy="turma", cascade=CascadeType.REMOVE, orphanRemoval=true )
    private Set<Participante> participantes = new HashSet<Participante>();

	@Column(name = "NOTA")
	private Double nota;

	@Column(name = "ENCERRADO", columnDefinition = "boolean default false")
	private boolean encerrado;	
	
	@Column(name = "FECHADO", columnDefinition = "boolean default false")
	private boolean fechado;
	
	@Column(name = "AUTO_INSCRICAO", columnDefinition = "boolean default false")
	private boolean autoInscricao;
	
	@Column(name = "INSCRITOS", columnDefinition = "integer default 0")
	private Integer inscritos;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}
	
	public Date getData2() {
		return data2;
	}

	public void setData2(Date data2) {
		this.data2 = data2;
	}

	public Integer getCarga() {
		return carga;
	}

	public void setCarga(Integer carga) {
		this.carga = carga;
	}

	public String getInstrutor() {
		return instrutor;
	}

	public void setInstrutor(String instrutor) {
		this.instrutor = instrutor;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}
	
	public String getHoraEntrada() {
		return horaEntrada;
	}

	public void setHoraEntrada(String horaEntrada) {
		this.horaEntrada = horaEntrada;
	}

	public String getHoraSaida() {
		return horaSaida;
	}

	public void setHoraSaida(String horaSaida) {
		this.horaSaida = horaSaida;
	}

	public Integer getNivel() {
		return nivel;
	}

	public void setNivel(Integer nivel) {
		this.nivel = nivel;
	}
	
	public Integer getVagas() {
		return vagas;
	}

	public void setVagas(Integer vagas) {
		this.vagas = vagas;
	}

	public String getDetalhe() {
		return detalhe;
	}

	public void setDetalhe(String detalhe) {
		this.detalhe = detalhe;
	}

	public Treinamento getTreinamento() {
		return treinamento;
	}

	public void setTreinamento(Treinamento treinamento) {
		this.treinamento = treinamento;
	}

	public Double getNota() {
		return nota;
	}

	public void setNota(Double nota) {
		this.nota = nota;
	}

	public boolean isEncerrado() {
		return encerrado;
	}

	public void setEncerrado(boolean encerrado) {
		this.encerrado = encerrado;
	}
	

	public boolean isAutoInscricao() {
		return autoInscricao;
	}

	public void setAutoInscricao(boolean autoInscricao) {
		this.autoInscricao = autoInscricao;
	}	

	public Integer getInscritos() {
		if(inscritos == null)
			inscritos = 0;
		return inscritos;
	}

	public void setInscritos(Integer inscritos) {
		this.inscritos = inscritos;
	}	

	public boolean isFechado() {
		return fechado;
	}

	public void setFechado(boolean fechado) {
		this.fechado = fechado;
	}

	public static Turma fromDtoToTurma(TurmaDto dto) {
		Turma turma = new Turma();
		turma.setUid(dto.getUid());
		turma.setNome(dto.getNome());
		turma.setData(dto.getData());
		turma.setData2(dto.getData2());
		turma.setCarga(dto.getCarga());
		turma.setInstrutor(dto.getInstrutor());
		turma.setLocal(dto.getLocal());
		turma.setHoraEntrada(dto.getHoraEntrada());
		turma.setHoraSaida(dto.getHoraSaida());		
		turma.setNivel(dto.getNivel());
		turma.setVagas(dto.getVagas());
		turma.setDetalhe(dto.getDetalhe());
		turma.setEncerrado(dto.isEncerrado());
		turma.setFechado(dto.isFechado());
		turma.setAutoInscricao(dto.isAutoInscricao());
		turma.setInscritos(dto.getInscritos());
				
		if(dto.getTreinamento() != null){
			turma.setTreinamento(Treinamento.fromDtoToTreinamento(dto.getTreinamento()));
		}
		turma.setNota(dto.getNota());
		return turma;
	}
}

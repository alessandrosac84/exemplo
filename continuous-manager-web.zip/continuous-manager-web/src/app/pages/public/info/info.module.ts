import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InfoRoutingModule } from './info-routing.module';
import { InfoComponent } from './info.component';
import { MaterialModule } from '../../../core/material/material.module';
import { ReactiveFormsModule, FormsModule } from '../../../../../node_modules/@angular/forms';
import { NewsComponent } from './news/news.component';
import { PipeModule } from '../../../shared/pipe/pipe.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
    InfoRoutingModule,
    PipeModule
  ],
  declarations: [InfoComponent, NewsComponent],
  entryComponents: [
    NewsComponent
  ]
})
export class InfoModule { }

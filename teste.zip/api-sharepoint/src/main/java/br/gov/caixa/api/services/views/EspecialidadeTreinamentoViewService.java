package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.model.views.EspecialidadeTreinamentoView;
import br.gov.caixa.api.repository.views.EspecialidadeTreinamentoViewRepository;
import br.gov.caixa.api.result.views.EspecialidadeTreinamentoViewResult;

@Named
public class EspecialidadeTreinamentoViewService {
	
	@Inject
	EspecialidadeTreinamentoViewRepository  repository;
			
	public EspecialidadeTreinamentoViewResult listEspecialidadeTreinamentoViewsByIdEspecialidade(Long idEspecialidade) {
		EspecialidadeTreinamentoViewResult result = new EspecialidadeTreinamentoViewResult();
		try {
						
			List<EspecialidadeTreinamentoView> lista = repository.findByEspecialidadeId(idEspecialidade);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Resgistro.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

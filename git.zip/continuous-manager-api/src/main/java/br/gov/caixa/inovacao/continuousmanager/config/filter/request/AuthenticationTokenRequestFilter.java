/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.filter.request;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.annotation.Priority;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.PreMatching;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.config.filter.vo.Authentication;
import br.gov.caixa.inovacao.continuousmanager.config.filter.vo.TokenExtension;
import br.gov.caixa.inovacao.continuousmanager.config.filter.vo.TokenVO;
import br.gov.caixa.inovacao.continuousmanager.config.roles.Roles;
import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sharepoint.AtivoSharepointVO;
import br.gov.caixa.inovacao.continuousmanager.service.integration.GitLabService;
import br.gov.caixa.inovacao.continuousmanager.service.integration.SharepointService;

/**
 * Filtro de autenticação da aplicação
 * 
 * @author Fabio Iwakoshi
 *
 */
@Provider
@PreMatching
@Priority(Priorities.AUTHENTICATION)
public class AuthenticationTokenRequestFilter implements ContainerRequestFilter {

	private static final String AUTH_FAILED = "auth-failed";
	
	private Logger log;

	@Context
	private HttpServletRequest request;

	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		log = Logger.getLogger(this.getClass().getName());
		log.fine("Executando Request Filter Authentication... ");

		if (requestContext.getMethod().equals("OPTIONS")) {
			requestContext.abortWith(Response.status(Response.Status.OK).build());
			return;
		}
		
		HelperThreadLocal.ROLES.set(new ArrayList<>());

		if (requestContext.getUriInfo().getPath().contains("/auth/login")) {
			authentication(requestContext);
		} else {
			if (requestContext.getHeaderString("Authorization") != null) {
				tokenValidation(requestContext);
			}
		}
	}

	private void authentication(ContainerRequestContext requestContext) {
		try {
			Authentication authentication = new Authentication().username("").password("");
			if (requestContext.hasEntity()) {
				String entity = new BufferedReader(new InputStreamReader(requestContext.getEntityStream())).lines()
						.collect(Collectors.joining("\n"));
				if (!entity.isEmpty()) {
					authentication = new ObjectMapper().readValue(entity, Authentication.class);
				}
			}

			SharepointService sharepointService = InitialContext.<SharepointService>doLookup("java:comp/SharepointService");
			GitLabService gitLabService = InitialContext.<GitLabService>doLookup("java:comp/GitLabService");

			TokenExtension tokenEx = new TokenExtension();
			tokenEx.setAtivos(sharepointService.getAtivos(authentication.getUsername()).stream()
					.map(AtivoSharepointVO::getId).collect(Collectors.toList()));
			tokenEx.setAdmin(gitLabService.getUserByMatricula(authentication.getUsername()).isAdmin());

			request.setAttribute("others", new ObjectMapper().writeValueAsString(tokenEx));
			// Login
			request.login(authentication.getUsername(), authentication.getPassword());
			HelperThreadLocal.USER.set(request.getUserPrincipal().getName());
			requestContext.abortWith(Response.status(Response.Status.OK).build());
		} catch (Exception e) {
			log.log(Level.SEVERE, "Erro na autenticação!", e);
			requestContext.setProperty(AUTH_FAILED, true);
			requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
		}
	}

	private void tokenValidation(ContainerRequestContext requestContext)
			throws IOException {
		try {
			TokenVO token = new ObjectMapper().readValue(
					new String(Base64.getDecoder()
							.decode(requestContext.getHeaderString("Authorization").split("\\.")[1])),
					TokenVO.class);
			request.login(token.getSub(), "");
			
			TokenExtension tokenExtension = new ObjectMapper().readValue(token.getOthers(), TokenExtension.class);
			
			HelperThreadLocal.USER.set(request.getUserPrincipal().getName());
			HelperThreadLocal.ATIVOS.set(tokenExtension.getAtivos());
			HelperThreadLocal.ROLES.get().add(Roles.AUTHENTICATED);
			// Caixa Fabrica
			if (HelperThreadLocal.USER.get().startsWith("c")) {
				HelperThreadLocal.ROLES.get().add(Roles.CAIXA);
			} else {
				HelperThreadLocal.ROLES.get().add(Roles.FABRICA);
			}
			// Admin
			if (tokenExtension.isAdmin()) {
				HelperThreadLocal.ROLES.get().add(Roles.ADMIN);
			}
		} catch (ServletException e) {
			log.log(Level.SEVERE, "Erro ao validar o token!", e);
			requestContext.setProperty(AUTH_FAILED, true);
			requestContext.abortWith(Response.status(Response.Status.FORBIDDEN).build());
		}
	}
}

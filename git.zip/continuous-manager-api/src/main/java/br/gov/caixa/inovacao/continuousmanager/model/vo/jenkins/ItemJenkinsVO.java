/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe de representação do Build do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class ItemJenkinsVO implements Serializable {

	private static final long serialVersionUID = 8801957575617252193L;

	@JsonProperty("_class")
	private String clazz;
	
	private String id;
	
	private Calendar timestamp;
	
	private AuthorJenkinsVO author;
	
	private String authorEmail;
	
	private String comment;
	
	private String msg;
	
	private List<PathJenkinsVO> paths;

	/**
	 * @return the paths
	 */
	public List<PathJenkinsVO> getPaths() {
		return paths;
	}

	/**
	 * @param paths the paths to set
	 */
	public void setPaths(List<PathJenkinsVO> paths) {
		this.paths = paths;
	}

	/**
	 * @return the clazz
	 */
	public String getClazz() {
		return clazz;
	}

	/**
	 * @param clazz the clazz to set
	 */
	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the timestamp
	 */
	public Calendar getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(Calendar timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the author
	 */
	public AuthorJenkinsVO getAuthor() {
		return author;
	}

	/**
	 * @param author the author to set
	 */
	public void setAuthor(AuthorJenkinsVO author) {
		this.author = author;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

	/**
	 * @return the authorEmail
	 */
	public String getAuthorEmail() {
		return authorEmail;
	}

	/**
	 * @param authorEmail the authorEmail to set
	 */
	public void setAuthorEmail(String authorEmail) {
		this.authorEmail = authorEmail;
	}
	
}

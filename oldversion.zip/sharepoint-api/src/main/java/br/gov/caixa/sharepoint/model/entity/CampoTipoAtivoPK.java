package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.Pattern;

/**
 * The primary key class for the campo_tipo_ativo database table.
 * 
 */
@Embeddable
public class CampoTipoAtivoPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="tipo_ativo", insertable=false, updatable=false, unique=true, nullable=false)
	private Integer tipoAtivo;

	@Pattern(regexp="[a-z_]+")
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=20)
	private String campo;

	public CampoTipoAtivoPK() {
	}
	public Integer getTipoAtivo() {
		return this.tipoAtivo;
	}
	public void setTipoAtivo(Integer tipoAtivo) {
		this.tipoAtivo = tipoAtivo;
	}
	public String getCampo() {
		return this.campo;
	}
	public void setCampo(String campo) {
		this.campo = campo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CampoTipoAtivoPK)) {
			return false;
		}
		CampoTipoAtivoPK castOther = (CampoTipoAtivoPK)other;
		return 
			this.tipoAtivo.equals(castOther.tipoAtivo)
			&& this.campo.equals(castOther.campo);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.tipoAtivo.hashCode();
		hash = hash * prime + this.campo.hashCode();
		
		return hash;
	}
}
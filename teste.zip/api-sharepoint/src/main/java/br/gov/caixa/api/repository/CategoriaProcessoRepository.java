package br.gov.caixa.api.repository;

import java.util.List;

import javax.persistence.OrderBy;

import org.springframework.data.jpa.repository.JpaRepository;

import br.gov.caixa.api.model.CategoriaProcesso;

public interface CategoriaProcessoRepository extends JpaRepository<CategoriaProcesso, Long>  {
	
	@OrderBy("uid")
	public List<CategoriaProcesso> findAll();		
}

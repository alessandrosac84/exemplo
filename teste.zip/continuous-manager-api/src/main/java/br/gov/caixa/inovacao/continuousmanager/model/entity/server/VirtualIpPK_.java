package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-14T14:54:21.041-0300")
@StaticMetamodel(VirtualIpPK.class)
public class VirtualIpPK_ {
	public static volatile SingularAttribute<VirtualIpPK, String> server;
	public static volatile SingularAttribute<VirtualIpPK, String> ip;
}

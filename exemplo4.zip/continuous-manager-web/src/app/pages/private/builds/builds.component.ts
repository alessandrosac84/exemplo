import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {
  trigger,
  transition,
  query,
  animate,
  stagger,
  style
} from '@angular/animations';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Repository } from '../../../shared/model/entity/repository.model';
import { ProjectService } from '../../../shared/service/project.service';
import { Project } from '../../../shared/model/entity/project.model';

@Component({
  selector: 'cm-builds',
  templateUrl: './builds.component.html',
  animations: [
    trigger('listStagger', [
      transition('* => *', [
        // each time the binding value changes
        query(
          ':enter',
          [
            style({ opacity: 0 }),
            stagger(200, [animate('0.5s', style({ opacity: 1 }))])
          ],
          { optional: true }
        ),
        query(
          ':leave',
          [stagger(200, [animate('0.5s', style({ opacity: 0 }))])],
          { optional: true }
        )
      ])
    ])
  ]
})
export class BuildsComponent implements OnInit {
  project: Project;
  repository: Repository;
  repositories$: Observable<Repository[]>;
  repositoriesLength: number;

  constructor(
    private _projectService: ProjectService,
    private _router: Router,
    private _activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    if (localStorage.getItem('project') != null) {
      this._projectService.getProject(+localStorage.getItem('project')).subscribe(data => this.project = data);
      this.repositories$ = this._projectService
        .getRepositories(+localStorage.getItem('project'))
        .pipe(
          map(data => {
            this.repositoriesLength = data.length;
            if (data.length > 0 && !this._activatedRoute.firstChild.snapshot.params['repository']) {
              this.loadRepository(data[0].id.id);
            }
            return data;
          })
        );
    } else {
      this._router.navigateByUrl('/projects');
    }
  }

  loadRepository(repositoryId) {
    this._projectService.getRepository(+localStorage.getItem('project'), repositoryId).subscribe(data => this.repository = data);
    this._router.navigateByUrl('/builds/' + repositoryId);
  }
}

package br.gov.caixa.api.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.dto.ParticipanteDto;
import br.gov.caixa.api.model.StatusParticipante;
import br.gov.caixa.api.result.ParticipanteResult;
import br.gov.caixa.api.services.ParticipanteService;

@RestController
public class ParticipanteController {
	
	@Inject
	ParticipanteService service;
	
	@RequestMapping(value="/api/participante/save", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ParticipanteResult save(@RequestBody ParticipanteDto dto) {
		return service.save(dto);
	}
	
	@RequestMapping(value="/api/participante/updateStatusParticipante/{statusParticipante}/{participanteId}/{turmaId}", method=RequestMethod.POST, produces = "application/json")			
	@ResponseStatus(HttpStatus.OK)
	public ParticipanteResult updateStatusParticipante(@PathVariable StatusParticipante statusParticipante, 
			@PathVariable Long participanteId, 
			@PathVariable Long turmaId) {		
		return service.updateStatusParticipante(statusParticipante, participanteId, turmaId);
	}
	
	//@RequestMapping(value="/api/participante/updatePresencaParticipante/{Presenca}/{matricula}/{turmaId}", method=RequestMethod.POST, produces = "application/json")			
	@RequestMapping(value="/api/participante/updatePresencaParticipante/{presenca}/{matricula}/{turmaId}", method=RequestMethod.GET,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ParticipanteResult updateStatusParticipante(@PathVariable Integer presenca, @PathVariable String matricula, @PathVariable Long turmaId) {
		
		return service.updatePresencaParticipantePorFuncionario(presenca, matricula, turmaId);  
	}
	
	@RequestMapping(value="/api/participante/saveList", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ParticipanteResult save(@RequestBody List<ParticipanteDto> dto) {
		return service.saveList(dto);
	}
	
	@RequestMapping(value="/api/participante/delete/{id}", method=RequestMethod.POST,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ParticipanteResult delte(@PathVariable Long id) {
		return service.delete(id);
	}
	
	@RequestMapping(value="/api/participante/get/{id}", method=RequestMethod.GET,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ParticipanteResult get(@PathVariable Long id) {
		return service.getOne(id);
	}
	
	@RequestMapping(value="/api/participante/getAll", method=RequestMethod.GET,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ParticipanteResult getAll() {
		return service.getAll();
	}
	
	@RequestMapping(value="/api/participante/getByTurma/{id}", method=RequestMethod.GET,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ParticipanteResult getByTurma(@PathVariable Long id) {
		return service.getByTurma(id);
	}
	
	@RequestMapping(value="/api/participante/getByFuncionario/{id}", method=RequestMethod.GET,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ParticipanteResult getByFuncionario(@PathVariable Long id) {
		return service.getByFuncionario(id);
	}
	
	@RequestMapping(value="/api/participante/getByFuncionarioNotInFeedback/{id}", method=RequestMethod.GET,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ParticipanteResult getByFuncionarioNotInFeedback(@PathVariable Long id) {
		return service.findByFuncionarioNotInFeedback(id);
	}
}

package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;


/**
 * The persistent class for the instance database table.
 * 
 */
@Entity
@Table(name="instance")
@NamedQuery(name="Instance.findAll", query="SELECT i FROM Instance i")
public class Instance implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	private InstancePK id;

	//bi-directional many-to-one association to Server
	@JsonView(ViewJson.JenkisfileView.class)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="server", nullable=false, insertable=false, updatable=false)
	private Server server;

	//bi-directional many-to-one association to ProjectInstance
	@OneToMany(mappedBy="instance", fetch = FetchType.LAZY)
	private Set<BranchInstance> branchInstances;

	public Instance() {
		/* class constructor intentionally left blank */
	}

	public InstancePK getId() {
		return this.id;
	}

	public void setId(InstancePK id) {
		this.id = id;
	}

	public Server getServer() {
		return this.server;
	}

	public void setServer(Server server) {
		this.server = server;
	}

	public Set<BranchInstance> getBranchInstances() {
		return this.branchInstances;
	}

	public void setBranchInstances(Set<BranchInstance> branchInstances) {
		this.branchInstances = branchInstances;
	}
}
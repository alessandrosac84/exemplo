package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the ativo_campo database table.
 * 
 */
@Entity
@Table(name="ativo_campo")
@NamedQueries ({	
	@NamedQuery(name="AtivoCampo.findAll", query="SELECT a FROM AtivoCampo a LEFT JOIN FETCH a.ativo")
})
public class AtivoCampo extends AuditedEntity implements Serializable, IEntity<AtivoCampoPK> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AtivoCampoPK id;

	@NotEmpty
	@Column(nullable=false, length=255)
	private String valor;

	@JsonIgnore
	//bi-directional many-to-one association to Ativo
	@ManyToOne(fetch=FetchType.LAZY) //TODO analizar se ocorrerá erro
	@JoinColumn(name="ativo", nullable=false, insertable=false, updatable=false)
	private Ativo ativo;
	
	@JsonIgnore
	//bi-directional many-to-one association to CampoTipoAtivo
	@ManyToOne(fetch=FetchType.LAZY, optional=false)
	@JoinColumns({
		@JoinColumn(name="campo", referencedColumnName="campo", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="tipo_ativo", referencedColumnName="tipo_ativo", nullable=false, insertable=false, updatable=false)
		})
	private CampoTipoAtivo campoTipoAtivo;
		
	public AtivoCampo() {
	}

	public AtivoCampoPK getId() {
		return this.id;
	}

	public void setId(AtivoCampoPK id) {
		this.id = id;
	}

	public String getValor() {
		return this.valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public Ativo getAtivo() {
		return this.ativo;
	}

	public void setAtivo(Ativo ativo) {
		this.ativo = ativo;
	}

	@JsonIgnore
	public CampoTipoAtivo getCampoTipoAtivo() {
		return campoTipoAtivo;
	}

	@JsonProperty
	public void setCampoTipoAtivo(CampoTipoAtivo campoTipoAtivo) {
		this.campoTipoAtivo = campoTipoAtivo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((valor == null) ? 0 : valor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AtivoCampo other = (AtivoCampo) obj;
		if (id == null) {
			return false;
		} else if (!id.equals(other.id))
			return false;
		if (valor == null) {
			if (other.valor != null)
				return false;
		} else if (!valor.equals(other.valor))
			return false;
		return true;
	}

	@Override
	public boolean isTheSameObject(IEntity<AtivoCampoPK> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		AtivoCampo other = (AtivoCampo) object;
		if (id == null) {
			return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
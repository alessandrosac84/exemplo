import { Component, OnInit } from '@angular/core';
import {
  trigger,
  transition,
  query,
  animate,
  stagger,
  style,
  animateChild
} from '@angular/animations';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Project } from '../../../shared/model/entity/project.model';
import { WalletService } from '../../../shared/service/wallet.service';

@Component({
  selector: 'cm-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.scss'],
  animations: [
    trigger('listStagger', [
      transition('* => *', [ // each time the binding value changes
        query(':enter', [
          style({ opacity: 0 }),
          stagger(100, [animate('0.8s', style({ opacity: 1 }))])
        ], { optional: true }),
        query(':leave', [
          stagger(100, [animate('0.8s', style({ opacity: 0 }))])
        ], { optional: true })
      ])
    ]),
  ]
})
export class ProjectsComponent implements OnInit {
  projects$: Observable<Project[]>;
  projectsLength: number;

  constructor(private _walletService: WalletService,
  ) {}

  ngOnInit() {
    this.projects$ = this._walletService.getProjects().pipe(
      map(data => {
        this.projectsLength = data.length;
        return data;
      })
    );
  }
}

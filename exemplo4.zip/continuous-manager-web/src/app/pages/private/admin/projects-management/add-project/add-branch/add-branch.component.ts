import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MatDialogConfig, MatDialog, MAT_DIALOG_DATA } from '@angular/material';
import { Branch } from '../../../../../../shared/model/entity/branch.model';
import { AddServersComponent } from './add-servers/add-servers.component';
import { AddParametersComponent } from './add-parameters/add-parameters.component';
import { BranchInstance } from '../../../../../../shared/model/entity/branch-instance.model';
import { Repository } from '../../../../../../shared/model/entity/repository.model';

@Component({
  selector: 'cm-add-branch',
  templateUrl: './add-branch.component.html',
  styleUrls: ['./add-branch.component.scss']
})
export class AddBranchComponent implements OnInit {

  firstFormGroup: FormGroup;
  branchData: Branch;
  nameBranch = new FormControl;
  branchs: Branch;
  servers: BranchInstance [];

  constructor(private _formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<AddBranchComponent>, public dialog: MatDialog,
          @Inject(MAT_DIALOG_DATA) public data: Repository) {

      this.branchs = new Branch;
      this.branchs.parameters = [];
      this.branchs.servers = [];
      this.branchData = new Branch;
      this.branchData.id = {id: ''};
    }

    ngOnInit() {
      this.firstFormGroup = this._formBuilder.group({
        firstCtrl: ['', Validators.required]
      });
      if (this.data.branchs !== undefined) {
        this.branchs.servers = this.data.branchs[0].servers;
        this.branchs.parameters = this.data.branchs[0].parameters;
      }
    }

    addBranch() {
      this.branchData.id.id = this.nameBranch.value;
      this.branchData.parameters = this.branchs.parameters;
      this.branchData.servers = this.branchs.servers;

      this.dialogRef.close(this.branchData);
    }

    openAddServer() {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = false;
      dialogConfig.autoFocus = true;

      const dialogRefServer = this.dialog.open(AddServersComponent, dialogConfig);

      dialogRefServer.afterClosed().subscribe(result => {
        console.log('result ' + result);
        if (result) {
          this.branchs.servers.push(result);
        }
      });
    }

    openAddParameter() {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = false;
      dialogConfig.autoFocus = true;

      const dialogRefParameter = this.dialog.open(AddParametersComponent, dialogConfig);

      dialogRefParameter.afterClosed().subscribe(result => {
        console.log('result ' + result);
        if (result) {
          this.branchs.parameters.push(result);
        }
      });
    }

    removeServer(serverSelected) {
      this.branchs.servers.splice(this.branchs.servers.indexOf(serverSelected), 1);
  }

    removeParameter(parameterSelected) {
      this.branchs.parameters.splice(this.branchs.parameters.indexOf(parameterSelected), 1);
    }
}

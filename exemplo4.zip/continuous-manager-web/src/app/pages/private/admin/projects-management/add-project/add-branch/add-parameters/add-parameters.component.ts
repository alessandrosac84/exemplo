import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Parameter } from '../../../../../../../shared/model/vo/parameter.model';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'cm-add-parameters',
  templateUrl: './add-parameters.component.html',
  styleUrls: ['./add-parameters.component.scss']
})
export class AddParametersComponent implements OnInit {

  firstFormGroup: FormGroup;
  chaveParameter = new FormControl;
  valorParameter = new FormControl;
  parameterData: Parameter;

  constructor(private _formBuilder: FormBuilder, public dialogRef: MatDialogRef<AddParametersComponent>) { }

  ngOnInit() {
    this.parameterData = new Parameter();
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
  }

  addParameter() {
    this.parameterData.id = this.chaveParameter.value;
    this.parameterData.valor = this.valorParameter.value;

    this.dialogRef.close(this.parameterData);
  }
}

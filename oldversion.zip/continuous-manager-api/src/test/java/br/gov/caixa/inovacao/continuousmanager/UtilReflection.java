/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager;

import java.lang.reflect.Field;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Fabio Iwakoshi
 *
 */
public class UtilReflection {
	
	private static Logger log = Logger.getAnonymousLogger();
	
	public static <E> void setField(E entity, String campo, Object valor) {
		Class<?> clazzEntidade = entity.getClass();
		Field field = null;
		try {
			field = clazzEntidade.getDeclaredField(campo);
		} catch (NoSuchFieldException | IllegalArgumentException e) {
			log.fine("Erro ao obter campo. Tentando superclass...");
			clazzEntidade = entity.getClass().getSuperclass();
			try {
				field = clazzEntidade.getDeclaredField(campo);
			} catch (NoSuchFieldException | SecurityException e1) {
				log.log(Level.SEVERE, "Erro ao atribuir valor", e);
				return;
			}
		}
		try {
			field.setAccessible(true);
			field.set(entity, valor);
		} catch (IllegalArgumentException | IllegalAccessException e) {
			log.log(Level.SEVERE, "Erro ao atribuir valor", e);
		}
	}
	
	public static void superficialEnumCodeCoverage(Class<? extends Enum<?>> enumClass) {
	    try {
	      for (Object o : (Object[])enumClass.getMethod("values").invoke(null)) {
	        enumClass.getMethod("valueOf", String.class).invoke(null, o.toString());
	      }
	    }
	    catch (Throwable e) {
	      throw new RuntimeException(e);
	    }
	  }

}

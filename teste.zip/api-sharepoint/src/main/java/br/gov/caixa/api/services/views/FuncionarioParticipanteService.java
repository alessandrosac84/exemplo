package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.views.FuncionarioParticipanteDto;
import br.gov.caixa.api.model.views.FuncionarioParticipante;
import br.gov.caixa.api.repository.views.FuncionarioParticipanteRepository;
import br.gov.caixa.api.result.views.FuncionarioParticipanteResult;

@Named
public class FuncionarioParticipanteService {
	
	@Inject
	private FuncionarioParticipanteRepository repository;

	public FuncionarioParticipanteResult listFuncionariosParticipantesByTurmaId(Long turmaId) {
		List<FuncionarioParticipante> lista = repository.findByTurmaAndNulls(turmaId);
		
		FuncionarioParticipanteResult result = new FuncionarioParticipanteResult();
		
		result.setList(FuncionarioParticipanteDto.fromFuncionarioParticipanteToListDto(lista));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}	
	
}

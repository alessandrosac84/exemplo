package br.gov.caixa.api.controller;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.dto.MailContentDto;
import br.gov.caixa.api.dto.NotificacaoDto;
import br.gov.caixa.api.model.Notificacao.TipoNotificacao;
import br.gov.caixa.api.result.NotificacaoResult;
import br.gov.caixa.api.services.MailService;
import br.gov.caixa.api.services.NotificacaoService;

@RestController
public class NotificacaoController {
	
	@Inject
	NotificacaoService service;
	
	@Inject
	MailService mailService;
	
	@RequestMapping(value="/api/notificacao/save", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public NotificacaoResult save(@RequestBody NotificacaoDto dto){
		return service.save(dto);
	}
	
	@RequestMapping(value="/api/notificacao/saveList", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public NotificacaoResult save(@RequestBody List<NotificacaoDto> lista){
		return service.saveList(lista);
	}
	
	@RequestMapping(value="/api/notificacao/delete", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public NotificacaoResult delete(@RequestBody NotificacaoDto dto){
		return service.delete(dto);
	}
	
	@RequestMapping(value="/api/notificacao/findAllByUser/{funcionarioId}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public NotificacaoResult findAllByUser(@PathVariable Long funcionarioId) {
		return service.findAllByUser(funcionarioId);
	}
	
	@RequestMapping(value="/api/notificacao/updateLido", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")			
	@ResponseStatus(HttpStatus.OK)
	public NotificacaoResult setLido(@RequestBody NotificacaoDto dto) {		
		return service.setLido(dto);
	}
	          
	@RequestMapping(value="/api/notificacao/updateLidoPorFuncionario/{funcionarioId}/{tipoNotificacao}", method=RequestMethod.POST, produces = "application/json")			
	@ResponseStatus(HttpStatus.OK)
	public NotificacaoResult setLidoPorFuncionario(@PathVariable Long funcionarioId, @PathVariable TipoNotificacao tipoNotificacao) {		
		return service.setLidoPorFuncionario(funcionarioId, tipoNotificacao);
	}
	
	@RequestMapping(value="/api/notificacao/deleteOnePorTipoFuncionario/{funcionarioId}/{tipoNotificacao}", method=RequestMethod.POST, produces = "application/json")			
	@ResponseStatus(HttpStatus.OK)
	public NotificacaoResult deleteOnePorTipoFuncionario(@PathVariable Long funcionarioId, @PathVariable TipoNotificacao tipoNotificacao) {		
		return service.deleteOnePorTipoFuncionario(funcionarioId, tipoNotificacao);
	}
	
	@RequestMapping(value="/api/notificacao/deleteOnePorTipoFuncionarioData/{funcionarioId}/{tipoNotificacao}/{dataFim}", 
	method=RequestMethod.GET, 
	produces = "application/json")			
	@ResponseStatus(HttpStatus.OK)
	public NotificacaoResult deleteOnePorTipoFuncionarioData(@PathVariable Long funcionarioId, @PathVariable TipoNotificacao tipoNotificacao, @PathVariable Date dataFim) {		
		return service.deleteOnePorTipoFuncionarioData(funcionarioId, tipoNotificacao, dataFim);
	}	
	
	@RequestMapping(value="/api/notificacao/sendMail", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")			
	@ResponseStatus(HttpStatus.OK)
	public NotificacaoResult sendMail(@RequestBody MailContentDto mailContentDto) {		
		return mailService.sendMail(mailContentDto);
	}
}

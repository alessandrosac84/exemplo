package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the artefato_sistema database table.
 * 
 */
@Entity
@Table(name="artefato_sistema")
@NamedQueries({	
	@NamedQuery(name="ArtefatoSistema.findAll", query="SELECT a FROM ArtefatoSistema a"),
	@NamedQuery(name="ArtefatoSistema.findByAKs", query="SELECT a FROM ArtefatoSistema a WHERE a.id <> :id AND (a.arquivo = :arquivo AND a.apuracaoSistema = :apuracaoSistema)"),
	@NamedQuery(name="ArtefatoSistema.findByEquals", query="SELECT a FROM ArtefatoSistema a WHERE a.arquivo = :arquivo AND a.apuracaoSistema.id.apuracao = :apuracao AND  a.apuracaoSistema.id.sistema = :sistema"),
})
public class ArtefatoSistema extends AuditedEntity implements Serializable, IEntity<Integer> {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(nullable=false, length=100)
	private String arquivo;

	private Calendar atualizacao;

	@JsonIgnore
	//bi-directional many-to-one association to ApuracaoSistema
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="apuracao", referencedColumnName="apuracao", nullable=false),
		@JoinColumn(name="sistema", referencedColumnName="sistema", nullable=false)
		})
	private ApuracaoSistema apuracaoSistema;

	//bi-directional many-to-one association to SituacaoArquivo
	@ManyToOne
	@JoinColumn(name="situacao", nullable=false)
	private SituacaoArquivo situacaoArquivo;

	//bi-directional many-to-one association to TipoArtefato
	@ManyToOne
	@JoinColumn(name="artefato", nullable=false)
	private TipoArtefato tipoArtefato;

	public ArtefatoSistema() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getArquivo() {
		return this.arquivo;
	}

	public void setArquivo(String arquivo) {
		this.arquivo = arquivo;
	}

	public Calendar getAtualizacao() {
		return this.atualizacao;
	}

	public void setAtualizacao(Calendar atualizacao) {
		this.atualizacao = atualizacao;
	}

	public ApuracaoSistema getApuracaoSistema() {
		return this.apuracaoSistema;
	}

	public void setApuracaoSistema(ApuracaoSistema apuracaoSistema) {
		this.apuracaoSistema = apuracaoSistema;
	}

	public SituacaoArquivo getSituacaoArquivo() {
		return this.situacaoArquivo;
	}

	public void setSituacaoArquivo(SituacaoArquivo situacaoArquivo) {
		this.situacaoArquivo = situacaoArquivo;
	}

	public TipoArtefato getTipoArtefato() {
		return this.tipoArtefato;
	}

	public void setTipoArtefato(TipoArtefato tipoArtefato) {
		this.tipoArtefato = tipoArtefato;
	}
	
	@Override
	public boolean isTheSameObject(IEntity<Integer> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		ArtefatoSistema other = (ArtefatoSistema) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
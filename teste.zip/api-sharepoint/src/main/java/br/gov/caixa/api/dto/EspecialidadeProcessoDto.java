package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.EspecialidadeProcesso;

public class EspecialidadeProcessoDto {

	private Long uid;
	private Integer rating;	
	private EspecialidadeDto especialidadeDto;
	private ProcessoDto processoDto;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public EspecialidadeDto getEspecialidadeDto() {
		return especialidadeDto;
	}

	public void setEspecialidadeDto(EspecialidadeDto especialidadeDto) {
		this.especialidadeDto = especialidadeDto;
	}

	public ProcessoDto getProcessoDto() {
		return processoDto;
	}

	public void setProcessoDto(ProcessoDto processoDto) {
		this.processoDto = processoDto;
	}


	public static EspecialidadeProcessoDto fromEspecialidadeProcessoDto(EspecialidadeProcesso especialidadeProcesso) {
		EspecialidadeProcessoDto dto = new EspecialidadeProcessoDto();
		
		dto.setUid(especialidadeProcesso.getUid());
		dto.setRating(especialidadeProcesso.getRating());
		dto.setEspecialidadeDto(EspecialidadeDto.fromEspecialidadeToDto(especialidadeProcesso.getEspecialidade()));
		dto.setProcessoDto(ProcessoDto.fromProcessoToDto(especialidadeProcesso.getProcesso()));	
		
		return dto;
	}
	
	public static List<EspecialidadeProcessoDto> fromEspecialidadeProcessoToListDto(List<EspecialidadeProcesso> especialidadeProcessos) {
		List<EspecialidadeProcessoDto> returnList = new ArrayList<EspecialidadeProcessoDto>();
		
		for (EspecialidadeProcesso especialidadeProcesso : especialidadeProcessos) {
			
			returnList.add(fromEspecialidadeProcessoDto(especialidadeProcesso) );
		}
		return returnList;
	}	

}

package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;


/**
 * The persistent class for the branch_instance database table.
 * 
 */
@Entity
@Table(name="branch_instance")
@NamedQuery(name="BranchInstance.findAll", query="SELECT b FROM BranchInstance b")
public class BranchInstance extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BranchInstancePK id;

	@Column(name="automatic_deploy")
	private Boolean automaticDeploy;

	//bi-directional many-to-one association to ProjectBranch
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="branch", referencedColumnName="branch", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="project", referencedColumnName="project", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private ProjectBranch projectBranch;

	//bi-directional many-to-one association to Instance
	@JsonView(ViewJson.JenkisfileView.class)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="instance", referencedColumnName="name", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="server", referencedColumnName="server", nullable=false, insertable=false, updatable=false)
		})
	private Instance instance;

	public BranchInstance() {
		/* class constructor intentionally left blank */
	}

	public BranchInstancePK getId() {
		return this.id;
	}

	public void setId(BranchInstancePK id) {
		this.id = id;
	}

	public Boolean getAutomaticDeploy() {
		return this.automaticDeploy;
	}

	public void setAutomaticDeploy(Boolean automaticDeploy) {
		this.automaticDeploy = automaticDeploy;
	}

	public ProjectBranch getProjectBranch() {
		return this.projectBranch;
	}

	public void setProjectBranch(ProjectBranch projectBranch) {
		this.projectBranch = projectBranch;
	}

	public Instance getInstance() {
		return this.instance;
	}

	public void setInstance(Instance instance) {
		this.instance = instance;
	}

}
package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.dto.views.FuncionarioQuestionanteDto;
import br.gov.caixa.api.result.BasicResult;

public class FuncionarioQuestionanteResult extends BasicResult  {
	private List<FuncionarioQuestionanteDto> list;
	private FuncionarioQuestionanteDto funcionarioQuestionante;	

	public List<FuncionarioQuestionanteDto> getList() {
		return list;
	}

	public void setList(List<FuncionarioQuestionanteDto> list) {
		this.list = list;
	}

	public FuncionarioQuestionanteDto getFuncionarioQuestionante() {
		return funcionarioQuestionante;
	}

	public void setFuncionarioQuestionante(FuncionarioQuestionanteDto funcionarioQuestionante) {
		this.funcionarioQuestionante = funcionarioQuestionante;
	}	
}

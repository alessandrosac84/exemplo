package br.gov.caixa.api.model;

public enum IniciativaTreinamento {
	INTERNO(0),
	EXTERNO_CAIXA(1), 
	EXTERNO(2);	
	
	private final int codigo;
	
	IniciativaTreinamento(int codigo) { this.codigo = codigo; }
	
	int codigo() { return codigo; }
	
	public static IniciativaTreinamento porCodigo(int codigo) {
        for (IniciativaTreinamento iniciativaTreinamento: IniciativaTreinamento.values()) {
            if (codigo == iniciativaTreinamento.codigo()) return iniciativaTreinamento;
        }
        throw new IllegalArgumentException("tipo invalido");
    }
}

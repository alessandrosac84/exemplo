package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSetPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSetPK_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet_;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de acesso ao banco de dados da entidade ChangeSet.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class ChangeSetRepository {

	@Inject
	private EntityManager entityManager;

	public ChangeSet findById(ChangeSetPK id) {
		return entityManager.find(ChangeSet.class, id);
	}

	public ChangeSet save(ChangeSet changeSet) {
		entityManager.persist(changeSet);
		return changeSet;
	}
	
	public List<ChangeSet> findAll(String carteira, String projeto, String job, int offset, int limit, String search, // NOSONAR
			String sort, AscDesc order) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ChangeSet> query = builder.createQuery(ChangeSet.class);
		Root<ChangeSet> from = query.from(ChangeSet.class);
		from.fetch(ChangeSet_.commit, JoinType.LEFT);
		from.fetch(ChangeSet_.build, JoinType.LEFT);
		
		
		Predicate predicate = builder.equal(from.get(ChangeSet_.id).get(ChangeSetPK_.wallet), carteira);
		predicate = builder.and(predicate, builder.equal(from.get(ChangeSet_.id).get(ChangeSetPK_.project), projeto));
		predicate = builder.and(predicate, builder.equal(from.get(ChangeSet_.id).get(ChangeSetPK_.job), job));

		Order ascDesc = builder.asc(from.get(ChangeSet_.id).get(sort));
		if (order != AscDesc.ASC) {
			ascDesc = builder.desc(from.get(ChangeSet_.id).get(sort));
		}

		return entityManager
				.createQuery(query.select(from).distinct(true).where(predicate).orderBy(ascDesc))
				.setFirstResult(offset).setMaxResults(limit).getResultList();
	}
	
	/**
	 * Obtem o total de changeSets
	 * 
	 * @param search
	 * @return Total de changeSets
	 */
	public Long countAll(String carteira, String projeto, String job, String search) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);

		Root<ChangeSet> from = query.from(ChangeSet.class);

		Predicate predicate = builder.equal(from.get(ChangeSet_.id).get(ChangeSetPK_.wallet), carteira);
		predicate = builder.and(predicate, builder.equal(from.get(ChangeSet_.id).get(ChangeSetPK_.project), projeto));
		predicate = builder.and(predicate, builder.equal(from.get(ChangeSet_.id).get(ChangeSetPK_.job), job));

		return entityManager.createQuery(query.select(builder.count(from)).where(predicate)).getSingleResult();
	}
}

export class Dashboard {
    public id: { wallet: string, project: string, commit: string };
    public key: string;
    public qualityGate: string;
    public lines: number;
    public sizeProject: string;
    public bugs: number;
    public vulnerabilities: number;
    public debts: number;
    public codeSmells: number;
    public coverages: number;
    public unitTests: number;
    public duplications: number;
    public security: string;
    public securityRating: number;
    public sqaleRating: number;
    public quality: string;
}

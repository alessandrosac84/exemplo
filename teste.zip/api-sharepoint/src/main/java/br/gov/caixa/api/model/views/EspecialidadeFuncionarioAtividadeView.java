package br.gov.caixa.api.model.views;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Subselect;

@Entity
@Subselect("select * from especialidade_funcionario_atividade_view")
public class EspecialidadeFuncionarioAtividadeView {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "NOME")
	private String nome;

	@Column(name = "RATING")
	private Integer rating;
	
	@Column(name = "ATIVIDADE_ID")
	private Long atividadeId;
	
	@Column(name = "ATIVIDADE_NOME")
	private String atividade_nome;
	
	@Column(name = "ATIVO")
	private Boolean ativo;	
	
	@Column(name = "RATING_ESPECIALIDADE")
	private Integer rating_especialidade;
	
	@Column(name = "ESPECIALIDADE_ID")
	private Long especialidadeId;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public Long getAtividadeId() {
		return atividadeId;
	}

	public void setAtividadeId(Long atividadeId) {
		this.atividadeId = atividadeId;
	}

	public String getAtividade_nome() {
		return atividade_nome;
	}

	public void setAtividade_nome(String atividade_nome) {
		this.atividade_nome = atividade_nome;
	}

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}
	
	public Integer getRating_especialidade() {
		return rating_especialidade;
	}

	public void setRating_especialidade(Integer rating_especialidade) {
		this.rating_especialidade = rating_especialidade;
	}
	
	public Long getEspecialidadeId() {
		return especialidadeId;
	}

	public void setEspecialidadeId(Long especialidadeId) {
		this.especialidadeId = especialidadeId;
	}
}

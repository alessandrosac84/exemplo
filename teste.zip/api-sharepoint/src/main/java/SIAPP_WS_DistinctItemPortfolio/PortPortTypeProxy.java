package SIAPP_WS_DistinctItemPortfolio;

public class PortPortTypeProxy implements SIAPP_WS_DistinctItemPortfolio.PortPortType {
  private String _endpoint = null;
  private SIAPP_WS_DistinctItemPortfolio.PortPortType portPortType = null;
  
  public PortPortTypeProxy() {
    _initPortPortTypeProxy();
  }
  
  public PortPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initPortPortTypeProxy();
  }
  
  private void _initPortPortTypeProxy() {
    try {
      portPortType = (new SIAPP_WS_DistinctItemPortfolio.SIAPP_WS_DistinctItemPortfolioServiceLocator()).getPortSoap();
      if (portPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)portPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)portPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (portPortType != null)
      ((javax.xml.rpc.Stub)portPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public SIAPP_WS_DistinctItemPortfolio.PortPortType getPortPortType() {
    if (portPortType == null)
      _initPortPortTypeProxy();
    return portPortType;
  }
  
  public SIAPP_WS_DistinctItemPortfolio.OutputMapping5GetListValues[] getList(java.lang.String qualification, java.lang.String startRecord, java.lang.String maxLimit) throws java.rmi.RemoteException{
    if (portPortType == null)
      _initPortPortTypeProxy();
    return portPortType.getList(qualification, startRecord, maxLimit);
  }
  
  
}
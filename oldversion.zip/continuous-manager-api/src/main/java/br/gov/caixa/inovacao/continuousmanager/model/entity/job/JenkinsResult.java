package br.gov.caixa.inovacao.continuousmanager.model.entity.job;

/**
 * Enum de Ambientes
 * 
 * @author Fabio Iwakoshi
 */
public enum JenkinsResult {

	SUCCESS("Sucesso"), UNSTABLE("Instável"), FAILURE("Falhou"), ABORTED("Abortado"), NOT_BUILT("Não Compilado");
	
	private String description;
	
	private JenkinsResult(String description) {
		this.description = description;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
}

/**
 * 
 */
package br.gov.caixa.portalinovacao.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entidade Parameter.
 * 
 * @author Fabio Iwakoshi
 *
 */
@Entity
@Table(name = "parameter")
public class Parameter implements Serializable {

	private static final long serialVersionUID = 5575858173668571090L;

	@Id
	@Enumerated(EnumType.STRING)
	private Environment environment;

	@Column(name = "portal_inovacao_host")
	private String portalInovacaoHost;
	
	@Column(name = "portal_inovacao_authorization")
	private String portalInovacaoAuthorization;

	/**
	 * @return the environment
	 */
	public Environment getEnvironment() {
		return environment;
	}

	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	/**
	 * @return the portalInovacaoHost
	 */
	public String getPortalInovacaoHost() {
		return portalInovacaoHost;
	}

	/**
	 * @param portalInovacaoHost the portalInovacaoHost to set
	 */
	public void setPortalInovacaoHost(String portalInovacaoHost) {
		this.portalInovacaoHost = portalInovacaoHost;
	}

	/**
	 * @return the portalInovacaoAuthorization
	 */
	public String getPortalInovacaoAuthorization() {
		return portalInovacaoAuthorization;
	}

	/**
	 * @param portalInovacaoAuthorization the portalInovacaoAuthorization to set
	 */
	public void setPortalInovacaoAuthorization(String portalInovacaoAuthorization) {
		this.portalInovacaoAuthorization = portalInovacaoAuthorization;
	}
}

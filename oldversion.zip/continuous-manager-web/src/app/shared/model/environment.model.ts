
export class Environment {
    public ambiente: string;
    public version: string;

}

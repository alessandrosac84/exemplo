export const environment = {
  production: true,
  apiBaseUrl: 'http://guardiao.caixa/continuous-manager-api/',
  hmr: false
};

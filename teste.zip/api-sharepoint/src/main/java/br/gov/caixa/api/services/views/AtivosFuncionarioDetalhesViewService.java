package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.model.views.AtivosFuncionarioDetalhesView;
import br.gov.caixa.api.repository.views.AtivosFuncionarioDetalhesViewRepository;
import br.gov.caixa.api.result.views.AtivosFuncionarioDetalhesViewResult;

@Named
public class AtivosFuncionarioDetalhesViewService {
	
	@Inject
	AtivosFuncionarioDetalhesViewRepository  repository;
			
	public AtivosFuncionarioDetalhesViewResult listAll() {
		
		AtivosFuncionarioDetalhesViewResult result = new AtivosFuncionarioDetalhesViewResult();
		
		try {
						
			List<AtivosFuncionarioDetalhesView> lista = repository.findAll();				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Registro.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}

	public AtivosFuncionarioDetalhesViewResult listFuncionariosAtivoNaoConheco(String tipo, Long ativoId) {
		AtivosFuncionarioDetalhesViewResult result = new AtivosFuncionarioDetalhesViewResult();
		
		try {
						
			List<AtivosFuncionarioDetalhesView> lista = repository.findByTipoAndAtivoIdAndNaoConhecoNot(tipo, ativoId);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Registro.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}
	
	public AtivosFuncionarioDetalhesViewResult listFuncionariosAtivoQueroConhecer1(String tipo, Long ativoId) {
		AtivosFuncionarioDetalhesViewResult result = new AtivosFuncionarioDetalhesViewResult();
		
		try {
						
			List<AtivosFuncionarioDetalhesView> lista = repository.findByTipoAndAtivoIdAndQueroConhecer1(tipo, ativoId);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Registro.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}
	
	public AtivosFuncionarioDetalhesViewResult listFuncionariosAtivoQueroConhecer2(String tipo, Long ativoId) {
		AtivosFuncionarioDetalhesViewResult result = new AtivosFuncionarioDetalhesViewResult();
		
		try {
						
			List<AtivosFuncionarioDetalhesView> lista = repository.findByTipoAndAtivoIdAndQueroConhecer2(tipo, ativoId);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Registro.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}
	
	public AtivosFuncionarioDetalhesViewResult listFuncionariosAtivoNaoMarcado(String tipo, Long ativoId) {
		AtivosFuncionarioDetalhesViewResult result = new AtivosFuncionarioDetalhesViewResult();
		
		try {
						
			List<AtivosFuncionarioDetalhesView> lista = repository.findByTipoAndAtivoIdAndNaoMarcado(tipo, ativoId);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Registro.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}
	
	
	public AtivosFuncionarioDetalhesViewResult listFuncionariosAtivoMaisConhecido(String tipo, Long ativoId) {
		AtivosFuncionarioDetalhesViewResult result = new AtivosFuncionarioDetalhesViewResult();
		
		try {
						
			List<AtivosFuncionarioDetalhesView> lista = repository.findByTipoAndAtivoIdAndMaisConhecido(tipo, ativoId);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Registro.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

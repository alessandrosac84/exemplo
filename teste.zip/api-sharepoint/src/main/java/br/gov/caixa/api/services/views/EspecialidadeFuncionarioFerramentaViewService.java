package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.model.views.EspecialidadeFuncionarioFerramentaView;
import br.gov.caixa.api.repository.views.EspecialidadeFuncionarioFerramentaViewRepository;
import br.gov.caixa.api.result.views.EspecialidadeFuncionarioFerramentaViewResult;

@Named
public class EspecialidadeFuncionarioFerramentaViewService {
	
	@Inject
	EspecialidadeFuncionarioFerramentaViewRepository repository;
	
	public EspecialidadeFuncionarioFerramentaViewResult listAll() {

		EspecialidadeFuncionarioFerramentaViewResult result = new EspecialidadeFuncionarioFerramentaViewResult();
		try {
			List<EspecialidadeFuncionarioFerramentaView> lista = repository.findAll();

			if (lista != null) {
				result.setList(lista);
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma especialidadeFerramentaView.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}

//	public EspecialidadeFuncionarioFerramentaViewResult listEspecialidadeFuncionarioFerramentaViewsByIdFerramenta(Long idFerramenta) {
//		EspecialidadeFuncionarioFerramentaViewResult result = new EspecialidadeFuncionarioFerramentaViewResult();
//		try {
//						
//			List<EspecialidadeFuncionarioFerramentaView> lista = repository.findByFerramentaId(idFerramenta);				
//			
//			if (lista != null) {
//				result.setList(lista);					
//				result.setMessage("Executado com sucesso.");
//			}
//			else {
//				result.setIsError(true);
//				result.setMessage("Nenhuma Ferramenta para a categoria tecnologica.");
//			}
//		} catch (Exception e) {				 
//			result.setIsError(true);
//			result.setMessage(e.getMessage());
//		}				
//	
//		return result;
//	}
//	
//	public EspecialidadeFuncionarioFerramentaViewResult listEspecialidadeFuncionarioFerramentasViewByIdsFerramenta(List<Long> idsFerramenta) {
//		
//		EspecialidadeFuncionarioFerramentaViewResult result = new EspecialidadeFuncionarioFerramentaViewResult();
//		try {
//						
//			List<EspecialidadeFuncionarioFerramentaView> lista = repository.findByFerramentaIdIn(idsFerramenta);				
//			
//			if (lista != null) {
//				result.setList(lista);					
//				result.setMessage("Executado com sucesso.");
//			}
//			else {
//				result.setIsError(true);
//				result.setMessage("Nenhuma Ferramenta para a categoria tecnologica.");
//			}
//		} catch (Exception e) {				 
//			result.setIsError(true);
//			result.setMessage(e.getMessage());
//		}				
//	
//		return result;
//	}
	
	public EspecialidadeFuncionarioFerramentaViewResult listEspecialidadeFuncionarioFerramentasViewByEspecialidadeId(Long especialidadeId) {
		
		EspecialidadeFuncionarioFerramentaViewResult result = new EspecialidadeFuncionarioFerramentaViewResult();
		try {
			
			List<EspecialidadeFuncionarioFerramentaView> lista = repository.findByEspecialidadeId(especialidadeId);
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Ferramenta para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}

	public EspecialidadeFuncionarioFerramentaViewResult listEspecialidadeFuncionarioFerramentasViewByIdsFerramentaAndEspecialidadeId(List<Long> idsFerramenta, Long especialidadeId) {
		
		EspecialidadeFuncionarioFerramentaViewResult result = new EspecialidadeFuncionarioFerramentaViewResult();
		try {
						
			//List<EspecialidadeFuncionarioFerramentaView> lista = repository.findByEspecialidadeIdAndFerramentaIdIn(especialidadeId,  idsFerramenta);				
			
			List<EspecialidadeFuncionarioFerramentaView> lista = repository.findByEspecialidadeId(especialidadeId);
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Ferramenta para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

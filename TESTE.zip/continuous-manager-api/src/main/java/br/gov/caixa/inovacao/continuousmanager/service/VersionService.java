package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.Calendar;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;

/**
 * Classe de servicos de Version.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class VersionService {

	@Inject
	private Logger log;
	
	@Inject
	private JenkinsService jenkinsService;
	
	@Inject
	private CommitService commitService;
	
	/**
	 * Gera uma nova versão do projeto para TQS
	 * 
	 * @param wallet
	 * @param project
	 * @param job
	 * @param commit
	 * @param version
	 */
	public void version(String wallet, String project, String job, String commit, String version) {
		log.fine("Iniciando Versionamento");
		String newJob = job.substring(0, job.indexOf("-ci-dev")) + "-ci-tqs";
		jenkinsService.createVersion(wallet, project, newJob, commit, version);
		CommitPK id = new CommitPK();	
		id.setWallet(wallet);
		id.setProject(project);
		id.setCommit(commit);
		Commit current = commitService.findById(id);
		current.setVersion(version);
		current.setVersionerUser(HelperThreadLocal.USER.get());
		current.setVersionedAt(Calendar.getInstance());
	}
}
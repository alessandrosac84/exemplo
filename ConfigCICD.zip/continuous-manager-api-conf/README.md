# Projeto de arquivos jenkins.

## Arquivo de pipeline

    - Jenkinsfile-CI-DEV // Arquivo do Pipeline de Integração Contínua em desenvolvimento
    - Jenkinsfile-CD-TQS // Arquivo do Pipeline de Entrega Contínua para TQS
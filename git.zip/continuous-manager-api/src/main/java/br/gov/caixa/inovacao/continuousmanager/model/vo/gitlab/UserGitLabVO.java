package br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab;

import java.io.Serializable;
import java.util.Calendar;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Fabio Iwakoshi
 *
 */
public class UserGitLabVO implements Serializable {

	private static final long serialVersionUID = -131240813576904520L;
	
	private String name;
	
	private String username;
	
	private Integer id;
	
	private String state;
	
	@JsonProperty("avatar_url")
	private String avatarUrl;

	@JsonProperty("web_url")
	private String webUrl;
	
	@JsonProperty("created_at")
	private Calendar createdAt;

	@JsonProperty("is_admin")
	private boolean admin;
	
	private String bio;
	
	private String location;
	
	private String skype;
	
	private String linkedin;
	
	private String twitter;

	@JsonProperty("website_url")
	private String websiteUrl;
	
	private String organization;
	
	@JsonProperty("last_sign_in_at")
	private Calendar lastSignInAt;

	@JsonProperty("confirmed_at")
	private Calendar confirmedAt;

	@JsonProperty("last_activity_on")
	private Calendar lastActivityOn;

	private String email;

	@JsonProperty("color_scheme_id")
	private Integer colorSchemeId;

	@JsonProperty("projects_limit")
	private Integer projectsLimit;

	@JsonProperty("current_sign_in_at")
	private Calendar currentSignInAt;

	private transient Object identities;

	@JsonProperty("can_create_group")
	private boolean canCreateGroup;

	@JsonProperty("can_create_project")
	private boolean canCreateProject;

	@JsonProperty("two_factor_enabled")
	private boolean twoFactorEnabled;

	private boolean external;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the avatarUrl
	 */
	public String getAvatarUrl() {
		return avatarUrl;
	}

	/**
	 * @param avatarUrl the avatarUrl to set
	 */
	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}

	/**
	 * @return the webUrl
	 */
	public String getWebUrl() {
		return webUrl;
	}

	/**
	 * @param webUrl the webUrl to set
	 */
	public void setWebUrl(String webUrl) {
		this.webUrl = webUrl;
	}

	/**
	 * @return the createdAt
	 */
	public Calendar getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Calendar createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return the admin
	 */
	public boolean isAdmin() {
		return admin;
	}

	/**
	 * @param admin the admin to set
	 */
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	/**
	 * @return the bio
	 */
	public String getBio() {
		return bio;
	}

	/**
	 * @param bio the bio to set
	 */
	public void setBio(String bio) {
		this.bio = bio;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return the skype
	 */
	public String getSkype() {
		return skype;
	}

	/**
	 * @param skype the skype to set
	 */
	public void setSkype(String skype) {
		this.skype = skype;
	}

	/**
	 * @return the linkedin
	 */
	public String getLinkedin() {
		return linkedin;
	}

	/**
	 * @param linkedin the linkedin to set
	 */
	public void setLinkedin(String linkedin) {
		this.linkedin = linkedin;
	}

	/**
	 * @return the twitter
	 */
	public String getTwitter() {
		return twitter;
	}

	/**
	 * @param twitter the twitter to set
	 */
	public void setTwitter(String twitter) {
		this.twitter = twitter;
	}

	/**
	 * @return the websiteUrl
	 */
	public String getWebsiteUrl() {
		return websiteUrl;
	}

	/**
	 * @param websiteUrl the websiteUrl to set
	 */
	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	/**
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}

	/**
	 * @param organization the organization to set
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}

	/**
	 * @return the lastSignInAt
	 */
	public Calendar getLastSignInAt() {
		return lastSignInAt;
	}

	/**
	 * @param lastSignInAt the lastSignInAt to set
	 */
	public void setLastSignInAt(Calendar lastSignInAt) {
		this.lastSignInAt = lastSignInAt;
	}

	/**
	 * @return the confirmedAt
	 */
	public Calendar getConfirmedAt() {
		return confirmedAt;
	}

	/**
	 * @param confirmedAt the confirmedAt to set
	 */
	public void setConfirmedAt(Calendar confirmedAt) {
		this.confirmedAt = confirmedAt;
	}

	/**
	 * @return the lastActivityOn
	 */
	public Calendar getLastActivityOn() {
		return lastActivityOn;
	}

	/**
	 * @param lastActivityOn the lastActivityOn to set
	 */
	public void setLastActivityOn(Calendar lastActivityOn) {
		this.lastActivityOn = lastActivityOn;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the colorSchemeId
	 */
	public Integer getColorSchemeId() {
		return colorSchemeId;
	}

	/**
	 * @param colorSchemeId the colorSchemeId to set
	 */
	public void setColorSchemeId(Integer colorSchemeId) {
		this.colorSchemeId = colorSchemeId;
	}

	/**
	 * @return the projectsLimit
	 */
	public Integer getProjectsLimit() {
		return projectsLimit;
	}

	/**
	 * @param projectsLimit the projectsLimit to set
	 */
	public void setProjectsLimit(Integer projectsLimit) {
		this.projectsLimit = projectsLimit;
	}

	/**
	 * @return the currentSignInAt
	 */
	public Calendar getCurrentSignInAt() {
		return currentSignInAt;
	}

	/**
	 * @param currentSignInAt the currentSignInAt to set
	 */
	public void setCurrentSignInAt(Calendar currentSignInAt) {
		this.currentSignInAt = currentSignInAt;
	}

	/**
	 * @return the identities
	 */
	public Object getIdentities() {
		return identities;
	}

	/**
	 * @param identities the identities to set
	 */
	public void setIdentities(Object identities) {
		this.identities = identities;
	}

	/**
	 * @return the canCreateGroup
	 */
	public boolean isCanCreateGroup() {
		return canCreateGroup;
	}

	/**
	 * @param canCreateGroup the canCreateGroup to set
	 */
	public void setCanCreateGroup(boolean canCreateGroup) {
		this.canCreateGroup = canCreateGroup;
	}

	/**
	 * @return the canCreateProject
	 */
	public boolean isCanCreateProject() {
		return canCreateProject;
	}

	/**
	 * @param canCreateProject the canCreateProject to set
	 */
	public void setCanCreateProject(boolean canCreateProject) {
		this.canCreateProject = canCreateProject;
	}

	/**
	 * @return the twoFactorEnabled
	 */
	public boolean isTwoFactorEnabled() {
		return twoFactorEnabled;
	}

	/**
	 * @param twoFactorEnabled the twoFactorEnabled to set
	 */
	public void setTwoFactorEnabled(boolean twoFactorEnabled) {
		this.twoFactorEnabled = twoFactorEnabled;
	}

	/**
	 * @return the external
	 */
	public boolean isExternal() {
		return external;
	}

	/**
	 * @param external the external to set
	 */
	public void setExternal(boolean external) {
		this.external = external;
	}
}

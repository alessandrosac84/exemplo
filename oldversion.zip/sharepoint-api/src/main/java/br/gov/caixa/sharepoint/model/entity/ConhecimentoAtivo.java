package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.gov.caixa.sharepoint.model.AuditedEntity;


/**
 * The persistent class for the conhecimento_ativo database table.
 * 
 */
@Entity
@Table(name="conhecimento_ativo")
@NamedQueries({
	@NamedQuery(name="ConhecimentoAtivo.findAll", query="SELECT c FROM ConhecimentoAtivo c"),
	@NamedQuery(name="ConhecimentoAtivo.findByAtivo", query="SELECT c FROM ConhecimentoAtivo c WHERE c.id.ativo = :ativo")
})
public class ConhecimentoAtivo extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ConhecimentoAtivoPK id;
	
	@Column(nullable=false, precision=2)
	private Integer rating;
	
	//bi-directional many-to-one association to Atividade
	@ManyToOne
	@JoinColumn(name="atividade", nullable=false, insertable=false, updatable=false)
	private Atividade atividade;

	@JsonBackReference
	//bi-directional many-to-one association to Ativo
	@ManyToOne
	@JoinColumn(name="ativo", nullable=false, insertable=false, updatable=false)
	private Ativo ativo;

	public ConhecimentoAtivo() {
	}

	public ConhecimentoAtivoPK getId() {
		return this.id;
	}

	public void setId(ConhecimentoAtivoPK id) {
		this.id = id;
	}

	public Atividade getAtividade() {
		return this.atividade;
	}

	public void setAtividade(Atividade atividade) {
		this.atividade = atividade;
	}

	public Ativo getAtivo() {
		return this.ativo;
	}

	public void setAtivo(Ativo ativo) {
		this.ativo = ativo;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

}
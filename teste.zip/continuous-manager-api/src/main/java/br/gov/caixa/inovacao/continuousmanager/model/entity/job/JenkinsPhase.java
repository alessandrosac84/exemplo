package br.gov.caixa.inovacao.continuousmanager.model.entity.job;

/**
 * Enum de Ambientes
 * 
 * @author Fabio Iwakoshi
 */
public enum JenkinsPhase {

	QUEUED("Enfileirado"), STARTED("Iniciado"), COMPLETED("Completado"), FINALIZED("Finalizado"), FAILED("Falhado");
	
	private String description;
	
	private JenkinsPhase(String description) {
		this.description = description;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
}

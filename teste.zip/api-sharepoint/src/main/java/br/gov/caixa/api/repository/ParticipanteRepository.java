package br.gov.caixa.api.repository;

import java.util.List;

import javax.persistence.OrderBy;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import br.gov.caixa.api.model.Participante;
import br.gov.caixa.api.model.StatusParticipante;
import br.gov.caixa.api.model.Turma;
import br.gov.caixa.api.model.views.FuncionarioView;

public interface ParticipanteRepository extends
		JpaRepository<Participante, Long> {

	@Query("select a from Participante a where a.turma.uid = ?1 order by a.data")	
	List<Participante> findByTurmaId(Long turmaId);
	
	@OrderBy("name")
	List<Participante> findByTurma(Turma turma);

	List<Participante> findByFuncionario(FuncionarioView funcionario);

	@Query(value = "SELECT * FROM participante p INNER JOIN turma t ON p.turma_id = t.uid "
			+ "WHERE p.funcionario_id = ?1 and p.status_participante = 3 and p.presensca = true "
			+ "AND p.uid NOT IN (SELECT participante_id FROM participante pa INNER JOIN feedback f ON pa.uid = f.participante_id WHERE pa.funcionario_id = ?1) AND t.encerrado = true", nativeQuery = true)
	List<Participante> findByFuncionarioNotInFeedback(Long funcionarioUid);
	
	@Modifying
	@Transactional
	@Query("update Participante p set p.statusParticipante = ?1 where p.uid = ?2")
	int updateStatusParticipante(StatusParticipante statusParticipante, Long uid);
	
	@Query("select a from Participante a where a.turma.uid = ?1 and a.funcionario.uid = ?2")
	Participante findByTurmaIdAndFuncionarioId(Long turmaId, Long funcionarioId);
	
	@Modifying
	@Transactional
	@Query("update Participante p set p.presenca = ?1 where p.funcionario.uid = ?2 and p.turma.uid = ?3")
	int updatePresencaParticipante(Boolean presenca, Long funcionarioUid, Long turmaId);
}

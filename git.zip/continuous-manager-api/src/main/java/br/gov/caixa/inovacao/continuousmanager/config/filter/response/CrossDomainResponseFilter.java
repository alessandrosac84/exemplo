/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.filter.response;

import java.io.IOException;
import java.util.logging.Logger;

import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;

/**
 * Filtro para cross domain
 * 
 * @author Fabio Iwakoshi
 *
 */
@Provider
@Priority(Priorities.HEADER_DECORATOR)
public class CrossDomainResponseFilter implements ContainerResponseFilter {

	@Override
	public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext)
			throws IOException {
		Logger log = Logger.getLogger(this.getClass().getName());
		log.fine("Executando CrossDomain Response Filter... ");
		
		responseContext.getHeaders().add("Access-Control-Allow-Origin", "*");
		responseContext.getHeaders().add("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");
		responseContext.getHeaders().add("Access-Control-Allow-Headers",
				"origin, content-type, accept, Authorization, If-Modified-Since, Cache-Control, Pragma, Expires");
		responseContext.getHeaders().add("Access-Control-Expose-Headers",
				"origin, content-type, accept, Authorization, cache, jwt, Content-Range");
	}

}

package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.EspecialidadeProcessoDto;
import br.gov.caixa.api.model.Especialidade;
import br.gov.caixa.api.model.EspecialidadeProcesso;
import br.gov.caixa.api.repository.EspecialidadeProcessoRepository;
import br.gov.caixa.api.result.EspecialidadeProcessoResult;

@Named
public class EspecialidadeProcessoService {
	
	@Inject
	EspecialidadeProcessoRepository repository;
	
	public EspecialidadeProcessoResult listAll() {

		EspecialidadeProcessoResult result = new EspecialidadeProcessoResult();
		
		try {
			List<EspecialidadeProcesso> lista = repository.findAll();

			if (lista != null) {
				result.setList(EspecialidadeProcessoDto.fromEspecialidadeProcessoToListDto(lista));
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma especialidade Processo.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}

	public EspecialidadeProcessoResult save(EspecialidadeProcessoDto dto) {
		
		EspecialidadeProcesso especialidadeProcesso = EspecialidadeProcesso.fromDtoToEspecialidadeProcesso(dto);
				
		especialidadeProcesso = repository.save(especialidadeProcesso);		
		dto.setUid(especialidadeProcesso.getUid());
		
		EspecialidadeProcessoResult result = new EspecialidadeProcessoResult();
		result.setEspecialidadeProcesso(dto);
		result.setMessage("Executado com sucesso.");
		
		return result;
	}

	public EspecialidadeProcessoResult delete(EspecialidadeProcessoDto dto) {

		EspecialidadeProcessoResult result;
		
		EspecialidadeProcesso especialidadeProcesso = repository.findOne(dto.getUid());
		
		try {
			repository.delete(especialidadeProcesso);
			
			result = new EspecialidadeProcessoResult();
			result.setMessage("Executado com sucesso.");
			
		} catch (Exception e) {
			result = new EspecialidadeProcessoResult();
			
			result.setIsError(true);
			result.setMessage("Existe(m) Rating(s) Associados a esta EspecialidadeProcesso.");
			
			e.printStackTrace();
		}		
		return result;
	}
	
	public EspecialidadeProcessoResult listEspecialidadeProcessosByIdProcesso(Long idEspecialidade) {
		EspecialidadeProcessoResult result = new EspecialidadeProcessoResult();
		try {
			
			Especialidade especialidade = new Especialidade();
			especialidade.setUid(idEspecialidade);
			
			List<EspecialidadeProcesso> lista = repository.findByEspecialidade(especialidade);				
			
			if (lista != null) {
				result.setList(EspecialidadeProcessoDto.fromEspecialidadeProcessoToListDto(lista));					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Processo para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

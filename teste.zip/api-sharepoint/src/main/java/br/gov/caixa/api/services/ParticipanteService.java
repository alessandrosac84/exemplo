package br.gov.caixa.api.services;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.MailContentDto;
import br.gov.caixa.api.dto.ParticipanteDto;
import br.gov.caixa.api.dto.TurmaDto;
import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.Participante;
import br.gov.caixa.api.model.StatusParticipante;
import br.gov.caixa.api.model.Turma;
import br.gov.caixa.api.model.views.FuncionarioView;
import br.gov.caixa.api.repository.FuncionarioRepository;
import br.gov.caixa.api.repository.ParticipanteRepository;
import br.gov.caixa.api.repository.TurmaRepository;
import br.gov.caixa.api.result.ParticipanteResult;

@Named
public class ParticipanteService {
	
	@Inject
	ParticipanteRepository repository;
	
	@Inject
	TurmaRepository turmaRepository;
	
	@Inject
	FuncionarioRepository funcionarioRepository;
	
	@Inject
	MailService mailService;
	
	public ParticipanteResult saveList(List<ParticipanteDto> dtoList){
		
		ParticipanteResult result = new ParticipanteResult();
		List<Participante> participantes = Participante.fromDtoToListParticipante(dtoList);
		
		repository.save(participantes);
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public ParticipanteResult save(ParticipanteDto dto){
		
		ParticipanteResult result = new ParticipanteResult();
		Participante participante = Participante.fromDtoToParticipante(dto);
		
		
		if(dto.getStatusParticipante() == StatusParticipante.INSCRITO) {
			
			Turma turma = turmaRepository.findOne(dto.getTurma().getUid());
		
			if(turma.getInscritos() < turma.getVagas())
			{				
				turmaRepository.addInscritos(turma.getUid());
				
				participante = repository.save(participante);				
				dto.setUid(participante.getUid());
				result.setParticipante(dto);				
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("N�o h� disponibilidade de vagas.");								
			}
			
			
		}
		else if(dto.getStatusParticipante() == StatusParticipante.CONFIRMADO || dto.getStatusParticipante() == StatusParticipante.RECUSADO) {
				
			participante = repository.save(participante);				
			dto.setUid(participante.getUid());
			result.setParticipante(dto);				
			result.setMessage("Executado com sucesso.");			
			
		}
		else if(dto.getStatusParticipante() == StatusParticipante.CONVIDADO) {
			
			Turma turma = turmaRepository.findOne(dto.getTurma().getUid());
						
			turmaRepository.removeInscritos(turma.getUid());
			
			participante = repository.save(participante);					
			dto.setUid(participante.getUid());
			
			result.setParticipante(dto);				
			result.setMessage("Executado com sucesso.");
		
			
		}	
		
		return result;
	}
	
	public ParticipanteResult updatePresencaParticipantePorFuncionario(Integer presenca, String matricula, Long turmaId) {
		
		ParticipanteResult result = new ParticipanteResult();
		
		Turma turma = turmaRepository.findOne(turmaId);			
		if (turma == null )
		{
			result.setIsError(true);
			result.setMessage("Turma n�o localizada");
			return result;
			
		}
				
		Funcionario funcionario = funcionarioRepository.findByMatricula(matricula);
		if (funcionario == null )
		{
			result.setIsError(true);
			result.setMessage("Funcion�rio/Visitante n�o localizado");
			return result;
			
		}
		
		Participante participante = repository.findByTurmaIdAndFuncionarioId(turmaId, funcionario.getUid());
		if (participante == null )
		{
			result.setIsError(true);
			result.setMessage("Participante n�o localizado na Turma Informada");
			return result;
			
		}
		
		repository.updatePresencaParticipante(presenca == 0 ? false : true, funcionario.getUid(), turmaId);
		
		result.setParticipante(ParticipanteDto.fromParticipanteToDto(participante));		
		result.setMessage("Presenca Atualizada com Sucesso!");
		
		if(presenca == 1)
			sendMail(turmaId, participante, StatusParticipante.PRESENTE);
		
		return result;
		
	}
	
	public ParticipanteResult updateStatusParticipante(StatusParticipante statusParticipante, Long uid, Long turmaId) {
		ParticipanteResult result = new ParticipanteResult();
		
		Participante participante = repository.findOne(uid);
				
		
		if(statusParticipante == StatusParticipante.INSCRITO) {
			
			Turma turma = turmaRepository.findOne(turmaId);
			
			if(turma.isFechado()) {
				
				result.setIsError(true);
				result.setMessage("Inscri��es Encerradas para Esta Turma.");		
				return result;
			}			
			else {
		
				if(turma.getInscritos() < turma.getVagas())
				{
					repository.updateStatusParticipante(statusParticipante, uid);
					turmaRepository.addInscritos(turmaId);
					participante.setStatusParticipante(StatusParticipante.INSCRITO);
					result.setVaga(1); 
				}
				else {
					
					repository.updateStatusParticipante(StatusParticipante.ESPERA, uid);
					participante.setStatusParticipante(StatusParticipante.ESPERA);				
				} 	
			}
		}
		else if(statusParticipante == StatusParticipante.CONVIDADO) {
			
			repository.updateStatusParticipante(statusParticipante, uid);
			
			if(participante.getStatusParticipante() == StatusParticipante.INSCRITO) {				
				turmaRepository.removeInscritos(turmaId);
				
				participante.setStatusParticipante(StatusParticipante.CONVIDADO);
				
				if (!checaParticipantesEmEspera(turmaId))
					result.setVaga(-1); 
			}			
			else
				participante.setStatusParticipante(StatusParticipante.CONVIDADO);
				
		}		
		else if(statusParticipante == StatusParticipante.CONFIRMADO) {
			
			repository.updateStatusParticipante(statusParticipante, uid);			
		}
		
		result.setParticipante( ParticipanteDto.fromParticipanteToDto(participante) );
		result.setMessage("Executado com sucesso.");
		
		return result;
	}
	
	private Boolean checaParticipantesEmEspera(Long turmaId) {
		
		Boolean result = false;
		List<Participante> participantes = repository.findByTurmaId(turmaId);
		
		
		for (Participante participante   : participantes) {
			
			if(participante.getStatusParticipante() == StatusParticipante.ESPERA) {
				
				repository.updateStatusParticipante(StatusParticipante.INSCRITO, participante.getUid());
				turmaRepository.addInscritos(turmaId);
				
				sendMail(turmaId, participante);								
				
				result = true;
				break;
			}
		}	
		
		return result;
		
	}
	
	private void sendMail(Long turmaId, Participante participante) {
		
		sendMail(turmaId, participante, StatusParticipante.INSCRITO); 
	}
	
	private void sendMail(Long turmaId, Participante participante, StatusParticipante status) {
		Turma turma = turmaRepository.findOne(turmaId);
		
		MailContentDto mailContentDto = new MailContentDto();
		mailContentDto.setTurma(TurmaDto.fromTurmaToDto(turma));
		
		List<String> toList = new ArrayList<String>();
		toList.add(participante.getFuncionario().getEmail());
		
		mailContentDto.setMail(toList);
		mailContentDto.setTipoTreinamento(turma.getTreinamento().getTipoTreinamento());
		mailContentDto.setNomeTreinamento(turma.getTreinamento().getNome());
		mailContentDto.setStatus(status);
			
		mailService.sendMail(mailContentDto);
	}

	public ParticipanteResult delete(Long id){
		
		Participante participante = repository.findOne(id);
		
		if(participante.getStatusParticipante() == StatusParticipante.INSCRITO || participante.getStatusParticipante() == StatusParticipante.CONFIRMADO ) {
			turmaRepository.removeInscritos(participante.getTurma().getUid());
			checaParticipantesEmEspera(participante.getTurma().getUid());
		}
		
		ParticipanteResult result = new ParticipanteResult();
		repository.delete(id);
		
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public ParticipanteResult deleteByTurma(Long id){
		ParticipanteResult result = new ParticipanteResult();
		
		Turma turma = new Turma();
		turma.setUid(id);
		List<Participante> participantes = repository.findByTurma(turma);
		
		repository.delete(participantes);
				
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public ParticipanteResult getOne(Long id){
		ParticipanteResult result = new ParticipanteResult();
		Participante participante = repository.findOne(id);
		result.setParticipante(ParticipanteDto.fromParticipanteToDto(participante));
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public ParticipanteResult getAll(){
		ParticipanteResult result = new ParticipanteResult();
		List<Participante> participantes = repository.findAll();
		result.setList(ParticipanteDto.fromParticipanteToListDto(participantes));
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public ParticipanteResult getByTurma(Long id){
		ParticipanteResult result = new ParticipanteResult();
		Turma turma = new Turma();
		turma.setUid(id);
		List<Participante> participantes = repository.findByTurma(turma);
		result.setList(ParticipanteDto.fromParticipanteToListDto(participantes));
		result.setMessage("Executado com sucesso.");
		return result;
	}

	public ParticipanteResult getByFuncionario(Long id) {
		ParticipanteResult result = new ParticipanteResult();
		
		//Funcionario funcionario = new Funcionario();
		FuncionarioView funcionario = new FuncionarioView();
		funcionario.setUid(id);
		
		List<Participante> participantes = repository.findByFuncionario(funcionario);
		
		result.setList(ParticipanteDto.fromParticipanteToListDto(participantes));
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public ParticipanteResult findByFuncionarioNotInFeedback(Long id) {
		ParticipanteResult result = new ParticipanteResult();
		List<Participante> participantes = repository.findByFuncionarioNotInFeedback(id);
		result.setList(ParticipanteDto.fromParticipanteToListDto(participantes));
		result.setMessage("Executado com sucesso.");
		return result;
	}
}

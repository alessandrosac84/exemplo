package br.gov.caixa.api.model.views;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.gov.caixa.api.dto.views.FuncionarioQuestionanteDto;

@Entity
@Table(name = "funcionario_questionante")
public class FuncionarioQuestionante {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "NOME", nullable = false)
	private String nome;
	
	@Column(name = "EMAIL")
	private String email;

	@Column(name = "MATRICULA", nullable = false)
	private String matricula;

	@Column(name = "CARGO", nullable = true)
	private String cargo;
	
	@Column(name = "QUESTIONANTE_ID")
	private Long questionanteId;
	
	@Column(name = "PARTICIPACAO", nullable = true, columnDefinition = "boolean default false")
	private Boolean participacao;

	@Column(name = "QUESTIONARIO_ID")
	private Long questionarioId;
	
	@Column(name = "QUESTAO")
	private String questao;
		
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	
	public Long getQuestionanteId() {
		return questionanteId;
	}

	public void setQuestionanteId(Long questionanteId) {
		this.questionanteId = questionanteId;
	}

	public Boolean isParticipacao() {
		return participacao;
	}

	public void setParticipacao(Boolean participacao) {
		this.participacao = participacao;
	}

	public Long getQuestionarioId() {
		return questionarioId;
	}

	public void setQuestionarioId(Long questionarioId) {
		this.questionarioId = questionarioId;
	}

	public String getQuestao() {
		return questao;
	}

	public void setQuestao(String questao) {
		this.questao = questao;
	}

	
	public static FuncionarioQuestionante fromDtoToFuncionarioQuestionante(FuncionarioQuestionanteDto funcionarioQuestionanteDto) {
		
		FuncionarioQuestionante funcionarioQuestionante = new FuncionarioQuestionante();
		
		funcionarioQuestionante.setUid(funcionarioQuestionanteDto.getUid());
		funcionarioQuestionante.setNome(funcionarioQuestionanteDto.getNome());
		funcionarioQuestionante.setEmail(funcionarioQuestionanteDto.getEmail());
		funcionarioQuestionante.setMatricula(funcionarioQuestionanteDto.getMatricula());
		funcionarioQuestionante.setCargo(funcionarioQuestionanteDto.getCargo());				
		funcionarioQuestionante.setQuestionanteId(funcionarioQuestionanteDto.getQuestionanteId());
		funcionarioQuestionante.setParticipacao(funcionarioQuestionanteDto.isParticipacao());
		funcionarioQuestionante.setQuestionarioId(funcionarioQuestionanteDto.getQuestionarioId());
		funcionarioQuestionante.setQuestao(funcionarioQuestionanteDto.getQuestao());
		
		return funcionarioQuestionante;
	}

	public static List<FuncionarioQuestionante> fromDtoToListFuncionarioQuestionante(List<FuncionarioQuestionanteDto> funcionariosQuestionantesDto) {
		 List<FuncionarioQuestionante> result = new ArrayList<FuncionarioQuestionante>();
		 
		 for (Iterator<FuncionarioQuestionanteDto> iterator = funcionariosQuestionantesDto.iterator(); iterator.hasNext();) {
			FuncionarioQuestionanteDto dto = (FuncionarioQuestionanteDto) iterator.next();
			result.add(fromDtoToFuncionarioQuestionante(dto));
		}
		 
		return result;
	}
}
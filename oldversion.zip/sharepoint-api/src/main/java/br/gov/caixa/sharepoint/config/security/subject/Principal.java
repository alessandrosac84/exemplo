/**
 * 
 */
package br.gov.caixa.sharepoint.config.security.subject;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Fabio Iwakoshi
 *
 */
public class Principal {

	private String username;
	private String cargo;
	private List<Integer> coordenacao = new ArrayList<>();
	private String ip;

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username
	 *            the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @param username
	 *            the username to set
	 */
	public Principal username(String username) {
		setUsername(username);
		return this;
	}

	/**
	 * @return the cargo
	 */
	public String getCargo() {
		return cargo;
	}

	/**
	 * @param cargo
	 *            the cargo to set
	 */
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	/**
	 * @param cargo
	 *            the cargo to set
	 */
	public Principal cargo(String cargo) {
		setCargo(cargo);
		return this;
	}

	/**
	 * @return the coordenacao
	 */
	public List<Integer> getCoordenacao() {
		return coordenacao;
	}

	/**
	 * @param coordenacao
	 *            the coordenacao to set
	 */
	public void setCoordenacao(List<Integer> coordenacao) {
		this.coordenacao = coordenacao;
	}

	/**
	 * @param coordenacao
	 *            the coordenacao to set
	 */
	public Principal coordenacao(List<Integer> coordenacao) {
		setCoordenacao(coordenacao);
		return this;
	}

	/**
	 * @return the ip
	 */
	public String getIp() {
		return ip;
	}

	/**
	 * @param ip
	 *            the ip to set
	 */
	public void setIp(String ip) {
		this.ip = ip;
	}

	/**
	 * @param ip
	 *            the ip to set
	 */
	public Principal ip(String ip) {
		this.ip = ip;
		return this;
	}
}

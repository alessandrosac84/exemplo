/**
 * 
 */
package br.gov.caixa.sharepoint.config.log;

import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.sharepoint.config.security.subject.PrincipalThreadLocal;
import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.entity.Auditoria;
import br.gov.caixa.sharepoint.model.entity.TipoAcao;
import br.gov.caixa.sharepoint.service.AuditoriaService;
import br.gov.caixa.sharepoint.util.Util;

/**
 * @author Fabio Iwakoshi
 *
 */
public class AuditInterceptor {

	@PrePersist
	public void onPrePersist(AuditedEntity entity) {
		entity.setTimestampInclusao(Calendar.getInstance());
		entity.setUsuarioInclusao(PrincipalThreadLocal.USER.get().getUsername());
	}
	
	@PreUpdate
	@PreRemove
	public void onPreUpdate(AuditedEntity entity) {
		entity.setTimestampAlteracao(Calendar.getInstance());
		entity.setUsuarioAlteracao(PrincipalThreadLocal.USER.get().getUsername());
	}
	
	@PostPersist
	public void onPostPersist(AuditedEntity entity) throws JsonProcessingException {
		saveAuditoria(createAuditoria(1, entity));
	}
	
	@PostUpdate
	public void onPostUpdate(AuditedEntity entity) throws JsonProcessingException {
		saveAuditoria(createAuditoria(2, entity));
	}

	@PostRemove
	public void onPostRemove(AuditedEntity entity) throws JsonProcessingException {
		saveAuditoria(createAuditoria(3, entity));
	}

	private Auditoria createAuditoria(int acao, AuditedEntity entity) throws JsonProcessingException {
		TipoAcao tipoAcao = new TipoAcao();
		tipoAcao.setId(acao);
		Auditoria auditoria = new Auditoria();
		auditoria.setTipoAcao(tipoAcao);
		auditoria.setFuncionalidade(entity.getClass().getSimpleName().replaceAll("([a-z])([A-Z])", "$1 $2"));
		auditoria.setEntidade(new ObjectMapper().writeValueAsString(Util.fixEntity(entity)));
		auditoria.setFuncionarioEvento(PrincipalThreadLocal.USER.get().getUsername());
		auditoria.setTimestampEvento(Calendar.getInstance());
		auditoria.setIpEvento(PrincipalThreadLocal.USER.get().getIp());
		
		return auditoria;
	}

	private void saveAuditoria(Auditoria auditoria) {
		try {
	        InitialContext initialContext = new InitialContext();
	        ((AuditoriaService) initialContext.lookup("java:comp/AuditoriaService")).save(auditoria);
	    } catch (NamingException e) {
	    	Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "Error in EntityListener resolution of Bean Manager", e);
	        throw new IllegalStateException(e);
	    }
	}
}

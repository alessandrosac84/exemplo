package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import javax.ws.rs.BadRequestException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;

/**
 * Classe de testes do VersionService.
 * 
 * @author Alessandro Carvalho
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class VersionServiceTest {

	@Mock
	private JenkinsService jenkinsService;

	@Mock
	private CommitService commitService;
	
	@InjectMocks
	private VersionService versionService;
	
	private Commit commit = new Commit();
	
	@Before
	public void before() {
		CommitPK pk = new CommitPK();
		pk.setCommit("commit");
		pk.setProject("project");
		pk.setWallet("wallet");
		commit.setId(pk);
		commit.setVersion("dsadsa");
		UtilReflection.setField(versionService, "log", Logger.getLogger(VersionService.class.getName()));
	}
	
	@Test
	public void testVersion() {
		// Arrange
		Mockito.when(commitService.findByVersionOrCommit(Mockito.anyString(), Mockito.anyString(), Mockito.any(Commit.class))).thenReturn(null);
		Mockito.when(commitService.findById(Mockito.any(CommitPK.class))).thenReturn(commit);
		
		// Act
		versionService.version("inovacao", "continuous-manager-web", commit);
	}
	
	@Test(expected=BadRequestException.class)
	public void testVersionExist() {		
		// Act
		versionService.version("inovacao", "continuous-manager-web", commit);
	}
}

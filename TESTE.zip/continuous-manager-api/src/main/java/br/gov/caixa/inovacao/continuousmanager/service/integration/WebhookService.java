/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildLog;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildLogPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSetPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsPhase;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Job;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JobPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.LocalError;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Measures;
import br.gov.caixa.inovacao.continuousmanager.model.entity.MeasuresPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Path;
import br.gov.caixa.inovacao.continuousmanager.model.entity.PathPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ProjectEnvironment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ProjectEnvironmentPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ProjectPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Wallet;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab.CommitGitLabVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ActionJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BuildJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ItemJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.JobJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.PathJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.PayloadNotificationJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ProjectJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.WalletJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.InfoSonarVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.MeasureVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.QualityGateVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.SonarMeasureVO;
import br.gov.caixa.inovacao.continuousmanager.service.BuildLogService;
import br.gov.caixa.inovacao.continuousmanager.service.BuildService;
import br.gov.caixa.inovacao.continuousmanager.service.ChangeSetService;
import br.gov.caixa.inovacao.continuousmanager.service.CommitService;
import br.gov.caixa.inovacao.continuousmanager.service.JobService;
import br.gov.caixa.inovacao.continuousmanager.service.MeasuresService;
import br.gov.caixa.inovacao.continuousmanager.service.PathService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectEnvironmentService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectService;
import br.gov.caixa.inovacao.continuousmanager.service.QualityGateService;
import br.gov.caixa.inovacao.continuousmanager.service.WalletService;

/**
 * Classe de servicos de Folder.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class WebhookService {

	@Inject
	private Logger log;

	@Inject
	private JenkinsService jenkinsService;

	@Inject
	private GitLabService gitLabService;

	@Inject
	private WalletService walletService;

	@Inject
	private ProjectService projectService;

	@Inject
	private JobService jobService;

	@Inject
	private BuildService buildService;

	@Inject
	private BuildLogService buildLogService;

	@Inject
	private CommitService commitService;

	@Inject
	private ChangeSetService changeSetService;

	@Inject
	private PathService pathService;
	
	@Inject
	private ProjectEnvironmentService projectEnvironmentService;
	
	@Inject
	private SonarService sonarService;
	
	@Inject
	private MeasuresService measuresService;
	
	@Inject
	private QualityGateService qualityGateService;
	
	private List<WalletJenkinsVO> wallets;
	
	private List<ProjectJenkinsVO> projects;
	
	private List<JobJenkinsVO> jobs;
	
	private List<BuildJenkinsVO> builds;
	
	/**
	 * Update Wallets, Projects, Jobs and Builds
	 * 
	 * @param payload
	 */
	public void add(String[] infos) {
		// Load wallets
		walletService.findAll(0, Integer.MAX_VALUE, "", "id", AscDesc.ASC);
		// Add all
		log.fine("Updating wallets");
		addWallet(infos);
	}

	private void addWallet(String[] infos) {
		if (infos.length > 0 && !infos[0].isEmpty()) {
			log.log(Level.SEVERE, "WALLET :: {0}", infos[0]);
			Wallet currentW = checkWalletJenkins(infos[0]);
			if (infos.length == 1) {
				jenkinsService.listProjects(currentW.getId()).forEach(project -> {
					log.log(Level.SEVERE, "PROJECT1 :: {0}", project.getName());
					Project currentP = checkProjectJenkins(currentW.getId(), project);
					jobs = null;
					jenkinsService.listJobs(currentP.getId().getWallet(), currentP.getId().getId()).forEach(job -> {
						log.log(Level.SEVERE, "JOB1 :: {0}", job.getName());
						Job currentJ = checkJobJenkins(currentP.getId(), job);
						builds = null;
						jenkinsService.listBuilds(currentJ.getId().getWallet(), currentJ.getId().getProject(), currentJ.getId().getId())
							.forEach(build -> {
								log.log(Level.SEVERE, "BUILD1 :: {0}", build.getNumber());
								checkBuildJenkins(currentJ.getId(), build);
						});
					});
				});
				return;
			}
			
			log.log(Level.SEVERE, "PROJECT :: {0}", infos[1]);
			Project currentP = checkProjectJenkins(currentW.getId(), findProject(infos[0], infos[1]));
			
			if (infos.length == 2) {
				jenkinsService.listJobs(currentP.getId().getWallet(), currentP.getId().getId()).forEach(job -> {
					log.log(Level.SEVERE, "JOB2 :: {0}", job.getName());
					Job currentJ = checkJobJenkins(currentP.getId(), job);
					builds = null;
					jenkinsService.listBuilds(currentJ.getId().getWallet(), currentJ.getId().getProject(), currentJ.getId().getId())
						.forEach(build -> {
							log.log(Level.SEVERE, "BUILD2 :: {0}", build.getNumber());
							checkBuildJenkins(currentJ.getId(), build);
					});
				});
				return;
			}
			
			log.log(Level.SEVERE, "JOB :: {0}", infos[2]);
			Job currentJ = checkJobJenkins(currentP.getId(), findJob(infos[0], infos[1], infos[2]));
			if (infos.length == 3) {
				infos = Arrays.copyOf(infos, infos.length + 1);
				infos[infos.length-1] = String.valueOf(Integer.MAX_VALUE);
			}
			int lastJob = Integer.parseInt(infos[3]);
			List<BuildJenkinsVO> listBuilds = jenkinsService.listBuilds(currentJ.getId().getWallet(), currentJ.getId().getProject(), currentJ.getId().getId());
			for (BuildJenkinsVO build : listBuilds) {
				if (build.getNumber() <= lastJob) {
					log.log(Level.SEVERE, "BUILD :: {0}", build.getNumber());
					checkBuildJenkins(currentJ.getId(), findBuild(infos[0], infos[1], infos[2], build.getNumber()));
				}
			}
		} else {
			jenkinsService.listWallets().forEach(wallet -> {
				log.log(Level.SEVERE, "WALLET :: {0}", wallet.getName());
				Wallet currentW = checkWalletJenkins(wallet.getName());
				projects = null;
				jenkinsService.listProjects(currentW.getId()).forEach(project -> {
					log.log(Level.SEVERE, "PROJECT :: {0}", project.getName());
					Project currentP = checkProjectJenkins(currentW.getId(), project);
					jobs = null;
					jenkinsService.listJobs(currentP.getId().getWallet(), currentP.getId().getId()).forEach(job -> {
						log.log(Level.SEVERE, "JOB :: {0}", job.getName());
						Job currentJ = checkJobJenkins(currentP.getId(), job);
						builds = null;
						jenkinsService.listBuilds(currentJ.getId().getWallet(), currentJ.getId().getProject(), currentJ.getId().getId())
							.forEach(build -> {
								log.log(Level.SEVERE, "BUILD :: {0}", build.getNumber());
								checkBuildJenkins(currentJ.getId(), build);
						});
					});
				});
			});
		}
	}

	/**
	 * Update Wallets, Projects, Jobs and create Build
	 * 
	 * @param payload
	 */
	public void add(PayloadNotificationJenkinsVO payload) {
		wallets = null;
		projects = null;
		jobs = null;
		builds = null;
		String[] tokenized = payload.getBuild().getUrl().split("/");
		Wallet currentW = checkWalletJenkins(tokenized[1]);
		Project currentP = checkProjectJenkins(currentW.getId(), findProject(tokenized[1], tokenized[3]));
		Job currentJ = checkJobJenkins(currentP.getId(), findJob(tokenized[1], tokenized[3], tokenized[5]));
		checkBuildJenkins(currentJ.getId(), findBuild(tokenized[1], tokenized[3], tokenized[5], payload.getBuild().getNumber()));
	}

	
	/**
	 * Update Wallets, Projects, Jobs and Build
	 * 
	 * @param payload
	 */
	public void update(PayloadNotificationJenkinsVO payload) {
		wallets = null;
		projects = null;
		jobs = null;
		builds = null;
		String[] tokenized = payload.getBuild().getUrl().split("/");
		BuildPK buildId = new BuildPK();
		buildId.setWallet(tokenized[1]);
		buildId.setProject(tokenized[3]);
		buildId.setJob(tokenized[5]);
		buildId.setId(payload.getBuild().getNumber());
		Build build = updateBuild(buildId, findBuild(tokenized[1], tokenized[3], tokenized[5], payload.getBuild().getNumber()), payload.getBuild().getPhase());

		if(tokenized[5].endsWith("-tqs") && build.getResult() != null && build.getResult() == JenkinsResult.SUCCESS) {
			ProjectEnvironment projectEnvironment = new ProjectEnvironment();
			projectEnvironment.setId(new ProjectEnvironmentPK());
			projectEnvironment.getId().setWallet(tokenized[1]);
			projectEnvironment.getId().setProject(tokenized[3]);
			projectEnvironment.getId().setJob(tokenized[5]);
			projectEnvironment.getId().setBuild(payload.getBuild().getNumber());
			projectEnvironment.getId().setEnvironment(Environment.TQS);
			projectEnvironment.setCreatedAt(build.getCreatedAt());
			projectEnvironmentService.update(projectEnvironment);
		}
	}
	
	/**
	 * Check and add Wallet if necessary
	 * 
	 * @param wallet
	 * @return Wallet
	 */
	private Wallet checkWalletJenkins(String wallet) {
		Wallet current = walletService.findById(wallet);
		if (current == null) {
			current = saveWallet(findWallet(wallet));
		}
		return current;
	}
	
	/**
	 * Check and add Project if necessary
	 * @param wallet 
	 * 
	 * @param project
	 * @return Project
	 */
	private Project checkProjectJenkins(String wallet, ProjectJenkinsVO project) {
		ProjectPK id = new ProjectPK();
		id.setWallet(wallet);
		id.setId(project.getName());
		Project current = projectService.findById(id);
		if (current == null) {
			current = saveProject(id, project);
		}
		return current;
	}

	/**
	 * Check and add Job if necessary
	 * @param wallet 
	 * 
	 * @param job
	 * @return Project
	 */
	private Job checkJobJenkins(ProjectPK projectId, JobJenkinsVO job) {
		JobPK id = new JobPK();
		id.setWallet(projectId.getWallet());
		id.setProject(projectId.getId());
		id.setId(job.getName());
		Job current = jobService.findById(id);
		if (current == null) {
			current = saveJob(id, job);
		}
		return current;
	}
	
	/**
	 * Check and add Build if necessary
	 * @param wallet 
	 * 
	 * @param build
	 * @param phase 
	 * @return Project
	 */
	private Build checkBuildJenkins(JobPK jobId, BuildJenkinsVO build) {
		BuildPK id = new BuildPK();
		id.setWallet(jobId.getWallet());
		id.setProject(jobId.getProject());
		id.setJob(jobId.getId());
		id.setId(build.getNumber());
		Build current = buildService.findById(id);
		if (current == null) {
			current = saveBuild(id, build);
		}
		if(jobId.getId().endsWith("-tqs") && build.getResult() != null && build.getResult() == JenkinsResult.SUCCESS) {
			ProjectEnvironment projectEnvironment = new ProjectEnvironment();
			projectEnvironment.setId(new ProjectEnvironmentPK());
			projectEnvironment.getId().setWallet(jobId.getWallet());
			projectEnvironment.getId().setProject(jobId.getProject());
			projectEnvironment.getId().setJob(jobId.getId());
			projectEnvironment.getId().setBuild(build.getNumber());
			projectEnvironment.getId().setEnvironment(Environment.TQS);
			projectEnvironment.setCreatedAt(build.getTimestamp());
			projectEnvironmentService.update(projectEnvironment);
		}
		return current;
	}

	/**
	 * Save Wallet after find that on Jenkins
	 * 
	 * @param id
	 * @return Wallet
	 */
	private Wallet saveWallet(WalletJenkinsVO wallet) {
		Wallet w = new Wallet();
		w.setId(wallet.getName());
		w.setName(wallet.getDisplayName());
		return walletService.save(w);
	}

	/**
	 * Save Project after find that on Jenkins
	 * @param id 
	 * 
	 * @param id
	 * @return Project
	 */
	private Project saveProject(ProjectPK id, ProjectJenkinsVO project) {
		Project p = new Project();
		p.setId(id);
		p.setName(project.getDisplayName());
		return projectService.save(p);
	}

	/**
	 * Save Project after find that on Jenkins
	 * @param id 
	 * 
	 * @param id
	 * @return Project
	 */
	private void updateProjectScm(ProjectPK id, String gitRepo) {
		Project current = projectService.findById(id);
		if (!gitRepo.equals(current.getGitRepo())) {
			current.setGitRepo(gitRepo);
		}
	}

	/**
	 * Save Job after find that on Jenkins
	 * @param id 
	 * 
	 * @param id
	 * @return Job
	 */
	private Job saveJob(JobPK id, JobJenkinsVO job) {
		Job j = new Job();
		j.setId(id);
		j.setName(job.getDisplayName());
		return jobService.save(j);
	}

	/**
	 * Save Build after find that on Jenkins
	 * @param id 
	 * 
	 * @param id
	 * @return Build
	 */
	private Build saveBuild(BuildPK id, BuildJenkinsVO build) {
		Build b = new Build();
		b.setId(id);
		b.setCreatedAt(build.getTimestamp());
		b.setDescription(build.getDescription());
		b.setDuration(new Date(build.getDuration()));
		b.setEstimateDuration(new Date(build.getEstimatedDuration()));
		b.setResult(build.getResult());

		if (b.getResult() == null) {
			b.setPhase(JenkinsPhase.STARTED);
		} else if (b.getResult() == JenkinsResult.SUCCESS) {
			b.setPhase(JenkinsPhase.FINALIZED);
		} else {
			b.setPhase(JenkinsPhase.FAILED);
		}
		
		String logFile = jenkinsService.getLog(b.getId().getWallet(), b.getId().getProject(), b.getId().getJob(), b.getId().getId());
		if (logFile != null && logFile.contains("ERROR: Pipeline abortado por falha no Quality Gate: ERROR")) {
			b.setLocalError(LocalError.SONAR);
		}
		Build current = buildService.save(b);

		saveBuildLog(id, logFile);
		updateGitScm(id, build);
		if (build.getChangeSets() != null && !build.getChangeSets().isEmpty()) {
			saveChangeSets(id, build);
		} else {
			saveCommit(id, build);
		}
		
		return current;
	}

	private Commit saveChangeSets(BuildPK id, BuildJenkinsVO build) {
		Commit retorno = null;
		for (ItemJenkinsVO item : build.getChangeSets().get(0).getItems()) {
			Commit g = new Commit();
			g.setId(new CommitPK());
			g.getId().setCommit(item.getId());
			g.getId().setProject(id.getProject());
			g.getId().setWallet(id.getWallet());
			
			Commit current = commitService.findById(g.getId());
			if (current == null) {
				g.setAuthoredDate(item.getTimestamp());
				g.setAuthorEmail(item.getAuthorEmail());
				g.setAuthorName(item.getAuthor().getFullName());
				g.setCommittedDate(item.getTimestamp());
				g.setCommitterEmail(item.getAuthorEmail());
				g.setCommitterName(item.getAuthor().getFullName());
				g.setMessage(item.getComment());
				g.setTitle(item.getMsg());
				current = commitService.save(g);
				
				for (PathJenkinsVO path : item.getPaths()) {
					Path p = new Path();
					p.setId(new PathPK());
					p.getId().setCommit(item.getId());
					p.getId().setProject(id.getProject());
					p.getId().setWallet(id.getWallet());
					p.getId().setFile(path.getFile());
					p.setEditType(path.getEditType());
					pathService.save(p);
				}
			}
			ChangeSet c = new ChangeSet();
			c.setId(new ChangeSetPK());
			c.getId().setBuild(build.getNumber());
			c.getId().setCommit(item.getId());
			c.getId().setJob(id.getJob());
			c.getId().setProject(id.getProject());
			c.getId().setWallet(id.getWallet());
			changeSetService.save(c);
			
			if (retorno == null || retorno.getCommittedDate().before(current.getCommittedDate())) {
				retorno = current;
			}
		}
		return retorno;
	}

	private Commit saveCommit(BuildPK id, BuildJenkinsVO build) {
		Commit retorno = null;
		for(ActionJenkinsVO action : build.getActions()) {
			if (action != null && action.getLastBuiltRevision() != null
					&& action.getLastBuiltRevision().getBranch() != null
					&& !action.getLastBuiltRevision().getBranch().isEmpty()
					&& action.getLastBuiltRevision().getBranch().get(0).getSha1() != null) {
				CommitPK commitId = new CommitPK();
				commitId.setWallet(id.getWallet());
				commitId.setProject(id.getProject());
				commitId.setCommit(action.getLastBuiltRevision().getBranch().get(0).getSha1());
				Commit current = commitService.findById(commitId);
				if (current == null) {
					CommitGitLabVO commit = gitLabService.getCommit(id.getWallet(), id.getProject(), commitId.getCommit());
					Commit c = new Commit();
					c.setId(commitId);
					c.setAuthoredDate(commit.getAuthoredDate());
					c.setAuthorEmail(commit.getAuthorEmail());
					c.setAuthorName(commit.getAuthorName());
					c.setCommittedDate(commit.getCommittedDate());
					c.setCommitterEmail(commit.getCommitterEmail());
					c.setCommitterName(commit.getCommitterName());
					c.setMessage(commit.getMessage());
					c.setTitle(commit.getTitle());
					current = commitService.save(c);
				}
				ChangeSetPK changeSetPK = new ChangeSetPK();
				changeSetPK.setBuild(build.getNumber());
				changeSetPK.setCommit(commitId.getCommit());
				changeSetPK.setJob(id.getJob());
				changeSetPK.setProject(id.getProject());
				changeSetPK.setWallet(id.getWallet());
				ChangeSet currentCS = changeSetService.findById(changeSetPK);
				if (currentCS == null) {
					ChangeSet c = new ChangeSet();
					c.setId(changeSetPK);
					changeSetService.save(c);
				}
				if (retorno == null || retorno.getCommittedDate().before(current.getCommittedDate())) {
					retorno = current;
				}
			}
		}
		return retorno;
	}

	/**
	 * Get Scm Repo GitLab
	 * @param buildId 
	 * 
	 * @param build
	 */
	private void updateGitScm(BuildPK buildId, BuildJenkinsVO build) {
		build.getActions().forEach(action -> {
			if (action != null && action.getRemoteUrls() != null
					&& !action.getRemoteUrls().isEmpty() && action.getRemoteUrls().get(0) != null) {
				ProjectPK projectId = new ProjectPK();
				projectId.setWallet(buildId.getWallet());
				projectId.setId(buildId.getProject());
				updateProjectScm(projectId, action.getRemoteUrls().get(0));
			}
		});
	}

	/**
	 * Update Build after find that on Jenkins
	 * @param id 
	 * 
	 * @param id
	 * @return Build
	 */
	private Build updateBuild(BuildPK id, BuildJenkinsVO build, JenkinsPhase phase) {
		Build current = buildService.findById(id);
		if (current != null) {
			current.setResult(build.getResult());
			current.setPhase(phase);
			current.setDescription(build.getDescription());
			String logFile = jenkinsService.getLog(current.getId().getWallet(), current.getId().getProject(), current.getId().getJob(), current.getId().getId());
			if (logFile != null && logFile.contains("ERROR: Pipeline abortado por falha no Quality Gate: ERROR")) {
				current.setLocalError(LocalError.SONAR);
			}
			updateBuildLog(id, logFile);
			updateGitScm(id, build);
			Commit commit = null;
			if (build.getChangeSets() != null && !build.getChangeSets().isEmpty()) {
				commit = saveChangeSets(id, build);
			} else {
				commit = saveCommit(id, build);
			}
			saveSonarMeasures(id, logFile, commit);
			return buildService.update(current);
		}
		throw new NotFoundException("Recurso não encontrado!");
	}

	private void saveSonarMeasures(BuildPK id, String logFile, Commit commit) {
		String keyJenkins = "";
		InfoSonarVO infoSonar = new InfoSonarVO();
		if(logFile != null){
			String[] lines = logFile.split("\n");
			for (String line : lines) {
				if(line.contains("Checking status of SonarQube task")){
					keyJenkins = line.substring(line.indexOf('\'')+1, line.indexOf('\'', line.indexOf('\'')+1));
					infoSonar = sonarService.getInfoSonar(keyJenkins);
					break;
				}
			}
		}
		
		Measures measure = measuresService.findById(id.getWallet(), id.getProject(), commit.getId().getCommit());
		QualityGateVO qualityGate = sonarService.getQualityGate(infoSonar.getTask().getAnalysisId());
		
		if(measure == null && qualityGate != null){
			if (!infoSonar.getTask().getComponentId().isEmpty() && commit != null) {
				SonarMeasureVO measuresSonarVO = sonarService.getMeasures(infoSonar.getTask().getComponentId());
				Measures measures = new Measures();
				measures.setId(new MeasuresPK());
				measures.getId().setWallet(id.getWallet());
				measures.getId().setProject(id.getProject());
				measures.getId().setCommit(commit.getId().getCommit());
				// Adicionar infos
				
				for (MeasureVO item : measuresSonarVO.getComponent().getMeasures()) {
					
					switch (item.getMetric()) {
					
					case "complexity":
						if (item.getValue() != null) {
							measures.setComplexity(Integer.parseInt(item.getValue()));
						}
						break;
						
					case "lines":
						if (item.getValue() != null) {
							measures.setLines(Integer.parseInt(item.getValue()));
						}
						break;
						
					case "bugs":
						if (item.getValue() != null) {
							measures.setBugs(Integer.parseInt(item.getValue()));
						}
						break;
						
					case "vulnerabilities":
						if (item.getValue() != null) {
							measures.setVulnerabilities(Integer.parseInt(item.getValue()));
						}
						break;
						
					case "code_smells":
						if (item.getValue() != null) {
							measures.setCodeSmells(Integer.parseInt(item.getValue()));
						}
						break;
						
					case "coverage":
						if (item.getValue() != null) {
							measures.setCoverage(new BigDecimal(item.getValue()));
						}
						break;
						
					case "unit_tests":
						if (item.getValue() != null) {
							measures.setUnitTests(Integer.parseInt(item.getValue()));
						}
						break;
						
					case "duplicated_lines":
						if (item.getValue() != null) {
							measures.setDuplicatedLines(new BigDecimal(item.getValue()));
						}
						break;
						
					case "new_code_smells":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewCodeSmells(Integer.parseInt(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "new_coverage":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewCoverage(new BigDecimal(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "new_lines":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewLines(Integer.parseInt(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "new_vulnerabilities":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewVulnerabilities(Integer.parseInt(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "new_bugs":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewBugs(Integer.parseInt(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "comment_lines":
						if (item.getValue() != null) {
							measures.setCommentLines(new BigDecimal(item.getValue()));
						}
						break;
						
					case "comment_lines_density":
						if (item.getValue() != null) {
							measures.setCommentLinesPercent(new BigDecimal(item.getValue()));
						}
						break;
						
					case "duplicated_lines_density":
						if (item.getValue() != null) {
							measures.setDuplicatedLinesPercent(new BigDecimal(item.getValue()));
						}
						break;
						
					case "new_duplicated_lines":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewDuplicatedLines(new BigDecimal(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "new_duplicated_lines_density":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewDuplicatedLinesPercent(new BigDecimal(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "violations":
						if (item.getValue() != null) {
							measures.setViolations(Integer.parseInt(item.getValue()));
						}
						break;
						
					case "new_violations":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewViolations(Integer.parseInt(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "sqale_rating":
						if (item.getValue() != null) {
							measures.setSqaleRating(new BigDecimal(item.getValue()));
						}
						break;
						
					case "new_maintainability_rating":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewMaintainabilityRating(new BigDecimal(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "security_rating":
						if (item.getValue() != null) {
							measures.setSecurityRating(new BigDecimal(item.getValue()));
						}
						break;
						
					case "new_security_rating":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewSecurityRating(new BigDecimal(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "reliability_rating":
						if (item.getValue() != null) {
							measures.setReliabilityRating(new BigDecimal(item.getValue()));
						}
						break;
						
					case "new_reliability_rating":
						if (item.getPeriods().get(0).getValue() != null) {
							measures.setNewReliabilityRating(new BigDecimal(item.getPeriods().get(0).getValue()));
						}
						break;
						
					case "files":
						if (item.getValue() != null) {
							measures.setFiles(Integer.parseInt(item.getValue()));
						}
						break;
						
					default:
						break;
					}
				}
				
				measures.setQualityGate(qualityGate.getProjectStatus().getStatus());
				measures.setVersion(qualityGate.getProjectStatus().getPeriods().get(0).getParameter());
				measuresService.save(measures);
				qualityGateService.saveAll(id.getWallet(), id.getProject(), commit.getId().getCommit(), qualityGate);
				
			}
		}
	}

	private BuildLog saveBuildLog(BuildPK id, String logFile) {
		return buildLogService.save(buildBuildLog(id, logFile));
	}

	private BuildLog updateBuildLog(BuildPK id, String logFile) {
		BuildLog buildLog = buildBuildLog(id, logFile);
		BuildLog current = buildLogService.findById(buildLog.getId());
		if (!buildLog.getLog().equals(current.getLog())) {
			current = buildLogService.update(buildLog);
		}
		return current;
	}

	private BuildLog buildBuildLog(BuildPK id, String logFile) {
		BuildLog b = new BuildLog();
		b.setId(new BuildLogPK());
		b.getId().setWallet(id.getWallet());
		b.getId().setProject(id.getProject());
		b.getId().setJob(id.getJob());
		b.getId().setBuild(id.getId());
		b.setLog(logFile);
		return b;
	}

	/**
	 * Find Wallet on Jenkins by Id
	 * 
	 * @param id
	 * @return WalletJenkinsVO
	 */
	private WalletJenkinsVO findWallet(String id) {
		if (wallets == null) {
			wallets = jenkinsService.listWallets();
		}
		for(WalletJenkinsVO wallet: wallets) {
			if (wallet.getName().equals(id)) {
				return wallet;
			}
		}
		throw new IllegalArgumentException("Id " + id + " de Wallet Inválido!");
	}

	/**
	 * Find Project on Jenkins by Id
	 * 
	 * @param id
	 * @param wallet 
	 * @return ProjectJenkinsVO
	 */
	private ProjectJenkinsVO findProject(String wallet, String id) {
		if (projects == null) {
			projects = jenkinsService.listProjects(wallet);
		}
		for(ProjectJenkinsVO project: projects) {
			if (project.getName().equals(id)) {
				return project;
			}
		}
		throw new IllegalArgumentException("Id " + id + " de Project Inválido!");
	}

	/**
	 * Find Job on Jenkins by Id
	 * 
	 * @param id
	 * @param wallet
	 * @param project
	 * @return JobJenkinsVO
	 */
	private JobJenkinsVO findJob(String wallet, String project, String id) {
		if (jobs == null) {
			jobs = jenkinsService.listJobs(wallet, project);
		}
		for(JobJenkinsVO job: jobs) {
			if (job.getName().equals(id)) {
				return job;
			}
		}
		throw new IllegalArgumentException("Id " + id + " de Job Inválido!");
	}

	/**
	 * Find Build on Jenkins by Id
	 * 
	 * @param id
	 * @param wallet
	 * @param project
	 * @param job
	 * @return JobJenkinsVO
	 */
	private BuildJenkinsVO findBuild(String wallet, String project, String job, Integer id) {
		if (builds == null) {
			builds = jenkinsService.listBuilds(wallet, project, job);
		}
		for(BuildJenkinsVO build: builds) {
			if (build.getNumber().equals(id)) {
				return build;
			}
		}
		throw new IllegalArgumentException("Id " + id + " de Build Inválido!");
	}
}

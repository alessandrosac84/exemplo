package br.gov.caixa.api.model.views;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "especialidade_ferramenta_view")
public class EspecialidadeFerramentaView {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "FERRAMENTA")
	private String ferramenta;

	@Column(name = "RATING")
	private Integer rating;
	
	@Column(name = "ESPECIALIDADE_ID")
	private Long especialidadeId;
	
	@Column(name = "ESPECIALIDADE")
	private String especialidade;
	
	@Column(name = "ESPECIALIDADE_FERRAMENTA_ID")
	private Long especialidadeFerramentaId;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}
	
	public String getFerramenta() {
		return ferramenta;
	}

	public void setFerramenta(String ferramenta) {
		this.ferramenta = ferramenta;
	}

	public Long getEspecialidadeId() {
		return especialidadeId;
	}

	public void setEspecialidadeId(Long especialidadeId) {
		this.especialidadeId = especialidadeId;
	}
	
	public Long getEspecialidadeFerramentaId() {
		return especialidadeFerramentaId;
	}

	public void setEspecialidadeFerramentaId(Long especialidadeFerramentaId) {
		this.especialidadeFerramentaId = especialidadeFerramentaId;
	}
	
//	public static EspecialidadeFerramentaView fromDtoToEspecialidadeFerramentaView(EspecialidadeFerramentaViewDto dto) {
//		EspecialidadeFerramentaView especialidadeFerramentaView = new EspecialidadeFerramentaView();
//		
//		especialidadeFerramentaView.setUid(dto.getUid());
//		especialidadeFerramentaView.setFerramenta(dto.getFerramenta());
//		especialidadeFerramentaView.setEspecialidade(dto.getEspecialidade());
//		especialidadeFerramentaView.setEspecialidadeId(dto.getEspecialidadeId());
//		especialidadeFerramentaView.setEspecialidadeFerramentaId(dto.getEspecialidadeFerramentaId());
//		especialidadeFerramentaView.setRating(dto.getRating());
//		
//		
//		return especialidadeFerramentaView;
//	}
//	
//	public static List<EspecialidadeFerramentaView> fromDtoFerramentaToListEspecialidadeFerramenta(List<EspecialidadeFerramentaViewDto> especialidadeFerramentaViews) {
//		List<EspecialidadeFerramentaView> returnList = new ArrayList<EspecialidadeFerramentaView>();
//		
//		for (EspecialidadeFerramentaViewDto dto : especialidadeFerramentaViews) {		    						
//			returnList.add(fromDtoToEspecialidadeFerramentaView(dto));		}
//		
//		return returnList;
//	}	
}

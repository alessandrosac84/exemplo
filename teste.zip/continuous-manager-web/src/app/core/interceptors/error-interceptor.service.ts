import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';

import { Observable } from 'rxjs/Rx';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

    constructor(private toastr: ToastrService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (next.handle(req).do) {
            return next.handle(req).do(event => { }, error => {
                console.log(error.error);
                if (error instanceof HttpErrorResponse && error.status === 500) {
                    this.toastr.error(error.error.message, 'Ops!');
                }
                if (error instanceof HttpErrorResponse && error.status > 500) {
                    this.toastr.error(error.error.message, 'Ops!');
                }
                if (error instanceof HttpErrorResponse && error.status === 401) {
                    this.toastr.error('Login ou senha inválido!', 'Ops!');
                }
                if (error instanceof HttpErrorResponse && error.status === 403) {
                    this.toastr.error('Sessão inválida! Efetue um novo Login!', 'Ops!');
                }
            });
        }
        return next.handle(req).map(event => {
            return event;
        });
    }
}

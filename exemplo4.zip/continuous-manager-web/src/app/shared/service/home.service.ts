import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { CedesBuilds } from '../model/vo/cedesBuilds.model';
import { ProjectsBuildsStatus } from '../model/vo/projectsBuildsStatus';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

    constructor(private http: HttpClient) { }

    getCedesBuilds(): Observable<CedesBuilds[]> {
        return this.http.get<CedesBuilds[]>('../../../assets/file/cedes.json');
      }

    getProjectsBuildsStatus(): Observable<ProjectsBuildsStatus[]> {
        return this.http.get<ProjectsBuildsStatus[]>('../../../assets/file/projectsBuildsStatus.json');
      }
}



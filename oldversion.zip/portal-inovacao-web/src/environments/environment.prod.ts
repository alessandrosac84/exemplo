export const environment = {
  production: true,
  apiBaseUrl: '/portal-inovacao-api/api/',
  apiSharepointBaseUrl: 'https://guardiao.caixa/sharepoint-api/api/',
  hmr: false
};

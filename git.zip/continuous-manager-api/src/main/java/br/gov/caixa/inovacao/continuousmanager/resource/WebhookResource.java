/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.resource;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsPhase;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.PayloadNotificationJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.service.integration.WebhookService;

@Path("webhook")
@RequestScoped
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class WebhookResource {
	
	@Inject
	private Logger log;
	
	@Inject
	private WebhookService webhookService;
	
	@POST
	@JsonView(ViewJson.WebhookView.class)
	public Response createJobResource(String payload) {
		log.log(Level.SEVERE, "Payload :: {0}", payload);
		try {
			return createJob(new ObjectMapper().readValue(payload, PayloadNotificationJenkinsVO.class));
		} catch (IOException e) {
			log.log(Level.SEVERE, "Não foi possível realizar o Parse do Payload :: {0}", payload);
			throw new IllegalArgumentException("Não foi possível realizar o Parse do Payload");
		}
	}

	public Response createJob(PayloadNotificationJenkinsVO payload) {
		if (payload == null || payload.getBuild() == null) {
			throw new IllegalArgumentException("Informações Inválidas!");
		}
		log.log(Level.SEVERE, "Phase :: {0}", payload.getBuild().getPhase());
		String ip = HelperThreadLocal.IP.get();
		String username = HelperThreadLocal.USER.get();
		new Thread(() -> {
			synchronized (WebhookResource.class) {
				log.log(Level.SEVERE, "Phase :: {0}", payload.getBuild().getPhase());
	        	HelperThreadLocal.IP.set(ip);
	        	HelperThreadLocal.USER.set(username);
	        	if (HelperThreadLocal.USER.get() == null) {
	    			HelperThreadLocal.USER.set("@SKYNET");
	    		}
	        	//Everything is good. Response has been successfully
	        	if (payload.getBuild().getPhase() == null) {
	        		webhookService.add(payload.getBuild().getUrl().split("/"));
	        	} else if (payload.getBuild().getPhase() == JenkinsPhase.QUEUED) {
					webhookService.add(payload);
	        	} else {
					webhookService.update(payload);
				}
	        	log.log(Level.SEVERE, "End Phase :: {0}", payload.getBuild().getPhase());
			}
        	//dispatched to client
		}).start();
		return Response.ok().build();
	}
}

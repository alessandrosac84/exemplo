package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.FuncionarioQuestionanteOptions;

public class FuncionarioQuestionanteOptionsDto {

	private Long uid;	
	private String nome;	
	private String matricula;	
	private String cargo;	
	private Long questionanteId;	
	private Boolean participacao;	
	private Long questionarioId;	
	private String questao;
	private String option1;
	private String option2;
	private String option3;
		
	public Long getUid() {
		return uid;
	}


	public void setUid(Long uid) {
		this.uid = uid;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getMatricula() {
		return matricula;
	}


	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}


	public String getCargo() {
		return cargo;
	}


	public void setCargo(String cargo) {
		this.cargo = cargo;
	}


	public Long getQuestionanteId() {
		return questionanteId;
	}


	public void setQuestionanteId(Long questionanteId) {
		this.questionanteId = questionanteId;
	}


	public Boolean isParticipacao() {
		return participacao;
	}


	public void setParticipacao(Boolean participacao) {
		this.participacao = participacao;
	}


	public Long getQuestionarioId() {
		return questionarioId;
	}


	public void setQuestionarioId(Long questionarioId) {
		this.questionarioId = questionarioId;
	}


	public String getQuestao() {
		return questao;
	}


	public void setQuestao(String questao) {
		this.questao = questao;
	}

	public String getOption1() {
		return option1;
	}


	public void setOption1(String option1) {
		this.option1 = option1;
	}


	public String getOption2() {
		return option2;
	}


	public void setOption2(String option2) {
		this.option2 = option2;
	}


	public String getOption3() {
		return option3;
	}


	public void setOption3(String option3) {
		this.option3 = option3;
	}
	
	public static FuncionarioQuestionanteOptionsDto fromFuncionarioQuestionanteOptionsToDto(FuncionarioQuestionanteOptions funcionarioQuestionanteOptions) {
		FuncionarioQuestionanteOptionsDto dto = new FuncionarioQuestionanteOptionsDto();
		
		dto.setUid(funcionarioQuestionanteOptions.getUid());		
		dto.setNome(funcionarioQuestionanteOptions.getNome());
		dto.setMatricula(funcionarioQuestionanteOptions.getMatricula());
		dto.setCargo(funcionarioQuestionanteOptions.getCargo());	
		dto.setQuestionanteId(funcionarioQuestionanteOptions.getQuestionanteId());
		dto.setParticipacao(funcionarioQuestionanteOptions.isParticipacao());
		dto.setQuestionarioId(funcionarioQuestionanteOptions.getQuestionarioId());
		dto.setQuestao(funcionarioQuestionanteOptions.getQuestao());
		dto.setOption1(funcionarioQuestionanteOptions.getOption1());
		dto.setOption2(funcionarioQuestionanteOptions.getOption2());
		dto.setOption3(funcionarioQuestionanteOptions.getOption3());
		
		return dto;
	}

	public static List<FuncionarioQuestionanteOptionsDto> fromFuncionarioQuestionanteOptionsToListDto(List<FuncionarioQuestionanteOptions> funcionariosQuestionantes) {		
		List<FuncionarioQuestionanteOptionsDto> result = new ArrayList<FuncionarioQuestionanteOptionsDto>();		
		
		for (FuncionarioQuestionanteOptions funcionarioQuestionanteOptions : funcionariosQuestionantes) {						
			result.add(fromFuncionarioQuestionanteOptionsToDto(funcionarioQuestionanteOptions));
		}
		
		return result;
	}


}

package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-05-22T14:11:42.175-0300")
@StaticMetamodel(QualityGatePK.class)
public class QualityGatePK_ {
	public static volatile SingularAttribute<QualityGatePK, String> project;
	public static volatile SingularAttribute<QualityGatePK, String> wallet;
	public static volatile SingularAttribute<QualityGatePK, String> commit;
	public static volatile SingularAttribute<QualityGatePK, String> metricKey;
}

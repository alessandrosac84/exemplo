import { NgbModule, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { CommitBuild } from './../../shared/model/commit-build.model';
import { ChangeSet } from './../../shared/model/changeset.model';
import { Project } from './../../shared/model/project.model';
import { ViewCommitsBuilds } from './../../shared/model/view-commits-builds.model';
import { Commit } from './../../shared/model/commit.model';
import { Build } from './../../shared/model/build.model';
import { Job } from './../../shared/model/job.model';
import { JenkinsService } from './../../shared/service/jenkins.service';
import { Title } from '@angular/platform-browser';
import { Wallet } from './../../shared/model/wallet.model';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'jmw-release',
  templateUrl: './release.component.html',
  styleUrls: ['./release.component.scss']
})
export class ReleaseComponent implements OnInit {

  pageTitle = 'Release Manager';
  listaWallets: Wallet[] = [];
  listaProjects: Project[] = [];
  projectId: Project;
  walletId: Wallet;
  listaJobs: Job[] = [];
  listaBuilds: Build[] = [];
  listaCommits: Commit[] = [];
  listaViewTqs: ViewCommitsBuilds[] = [];
  jobId: Job;
  page: number;
  version: string;
  itemSelecionado: ViewCommitsBuilds;
  updated: Date;
  total: number;
  popup: boolean;
  closeResult: string;
  botaoVersion: boolean;

  @Output('destroy')
  destroy = new EventEmitter();

  statusBuildTqsLiberada: Boolean = false;

  constructor(private title: Title,
    private jenkinsService: JenkinsService, private modalService: NgbModal) {
  }

  ngOnInit() {
    this.title.setTitle(this.pageTitle);
    this.popup = false;
    this.botaoVersion = true;
    this.jenkinsService.getWallets().subscribe(data => {
      this.listaWallets = data;
    });
    this.page = 1;

    /*this.jenkinsService.getJSON().subscribe(data => {
       this.listaCommits = data;
     });*/
  }

  public chargeProjects() {
    this.listaProjects = [];
    this.projectId = undefined;
    this.jobId = undefined;
    if (!!this.walletId) {
      this.jenkinsService.getProjects(this.walletId.id).subscribe(data => {
        this.listaProjects = data;
      });
    }
  }

  public chargeJobs() {
    this.listaJobs = [];
    this.jobId = undefined;
    if (!!this.projectId) {
      this.jenkinsService.getJobs(this.walletId.id, this.projectId.id.id).subscribe(data => {
        this.listaJobs = data;
      });
    }
  }

  public chargeChangeSets() {
    this.listaViewTqs = [];
    if (!!this.jobId) {
      this.jenkinsService.getChangeSets(this.walletId.id, this.projectId.id.id, this.jobId.id.id, this.page).subscribe((res: any) => {
        console.log(res);

        res.body.forEach(commit => {
          const item: ViewCommitsBuilds = new ViewCommitsBuilds;
          item.id_commit = commit.id.commit;
          item.id_short_commit = commit.id.commit.substring(0, 8);
          item.author_commit = commit.gitRepo.authorName;
          item.author_email_commit = commit.gitRepo.authorEmail;
          item.message_commit = commit.gitRepo.title.substring(0, 25) + '...';
          item.versao_release_build = null;
          item.build_number = commit.id.build;
          item.build_result = commit.build.result;

          const dateCommitString = commit.gitRepo.committedDate;
          const dateCommitDate = new Date(dateCommitString);
          item.committed_date_commit = dateCommitDate;

          if (this.listaViewTqs.length === 0) {
            item.list_view_builds = [];
            item.list_view_builds.push(this.addItemBuild(commit));
            this.listaViewTqs.push(item);
          } else {
            let found: ViewCommitsBuilds;
            this.listaViewTqs.forEach(i => {
              if (i.id_short_commit === item.id_short_commit) {
                found = i;
              }
            });
            if (found) {
              if (found.list_view_builds) {
                found.list_view_builds.push(this.addItemBuild(commit));
              }
            } else {
              item.list_view_builds = [];
              item.list_view_builds.push(this.addItemBuild(commit));
              this.listaViewTqs.push(item);
            }
          }
        });
        this.total = res.headers.get('Content-Range').substring(res.headers.get('Content-Range').indexOf('/') + 1);
        this.updated = new Date();
      });
    }
  }

  public addItemBuild(commit: ChangeSet) {
    const commitBuild = new CommitBuild;
    commitBuild.build = commit.id.build;
    commitBuild.commit = commit.id.commit;
    commitBuild.result = commit.build.result;
    const dataBuild = new Date(commit.build.createdAt);
    commitBuild.data_hora_build = dataBuild;

    return commitBuild;
  }

  public confirmRebuild(version: string) {
    if (version) {
      this.jenkinsService.version(this.walletId.id, this.projectId.id.id, this.jobId.id.id,
        this.itemSelecionado.id_commit, version).subscribe(data => {
        });
      console.log('teste');
    } else {
      console.log('informe a versão');
    }
  }

  public guardaItem(itemCommit: ViewCommitsBuilds, content) {
    if (itemCommit) {
      this.itemSelecionado = itemCommit;
      this.open(content);
    }
  }

  pageChanged(event) {
    if ((this.updated.getTime() + 500) < new Date().getTime()) {
      this.page = event;
      this.chargeChangeSets();
    }
  }

  open(content) {
    this.modalService.open(content, { centered: true, size: 'sm' }).result.then((result) => {
      this.closeResult = `Closed with: $(result)`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  disableConfirmar($event) {
    if ($event === '') {
      this.botaoVersion = true;
    } else {
      this.botaoVersion = false;
    }
  }
}

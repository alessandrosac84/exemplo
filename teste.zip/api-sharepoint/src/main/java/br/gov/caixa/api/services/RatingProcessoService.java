package br.gov.caixa.api.services;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.RatingProcessoDto;
import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.Processo;
import br.gov.caixa.api.model.RatingProcesso;
import br.gov.caixa.api.repository.ProcessoRepository;
import br.gov.caixa.api.repository.FuncionarioRepository;
import br.gov.caixa.api.repository.RatingProcessoRepository;
import br.gov.caixa.api.result.RatingProcessoResult;

@Named
public class RatingProcessoService {

	@Inject
	RatingProcessoRepository repository;

	@Inject
	ProcessoRepository ProcessoRepository;
	
	@Inject
	FuncionarioRepository funcionarioRepository;

	public RatingProcessoResult listByFuncionario(Long idFuncionario) {

		RatingProcessoResult result = new RatingProcessoResult();
		try {
			//Obtem funcionario
			Funcionario funcionario = funcionarioRepository.findOne(idFuncionario);
			
			//obtem todas Processos
			List<Processo> ProcessosNovas = ProcessoRepository.findAllAtivas();
			
			//Transforma Processos com ratings zerado
			List<RatingProcesso> Processos = RatingProcesso.fromProcessoToListRatingProcesso(ProcessosNovas, funcionario);
			
			//obtem as Processos com rating
			List<RatingProcesso> ratingProcessos = repository.findByFuncionario(idFuncionario);
			
			//Faz merge das Processos novas com as que j� existem rating
			ratingProcessos = generateListProcessos(Processos, ratingProcessos);
			
			//Salva as Processos para gerar o id
			repository.save(ratingProcessos);
			
			//Obt�m as Processos com rating com seus respectivos IDS gerados
			ratingProcessos = repository.findByFuncionario(idFuncionario);
			
			if (ratingProcessos != null) {
				result.setList(RatingProcessoDto.fromRatingProcessoToListDto(ratingProcessos));
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhum rating nas Processo para esse usu�rio.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}

	private List<RatingProcesso> generateListProcessos(List<RatingProcesso> Processos, List<RatingProcesso> ratingProcessos) {
		List<RatingProcesso> mergedRating = null;
		boolean isExiste = false;
		if(Processos.size() > ratingProcessos.size()){
			mergedRating = new ArrayList<RatingProcesso>();
			for (RatingProcesso Processo : Processos) {
				for (RatingProcesso ratingProcesso : ratingProcessos) {
					if(Processo.getProcesso().getUid().equals(ratingProcesso.getProcesso().getUid())){
						isExiste = true;
						mergedRating.add(ratingProcesso);
					}
				}
				
				if(!isExiste){
					mergedRating.add(Processo);					
				}
				isExiste = false;
			}
		}
		return mergedRating;
	}
	
	public void save(RatingProcessoDto dto){
		RatingProcesso ratingProcesso = RatingProcesso.fromDtoToRatingProcesso(dto);
		repository.save(ratingProcesso);
	}
}

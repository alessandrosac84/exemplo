package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity_;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-27T11:48:10.522-0300")
@StaticMetamodel(BranchInstance.class)
public class BranchInstance_ extends AuditedEntity_ {
	public static volatile SingularAttribute<BranchInstance, BranchInstancePK> id;
	public static volatile SingularAttribute<BranchInstance, Boolean> automaticDeploy;
	public static volatile SingularAttribute<BranchInstance, ProjectBranch> projectBranch;
	public static volatile SingularAttribute<BranchInstance, Instance> instance;
}

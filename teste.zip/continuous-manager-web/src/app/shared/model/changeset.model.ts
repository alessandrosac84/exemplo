import { GitRepo } from './gitrepo.model';
import { Build } from './build.model';

export class ChangeSet {
    public id: { project: string, wallet: string, job: string, build: number, commit: string };
    public gitRepo: GitRepo;
    public build: Build;
}

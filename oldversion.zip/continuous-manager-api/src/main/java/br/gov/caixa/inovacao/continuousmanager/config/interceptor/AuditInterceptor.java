/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.interceptor;

import java.util.Calendar;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;
import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Action;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Audit;
import br.gov.caixa.inovacao.continuousmanager.service.AuditService;
import br.gov.caixa.inovacao.continuousmanager.util.Util;

/**
 * @author Fabio Iwakoshi
 *
 */
public class AuditInterceptor {

	@PrePersist
	public void onPrePersist(AuditedEntity entity) {
		if (entity.getCreatedAt() == null) {
			entity.setCreatedAt(Calendar.getInstance());
		}
		entity.setUserInsert(HelperThreadLocal.USER.get());
	}

	@PreUpdate
	@PreRemove
	public void onPreUpdateRemove(AuditedEntity entity) {
		entity.setUpdatedAt(Calendar.getInstance());
		entity.setUserUpdate(HelperThreadLocal.USER.get());
	}

	@PostPersist
	public void onPostPersist(AuditedEntity entity)
			throws JsonProcessingException, IllegalAccessException, NamingException {
		saveAuditoria(createAuditoria(Action.INCLUIR, entity));
	}

	@PostUpdate
	public void onPostUpdate(AuditedEntity entity)
			throws JsonProcessingException, IllegalAccessException, NamingException {
		saveAuditoria(createAuditoria(Action.ALTERAR, entity));
	}

	@PostRemove
	public void onPostRemove(AuditedEntity entity)
			throws JsonProcessingException, IllegalAccessException, NamingException {
		saveAuditoria(createAuditoria(Action.EXCLUIR, entity));
	}

	private Audit createAuditoria(Action acao, AuditedEntity entity)
			throws JsonProcessingException, IllegalAccessException {
		Audit auditoria = new Audit();
		auditoria.setAction(acao);
		auditoria.setFunctionality(entity.getClass().getSimpleName().replaceAll("([a-z])([A-Z])", "$1 $2"));
		auditoria.setEntity(new ObjectMapper().writeValueAsString(Util.fixEntity(entity)));
		auditoria.setUserEvent(HelperThreadLocal.USER.get());
		auditoria.setTimestampEvent(Calendar.getInstance());
		auditoria.setIpEvent(HelperThreadLocal.IP.get());

		return auditoria;
	}

	private void saveAuditoria(Audit audit) throws NamingException {
		InitialContext.<AuditService>doLookup("java:comp/AuditService").save(audit);
	}
}

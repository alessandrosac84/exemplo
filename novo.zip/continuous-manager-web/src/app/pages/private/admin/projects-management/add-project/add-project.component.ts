import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatDialog, MatDialogConfig } from '@angular/material';
import { WalletService } from '../../../../../shared/service/wallet.service';
import { Wallet } from '../../../../../shared/model/entity/wallet.model';
import { Repository } from '../../../../../shared/model/entity/repository.model';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AddRepositoryComponent } from './add-repository/add-repository.component';

@Component({
  selector: 'cm-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.scss']
})
export class AddProjectComponent implements OnInit {

  wallets: Wallet[];
  walletSelected: Wallet;
  listRepositories: Repository[];
  lengthList: number;
  displayedColumns: string[] = [
    'name'
  ];

  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;

  constructor(private _walletService: WalletService, private _formBuilder: FormBuilder, public dialog: MatDialog) {}

  ngOnInit() {
    this._walletService.getWallets().subscribe(data => this.wallets = data);

    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });

    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });

    this.thirdFormGroup = this._formBuilder.group({
      thirdCtrl: ['', Validators.required]
    });
  }

  openAddRepository() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;

    const dialogRef = this.dialog.open(AddRepositoryComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(result => {
      console.log('result ' + result);
      if (this.listRepositories === undefined) {
        this.listRepositories = [];
        this.listRepositories.push(result);
      } else {
        this.listRepositories.push(result);
      }
    });
    }
}

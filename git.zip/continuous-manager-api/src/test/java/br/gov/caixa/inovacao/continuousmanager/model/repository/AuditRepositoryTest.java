/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Audit;

/**
 * Classe de testes de AuditRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class AuditRepositoryTest {
	
	@Mock
	private EntityManager em;

	@InjectMocks
	private AuditRepository auditRepository;
	
	private List<Audit> audits;

	@Before
	public void before() {
		audits = new ArrayList<Audit>();
		Audit audit = new Audit();
		audit.setId(1L);
		audits.add(audit);
	}

	@Test
	public void testSave() {
		// Act
		Audit save = auditRepository.save(audits.get(0));
		// Then
		Assert.assertEquals(audits.get(0).getId(), save.getId());
	}

}

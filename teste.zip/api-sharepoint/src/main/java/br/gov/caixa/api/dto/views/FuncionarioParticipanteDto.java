package br.gov.caixa.api.dto.views;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.StatusParticipante;
import br.gov.caixa.api.model.views.FuncionarioParticipante;

public class FuncionarioParticipanteDto {

	private Long uid;	
	private String nome;
	private String email;
	private String matricula;	
	private String cargo;	
	private Long turmaId;	
	private Boolean participacao;	
	private Long participanteId;	
	private StatusParticipante statusParticipante;
	
	public Long getUid() {
		return uid;
	}


	public void setUid(Long uid) {
		this.uid = uid;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getMatricula() {
		return matricula;
	}


	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}


	public String getCargo() {
		return cargo;
	}


	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	
		
	public Long getTurmaId() {
		return turmaId;
	}


	public void setTurmaId(Long turmaId) {
		this.turmaId = turmaId;
	}


	public Boolean getParticipacao() {
		return participacao;
	}


	public void setParticipacao(Boolean participacao) {
		this.participacao = participacao;
	}


	public Long getParticipanteId() {
		return participanteId;
	}


	public void setParticipanteId(Long participanteId) {
		this.participanteId = participanteId;
	}


	public StatusParticipante getStatusParticipante() {
		return statusParticipante;
	}


	public void setStatusParticipante(StatusParticipante statusParticipante) {
		this.statusParticipante = statusParticipante;
	}


	public static FuncionarioParticipanteDto fromFuncionarioParticipanteToDto(FuncionarioParticipante funcionarioParticipante) {
		FuncionarioParticipanteDto dto = new FuncionarioParticipanteDto();
		
		dto.setUid(funcionarioParticipante.getUid());		
		dto.setNome(funcionarioParticipante.getNome());
		dto.setEmail(funcionarioParticipante.getEmail());
		dto.setMatricula(funcionarioParticipante.getMatricula());
		dto.setCargo(funcionarioParticipante.getCargo());	
		dto.setTurmaId(funcionarioParticipante.getTurmaId());
		dto.setParticipacao(funcionarioParticipante.getParticipacao());
		dto.setParticipanteId(funcionarioParticipante.getParticipanteId());
		dto.setStatusParticipante(funcionarioParticipante.getStatusParticipante());
		
		return dto;
	}

	public static List<FuncionarioParticipanteDto> fromFuncionarioParticipanteToListDto(List<FuncionarioParticipante> funcionariosParticipantes) {		
		List<FuncionarioParticipanteDto> result = new ArrayList<FuncionarioParticipanteDto>();		
		
		for (FuncionarioParticipante funcionarioParticipante : funcionariosParticipantes) {						
			result.add(fromFuncionarioParticipanteToDto(funcionarioParticipante));
		}
		
		return result;
	}


}

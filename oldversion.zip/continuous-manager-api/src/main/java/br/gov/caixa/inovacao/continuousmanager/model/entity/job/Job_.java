package br.gov.caixa.inovacao.continuousmanager.model.entity.job;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-15T10:35:00.354-0300")
@StaticMetamodel(Job.class)
public class Job_ extends AuditedEntity_ {
	public static volatile SingularAttribute<Job, JobPK> id;
	public static volatile SingularAttribute<Job, String> name;
	public static volatile SetAttribute<Job, Build> builds;
	public static volatile SingularAttribute<Job, Project> project;
}

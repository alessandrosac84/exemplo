package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.deser.std.DateDeserializers.DateDeserializer;
import com.fasterxml.jackson.databind.ser.std.DateSerializer;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;


/**
 * The persistent class for the build database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name="build")
@NamedQuery(name="Build.findAll", query="SELECT b FROM Build b")
public class Build implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonView({ViewJson.BuildView.class, ViewJson.ChangeSetView.class})
	private BuildPK id;

	@Temporal(TemporalType.TIMESTAMP)
	@JsonView({ViewJson.BuildView.class, ViewJson.ChangeSetView.class})
	@Column(name="created_at", nullable=false)
	private Calendar createdAt;

	@JsonView(ViewJson.BuildView.class)
	@Column(nullable=false, length=200)
	private String description;

	@Temporal(TemporalType.TIME)
	@JsonSerialize(using = DateSerializer.class)
    @JsonDeserialize(using = DateDeserializer.class)
	@JsonView(ViewJson.BuildView.class)
	@Column(nullable=false)
	private Date duration;

	@Temporal(TemporalType.TIME)
	@JsonSerialize(using = DateSerializer.class)
    @JsonDeserialize(using = DateDeserializer.class)
	@JsonView(ViewJson.BuildView.class)
	@Column(name="estimate_duration", nullable=false)
	private Date estimateDuration;
	
	@Enumerated(EnumType.STRING)
	@JsonView(ViewJson.BuildView.class)
	@Column(name="local_error", length=10)
	private LocalError localError;

	@Enumerated(EnumType.STRING)
	@JsonView({ViewJson.BuildView.class, ViewJson.ChangeSetView.class})
	@Column(length=9)
	private JenkinsResult result;

	@Enumerated(EnumType.STRING)
	@JsonView(ViewJson.BuildView.class)
	@Column(length=9)
	private JenkinsPhase phase;

	//bi-directional many-to-one association to Job
	/*@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="job", referencedColumnName="id", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="project", referencedColumnName="project", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private Job job;*/

	//bi-directional many-to-many association to GitRepo
	@JsonView(ViewJson.BuildView.class)
	@OneToMany(mappedBy="build", fetch=FetchType.LAZY)
	private Set<ChangeSet> changeSets;

	//bi-directional many-to-many association to GitRepo
	/*@OneToMany(mappedBy="build", fetch=FetchType.LAZY)
	private Set<BuildLog> buildLogs;

	//bi-directional many-to-one association to ProjectEnvironment
	@OneToMany(mappedBy="build", fetch=FetchType.LAZY)
	private Set<ProjectEnvironment> projectEnvironments;*/

	public Build() {
		/* class constructor intentionally left blank */
	}

	public BuildPK getId() {
		return this.id;
	}

	public void setId(BuildPK id) {
		this.id = id;
	}

	public Calendar getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Calendar createdAt) {
		this.createdAt = createdAt;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDuration() {
		return this.duration;
	}

	public void setDuration(Date duration) {
		this.duration = duration;
	}

	public Date getEstimateDuration() {
		return this.estimateDuration;
	}

	public void setEstimateDuration(Date estimateDuration) {
		this.estimateDuration = estimateDuration;
	}

	public JenkinsResult getResult() {
		return this.result;
	}

	public void setResult(JenkinsResult result) {
		this.result = result;
	}

	/*public Job getJob() {
		return this.job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public Set<BuildLog> getBuildLogs() {
		return this.buildLogs;
	}

	public void setBuildLogs(Set<BuildLog> buildLogs) {
		this.buildLogs = buildLogs;
	}*/

	public Set<ChangeSet> getChangeSets() {
		return this.changeSets;
	}

	public void setChangeSets(Set<ChangeSet> changeSet) {
		this.changeSets = changeSet;
	}

	/*public Set<ProjectEnvironment> getProjectEnvironments() {
		return this.projectEnvironments;
	}

	public void setProjectEnvironments(Set<ProjectEnvironment> projectEnvironments) {
		this.projectEnvironments = projectEnvironments;
	}

	public ProjectEnvironment addProjectEnvironment(ProjectEnvironment projectEnvironment) {
		getProjectEnvironments().add(projectEnvironment);
		projectEnvironment.setBuild(this);

		return projectEnvironment;
	}

	public ProjectEnvironment removeProjectEnvironment(ProjectEnvironment projectEnvironment) {
		getProjectEnvironments().remove(projectEnvironment);
		projectEnvironment.setBuild(null);

		return projectEnvironment;
	}*/

	/**
	 * @return the localError
	 */
	public LocalError getLocalError() {
		return localError;
	}

	/**
	 * @param localError the localError to set
	 */
	public void setLocalError(LocalError localError) {
		this.localError = localError;
	}

	/**
	 * @return the phase
	 */
	public JenkinsPhase getPhase() {
		return phase;
	}

	/**
	 * @param phase the phase to set
	 */
	public void setPhase(JenkinsPhase phase) {
		this.phase = phase;
	}

}
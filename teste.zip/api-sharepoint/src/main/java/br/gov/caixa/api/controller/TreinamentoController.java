package br.gov.caixa.api.controller;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.dto.TreinamentoDto;
import br.gov.caixa.api.result.TreinamentoResult;
import br.gov.caixa.api.services.TreinamentoService;

@RestController
public class TreinamentoController {
	
	@Inject
	private TreinamentoService service;
	
	@RequestMapping(value="/api/treinamento/save", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public TreinamentoResult save(@RequestBody TreinamentoDto treinamentoDto) {
		return service.save(treinamentoDto);
	}
	
	@RequestMapping(value="/api/treinamento/delete/{id}", method=RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public TreinamentoResult delete(@PathVariable Long id) {
		return service.delete(id);
	}
	
	@RequestMapping(value="/api/treinamento/get/{id}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public TreinamentoResult get(@PathVariable Long id) {
		return service.get(id);
	}
	
	@RequestMapping(value="/api/treinamento/getAll", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public TreinamentoResult get() {
		return service.getAll();
	}
	
	@RequestMapping(value="/api/treinamento/getAllAlfa", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public TreinamentoResult getAlfa() {
		return service.getAllAlfa();
	}

}

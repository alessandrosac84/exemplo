package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.ProfilePercentualPreenchimentoView;
import br.gov.caixa.api.result.BasicResult;

public class ProfilePercentualPreenchimentoViewResult extends BasicResult {
	private List<ProfilePercentualPreenchimentoView> list;
	private ProfilePercentualPreenchimentoView profilePercentualPreenchimentoView;

	public List<ProfilePercentualPreenchimentoView> getList() {
		return list;
	}

	public void setList(List<ProfilePercentualPreenchimentoView> list) {
		this.list = list;
	}

	public ProfilePercentualPreenchimentoView profilePercentualPreenchimentoView() {
		return profilePercentualPreenchimentoView;
	}

	public void setProfilePercentualPreenchimentoView(ProfilePercentualPreenchimentoView profilePercentualPreenchimentoView) {
		this.profilePercentualPreenchimentoView = profilePercentualPreenchimentoView;
	}
}
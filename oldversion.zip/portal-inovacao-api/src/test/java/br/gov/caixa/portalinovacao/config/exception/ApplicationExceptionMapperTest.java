package br.gov.caixa.portalinovacao.config.exception;

import javax.ws.rs.NotFoundException;
import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ApplicationExceptionMapperTest {

	@InjectMocks
	private ApplicationExceptionMapper applicationExceptionMapper;
	/**
	 * Test method for {@link br.gov.caixa.portalinovacao.config.exception.ApplicationExceptionMapper#toResponse(java.lang.Exception)}.
	 */
	@Test
	public void testToResponseNotFoundException() {
		Response response = applicationExceptionMapper.toResponse(new NotFoundException("Nada foi encontrado!"));
		ErrorEntity entity = (ErrorEntity) response.getEntity();

		Assert.assertEquals(404, entity.getStatus());
		Assert.assertEquals(0, entity.getCode());
		Assert.assertEquals("api/page-codes", entity.getLink());
		Assert.assertEquals("Nada foi encontrado!", entity.getMessage());
	}
	/**
	 * Test method for {@link br.gov.caixa.portalinovacao.config.exception.ApplicationExceptionMapper#toResponse(java.lang.Exception)}.
	 */
	@Test
	public void testToResponseException() {
		applicationExceptionMapper.toResponse(new Exception("Exception!"));
	}


}

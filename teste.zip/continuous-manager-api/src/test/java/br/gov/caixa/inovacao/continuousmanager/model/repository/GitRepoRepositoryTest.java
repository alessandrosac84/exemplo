/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.GitRepo;

/**
 * Classe de testes de ChangeSetRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class GitRepoRepositoryTest {

	@Mock
	private EntityManager em;

	@InjectMocks
	private GitRepoRepository gitRepoRepository;

	private GitRepo gitRepo;

	@Before
	public void before() {
		gitRepo = null;//EntityBuilder.createProjects().get(0).getGitRepos().stream().findAny().get();
	}

	@Test
	public void testSave() {
		// Act
		GitRepo save = gitRepoRepository.save(gitRepo);
		// Then
		Assert.assertEquals(gitRepo.getId(), save.getId());
	}

}

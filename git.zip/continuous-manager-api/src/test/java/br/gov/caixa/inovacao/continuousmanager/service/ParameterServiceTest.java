/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.repository.ParameterRepository;
import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;
import br.gov.caixa.inovacao.continuousmanager.service.WalletService;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;

/**
 * Classe de testes do ParameterService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ParameterServiceTest {

	@Mock
	private JenkinsService jenkinsService;
	
	@Mock
	private ParameterRepository parameterRepository;

	@InjectMocks
	private ParameterService parameterService;
	
	private Parameter parameter;

	@Before
	public void before() {
		parameter = new Parameter();
		parameter.setId(new ParameterPK());
		parameter.getId().setEnvironment(Environment.DES);
		parameter.getId().setServerType(ServerType.JENKINS);
		parameter.setCredential("");
		parameter.setHost("https://jenkins.caixa");
		parameter.setPrincipal("jenkins");
		UtilReflection.setField(parameterService, "log", Logger.getLogger(WalletService.class.getName()));
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.service.ParameterService#findById(Environment)}.
	 */
	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(parameterRepository.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		Parameter retorno = parameterService.findById(parameter.getId());

		// Then
		Assert.assertEquals(Environment.DES, retorno.getId().getEnvironment());
		Assert.assertEquals(ServerType.JENKINS, retorno.getId().getServerType());
		Assert.assertEquals("", retorno.getCredential());
		Assert.assertEquals("https://jenkins.caixa", retorno.getHost());
		Assert.assertEquals("jenkins", retorno.getPrincipal());
	}

}

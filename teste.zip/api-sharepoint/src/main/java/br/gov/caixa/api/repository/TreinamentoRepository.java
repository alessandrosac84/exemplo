package br.gov.caixa.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.Treinamento;

public interface TreinamentoRepository extends JpaRepository<Treinamento, Long>  {
	
	@Query("select a from Treinamento a order by a.nome")
	List<Treinamento> findAllOrderByNome();

}

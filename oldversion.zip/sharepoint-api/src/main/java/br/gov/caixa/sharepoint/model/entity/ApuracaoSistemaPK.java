package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.*;
import javax.validation.constraints.Past;

/**
 * The primary key class for the apuracao_sistema database table.
 * 
 */
@Embeddable
public class ApuracaoSistemaPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Past
	@Temporal(TemporalType.TIMESTAMP)
	@Column(unique=true, nullable=false)
	private Calendar apuracao;

	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private Integer sistema;

	public ApuracaoSistemaPK() {
	}
	public Calendar getApuracao() {
		return this.apuracao;
	}
	public void setApuracao(Calendar apuracao) {
		this.apuracao = apuracao;
	}
	public Integer getSistema() {
		return this.sistema;
	}
	public void setSistema(Integer sistema) {
		this.sistema = sistema;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ApuracaoSistemaPK)) {
			return false;
		}
		ApuracaoSistemaPK castOther = (ApuracaoSistemaPK)other;
		return 
			this.apuracao.equals(castOther.apuracao)
			&& this.sistema.equals(castOther.sistema);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.apuracao.hashCode();
		hash = hash * prime + this.sistema.hashCode();
		
		return hash;
	}
}
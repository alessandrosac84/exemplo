/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.provider;

import java.lang.reflect.Member;
import java.util.logging.Logger;

import javax.enterprise.inject.spi.InjectionPoint;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * Classe de teste de LogProvider
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class LogProviderTest {
	
	@Mock
	private InjectionPoint injectionPoint;
	
	/**
	 * Test method for {@link br.gov.caixa.sharepoint.config.provider.LogProvider#produceLog(javax.enterprise.inject.spi.InjectionPoint)}.
	 */
	@Test
	public void testProduceLog() {
		// Arrange
		LogProvider logProvider = new LogProvider();
		Member member = this.getClass().getDeclaredMethods()[0];
		Mockito.when(injectionPoint.getMember()).thenReturn(member);
		
		// Act
		Logger produceLog = logProvider.produceLog(injectionPoint);
		
		// Then
		Assert.assertNotNull(produceLog);
	}

}

package br.gov.caixa.api.model.views;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "especialidade_atividade_view")
public class EspecialidadeAtividadeView {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "ATIVIDADE")
	private String atividade;

	@Column(name = "RATING")
	private Integer rating;
	
	@Column(name = "ESPECIALIDADE_ID")
	private Long especialidadeId;
	
	@Column(name = "ESPECIALIDADE")
	private String especialidade;
	
	@Column(name = "ESPECIALIDADE_ATIVIDADE_ID")
	private Long especialidadeAtividadeId;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}
	
	public String getAtividade() {
		return atividade;
	}

	public void setAtividade(String atividade) {
		this.atividade = atividade;
	}

	public Long getEspecialidadeId() {
		return especialidadeId;
	}

	public void setEspecialidadeId(Long especialidadeId) {
		this.especialidadeId = especialidadeId;
	}
	
	public Long getEspecialidadeAtividadeId() {
		return especialidadeAtividadeId;
	}

	public void setEspecialidadeAtividadeId(Long especialidadeAtividadeId) {
		this.especialidadeAtividadeId = especialidadeAtividadeId;
	}
	
	
}

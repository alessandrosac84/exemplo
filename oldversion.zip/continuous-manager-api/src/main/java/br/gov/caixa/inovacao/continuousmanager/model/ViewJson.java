package br.gov.caixa.inovacao.continuousmanager.model;

/**
 * @author Fabio Iwakoshi
 *
 */
public class ViewJson {
	
	private ViewJson() {}
	
	public static class WalletView {} //NOSONAR
	
	public static class ProjectView {} //NOSONAR
	
	public static class JobView {} //NOSONAR
	
	public static class BuildView {} //NOSONAR
	
	public static class CommitView {} //NOSONAR
	
	public static class LogStageView {} //NOSONAR
	
	public static class WebhookView {} //NOSONAR
	
	public static class SonarView {} //NOSONAR
	
	public static class ResultVO {} //NOSONAR
	
	public static class VersionProjectVO {} //NOSONAR
	
	public static class JenkisfileView {} //NOSONAR
}

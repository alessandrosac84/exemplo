export class CommitBuild {
    public build: number;
    public commit: string;
    public result: string;
    public data_hora_build: Date;
}

package br.gov.caixa.inovacao.continuousmanager.model.entity.job;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGate;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ProjectBranch;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-27T11:48:10.393-0300")
@StaticMetamodel(Project.class)
public class Project_ extends AuditedEntity_ {
	public static volatile SingularAttribute<Project, ProjectPK> id;
	public static volatile SingularAttribute<Project, String> gitRepo;
	public static volatile SingularAttribute<Project, String> name;
	public static volatile SingularAttribute<Project, String> sonarKey;
	public static volatile SingularAttribute<Project, Integer> ativoSharepoint;
	public static volatile SingularAttribute<Project, Wallet> wallet;
	public static volatile SetAttribute<Project, Commit> commits;
	public static volatile SetAttribute<Project, Job> jobs;
	public static volatile SetAttribute<Project, ProjectBranch> projectBranches;
	public static volatile SetAttribute<Project, QualityGate> qualityGates;
}

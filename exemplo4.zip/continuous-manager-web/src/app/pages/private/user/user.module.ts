import { NgModule } from '@angular/core';

import { UserRoutingModule } from './user-routing.module';
import { SharedModule } from '../../../shared/shared.module';

import { ProfileComponent } from './profile/profile.component';

@NgModule({
  imports: [
    SharedModule,
    UserRoutingModule,
  ],
  declarations: [ProfileComponent]
})
export class UserModule { }

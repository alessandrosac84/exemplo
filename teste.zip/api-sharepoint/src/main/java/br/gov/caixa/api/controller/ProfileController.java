package br.gov.caixa.api.controller;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.dto.ProfileDto;
import br.gov.caixa.api.dto.RatingAtividadeDto;
import br.gov.caixa.api.dto.RatingFerramentaDto;
import br.gov.caixa.api.dto.RatingProcessoDto;
import br.gov.caixa.api.result.ProfileResult;
import br.gov.caixa.api.result.RatingAtividadeResult;
import br.gov.caixa.api.result.RatingFerramentaResult;
import br.gov.caixa.api.result.RatingProcessoResult;
import br.gov.caixa.api.result.views.AtivosFuncionarioDetalhesViewResult;
import br.gov.caixa.api.result.views.AtivosPercentualConhecimentoViewResult;
import br.gov.caixa.api.result.views.ProfilePercentualPreenchimentoViewResult;
import br.gov.caixa.api.services.ProfileService;
import br.gov.caixa.api.services.RatingAtividadeService;
import br.gov.caixa.api.services.RatingFerramentaService;
import br.gov.caixa.api.services.RatingProcessoService;
import br.gov.caixa.api.services.views.AtivosFuncionarioDetalhesViewService;
import br.gov.caixa.api.services.views.AtivosPercentualConhecimentoViewService;
import br.gov.caixa.api.services.views.ProfilePercentualPreenchimentoViewService;

@RestController
public class ProfileController {
	
	@Inject
	ProfileService service;
	
	@Inject
	RatingAtividadeService serviceRating;
	
	@Inject
	RatingFerramentaService serviceRatingFerramenta;
	
	@Inject
	RatingProcessoService serviceRatingProcesso;
		
	@Inject
	ProfilePercentualPreenchimentoViewService profilePercentualPreenchimentoViewService;
	
	@Inject
	AtivosPercentualConhecimentoViewService ativosPercentualConhecimentoViewService;
	
	@Inject
	AtivosFuncionarioDetalhesViewService ativosFuncionarioDetalhesViewService;

	@RequestMapping(value="/api/profile/allPercent", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ProfilePercentualPreenchimentoViewResult listAllPercentuais() {
		
		return profilePercentualPreenchimentoViewService.listAll();
	}
	
	@RequestMapping(value="/api/profile/allAtivosConhecimentos", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public AtivosPercentualConhecimentoViewResult listAllAtivosConhecimento() {
		
		return ativosPercentualConhecimentoViewService.listAll();
	}	
	                             
	@RequestMapping(value="/api/profile/listFuncionariosAtivoNaoConheco/{tipo}/{ativoId}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public AtivosFuncionarioDetalhesViewResult listFuncionariosAtivoNaoConhceco(@PathVariable String tipo, @PathVariable Long ativoId) {
		
		return ativosFuncionarioDetalhesViewService.listFuncionariosAtivoNaoConheco(tipo, ativoId);
	}
	
	@RequestMapping(value="/api/profile/listFuncionariosAtivoQueroConhecer1/{tipo}/{ativoId}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public AtivosFuncionarioDetalhesViewResult listFuncionariosAtivoQueroConhecer1(@PathVariable String tipo, @PathVariable Long ativoId) {
		
		return ativosFuncionarioDetalhesViewService.listFuncionariosAtivoQueroConhecer1(tipo, ativoId);
	}
	
	@RequestMapping(value="/api/profile/listFuncionariosAtivoQueroConhecer2/{tipo}/{ativoId}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public AtivosFuncionarioDetalhesViewResult listFuncionariosAtivoQueroConhecer2(@PathVariable String tipo, @PathVariable Long ativoId) {
		
		return ativosFuncionarioDetalhesViewService.listFuncionariosAtivoQueroConhecer2(tipo, ativoId);
	}
	                                    
	@RequestMapping(value="/api/profile/listFuncionariosAtivoNaoMarcado/{tipo}/{ativoId}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public AtivosFuncionarioDetalhesViewResult listFuncionariosAtivoNaoMarcado(@PathVariable String tipo, @PathVariable Long ativoId) {
		
		return ativosFuncionarioDetalhesViewService.listFuncionariosAtivoNaoMarcado(tipo, ativoId);
	}
	
	@RequestMapping(value="/api/profile/listFuncionariosAtivoMaisConhecido/{tipo}/{ativoId}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public AtivosFuncionarioDetalhesViewResult listFuncionariosAtivoMaisConhecido(@PathVariable String tipo, @PathVariable Long ativoId) {
		
		return ativosFuncionarioDetalhesViewService.listFuncionariosAtivoMaisConhecido(tipo, ativoId);
	}
	
	@RequestMapping(value="/api/profile/salvarProfile", 
			method=RequestMethod.POST,
			consumes = "application/json",  
			produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ProfileResult salvarProfile(@RequestBody ProfileDto dto) {
		
		return service.salvar(dto);
	}
	
//	@RequestMapping(value="/api/profile/salvarProfileByFuncionario", 
//			method=RequestMethod.POST,
//			consumes = "application/json",  
//			produces = "application/json")
//	@ResponseStatus(HttpStatus.OK)
//	public ProfileResult salvarProfileByFuncionario(@RequestBody ProfileDto dto) {
//		
//		return service.salvarFuncionario(dto);
//	}
	
	@RequestMapping(value="/api/profile/listProfilePorIdFuncionario/{uid}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ProfileResult listOne(@PathVariable Long uid) {
		
		return service.listProfilePorFuncionario(uid);
	}
	
	@RequestMapping(value="/api/profile/listprofilePorId/{uid}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public ProfileResult listProfilePorId(@PathVariable Long uid) {
		
		return service.listOne(uid);
	}
	
	@RequestMapping(value = "/api/profile/obterRatingPorIdFuncionario/{idFuncionario}", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public RatingAtividadeResult listByFuncionario(@PathVariable Long idFuncionario) {
		return serviceRating.listByFuncionario(idFuncionario);
	}
	
	@RequestMapping(value = "/api/profile/obterRatingFerramentaPorIdFuncionario/{idFuncionario}", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public RatingFerramentaResult listFerramentaByFuncionario(@PathVariable Long idFuncionario) {
		return serviceRatingFerramenta.listByFuncionario(idFuncionario);
	}
	
	@RequestMapping(value = "/api/profile/obterRatingProcessoPorIdFuncionario/{idFuncionario}", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public RatingProcessoResult listProcessoByFuncionario(@PathVariable Long idFuncionario) {
		return serviceRatingProcesso.listByFuncionario(idFuncionario);
	}
	
	@RequestMapping(value = "/api/profile/salvarRating", method=RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public void saveRating(@RequestBody RatingAtividadeDto dto) {
		serviceRating.save(dto);
	}
	
	@RequestMapping(value = "/api/profile/salvarRatingFerramenta", method=RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public void saveRatingFerramenta(@RequestBody RatingFerramentaDto dto) {
		serviceRatingFerramenta.save(dto);
	}
	
	@RequestMapping(value = "/api/profile/salvarRatingProcesso", method=RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public void saveRatingProcesso(@RequestBody RatingProcessoDto dto) {
		serviceRatingProcesso.save(dto);
	}
	
	@RequestMapping(value="/api/profile/addTreinamentoInterno/{treinamento}/{funcionarioId}" , method=RequestMethod.POST, produces = "application/json")			
	@ResponseStatus(HttpStatus.OK)
	public int TreinamentoInterno(@PathVariable String treinamento, @PathVariable Long funcionarioId) {
		
		return service.addTreinamentoInterno(treinamento, funcionarioId);
		
	}
}




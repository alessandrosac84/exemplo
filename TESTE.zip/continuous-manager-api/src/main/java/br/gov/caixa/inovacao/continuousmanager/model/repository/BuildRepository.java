package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildPK_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Build_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet_;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.model.vo.ResultVO;

/**
 * Classe de acesso ao banco de dados da entidade Build.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class BuildRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Metodo responsavel pela consulta paginada de Builds no banco de dados
	 * 
	 * @param Build
	 * @return Build
	 */
	public Build findById(BuildPK id) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Build> query = builder.createQuery(Build.class);
		Root<Build> from = query.from(Build.class);
		from.fetch(Build_.changeSets, JoinType.LEFT).fetch(ChangeSet_.commit, JoinType.LEFT);

		Predicate predicate = builder.equal(from.get(Build_.id), id);

		return entityManager.createQuery(query.select(from).where(predicate)).getSingleResult();
	}

	/**
	 * Lista Builds por paginacao
	 * 
	 * @param offset
	 * @param limit
	 * @param search
	 * @param sort
	 * @param order
	 * @return Todos os Builds por paginacao
	 */
	public List<Build> findAll(String carteira, String projeto, String job, int offset, int limit, String search, // NOSONAR
			String sort, AscDesc order) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Build> query = builder.createQuery(Build.class);
		Root<Build> from = query.from(Build.class);
		from.fetch(Build_.changeSets, JoinType.LEFT).fetch(ChangeSet_.commit, JoinType.LEFT);

		Predicate predicate = builder.equal(from.get(Build_.id).get(BuildPK_.wallet), carteira);
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.project), projeto));
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.job), job));

		Order ascDesc = builder.asc(from.get(Build_.id).get(sort));
		if (order != AscDesc.ASC) {
			ascDesc = builder.desc(from.get(Build_.id).get(sort));
		}

		return entityManager.createQuery(query.select(from).distinct(true).where(predicate).orderBy(ascDesc))
				.setFirstResult(offset).setMaxResults(limit).getResultList();
	}

	/**
	 * Obtem o total de projetos
	 * 
	 * @param search
	 * @return Total de projetos
	 */
	public Long countAll(String carteira, String projeto, String job, String search) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);

		Root<Build> from = query.from(Build.class);

		Predicate predicate = builder.equal(from.get(Build_.id).get(BuildPK_.wallet), carteira);
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.project), projeto));
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.job), job));

		return entityManager.createQuery(query.select(builder.count(from)).where(predicate)).getSingleResult();
	}

	/**
	 * Metodo responsavel pela consulta paginada de Folders no banco de dados
	 * 
	 * @param environment
	 * @return Parameter
	 */
	public List<ResultVO> findBuildsById(String wallet, String project) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ResultVO> query = builder.createQuery(ResultVO.class);
		Root<Build> from = query.from(Build.class);

		Predicate predicate = builder.equal(from.get(Build_.id).get(BuildPK_.wallet), wallet);
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.project), project));

		return entityManager.createQuery(query.multiselect(from.get(Build_.result), builder.count(from))
				.where(predicate).groupBy(from.get(Build_.result))).getResultList();
	}

	/**
	 * Salva Build
	 * 
	 * @param Build
	 * @return Build
	 */
	public Build save(Build build) {
		entityManager.persist(build);
		return build;
	}

	/**
	 * Atualiza Build
	 * 
	 * @param build
	 * @return build
	 */
	public Build update(Build build) {
		return entityManager.merge(build);
	}
}

import { Build } from './build.model';

export class Job {
  id: { id: string, wallet: string, project: string };
  name: string;
  builds: Build[];
}

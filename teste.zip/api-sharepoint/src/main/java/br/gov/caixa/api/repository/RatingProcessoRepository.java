package br.gov.caixa.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.RatingProcesso;

public interface RatingProcessoRepository extends JpaRepository<RatingProcesso, Long> {
	
	@Query("select a from RatingProcesso a left join fetch a.processo b "
			+ "where a.funcionario.uid = ?1 "
			+ "and b.ativo = true "
			+ "order by a.processo.categoriaProcesso.nome, a.uid")
	public List<RatingProcesso> findByFuncionario(Long idFuncionario);
}

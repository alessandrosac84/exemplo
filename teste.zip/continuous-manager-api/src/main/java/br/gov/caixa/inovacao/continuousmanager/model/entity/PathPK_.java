package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-02-07T10:04:27.767-0200")
@StaticMetamodel(PathPK.class)
public class PathPK_ {
	public static volatile SingularAttribute<PathPK, String> commit;
	public static volatile SingularAttribute<PathPK, String> project;
	public static volatile SingularAttribute<PathPK, String> wallet;
	public static volatile SingularAttribute<PathPK, String> file;
}

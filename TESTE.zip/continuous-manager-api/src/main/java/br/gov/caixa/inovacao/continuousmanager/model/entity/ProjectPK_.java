package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-01-30T16:53:57.813-0200")
@StaticMetamodel(ProjectPK.class)
public class ProjectPK_ {
	public static volatile SingularAttribute<ProjectPK, String> id;
	public static volatile SingularAttribute<ProjectPK, String> wallet;
}

package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.gov.caixa.sharepoint.model.AuditedEntity;


/**
 * The persistent class for the ativo_interface database table.
 * 
 */
@Entity
@Table(name="ativo_interface")
@NamedQuery(name="AtivoInterface.findAll", query="SELECT a FROM AtivoInterface a")
public class AtivoInterface extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(nullable=false)
	private Boolean migrado;
	
	//bi-directional many-to-one association to Ativo
	@ManyToOne
	@JoinColumn(name="ativo", nullable=false, insertable=false, updatable=false)
	private Ativo ativo;
		
	//bi-directional many-to-one association to InterfaceServidor
	@ManyToOne
	@JoinColumn(name="interface_servidor", nullable=false)
	private InterfaceServidor interfaceServidor;

	//bi-directional many-to-one association to InterfaceServidor
//	@ManyToOne
//	@JoinColumn(name="interface_servidor", nullable=false)
//	private InterfaceServidor interfaceServidor2;

	//bi-directional many-to-one association to Instancia
	@OneToMany(mappedBy="ativoInterface")
	private Set<Instancia> instancias;

	public AtivoInterface() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getMigrado() {
		return this.migrado;
	}

	public void setMigrado(Boolean migrado) {
		this.migrado = migrado;
	}

	public InterfaceServidor getInterfaceServidor() {
		return this.interfaceServidor;
	}

	public void setInterfaceServidor(InterfaceServidor interfaceServidor) {
		this.interfaceServidor = interfaceServidor;
	}

	public Set<Instancia> getInstancias() {
		return this.instancias;
	}

	public void setInstancias(Set<Instancia> instancias) {
		this.instancias = instancias;
	}

	public Instancia addInstancia(Instancia instancia) {
		getInstancias().add(instancia);
		instancia.setAtivoInterface(this);

		return instancia;
	}

	public Instancia removeInstancia(Instancia instancia) {
		getInstancias().remove(instancia);
		instancia.setAtivoInterface(null);

		return instancia;
	}

	public Ativo getAtivo() {
		return ativo;
	}

	public void setAtivo(Ativo ativo) {
		this.ativo = ativo;
	}

}
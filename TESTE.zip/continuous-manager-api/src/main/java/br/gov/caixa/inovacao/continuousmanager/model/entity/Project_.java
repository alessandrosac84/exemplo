package br.gov.caixa.inovacao.continuousmanager.model.entity;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity_;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-05-22T14:16:04.053-0300")
@StaticMetamodel(Project.class)
public class Project_ extends AuditedEntity_ {
	public static volatile SingularAttribute<Project, ProjectPK> id;
	public static volatile SingularAttribute<Project, String> gitRepo;
	public static volatile SingularAttribute<Project, String> name;
	public static volatile SingularAttribute<Project, Integer> ativoSharepoint;
	public static volatile SetAttribute<Project, Commit> commits;
	public static volatile SetAttribute<Project, Job> jobs;
	public static volatile SingularAttribute<Project, Wallet> wallet;
}

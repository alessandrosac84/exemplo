package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the build database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name="Build_log")
@NamedQuery(name="BuildLog.findAll", query="SELECT b FROM BuildLog b")
public class BuildLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BuildLogPK id;

	@Column(nullable=false, columnDefinition = "TEXT")
	private String log;

	// bi-directional many-to-one association to Project
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "build", referencedColumnName = "id", nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "job", referencedColumnName = "job", nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "project", referencedColumnName = "project", nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "wallet", referencedColumnName = "wallet", nullable = false, insertable = false, updatable = false) })
	private Build build;

	public BuildLog() {
		/* class constructor intentionally left blank */
	}

	public BuildLogPK getId() {
		return this.id;
	}

	public void setId(BuildLogPK id) {
		this.id = id;
	}

	public String getLog() {
		return this.log;
	}

	public void setLog(String log) {
		this.log = log;
	}

	public Build getBuild() {
		return this.build;
	}

	public void setBuild(Build build) {
		this.build = build;
	}

}
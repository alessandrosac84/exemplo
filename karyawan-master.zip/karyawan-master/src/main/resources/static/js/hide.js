<script type="text/javascript">
    $("#password").password('toggle');
</script>
package br.gov.caixa.api.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.gov.caixa.api.dto.EspecialidadeFerramentaDto;

@Entity
@Table(name = "especialidade_ferramenta")
public class EspecialidadeFerramenta {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "rating")
	private Integer rating;

	@ManyToOne
	@JoinColumn(name = "ESPECIALIDADE_ID")
	private Especialidade especialidade;
	
	@ManyToOne
	@JoinColumn(name = "FERRAMENTA_ID")
	private Ferramenta ferramenta;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public Especialidade getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(Especialidade especialidade) {
		this.especialidade = especialidade;
	}
	
	public Ferramenta getFerramenta() {
		return ferramenta;
	}

	public void setFerramenta(Ferramenta ferramenta) {
		this.ferramenta = ferramenta;
	}
	
	public static EspecialidadeFerramenta fromDtoToEspecialidadeFerramenta(EspecialidadeFerramentaDto dto) {
		EspecialidadeFerramenta especialidadeFerramenta = new EspecialidadeFerramenta();
		
		especialidadeFerramenta.setUid(dto.getUid());
		especialidadeFerramenta.setRating(dto.getRating());
		especialidadeFerramenta.setEspecialidade(Especialidade.fromDtoToEspecialidade(dto.getEspecialidadeDto()));
		especialidadeFerramenta.setFerramenta(Ferramenta.fromDtoToFerramenta(dto.getFerramentaDto()));
		
		return especialidadeFerramenta;
	}
	
	public static List<EspecialidadeFerramenta> fromDtoFerramentaToListEspecialidadeFerramenta(List<EspecialidadeFerramentaDto> especialidadeFerramentas) {
		List<EspecialidadeFerramenta> returnList = new ArrayList<EspecialidadeFerramenta>();
		
		for (EspecialidadeFerramentaDto dto : especialidadeFerramentas) {		    						
			returnList.add(fromDtoToEspecialidadeFerramenta(dto));		
		}
		
		return returnList;
	}	
}

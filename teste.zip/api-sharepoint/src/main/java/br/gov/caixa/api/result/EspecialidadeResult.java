package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.EspecialidadeDto;

public class EspecialidadeResult extends BasicResult {
	private List<EspecialidadeDto> list;
	private EspecialidadeDto especialidade;

	public List<EspecialidadeDto> getList() {
		return list;
	}

	public void setList(List<EspecialidadeDto> list) {
		this.list = list;
	}

	public EspecialidadeDto getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(EspecialidadeDto especialidade) {
		this.especialidade = especialidade;
	}
}
import { Build } from '../entity/build.model';

export class ProjectsBuildsStatus {
    public name: string;
    public buildsStatus: {status: string, qtdBuilds: number};
}

package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-15T10:40:32.955-0300")
@StaticMetamodel(Instance.class)
public class Instance_ {
	public static volatile SingularAttribute<Instance, InstancePK> id;
	public static volatile SingularAttribute<Instance, Server> server;
	public static volatile SetAttribute<Instance, BranchInstance> branchInstances;
}

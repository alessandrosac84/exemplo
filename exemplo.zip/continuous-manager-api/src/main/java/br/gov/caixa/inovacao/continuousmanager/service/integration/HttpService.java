/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.net.ssl.SSLContext;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;

import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpProtocol;

/**
 * Classe de servicos do Jenkins.
 * 
 * @author Fabio IWakoshi
 *
 */
@Stateless
public class HttpService {

	private HttpService() {
	}

	private static Logger log = Logger.getAnonymousLogger();

	public static Response callHttp(HttpProtocol httpProtocol, String host, String path, String queryParam,
			String query, MultivaluedMap<String, Object> headers) {
		log.log(Level.FINE, "Chamando :: ", host);

		ClientBuilder builder = ClientBuilder.newBuilder();

		if (httpProtocol == HttpProtocol.HTTPS) {
			TrustStrategy trustStrategy = new TrustSelfSignedStrategy();
			SSLContext sslContext;
			try {
				sslContext = SSLContexts.custom().loadTrustMaterial(trustStrategy).build();
			} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
				log.log(Level.SEVERE, "Erro ao gerar certificado de acesso!", e);
				throw new ServiceUnavailableException("Erro ao acessar o servidor!");
			}
			
			builder = builder.hostnameVerifier(NoopHostnameVerifier.INSTANCE).sslContext(sslContext);
		}

		Builder request = builder.build().target(host).path(path).queryParam(queryParam, query)
				.request(MediaType.APPLICATION_JSON);

		if (headers != null) {
			request = request.headers(headers);
		}

		return request.get();
	}
}

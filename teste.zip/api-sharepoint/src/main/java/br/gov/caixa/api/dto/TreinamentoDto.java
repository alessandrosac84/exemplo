package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.IniciativaTreinamento;
import br.gov.caixa.api.model.TipoTreinamento;
import br.gov.caixa.api.model.Treinamento;

public class TreinamentoDto {

	private Long uid;
	private TipoTreinamento tipoTreinamento;
	private IniciativaTreinamento iniciativaTreinamento;
	private String nome;
	private String codigo;
	private String descricao;
	private Boolean autoInscricao;
	private AtividadeDto atividadeDto;
	private FerramentaDto ferramentaDto;
	private ProcessoDto processoDto;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}	

	public TipoTreinamento getTipoTreinamento() {
		return tipoTreinamento;
	}

	public void setTipoTreinamento(TipoTreinamento tipoTreinamento) {
		this.tipoTreinamento = tipoTreinamento;
	}
	
	public IniciativaTreinamento getIniciativaTreinamento() {
		return iniciativaTreinamento;
	}

	public void setIniciativaTreinamento(IniciativaTreinamento iniciativaTreinamento) {
		this.iniciativaTreinamento = iniciativaTreinamento;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public AtividadeDto getAtividadeDto() {
		return atividadeDto;
	}

	public void setAtividadeDto(AtividadeDto atividadeDto) {
		this.atividadeDto = atividadeDto;
	}
	
	public FerramentaDto getFerramentaDto() {
		return ferramentaDto;
	}

	public void setFerramentaDto(FerramentaDto ferramentaDto) {
		this.ferramentaDto = ferramentaDto;
	}
	
	public ProcessoDto getProcessoDto() {
		return processoDto;
	}

	public void setProcessoDto(ProcessoDto processoDto) {
		this.processoDto = processoDto;
	}	

	public Boolean getAutoInscricao() {
		return autoInscricao;
	}

	public void setAutoInscricao(Boolean autoInscricao) {
		this.autoInscricao = autoInscricao;
	}

	public static TreinamentoDto fromTreinamentoToDto(Treinamento treinamento) {
		TreinamentoDto dto = new TreinamentoDto();
		dto.setUid(treinamento.getUid());
		dto.setTipoTreinamento(treinamento.getTipoTreinamento());
		dto.setIniciativaTreinamento(treinamento.getIniciativaTreinamento());
		dto.setNome(treinamento.getNome());
		dto.setCodigo(treinamento.getCodigo());
		dto.setDescricao(treinamento.getDescricao());
		dto.setAutoInscricao(dto.getAutoInscricao());
	
		if(treinamento.getAtividade() != null){
			dto.setAtividadeDto(AtividadeDto.fromAtividadeToDto(treinamento.getAtividade()));
		}
		if(treinamento.getFerramenta() != null){
			dto.setFerramentaDto(FerramentaDto.fromFerramentaToDto(treinamento.getFerramenta()));
		}
		
		if(treinamento.getProcesso() != null){
			dto.setProcessoDto(ProcessoDto.fromProcessoToDto(treinamento.getProcesso()));
		}
		
		return dto;
	}

	public static List<TreinamentoDto> fromTreinamentoToListDto(List<Treinamento> listaTreinamento) {
		List<TreinamentoDto> listaResult = new ArrayList<TreinamentoDto>();
		for (Treinamento treinamento : listaTreinamento) {
			listaResult.add(fromTreinamentoToDto(treinamento));
		}
		return listaResult;
	}
}

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.repository.ChangeSetRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de servicos de ChangeSet.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class ChangeSetService {

	@Inject
	private Logger log;

	@Inject
	private ChangeSetRepository changeSetRepository;

	public ChangeSet save(@Valid ChangeSet changeSet) {
		log.log(Level.FINE, "Salvando ChangeSet :: {0}", changeSet.getId());
		return changeSetRepository.save(changeSet);
	}
	
	public List<ChangeSet> findAll(String wallet, String project, String job, int offset, int limit, String search, String sort, AscDesc order) { //NOSONAR
		log.log(Level.FINE,
				"Listando Builds : offset :: {0} :: limit :: {1} :: search :: {2} :: sort :: {3} :: order :: {4}",
				new Object[] { offset, limit, search, sort, order });
		return changeSetRepository.findAll(wallet, project, job, offset, limit, search, sort, order);
	}
	
	public Long countAll(String wallet, String project, String job, String search) {
		log.log(Level.FINE, "Contando ChangeSets: Carteira :: {0} :: Projeto {1} :: Job {2} :: Search :: {3}", new Object[] { wallet, project, job, search });
		return changeSetRepository.countAll(wallet, project, job, search);
	}
}

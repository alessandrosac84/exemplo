package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.model.views.EspecialidadeFerramentaView;
import br.gov.caixa.api.repository.views.EspecialidadeFerramentaViewRepository;
import br.gov.caixa.api.result.views.EspecialidadeFerramentaViewResult;

@Named
public class EspecialidadeFerramentaViewService {
	
	@Inject
	EspecialidadeFerramentaViewRepository repository;
	
	public EspecialidadeFerramentaViewResult listAll() {

		EspecialidadeFerramentaViewResult result = new EspecialidadeFerramentaViewResult();
		try {
			List<EspecialidadeFerramentaView> lista = repository.findAll();

			if (lista != null) {
				result.setList(lista);
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma especialidadeFerramentaView.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}
	
	public EspecialidadeFerramentaViewResult listEspecialidadeFerramentaViewsByIdEspecialidade(Long idEspecialidade) {
		EspecialidadeFerramentaViewResult result = new EspecialidadeFerramentaViewResult();
		try {
						
			List<EspecialidadeFerramentaView> lista = repository.findByEspecialidadeId(idEspecialidade);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Ferramenta para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

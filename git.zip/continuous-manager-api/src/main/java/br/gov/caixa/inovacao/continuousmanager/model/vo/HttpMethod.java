package br.gov.caixa.inovacao.continuousmanager.model.vo;

public enum HttpMethod {
	GET, POST, PUT, DELETE
}

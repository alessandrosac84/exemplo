package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpMethod;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpProtocol;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.InfoSonarVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.QualityGateVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.SonarMeasureVO;
import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;
import br.gov.caixa.inovacao.continuousmanager.service.integration.HttpService.IEntity;

/**
 * Classe de servicos do Sonar.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class SonarService {

	private String metricKeys = "accessors,new_technical_debt,blocker_violations,conditions_to_cover,new_it_conditions_to_cover,new_conditions_to_cover,bugs,"
			+ "burned_budget,business_value,class_complexity_distribution,classes,code_smells,cognitive_complexity,commented_out_code_lines,"
			+ "comment_lines,comment_lines_data,comment_lines_density,complexity,class_complexity,file_complexity,function_complexity,"
			+ "complexity_in_classes,complexity_in_functions,branch_coverage,new_it_branch_coverage,new_branch_coverage,conditions_by_line,"
			+ "confirmed_issues,coverage,new_it_coverage,coverage_line_hits_data,new_coverage,covered_conditions_by_line,critical_violations,"
			+ "last_commit_date,directories,duplicated_blocks,new_duplicated_blocks,duplicated_files,duplicated_lines,duplicated_lines_density,"
			+ "new_duplicated_lines,new_duplicated_lines_density,duplications_data,effort_to_reach_maintainability_rating_a,executable_lines_data,"
			+ "false_positive_issues,file_complexity_distribution,files,function_complexity_distribution,functions,generated_lines,generated_ncloc,"
			+ "info_violations,violations,it_conditions_to_cover,it_branch_coverage,it_conditions_by_line,it_coverage,it_coverage_line_hits_data,"
			+ "it_covered_conditions_by_line,it_line_coverage,it_lines_to_cover,it_uncovered_conditions,it_uncovered_lines,line_coverage,"
			+ "new_it_line_coverage,new_line_coverage,lines,ncloc,ncloc_language_distribution,new_lines,lines_to_cover,new_it_lines_to_cover,"
			+ "new_lines_to_cover,sqale_rating,new_maintainability_rating,major_violations,minor_violations,ncloc_data,new_blocker_violations,"
			+ "new_bugs,new_code_smells,new_critical_violations,new_info_violations,new_violations,new_major_violations,new_minor_violations,"
			+ "new_vulnerabilities,open_issues,overall_conditions_to_cover,new_overall_conditions_to_cover,overall_branch_coverage,new_overall_branch_coverage,"
			+ "overall_conditions_by_line,overall_coverage,overall_coverage_line_hits_data,new_overall_coverage,overall_covered_conditions_by_line,overall_line_coverage,"
			+ "vulnerabilities,new_security_rating,new_reliability_rating,reliability_rating,security_rating,tests";

	@Inject
	private Logger log;

	@Inject
	private ParameterService parameterService;

	/**
	 * Obtem as metricas de um projeto do sonar
	 * 
	 * @return
	 * 
	 * @return Lista de metricas
	 */
	public SonarMeasureVO getMeasures(String taskId) {
		log.fine("Obtendo Measures Sonar");
		try {
			Map<String, String> query = new HashMap<>();
			query.put("metricKeys", this.metricKeys);
			query.put("componentId", taskId);
			return callSonar(Environment.DES, HttpMethod.GET, "/api/measures/component", query, null,
					new TypeReference<SonarMeasureVO>() {
					});
		} catch (Exception e) {
			throw new ServiceUnavailableException("Erro ao obter métricas do Sonar!");
		}
	}
	
	/**
	 * Obtem as informações  de um projeto do sonar
	 * 
	 * @return
	 * 
	 * @return Lista de informações
	 */
	public InfoSonarVO getInfoSonar(String keySonar) {
		log.fine("Obtendo Informações Sonar");
		try {
			Map<String, String> query = new HashMap<>();
			query.put("id", keySonar);
			return callSonar(Environment.DES, HttpMethod.GET, "/api/ce/task", query, null,
					new TypeReference<InfoSonarVO>() {
					});
		} catch (Exception e) {
			throw new ServiceUnavailableException("Erro ao obter informações do Sonar!");
		}
	}
	
	/**
	 * Obtem quality gate de um projeto do sonar
	 * 
	 * @return
	 * 
	 * @return Lista de quality gate
	 */
	public QualityGateVO getQualityGate(String analysisId) {
		log.fine("Obtendo Quality Gate Sonar");
		try {
			Map<String, String> query = new HashMap<>();
			query.put("analysisId", analysisId);
			return callSonar(Environment.DES, HttpMethod.GET, "/api/qualitygates/project_status", query, null,
					new TypeReference<QualityGateVO>() {
					});
		} catch (Exception e) {
			throw new ServiceUnavailableException("Erro ao obter quality Gate do Sonar!");
		}
	}

	@SuppressWarnings("unchecked")
	private <T> T callSonar(Environment environment, HttpMethod httpMethod, String path, Map<String, String> queries,
			Entity<?> entity, TypeReference<T> typeReference) {

		ParameterPK parameterId = new ParameterPK();
		parameterId.setEnvironment(environment);
		parameterId.setServerType(ServerType.SONAR);

		Parameter parameter = parameterService.findById(parameterId);

		if (parameter == null) {
			throw new NotFoundException("Erro ao obter informações do Sonar!");
		}

		IEntity build = HttpService.httpProtocol(HttpProtocol.HTTP).httpMethod(httpMethod).host(parameter.getHost())
				.path(path).queries(queries).header("Authorization", parameter.getPrincipal());

		Response response = build.entity(entity).build();

		if (response.hasEntity() && response.getStatus() == 200) {
			try {
				String resposta = response.readEntity(String.class);
				if (typeReference.getType().getTypeName().equals("java.lang.String")) {
					return (T) resposta;
				}
				return new ObjectMapper().readValue(resposta, typeReference);
			} catch (IOException e) {
				log.log(Level.SEVERE, "Erro ao transformar informações do Sonar!", e);
				throw new ServiceUnavailableException("Erro ao obter informações do Sonar!");
			}
		} else if (response.getStatus() == 201 || response.getStatus() == 204) {
			return null;
		}
		throw new NotFoundException("Nenhuma informação encontrada!");
	}
}

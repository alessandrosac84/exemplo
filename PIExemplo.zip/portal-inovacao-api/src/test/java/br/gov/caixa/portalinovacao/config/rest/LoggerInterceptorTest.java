package br.gov.caixa.portalinovacao.config.rest;

import java.util.logging.Logger;

import javax.interceptor.InvocationContext;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.portalinovacao.UtilReflection;
import br.gov.caixa.portalinovacao.config.log.LoggerInterceptor;
import br.gov.caixa.portalinovacao.service.TransacaoService;

@RunWith(MockitoJUnitRunner.class)
public class LoggerInterceptorTest {

	/**
	 * Test method for {@link br.gov.caixa.portalinovacao.config.log.LoggerInterceptor#intercept(javax.interceptor.InvocationContext)}.
	 * @throws Exception 
	 */
	@Test
	public void testIntercept() throws Exception {
		InvocationContext invocationContext = Mockito.mock(InvocationContext.class);
		LoggerInterceptor loggerInterceptor = new LoggerInterceptor();

		Mockito.when(invocationContext.getTarget()).thenReturn(LoggerInterceptorTest.class);
		Mockito.when(invocationContext.getMethod()).thenReturn(LoggerInterceptorTest.class.getMethods()[0]);

		UtilReflection.setField(loggerInterceptor, "log", Logger.getLogger(TransacaoService.class.getName()));
		
		loggerInterceptor.intercept(invocationContext);
	}
	
	@Rule
	public ExpectedException expectedEx = ExpectedException.none();
	
	/**
	 * Test method for {@link br.gov.caixa.portalinovacao.config.log.LoggerInterceptor#intercept(javax.interceptor.InvocationContext)}.
	 * @throws Exception 
	 */
	@Test
	public void testInterceptException() throws Exception {
		// Expected
		expectedEx.expect(Exception.class);
		
		InvocationContext invocationContext = Mockito.mock(InvocationContext.class);
		LoggerInterceptor loggerInterceptor = new LoggerInterceptor();
		loggerInterceptor.intercept(invocationContext);
	}

}

package br.gov.caixa.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import br.gov.caixa.api.model.Siapp;

public interface SiappRepository extends JpaRepository<Siapp, Long> {

	public Siapp findByUid(Long uid);
	public Siapp findByCodigo(Long Codigo);
	public Siapp findBySistemaAndAlias(String sistema, String Alias);
	public List<Siapp> findBySistema(String sistema);
	
	public List<Siapp> findByCoordenacaoProjeto(String nomeCoordenacao);
	public List<Siapp> findByCoordenacaoProjetoAndEstadoNot(String nomeCoordenacao, String estado);
	
	@Modifying
	@Transactional
	@Query("update Siapp s set s.estado = ?1 ")
	int setEstadoNulo(String estado);
}

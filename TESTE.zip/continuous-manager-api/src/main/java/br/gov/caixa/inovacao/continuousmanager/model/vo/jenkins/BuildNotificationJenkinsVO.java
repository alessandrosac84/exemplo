package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;
import java.util.Calendar;

import com.fasterxml.jackson.annotation.JsonProperty;

import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsPhase;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsResult;

/**
 * Classe de representação do Build de Notificacao do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class BuildNotificationJenkinsVO implements Serializable {

	private static final long serialVersionUID = 3766818117030139597L;

	@JsonProperty("full_url")
	private String fullUrl;
	
	private Integer number;

	@JsonProperty("queue_id")
	private Integer queueId;
	
	private Calendar timestamp;
	
	private JenkinsPhase phase;
	
	private JenkinsResult status;
	
	private String url;
	
	private transient Object scm;
	
	private transient Object parameters;
	
	private String log;
	
	private transient Object artifacts;

	/**
	 * @return the fullUrl
	 */
	public String getFullUrl() {
		return fullUrl;
	}

	/**
	 * @param fullUrl the fullUrl to set
	 */
	public void setFullUrl(String fullUrl) {
		this.fullUrl = fullUrl;
	}

	/**
	 * @return the number
	 */
	public Integer getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(Integer number) {
		this.number = number;
	}

	/**
	 * @return the queueId
	 */
	public Integer getQueueId() {
		return queueId;
	}

	/**
	 * @param queueId the queueId to set
	 */
	public void setQueueId(Integer queueId) {
		this.queueId = queueId;
	}

	/**
	 * @return the timestamp
	 */
	public Calendar getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(Calendar timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the phase
	 */
	public JenkinsPhase getPhase() {
		return phase;
	}

	/**
	 * @param phase the phase to set
	 */
	public void setPhase(JenkinsPhase phase) {
		this.phase = phase;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the log
	 */
	public String getLog() {
		return log;
	}

	/**
	 * @param log the log to set
	 */
	public void setLog(String log) {
		this.log = log;
	}

	/**
	 * @return the status
	 */
	public JenkinsResult getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(JenkinsResult status) {
		this.status = status;
	}

	/**
	 * @return the scm
	 */
	public Object getScm() {
		return scm;
	}

	/**
	 * @param scm the scm to set
	 */
	public void setScm(Object scm) {
		this.scm = scm;
	}

	/**
	 * @return the parameters
	 */
	public Object getParameters() {
		return parameters;
	}

	/**
	 * @param parameters the parameters to set
	 */
	public void setParameters(Object parameters) {
		this.parameters = parameters;
	}

	/**
	 * @return the artifacts
	 */
	public Object getArtifacts() {
		return artifacts;
	}

	/**
	 * @param artifacts the artifacts to set
	 */
	public void setArtifacts(Object artifacts) {
		this.artifacts = artifacts;
	}
}

# Projeto de arquivos jenkins.

## Arquivo de pipeline

- Jenkinsfile-CI-DEV // Arquivo do Pipeline de Integração Contínua em Desenvolvimento
- Jenkinsfile-CI-TQS // Arquivo do Pipeline de Integração Contínua em TQS
- Jenkinsfile-CD-TQS // Arquivo do Pipeline de Entrega Contínua em TQS
package br.gov.caixa.api.repository.views;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.views.AtivosFuncionarioDetalhesView;

public interface AtivosFuncionarioDetalhesViewRepository extends JpaRepository<AtivosFuncionarioDetalhesView, Long> {
		
	@Query("select a from AtivosFuncionarioDetalhesView a where (a.tipo = ?1 and a.ativoId = ?2 and a.naoConheco is true)")
	public List<AtivosFuncionarioDetalhesView> findByTipoAndAtivoIdAndNaoConhecoNot(String tipo, Long ativoId);
	
	
	@Query("select a from AtivosFuncionarioDetalhesView a where (a.tipo = ?1 and a.ativoId = ?2 and a.queroConhecer is true)")
	public List<AtivosFuncionarioDetalhesView> findByTipoAndAtivoIdAndQueroConhecer1(String tipo, Long ativoId);
	
	@Query("select a from AtivosFuncionarioDetalhesView a where (a.tipo = ?1 and a.ativoId = ?2 and a.queroConhecer is true and a.rating = 0)")
	public List<AtivosFuncionarioDetalhesView> findByTipoAndAtivoIdAndQueroConhecer2(String tipo, Long ativoId);
	
	@Query("select a from AtivosFuncionarioDetalhesView a where (a.tipo = ?1 and a.ativoId = ?2 and a.naoConheco is false and a.queroConhecer is false and a.rating = 0)")
	public List<AtivosFuncionarioDetalhesView> findByTipoAndAtivoIdAndNaoMarcado(String tipo, Long ativoId);
	
	@Query("select a from AtivosFuncionarioDetalhesView a where (a.tipo = ?1 and a.ativoId = ?2 and a.rating > 0)")
	public List<AtivosFuncionarioDetalhesView> findByTipoAndAtivoIdAndMaisConhecido(String tipo, Long ativoId);

}

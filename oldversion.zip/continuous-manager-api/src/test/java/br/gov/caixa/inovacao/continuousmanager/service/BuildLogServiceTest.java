/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildLog;
import br.gov.caixa.inovacao.continuousmanager.model.repository.BuildLogRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.Stage;

/**
 * Classe de testes do Build Log Service.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BuildLogServiceTest {
	
	@Mock
	private BuildLogRepository buildLogRepository;
	
	@InjectMocks
	private BuildLogService buildLogService;
	
	private BuildLog buildLog;

	@Before
	public void before() {
		buildLog = EntityBuilder.createBuilds().get(0).getBuildLogs().stream().findFirst().get();
		UtilReflection.setField(buildLogService, "log", Logger.getLogger(BuildLogService.class.getName()));
	}
	
	/**
	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.service.BuildLogService#findById(java.lang.String, java.lang.String, java.lang.String, java.lang.Integer)}.
	 */
	@Test
	public void testFindById2() {
		// Arrange
		Mockito.when(buildLogRepository.findById(Mockito.any())).thenReturn(buildLog);
		// Act
		BuildLog bl = buildLogService.findById("inovacao", "continuous-manager-web", "continuous-manager-web-ci-dev", 2);
		// Then
		Assert.assertNotNull(bl);
	}

	/**
	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.service.BuildLogService#findById(br.gov.caixa.inovacao.continuousmanager.model.entity.BuildLogPK)}.
	 */
	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(buildLogRepository.findById(Mockito.any())).thenReturn(buildLog);
		// Act
		BuildLog bl = buildLogService.findById("inovacao", "continuous-manager-web", "continuous-manager-web-ci-dev", 2);
		// Then
		Assert.assertNotNull(bl.getLog());
		Assert.assertNotNull(bl.getBuild());
		Assert.assertNotNull(bl.getId().getWallet());
		Assert.assertNotNull(bl.getId().getProject());
		Assert.assertNotNull(bl.getId().getJob());
		Assert.assertNotNull(bl.getId().getBuild());
	}

	/**
	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.service.BuildLogService#getLog(java.lang.String, java.lang.String, java.lang.String, java.lang.Integer)}.
	 */
	@Test
	public void testGetLog() {
		// Arrange
		Mockito.when(buildLogRepository.findById(Mockito.any())).thenReturn(buildLog);
		// Act
		String bl = buildLogService.getLog("inovacao", "continuous-manager-web", "continuous-manager-web-ci-dev", 2);
		// Then
		Assert.assertNotNull(bl);
	}

	/**
	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.service.BuildLogService#getLogStages(java.lang.String, java.lang.String, java.lang.String, java.lang.Integer)}.
	 */
	@Test
	public void testGetLogStages() {
		// Arrange
		Mockito.when(buildLogRepository.findById(Mockito.any())).thenReturn(buildLog);
		// Act
		List<Stage> bl = buildLogService.getLogStages("inovacao", "continuous-manager-web", "continuous-manager-web-ci-dev", 2);
		// Then
		Assert.assertNotNull(bl);
	}

	/**
	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.service.BuildLogService#save(br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildLog)}.
	 */
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(buildLogRepository.save(buildLog)).thenReturn(buildLog);
		
		// Act
		BuildLog bl = buildLogService.save(buildLog);

		// Then
		Assert.assertEquals(buildLog.getId(), bl.getId());
	}

	/**
	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.service.BuildLogService#update(br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildLog)}.
	 */
	@Test
	public void testUpdate() {
		// Arrange
		Mockito.when(buildLogRepository.update(buildLog)).thenReturn(buildLog);
		
		// Act
		BuildLog bl = buildLogService.update(buildLog);

		// Then
		Assert.assertEquals(buildLog.getId(), bl.getId());
	}

}

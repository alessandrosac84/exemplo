import { Component, OnInit, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { Login } from '../../../shared/model/login.model';
import { AuthService } from '../auth.service';

@Component({
  selector: 'jmw-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnChanges {

  login: Login;
  loginForm: FormGroup;

  constructor(private fb: FormBuilder,
    private authService: AuthService) {
    this.createForm();
  }

  ngOnInit() {
  }

  createForm() {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      rememberMe: false,
    });
    this.ngOnChanges();
  }

  ngOnChanges() {
    // Obter usuario do cookie
    this.loginForm.reset({
      username: ''// this.hero.name
    });
  }

  onSubmit() {
    this.login = this.prepareLogin();
    this.authService.login(this.login).subscribe(/* error handling */);
  }

  prepareLogin(): Login {
    const formModel = this.loginForm.value;
    // return new `Login` object containing a combination of original login value(s)
    // and deep copies of changed form model values
    const saveLogin: Login = {
      username: this.login.username,
      password: this.login.password,
      rememberMe: this.login.rememberMe,
    };
    return saveLogin;
  }

}

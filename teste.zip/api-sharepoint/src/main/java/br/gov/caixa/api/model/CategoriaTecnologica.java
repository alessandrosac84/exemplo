package br.gov.caixa.api.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.gov.caixa.api.dto.CategoriaTecnologicaDto;
import br.gov.caixa.api.dto.FuncionarioDto;

@Entity
@Table(name = "categoria_tecnologica")
public class CategoriaTecnologica {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "nome")
	private String nome;
	
	public Long getUid() {
		return uid;
	}
	
	@ManyToOne(optional = true, fetch=FetchType.EAGER, cascade={CascadeType.DETACH})
	@JoinColumn(name="COORDENACAO_ID", nullable = true )
	private Coordenacao coordenacao;
		
	@OneToMany(fetch = FetchType.EAGER)	
	@JoinTable(name = "categoria_tecnologica_funcionario", joinColumns = @JoinColumn(name = "CATEGORIA_TECNOLOGICA_ID", referencedColumnName = "UID"), 
								inverseJoinColumns = @JoinColumn(name = "FUNCIONARIO_ID", referencedColumnName = "UID"))
	private List<Funcionario> funcionarios = new ArrayList<Funcionario>();


	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Coordenacao getCoordenacao() {
		return coordenacao;
	}

	public void setCoordenacao(Coordenacao coordenacao) {
		this.coordenacao = coordenacao;
	}
	
	public List<Funcionario> getFuncionarios() {
		return funcionarios;
	}

	public void setFuncionarios(List<Funcionario> funcionarios) {
		this.funcionarios = funcionarios;
	}
	
	public static CategoriaTecnologica fromDtoToCategoriaTecnologica(CategoriaTecnologicaDto dto){
		CategoriaTecnologica categoriaTecnologica = new CategoriaTecnologica();
		categoriaTecnologica.setUid(dto.getUid());
		categoriaTecnologica.setNome(dto.getNome());
		
		if(dto.getCoordenacaoDto() != null){
			Coordenacao coordenacao = Coordenacao.fromDtoToCoordenacao(dto.getCoordenacaoDto());
			categoriaTecnologica.setCoordenacao(coordenacao);
		}
		
		if(dto.getFuncionariosDto() != null){
			List<Funcionario> funcionarios = new ArrayList<Funcionario>();
			
			for (FuncionarioDto funcionarioDto : dto.getFuncionariosDto()) {
				Funcionario funcionario = Funcionario.fromDtoToFuncionario(funcionarioDto);
				funcionarios.add(funcionario);
			}
			categoriaTecnologica.setFuncionarios(funcionarios);
		}
		
		return categoriaTecnologica;
	}
}

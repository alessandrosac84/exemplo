import { Commit } from './commit.model';

export class Build {
  public id: { id: number, job: string, repository: string, project: number, wallet: string };
  public createdAt: Date;
  public branch: string;
  public since: string;
  public description: string;
  public duration: Date;
  public estimateDuration: Date;
  public localError: string;
  public result: string;
  public lastCommit: Commit;
}

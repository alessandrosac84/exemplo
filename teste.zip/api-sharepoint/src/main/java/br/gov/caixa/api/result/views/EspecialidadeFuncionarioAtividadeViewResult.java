package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeFuncionarioAtividadeView;
import br.gov.caixa.api.result.BasicResult;

public class EspecialidadeFuncionarioAtividadeViewResult extends BasicResult {
	private List<EspecialidadeFuncionarioAtividadeView> list;
	private EspecialidadeFuncionarioAtividadeView especialidadeFuncionarioAtividadeView;

	public List<EspecialidadeFuncionarioAtividadeView> getList() {
		return list;
	}

	public void setList(List<EspecialidadeFuncionarioAtividadeView> list) {
		this.list = list;
	}

	public EspecialidadeFuncionarioAtividadeView getEspecialidadeFuncionarioAtividadeView() {
		return especialidadeFuncionarioAtividadeView;
	}

	public void setEspecialidadeFuncionarioAtividadeView(EspecialidadeFuncionarioAtividadeView especialidadeFuncionarioAtividadeView) {
		this.especialidadeFuncionarioAtividadeView = especialidadeFuncionarioAtividadeView;
	}
}
export class LastBuiltRevisionJenkins {
    public SHA1: string;
}

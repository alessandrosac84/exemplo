package br.gov.caixa.api.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.Notificacao;
import br.gov.caixa.api.model.Notificacao.TipoNotificacao;


public interface NotificacaoRepository extends JpaRepository<Notificacao, Long> {
	
//	public List<Notificacao> findByFuncionarioAndDataExpiracaoGreaterThan(Funcionario funcionario, Date dataExp);
	public List<Notificacao> findByFuncionario(Funcionario funcionario);
	
	@Query("Select n from Notificacao n where n.funcionario = ?1 and n.tipoNotificacao = ?2")
	public List<Notificacao> findByFuncionarioAndTipoNotificacao(Funcionario funcionario, TipoNotificacao tipoNotificacao);
	
	@Query("Select n from Notificacao n where n.funcionario = ?1 and n.tipoNotificacao = ?2 and n.dataExpiracao = ?3")
	public List<Notificacao> findByFuncionarioAndTipoNotificacaoAndDataExpiracao(Funcionario funcionario, TipoNotificacao tipoNotificacao, Date dataFim);
	
	@Modifying
	@Transactional
	@Query("update Notificacao n set n.lido = ?1 where n.uid = ?2")
	int setLido(Boolean lido, Long uid);
	
	@Modifying
	@Transactional
	@Query("update Notificacao n set n.lido = ?1 where n.funcionario = ?2 and n.tipoNotificacao = ?3")
	int setLidoPorFuncionario(Boolean lido, Funcionario funcionario, TipoNotificacao tipoNotificacao);
	
	@Modifying
	@Transactional
	@Query("delete from Notificacao n where n.funcionario in ?1 and n.tipoNotificacao = ?2 and n.dataExpiracao = ?3")
	int deletePorTipoDataFuncionario(List<Funcionario> funcionario, TipoNotificacao tipoNotificacao, Date dataFim);

}

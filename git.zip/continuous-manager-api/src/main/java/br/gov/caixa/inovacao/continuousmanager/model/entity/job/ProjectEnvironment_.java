package br.gov.caixa.inovacao.continuousmanager.model.entity.job;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-15T10:35:00.395-0300")
@StaticMetamodel(ProjectEnvironment.class)
public class ProjectEnvironment_ extends AuditedEntity_ {
	public static volatile SingularAttribute<ProjectEnvironment, ProjectEnvironmentPK> id;
	public static volatile SingularAttribute<ProjectEnvironment, Build> build;
}

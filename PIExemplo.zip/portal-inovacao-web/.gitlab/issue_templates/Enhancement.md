<!-- Para uma solução mais rápida, providencie as seguintes informações. -->

### Melhoria

## Qual o motivo/caso de uso para implementação da melhoria?
<!-- Descreva a motivação do real caso de uso -->


Others:
<!-- Alguma outra coisa relevante?  Versão do sistema operacional... -->

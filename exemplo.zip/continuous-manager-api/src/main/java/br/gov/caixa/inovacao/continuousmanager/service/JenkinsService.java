/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpProtocol;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BuildJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.JobJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ProjectJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.WalletJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.service.integration.HttpService;

/**
 * Classe de servicos do Jenkins.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class JenkinsService {

	private static final String JOB = "/job/";
	private static final String API_JSON = "/api/json";

	private static final String QUERY_PARAM = "tree";
	private static final String JOB_INFO = "jobs[name,displayName]";

	@Inject
	private Logger log;

	@Inject
	private ParameterService parameterService;

	/**
	 * Obtem as listas de carteiras
	 * 
	 * @return Lista de Carteiras
	 */
	public List<WalletJenkinsVO> listWallets() {
		log.fine("Listando Carteiras");
		return callJenkins(Environment.DES, API_JSON, JOB_INFO, new TypeReference<List<WalletJenkinsVO>>() {
		});
	}

	/**
	 * Obtem as listas de projetos
	 * 
	 * @return Lista de Projetos
	 */
	public List<ProjectJenkinsVO> listProjects(String wallet) {
		log.fine("Listando Projetos");
		return callJenkins(Environment.DES, new StringBuilder(JOB).append(wallet).append(API_JSON).toString(), JOB_INFO,
				new TypeReference<List<ProjectJenkinsVO>>() {
				});
	}

	/**
	 * Obtem as listas de projetos
	 * 
	 * @return Lista de Projetos
	 */
	public List<JobJenkinsVO> listJobs(String wallet, String project) {
		log.fine("Listando Jobs");
		return callJenkins(Environment.DES,
				new StringBuilder(JOB).append(wallet).append(JOB).append(project).append(API_JSON).toString(), JOB_INFO,
				new TypeReference<List<JobJenkinsVO>>() {
				});
	}

	/**
	 * Obtem as listas de Builds
	 * 
	 * @return Lista de Builds
	 */
	public List<BuildJenkinsVO> listBuilds(String wallet, String project, String job) {
		log.fine("Listando Builds");
		return callJenkins(Environment.DES,
				new StringBuilder(JOB).append(wallet).append(JOB).append(project).append(JOB).append(job)
						.append(API_JSON).toString(),
				"allBuilds[number,description,duration,estimatedDuration,result,timestamp]",
				new TypeReference<List<BuildJenkinsVO>>() {
				});
	}

	/**
	 * Obtem o Log do build informado
	 * 
	 * @return Log
	 */
	public String getLog(String wallet, String project, String job, int build) {
		log.fine("Obtendo Log");
		return callJenkins(Environment.DES, new StringBuilder(JOB).append(wallet).append(JOB).append(project)
				.append(JOB).append(job).append("/").append(build).append("/consoleText").toString(), "",
				new TypeReference<String>() {
				});
	}

	@SuppressWarnings("unchecked")
	private <T> T callJenkins(Environment environment, String path, String query, TypeReference<T> typeReference) {

		ParameterPK parameterId = new ParameterPK();
		parameterId.setEnvironment(environment);
		parameterId.setServerType(ServerType.JENKINS);

		Parameter parameter = parameterService.findById(parameterId);

		if (parameter == null) {
			throw new NotFoundException("Erro ao obter informação do sistema!");
		}

		MultivaluedMap<String, Object> headers = new MultivaluedHashMap<>();
		headers.add("Authorization", parameter.getPrincipal());

		Response response = HttpService.callHttp(HttpProtocol.HTTPS, parameter.getHost(), path, QUERY_PARAM, query,
				headers);

		if (response.hasEntity()) {
			try {
				String resposta = response.readEntity(String.class);
				if (typeReference.getType().getTypeName().equals("java.lang.String")) {
					return (T) resposta;
				}
				resposta = resposta.replaceAll("^\\{\"_class\":\"[A-z0-9\\.]+\",*", "").replaceFirst("\"[A-z]+\":", "")
						.replaceAll("\\}$", "");

				return new ObjectMapper().readValue(resposta, typeReference);
			} catch (IOException e) {
				log.log(Level.SEVERE, "Erro ao transformar informações do Jenkins!", e);
				throw new ServiceUnavailableException("Erro ao obter informações do jenkins!");
			}
		}
		throw new NotFoundException("Nenhuma informação encontrada!");
	}
}

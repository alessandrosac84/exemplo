/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.config.roles.Roles;
import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.ProjectPK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.ProjectRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de servicos de Job.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class ProjectService {

	@Inject
	private Logger log;

	@Inject
	private ProjectRepository projectRepository;

	public List<Project> findAll(String carteira, int offset, int limit, String search, String sort, AscDesc order) {
		log.log(Level.FINE,
				"Listando Projetos : offset :: {0} :: limit :: {1} :: search :: {2} :: sort :: {3} :: order :: {4}",
				new Object[] { offset, limit, search, sort, order });
		List<Project> projects = projectRepository.findAll(carteira, offset, limit, search, sort, order);

		if (HelperThreadLocal.ATIVOS.get() != null && !HelperThreadLocal.ATIVOS.get().isEmpty()
				&& !HelperThreadLocal.ROLES.get().contains(Roles.ADMIN)) {
			projects.removeIf(p -> !HelperThreadLocal.ATIVOS.get().contains(p.getAtivoSharepoint()));
		}
		return projects;
	}

	public Long countAll(String carteira, String search) {
		log.log(Level.FINE, "Contando Projetos: Carteira :: {0} :: Search :: {1}", new Object[] { carteira, search });
		return (long) projectRepository.findAll(carteira, 0, Integer.MAX_VALUE, search, "id", AscDesc.ASC).size();
	}

	public Project save(@Valid Project project) {
		log.log(Level.FINE, "Salvando Projeto :: {0}", project.getId());
		return projectRepository.save(project);
	}

	public Project findById(ProjectPK id) {
		log.fine("Obtendo Projeto");
		return projectRepository.findById(id);
	}

	public Project findById(String wallet, String project) {
		ProjectPK id = new ProjectPK();
		id.setWallet(wallet);
		id.setId(project);
		return findById(id);
	}
}

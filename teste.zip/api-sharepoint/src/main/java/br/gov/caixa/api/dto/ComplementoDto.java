package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.Complemento;

public class ComplementoDto {

	public ComplementoDto() {

	}

	private Long uid;
	private String mensagem;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public static List<ComplementoDto> fromComplementoToListDto(List<Complemento> list) {
		
		List<ComplementoDto> returnList = new ArrayList<ComplementoDto>();
		
		for (Complemento complemento : list) {
			ComplementoDto dto = new ComplementoDto();
			
			dto.setUid(complemento.getUid());
			dto.setMensagem(complemento.getMensagem());
			
			returnList.add(dto);
		}
		
		return returnList;
	}
	
	public static ComplementoDto fromComplementoToDto(Complemento complemento){
		ComplementoDto dto = new ComplementoDto();
		dto.setUid(complemento.getUid());
		dto.setMensagem(complemento.getMensagem());
		return dto;		
	}

}

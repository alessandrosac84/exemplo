package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.QuestionarioDto;

public class QuestionarioResult extends BasicResult  {
	private List<QuestionarioDto> list;
	private QuestionarioDto questionario;	

	public List<QuestionarioDto> getList() {
		return list;
	}

	public void setList(List<QuestionarioDto> list) {
		this.list = list;
	}

	public QuestionarioDto getQuestionario() {
		return questionario;
	}

	public void setQuestionario(QuestionarioDto questionario) {	
		this.questionario = questionario;
	}
}

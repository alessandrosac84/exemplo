/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.filter.response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.core.MultivaluedMap;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * Classe de Teste de TokenResponseFilter
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TokenResponseFilterTest {

	@Mock
	private ContainerRequestContext containerRequestContext;

	@Mock
	private ContainerResponseContext containerResponseContext;

	@Mock
	private HttpServletRequest request;

	@InjectMocks
	private TokenResponseFilter tokenResponseFilter;

	@Mock
	private MultivaluedMap<String, Object> headers;
	
	@Mock
	private HttpSession httpSession;

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.TokenResponseFilter#filter(javax.ws.rs.container.ContainerRequestContext, javax.ws.rs.container.ContainerResponseContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilterOptions() throws IOException {
		// Arrange
		Mockito.when(containerRequestContext.getMethod()).thenReturn("OPTIONS");

		// Act
		tokenResponseFilter.filter(containerRequestContext, containerResponseContext);

		// Then
		Assert.assertEquals("OPTIONS", containerRequestContext.getMethod());
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.TokenResponseFilter#filter(javax.ws.rs.container.ContainerRequestContext, javax.ws.rs.container.ContainerResponseContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilterJwt() throws IOException {
		// Arrange
		Mockito.when(containerResponseContext.getHeaders()).thenReturn(headers);
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(request.getAttribute("jwt")).thenReturn(new ArrayList<>(
				Arrays.asList("Bearer eyJhbGciOiJSUzI1NiJ9.eyJleHAiOjE1MTYyOTk1OTYsImp0aSI6IklYRnpyV3hQcTV2b1ZzeUJfVEZR"
						+ "X1EiLCJpYXQiOjE1MTYyOTg2OTYsInN1YiI6ImY3NzEyNzQiLCJlbWFpbCI6bnVsbCwicm9sZXMiOlsiQ0VBU0F"
						+ "QIiwiQkFNQURNIiwiV0tMREVQTE9ZRVIiLCJXQVNERVBMT1lFUiIsIkNFQVNBUCIsIkJBTUFETSIsIldLTERFUEx"
						+ "PWUVSIiwiV0FTREVQTE9ZRVIiXX0.oCJR-Xpy5djsnSkVGX6Zxfv4gZXWvkU5gp5sLZTQZIDY26gl4qM5_-9OPAXX"
						+ "-zXiAXsuJv7Q5NO1r1fFZR2a20QQpYprlSxrZ-EMu8zIpMTk3pjcI4aoj70tU5vXZltweozZ0tZOwTHVPYj2p68ANp"
						+ "YYOMGBvGlTBI_uL6j-ZAfEG4pp_a3vhr3VbNNzIu9af3OhYfNs0wdn5r2Dgb3GvptcUv_ZyZuIQvPETftB6xKl3a-V"
						+ "8iM4XKbr24E_V8mr3gnbLRUtbu-7iQ75Y60Vcre0foH-oOITIUVHCIiuD79f2oAtRnNxsG3Wou4BXggCOdjvnldM2uqtfEBcmxuirg")));
		// Act
		tokenResponseFilter.filter(containerRequestContext, containerResponseContext);

		// Then
		Assert.assertEquals("GET", containerRequestContext.getMethod());
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.TokenResponseFilter#filter(javax.ws.rs.container.ContainerRequestContext, javax.ws.rs.container.ContainerResponseContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilterNoJwt() throws IOException {
		// Arrange
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(request.getAttribute("jwt")).thenReturn(null);
		// Act
		tokenResponseFilter.filter(containerRequestContext, containerResponseContext);

		// Then
		Assert.assertEquals("GET", containerRequestContext.getMethod());
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.TokenResponseFilter#filter(javax.ws.rs.container.ContainerRequestContext, javax.ws.rs.container.ContainerResponseContext)}.
	 * 
	 * @throws IOException
	 * @throws ServletException 
	 */
	@Test
	public void testFilterException() throws IOException, ServletException {
		// Arrange
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(request.getAttribute("jwt")).thenReturn(null);
		Mockito.doThrow(new ServletException()).when(request).logout();
		// Act
		tokenResponseFilter.filter(containerRequestContext, containerResponseContext);

		// Then
		Assert.assertEquals("GET", containerRequestContext.getMethod());
	}

	
}

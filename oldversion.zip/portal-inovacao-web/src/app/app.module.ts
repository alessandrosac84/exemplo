import { BrowserModule, Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

// Third party
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

// Guards
import { AuthGuard } from './guards/auth.guard';
import { MapaAmbienteGuard } from './guards/mapa-ambiente.guard';

// Root
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// Layout
import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';
import { SidebarComponent } from './layout/sidebar/sidebar.component';

// Pages
import { HomeComponent } from './pages/home/home.component';
import { TransacaoComponent } from './pages/transacao/transacao.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';

import { PortalInovacaoService } from './pages/shared/portal.inovacao.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    TransacaoComponent,
    SidebarComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NgbModule.forRoot(),
    AppRoutingModule,
    FormsModule
  ],
  providers: [
    Title,
    PortalInovacaoService,
    MapaAmbienteGuard,
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

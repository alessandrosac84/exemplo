package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the project_branch database table.
 * 
 */
@Embeddable
public class ProjectBranchPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String wallet;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String project;

	@Column(unique=true, nullable=false, length=100)
	private String branch;

	public ProjectBranchPK() {
		/* class constructor intentionally left blank */
	}
	public String getWallet() {
		return this.wallet;
	}
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}
	public String getProject() {
		return this.project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getBranch() {
		return this.branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ProjectBranchPK)) {
			return false;
		}
		ProjectBranchPK castOther = (ProjectBranchPK)other;
		return 
			this.wallet.equals(castOther.wallet)
			&& this.project.equals(castOther.project)
			&& this.branch.equals(castOther.branch);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.wallet.hashCode();
		hash = hash * prime + this.project.hashCode();
		hash = hash * prime + this.branch.hashCode();
		
		return hash;
	}
}
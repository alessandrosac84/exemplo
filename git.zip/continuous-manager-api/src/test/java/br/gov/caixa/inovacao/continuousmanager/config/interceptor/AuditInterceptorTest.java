/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.interceptor;

import javax.naming.InitialContext;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Job;
import br.gov.caixa.inovacao.continuousmanager.service.AuditService;

/**
 * Classe de testes do LoggerInterceptor.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ InitialContext.class })
public class AuditInterceptorTest {
	
	@Rule
	public MockitoRule mrule = MockitoJUnit.rule();

	@Mock
	private AuditService auditService;
	
	@Mock
	private InitialContext initialContext;

	@InjectMocks
	private AuditInterceptor auditInterceptor;

	@Test
	public void testOnPrePersist() throws Exception {
		// Arrange
		AuditedEntity entity = new Job();

		// Act
		auditInterceptor.onPrePersist(entity);
	}

	@Test
	public void testOnPreUpdateRemove() throws Exception {
		// Arrange
		AuditedEntity entity = new Job();

		// Act
		auditInterceptor.onPreUpdateRemove(entity);
	}

	@Test
	public void testOnPostPersist() throws Exception {
		// Arrange
		AuditedEntity entity = new Job();
		PowerMockito.mockStatic(InitialContext.class);
		PowerMockito.when(InitialContext.doLookup(Mockito.anyString())).thenReturn(auditService);

		// Act
		auditInterceptor.onPostPersist(entity);
	}

	@Test
	public void testOnPostUpdate() throws Exception {
		// Arrange
		AuditedEntity entity = new Job();
		PowerMockito.mockStatic(InitialContext.class);
		PowerMockito.when(InitialContext.doLookup(Mockito.anyString())).thenReturn(auditService);

		// Act
		auditInterceptor.onPostUpdate(entity);
	}

	@Test
	public void testOnPostRemove() throws Exception {
		// Arrange
		AuditedEntity entity = new Job();
		PowerMockito.mockStatic(InitialContext.class);
		PowerMockito.when(InitialContext.doLookup(Mockito.anyString())).thenReturn(auditService);
		entity.getUserInsert();
		entity.getUpdatedAt();
		entity.getUserUpdate();

		// Act
		auditInterceptor.onPostRemove(entity);
	}

}

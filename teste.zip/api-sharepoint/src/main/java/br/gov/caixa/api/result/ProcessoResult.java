package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.ProcessoDto;

public class ProcessoResult extends BasicResult {

	private List<ProcessoDto> list;
	private ProcessoDto processo;

	public List<ProcessoDto> getList() {
		return list;
	}

	public void setList(List<ProcessoDto> list) {
		this.list = list;
	}

	public ProcessoDto getProcesso() {
		return processo;
	}

	public void setProcesso(ProcessoDto processo) {
		this.processo = processo;
	}
}

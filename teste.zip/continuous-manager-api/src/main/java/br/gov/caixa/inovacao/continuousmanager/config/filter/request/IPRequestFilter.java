/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.filter.request;

import java.io.IOException;
import java.util.logging.Logger;

import javax.annotation.Priority;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.ext.Provider;

import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;

/**
 * Filtro para opter o ip remoto
 * 
 * @author Fabio Iwakoshi
 *
 */
@Provider
@Priority(Priorities.ENTITY_CODER)
public class IPRequestFilter implements ContainerRequestFilter {
	
	@Context
	private ResourceInfo resourceInfo;

	@Context
	private HttpServletRequest request;

	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		Logger log = Logger.getLogger(this.getClass().getName());
		log.fine("Executando Request Filter IP... ");

		HelperThreadLocal.IP.set(request.getRemoteAddr());
	}
}

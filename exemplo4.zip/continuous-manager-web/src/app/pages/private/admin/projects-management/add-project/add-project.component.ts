import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatDialog, MatDialogConfig } from '@angular/material';
import { WalletService } from '../../../../../shared/service/wallet.service';
import { Wallet } from '../../../../../shared/model/entity/wallet.model';
import { Repository } from '../../../../../shared/model/entity/repository.model';

import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { AddRepositoryComponent } from './add-repository/add-repository.component';
import { Project } from '../../../../../shared/model/entity/project.model';
import { ScrollDispatcher, CdkScrollable } from '@angular/cdk/overlay';
import {ScrollDispatchModule} from '@angular/cdk/scrolling';
import { AddBranchComponent } from './add-branch/add-branch.component';
import { AddMemberComponent } from './add-member/add-member.component';

@Component({
  selector: 'cm-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.scss']
})
export class AddProjectComponent implements OnInit {
  walletSelected = new FormControl;
  nameSistema = new FormControl;
  coordSistema = new FormControl;
  descSistema = new FormControl;

  wallets: Wallet[];
  project = new FormControl;
  listRepositories: Repository[];
  lengthList: number;
  displayedColumns: string[] = [
    'repo',
    'tipo'
  ];

  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;

  constructor(private _walletService: WalletService, private _formBuilder: FormBuilder,
    public dialog: MatDialog, public scroll: ScrollDispatcher) {
    this.listRepositories = [];
  }

  ngOnInit() {
    this._walletService.getWallets().subscribe(data => this.wallets = data);

    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });

    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });

    this.thirdFormGroup = this._formBuilder.group({
      thirdCtrl: ['', Validators.required]
    });
  }

  openAddRepository() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;

    const dialogRef = this.dialog.open(AddRepositoryComponent, dialogConfig);


    dialogRef.afterClosed().subscribe(result => {
      console.log('result ' + result);
      if (result) {
        this.listRepositories.push(result);
      }
    });
  }

    openAddBranch(repositorySelected) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = false;
      dialogConfig.autoFocus = true;
      dialogConfig.data = repositorySelected;

      const dialogRef = this.dialog.open(AddBranchComponent, dialogConfig);

      dialogRef.afterClosed().subscribe(result => {
        console.log('result ' + result);
        if (result) {
          if (repositorySelected.branchs !== undefined) {
            repositorySelected.branchs.push(result);
          } else {
            repositorySelected.branchs = [];
            repositorySelected.branchs.push(result);
          }
          console.log(this.listRepositories);
        }
      });
    }

    openAddMember(repositorySelected) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = false;
      dialogConfig.autoFocus = true;
      dialogConfig.data = repositorySelected;

      const dialogRef = this.dialog.open(AddMemberComponent, dialogConfig);

      dialogRef.afterClosed().subscribe(result => {
        console.log('result ' + result);
        if (result) {
          if (repositorySelected.branchs !== undefined) {
            repositorySelected.branchs.push(result);
          } else {
            repositorySelected.branchs = [];
            repositorySelected.branchs.push(result);
          }
          console.log(this.listRepositories);
        }
      });
    }
}

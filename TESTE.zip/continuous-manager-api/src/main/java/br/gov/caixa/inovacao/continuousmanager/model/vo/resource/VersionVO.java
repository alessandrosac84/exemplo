package br.gov.caixa.inovacao.continuousmanager.model.vo.resource;

import java.io.Serializable;

public class VersionVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4517039709277515439L;

	private String commit;
	
	private String version;

	/**
	 * @return the commit
	 */
	public String getCommit() {
		return commit;
	}

	/**
	 * @param commit the commit to set
	 */
	public void setCommit(String commit) {
		this.commit = commit;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

}

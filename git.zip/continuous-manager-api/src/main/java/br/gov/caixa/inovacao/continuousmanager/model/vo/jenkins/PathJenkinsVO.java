/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.EditType;

/**
 * Classe de representação do Build do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class PathJenkinsVO implements Serializable {

	private static final long serialVersionUID = 8071496924918677911L;

	private EditType editType;
	
	private String file;

	/**
	 * @return the editType
	 */
	public EditType getEditType() {
		return editType;
	}

	/**
	 * @param editType the editType to set
	 */
	public void setEditType(EditType editType) {
		this.editType = editType;
	}

	/**
	 * @return the file
	 */
	public String getFile() {
		return file;
	}

	/**
	 * @param file the file to set
	 */
	public void setFile(String file) {
		this.file = file;
	}
}

package br.gov.caixa.api.model.views;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "profile_percentuais_prenchimento_view")
public class ProfilePercentualPreenchimentoView {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "NOME")
	private String nome;
	
	@Column(name = "MATRICULA")
	private String matricula;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "FONE")
	private String fone;
	
	@Column(name = "PERCENT")
	private Double percent;
	
	@Column(name = "LIDAS")
	private Long lidas;
	
	@Column(name = "TOTAL")
	private Long total;
			
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getFone() {
		return fone;
	}

	public void setFone(String fone) {
		this.fone = fone;
	}

	public Double getPercent() {
		return percent;
	}

	public void setPercent(Double percent) {
		this.percent = percent;
	}

	public Long getLidas() {
		return lidas;
	}

	public void setLidas(Long lidas) {
		this.lidas = lidas;
	}

	public Long getTotal() {
		return total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

}

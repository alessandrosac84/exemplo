import { ChangeSet } from './../model/changeset.model';
import { Stage } from './../model/stage.model';
import { Build } from '../model/build.model';
import { Job } from '../model/job.model';
import { Wallet } from '../model/wallet.model';
import { Project } from '../model/project.model';
import { Observable } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import 'rxjs/add/operator/map';

import { environment } from '../../../environments/environment';

@Injectable()
export class JenkinsService {

  private walletUrl = `${environment.apiBaseUrl}api/carteiras`;
  private projectsUrl = '/projetos';
  private jobUrl = '/jobs';
  private buildUrl = '/builds';
  private logUrl = '/log';
  private logStagesUrl = '/log/stages';
  private currentBuildsUrl = '/currentBuilds';
  private changeSetUrl = '/change-sets';
  private rebuildUrl = '/rebuild';
  private versionUrl = '/version';
  private limit = 10;

  constructor(private http: HttpClient) { }

  getWallets(): Observable<Wallet[]> {
    return this.http.get<Wallet[]>(`${this.walletUrl}`);
  }

  getProjects(walletName: string): Observable<Project[]> {
    return this.http.get<Project[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}`);
  }

  getJobs(walletName: string, projectName: string): Observable<Job[]> {
    return this.http.get<Job[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}`);
  }

  getBuilds(walletName: string, projectName: string, jobName: string, page: number): Observable<HttpResponse<Build[]>> {
    const p = (page - 1) * this.limit;
    return this.http.get<Build[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/` +
      `${projectName}${this.jobUrl}/${jobName}${this.buildUrl}?order=DESC&limit=${this.limit}&offset=${p}`, { observe: 'response' });
  }

  geDetailtBuild(walletName: string, projectName: string, jobName: string, build: number): Observable<any> {
    return this.http.get(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}/${jobName}` +
      `${this.buildUrl}/${build}`);
  }

  getLog(walletName: string, projectName: string, jobName: string, build: number): Observable<any> {
    return this.http.get(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}` +
      `${this.jobUrl}/${jobName}${this.buildUrl}/${build}${this.logUrl}`,
      { responseType: 'text' });
  }

  getLogStages(walletName: string, projectName: string, jobName: string, build: number): Observable<Stage[]> {
    return this.http.get<Stage[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}` +
      `${this.jobUrl}/${jobName}${this.buildUrl}/${build}${this.logStagesUrl}`);
  }

  getCurrentBuilds(walletName: string): Observable<Build[]> {
    return this.http.get<Build[]>(`${this.walletUrl}/${walletName}${this.currentBuildsUrl}`);
  }

  getChangeSets(walletName: string, projectName: string, jobName: string, page: number): Observable<HttpResponse<ChangeSet[]>> {
    const p = (page - 1) * this.limit;
    return this.http.get<ChangeSet[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/` +
      `${projectName}${this.jobUrl}/${jobName}${this.changeSetUrl}?order=DESC&limit=${this.limit}&offset=${p}`, { observe: 'response' });
  }

  rebuild(walletName: string, projectName: string, jobName: string, build: number, commit: string): Observable<any> {
    return this.http.post(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}/${jobName}` +
      `${this.buildUrl}/${build}${this.rebuildUrl}`, commit);
  }

  version(walletName: string, projectName: string, jobName: string, commit: string, version: string): Observable<any> {
    return this.http.post(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}/${jobName}` +
      `${this.versionUrl}`, { commit: commit, version: version });
  }

  /*getJSON(): Observable<any> {
    return this.http.get('../../../assets/files/commits.json')
      .map((response: Response) => {
        const data = response;
        return data;
      });
  }*/
}

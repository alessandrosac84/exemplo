package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.CategoriaProcessoDto;

public class CategoriaProcessoResult extends BasicResult {

	private List<CategoriaProcessoDto> list;
	private CategoriaProcessoDto categoriaProcessoDto;

	public List<CategoriaProcessoDto> getList() {
		return list;
	}

	public void setList(List<CategoriaProcessoDto> list) {
		this.list = list;
	}

	public CategoriaProcessoDto getCategoriaProcessoDto() {
		return categoriaProcessoDto;
	}

	public void setCategoriaProcessoDto(
			CategoriaProcessoDto categoriaProcessoDto) {
		this.categoriaProcessoDto = categoriaProcessoDto;
	}

}

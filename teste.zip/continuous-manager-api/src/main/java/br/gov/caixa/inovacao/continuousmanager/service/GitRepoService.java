/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.NoResultException;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.GitRepo;
import br.gov.caixa.inovacao.continuousmanager.model.entity.GitRepoPK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.GitRepoRepository;

/**
 * Classe de servicos de GitRepo.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class GitRepoService {

	@Inject
	private Logger log;

	@Inject
	private GitRepoRepository gitRepoRepository;

	public GitRepo save(@Valid GitRepo gitRepo) {
		log.log(Level.FINE, "Salvando GitRepo :: {0}", gitRepo.getId());
		return gitRepoRepository.save(gitRepo);
	}

	public GitRepo findById(GitRepoPK id) {
		log.fine("Obtendo Git Repo");
		try {
			return gitRepoRepository.findById(id);
		} catch (NoResultException e) {
			log.log(Level.SEVERE, "Não foram encontrada informações do Git Repo!");
			return null;
		}
	}

	public int maxSequence(String wallet, String project) {
		log.fine("Obtendo Max Sequence Git Repo");
		Integer max = gitRepoRepository.maxSequence(wallet, project);
		if (max == null) {
			max = 0;
		}
		return max;
	}

	public GitRepo update(@Valid GitRepo gitRepo) {
		log.log(Level.FINE, "Atualizando GitRepo :: {0}", gitRepo.getId());
		return gitRepoRepository.update(gitRepo);
	}
}

import { MapaAmbienteGuard } from './../../guards/mapa-ambiente.guard';
import { MapaAmbienteComponent } from './mapa-ambiente.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '', component: MapaAmbienteComponent,
    canActivateChild: [MapaAmbienteGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MapaAmbienteRoutingModule { }

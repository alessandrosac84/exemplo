/**
 * SIAPP_WS_DistinctItemPortfolioServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package SIAPP_WS_DistinctItemPortfolio;

public class SIAPP_WS_DistinctItemPortfolioServiceLocator extends org.apache.axis.client.Service implements SIAPP_WS_DistinctItemPortfolio.SIAPP_WS_DistinctItemPortfolioService {

    public SIAPP_WS_DistinctItemPortfolioServiceLocator() {
    }


    public SIAPP_WS_DistinctItemPortfolioServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public SIAPP_WS_DistinctItemPortfolioServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for PortSoap
    private java.lang.String PortSoap_address = "http://cx0000nt872.corecaixa:8080/arsys/services/ARService?server=cx0000ux936.corecaixa&webService=SIAPP_WS_DistinctItemPortfolio";

    public java.lang.String getPortSoapAddress() {
        return PortSoap_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String PortSoapWSDDServiceName = "PortSoap";

    public java.lang.String getPortSoapWSDDServiceName() {
        return PortSoapWSDDServiceName;
    }

    public void setPortSoapWSDDServiceName(java.lang.String name) {
        PortSoapWSDDServiceName = name;
    }

    public SIAPP_WS_DistinctItemPortfolio.PortPortType getPortSoap() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(PortSoap_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getPortSoap(endpoint);
    }

    public SIAPP_WS_DistinctItemPortfolio.PortPortType getPortSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            SIAPP_WS_DistinctItemPortfolio.PortSoapBindingStub _stub = new SIAPP_WS_DistinctItemPortfolio.PortSoapBindingStub(portAddress, this);
            _stub.setPortName(getPortSoapWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setPortSoapEndpointAddress(java.lang.String address) {
        PortSoap_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (SIAPP_WS_DistinctItemPortfolio.PortPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                SIAPP_WS_DistinctItemPortfolio.PortSoapBindingStub _stub = new SIAPP_WS_DistinctItemPortfolio.PortSoapBindingStub(new java.net.URL(PortSoap_address), this);
                _stub.setPortName(getPortSoapWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("PortSoap".equals(inputPortName)) {
            return getPortSoap();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "SIAPP_WS_DistinctItemPortfolioService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "PortSoap"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("PortSoap".equals(portName)) {
            setPortSoapEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}

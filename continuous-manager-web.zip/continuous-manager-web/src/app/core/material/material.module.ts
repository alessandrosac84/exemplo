import { NgModule } from '@angular/core';
import {
  MatButtonModule,
  MatCardModule,
  MatIconModule,
  MatInputModule,
  MatMenuModule,
  MatToolbarModule,
  MatRadioModule,
  MatSelectModule,
  MatFormFieldModule,
  MatGridListModule,
  MatStepperModule,
  MatTreeModule,
  MatDialogModule,
  MatRippleModule
} from '@angular/material';

@NgModule({
  imports: [
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatToolbarModule,
    MatRadioModule,
    MatSelectModule,
    MatFormFieldModule,
    MatGridListModule,
    MatStepperModule,
    MatTreeModule,
    MatDialogModule,
    MatRippleModule
  ],
  exports: [
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatToolbarModule,
    MatRadioModule,
    MatSelectModule,
    MatFormFieldModule,
    MatGridListModule,
    MatStepperModule,
    MatTreeModule,
    MatDialogModule,
    MatRippleModule
  ]
})
export class MaterialModule {}

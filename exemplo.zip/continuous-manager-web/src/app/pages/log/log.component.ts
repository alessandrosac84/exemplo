import { ViewLog } from './../../shared/model/view-log.model';
import { Commit } from './../../shared/model/commit.model';
import { Observable } from 'rxjs/Rx';
import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { JenkinsService } from '../../shared/service/jenkins.service';

import { Build } from '../../shared/model/build.model';
import { Job } from '../../shared/model/job.model';
import { Folder } from '../../shared/model/folder.model';

@Component({
  selector: 'jmw-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.scss']
})
export class LogComponent implements OnInit {
  pageTitle = 'Log do Jenkins';

  folderId: Folder;
  listaFolders: Folder[] = [];
  jobId: Job;
  listaJobs: Job[] = [];
  listaBuilds: Build[] = [];
  listaCommits: Commit[] = [];
  listaViewLog: ViewLog[] = [];

  constructor(private title: Title,
    private jenkinsService: JenkinsService) {
  }

  ngOnInit() {
    this.title.setTitle(this.pageTitle);
    this.jenkinsService.getFolders().subscribe(data => {
      this.listaFolders = data;
    });

    this.jenkinsService.getJSON().subscribe(data => {
      this.listaCommits = data;
    });
  }

  public changeSistema(option) {
    this.jobId = undefined;
    this.folderId = option;
    this.listaJobs = [];
    if (option !== undefined) {
      this.jenkinsService.getJobs(option.name).subscribe(data => {
        this.listaJobs = data;
      });
    }
  }

  public changeJob(job) {
    if (job !== undefined) {
      this.jenkinsService.getBuilds(this.folderId.name, job.name).subscribe(data => {
        this.listaBuilds = data;

        this.listaBuilds.forEach(build => {
          const itemBuild: ViewLog = new ViewLog;
          itemBuild.number_build = build.number;
          itemBuild.result_build = build.result;
          itemBuild.timestamp_build = build.timestamp;

          this.listaCommits.filter((commit: Commit) => {
            if (build.actions[0].lastBuiltRevision.SHA1 === commit.id) {
              itemBuild.short_id_commit = commit.short_id;
              itemBuild.title_commit = commit.title;
              itemBuild.author_name_commit = commit.author_name;
            }
          });
          this.listaViewLog.push(itemBuild);
        });
      });
    }
  }

  downloadfile($event, buildId) {
    this.jenkinsService.getLog(this.folderId.name, this.jobId.name, buildId).subscribe(
      res => this.exportData(res, buildId),
      (error: any) => Observable.throw(error || 'Server error')
    );
  }

  exportData(res: string, buildId) {
    const blob = res;
    const myBlob: Blob = new Blob([res], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(myBlob);
    a.download = 'Log - ' + this.folderId.name + ' - Job - ' + this.jobId.name + ' - Build - ' + buildId + '.txt';
    document.body.appendChild(a);
    a.click();
  }
}

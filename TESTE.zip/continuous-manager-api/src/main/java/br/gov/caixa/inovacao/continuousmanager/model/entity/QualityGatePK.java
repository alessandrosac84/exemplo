package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the quality_gate database table.
 * 
 */
@Embeddable
public class QualityGatePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String project;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String wallet;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=40)
	private String commit;

	@Column(name="metric_key", unique=true, nullable=false, length=30)
	private String metricKey;

	public QualityGatePK() {
	}
	public String getProject() {
		return this.project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getWallet() {
		return this.wallet;
	}
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}
	public String getCommit() {
		return this.commit;
	}
	public void setCommit(String commit) {
		this.commit = commit;
	}
	public String getMetricKey() {
		return this.metricKey;
	}
	public void setMetricKey(String metricKey) {
		this.metricKey = metricKey;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof QualityGatePK)) {
			return false;
		}
		QualityGatePK castOther = (QualityGatePK)other;
		return 
			this.project.equals(castOther.project)
			&& this.wallet.equals(castOther.wallet)
			&& this.commit.equals(castOther.commit)
			&& this.metricKey.equals(castOther.metricKey);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.project.hashCode();
		hash = hash * prime + this.wallet.hashCode();
		hash = hash * prime + this.commit.hashCode();
		hash = hash * prime + this.metricKey.hashCode();
		
		return hash;
	}
}
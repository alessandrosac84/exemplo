package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the ddd database table.
 * 
 */
@Entity
@Table(name="ddd")
@NamedQuery(name="Ddd.findAll", query="SELECT d FROM Ddd d ORDER BY d.ddd")
public class Ddd implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=3)
	private int ddd;

	@Column(nullable=false, length=70)
	private String localidade;

	@JsonIgnore
	//bi-directional many-to-one association to FuncionarioTelefone
	@OneToMany(mappedBy="ddd")
	private List<FuncionarioTelefone> funcionarioTelefones;

	public Ddd() {
	}

	public int getDdd() {
		return this.ddd;
	}

	public void setDdd(int ddd) {
		this.ddd = ddd;
	}

	public String getLocalidade() {
		return this.localidade;
	}

	public void setLocalidade(String localidade) {
		this.localidade = localidade;
	}

	public List<FuncionarioTelefone> getFuncionarioTelefones() {
		return this.funcionarioTelefones;
	}

	public void setFuncionarioTelefones(List<FuncionarioTelefone> funcionarioTelefones) {
		this.funcionarioTelefones = funcionarioTelefones;
	}

	public FuncionarioTelefone addFuncionarioTelefone(FuncionarioTelefone funcionarioTelefone) {
		getFuncionarioTelefones().add(funcionarioTelefone);
		funcionarioTelefone.setDdd(this);

		return funcionarioTelefone;
	}

	public FuncionarioTelefone removeFuncionarioTelefone(FuncionarioTelefone funcionarioTelefone) {
		getFuncionarioTelefones().remove(funcionarioTelefone);
		funcionarioTelefone.setDdd(null);

		return funcionarioTelefone;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ddd;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Ddd))
			return false;
		Ddd other = (Ddd) obj;
		if (ddd != other.ddd)
			return false;
		return true;
	}

}
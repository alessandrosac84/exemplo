package br.gov.caixa.api.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.gov.caixa.api.dto.RatingProcessoDto;

@Entity
@Table(name = "rating_processo")
public class RatingProcesso {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "rating")
	private Integer rating;

	@Column(name = "conhecer", columnDefinition = "boolean default false")
	private boolean conhecer;
	
	@Column(name = "conheco", columnDefinition = "boolean default false")
	private boolean conheco;

	@Column(name = "multiplicador", columnDefinition = "boolean default false")
	private boolean multiplicador;

	@ManyToOne
	@JoinColumn(name = "PROCESSO_ID")
	private Processo processo;

	@ManyToOne
	@JoinColumn(name = "FUNCIONARIO_ID")
	private Funcionario funcionario;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public boolean isConhecer() {
		return conhecer;
	}

	public void setConhecer(boolean conhecer) {
		this.conhecer = conhecer;
	}
	
	public boolean isConheco() {
		return conheco;
	}

	public void setConheco(boolean conheco) {
		this.conheco = conheco;
	}

	public boolean isMultiplicador() {
		return multiplicador;
	}

	public void setMultiplicador(boolean multiplicador) {
		this.multiplicador = multiplicador;
	}

	public Processo getProcesso() {
		return processo;
	}

	public void setProcesso(Processo processo) {
		this.processo = processo;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}
	
	
	public static RatingProcesso fromDtoToRatingProcesso(RatingProcessoDto ratingProcessoDto) {
		RatingProcesso ratingProcesso = new RatingProcesso();
		ratingProcesso.setUid(ratingProcessoDto.getUid());
		ratingProcesso.setRating(ratingProcessoDto.getRating());
		ratingProcesso.setConhecer(ratingProcessoDto.isConhecer());
		ratingProcesso.setConheco(ratingProcessoDto.isConheco());
		ratingProcesso.setMultiplicador(ratingProcessoDto.isMultiplicador());
		ratingProcesso.setProcesso(Processo.fromDtoToProcesso(ratingProcessoDto.getProcesso()));
		ratingProcesso.setFuncionario(Funcionario.fromDtoToFuncionario(ratingProcessoDto.getFuncionario()));
		return ratingProcesso;
	}
	
	public static List<RatingProcesso> fromProcessoToListRatingProcesso(List<Processo> processos, Funcionario funcionario) {
		List<RatingProcesso> returnList = new ArrayList<RatingProcesso>();
		for (Processo processo : processos) {
			RatingProcesso ratingProcesso = new RatingProcesso();
			ratingProcesso.setConhecer(false);
			ratingProcesso.setMultiplicador(false);
			ratingProcesso.setConheco(false);
			ratingProcesso.setProcesso(processo);
			ratingProcesso.setRating(Integer.valueOf(0));
			ratingProcesso.setFuncionario(funcionario);
			returnList.add(ratingProcesso);
		}
		return returnList;
	}	
}

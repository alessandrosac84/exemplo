package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the campo_adicional database table.
 * 
 */
@Entity
@Table(name="campo_adicional")
@NamedQueries({
	@NamedQuery(name="CampoAdicional.findAll", query="SELECT c FROM CampoAdicional c"),
	@NamedQuery(name="CampoAdicional.findByAKs", query="SELECT c FROM CampoAdicional c WHERE c.id <> :id AND c.descricao = :descricao"),
	@NamedQuery(name="CampoAdicional.findByReferencia", query="SELECT c FROM CampoAdicional c INNER JOIN c.campoTipoAtivos ca WHERE c.id = :campoAdicional")
})
public class CampoAdicional extends AuditedEntity implements Serializable, IEntity<String> {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=20)
	@NotEmpty
	@Pattern(regexp="[a-z_]+")
	private String id;

	@NotEmpty
	@Size(min=3, max=45)
	@Column(nullable=false, length=45)
	private String descricao;

	@Column
	private Integer tamanho;

	@Column(name="tamanho_decimal")
	private Integer tamanhoDecimal;

	@NotNull
	//bi-directional many-to-one association to TipoCampo
	@ManyToOne
	@JoinColumn(name="tipo_campo", nullable=false)
	private TipoCampo tipoCampo;

	@JsonIgnore
	//bi-directional many-to-one association to CampoTipoAtivo
	@OneToMany(mappedBy="campoAdicional")
	private Set<CampoTipoAtivo> campoTipoAtivos;
	
	public CampoAdicional() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescricao() {
		return this.descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Integer getTamanho() {
		return this.tamanho;
	}

	public void setTamanho(Integer tamanho) {
		this.tamanho = tamanho;
	}

	public TipoCampo getTipoCampo() {
		return this.tipoCampo;
	}

	public void setTipoCampo(TipoCampo tipoCampo) {
		this.tipoCampo = tipoCampo;
	}

	public Set<CampoTipoAtivo> getCampoTipoAtivos() {
		return this.campoTipoAtivos;
	}

	public void setCampoTipoAtivos(Set<CampoTipoAtivo> campoTipoAtivos) {
		this.campoTipoAtivos = campoTipoAtivos;
	}

	public CampoTipoAtivo addCampoTipoAtivo(CampoTipoAtivo campoTipoAtivo) {
		getCampoTipoAtivos().add(campoTipoAtivo);
		campoTipoAtivo.setCampoAdicional(this);

		return campoTipoAtivo;
	}

	public CampoTipoAtivo removeCampoTipoAtivo(CampoTipoAtivo campoTipoAtivo) {
		getCampoTipoAtivos().remove(campoTipoAtivo);
		campoTipoAtivo.setCampoAdicional(null);

		return campoTipoAtivo;
	}

	public Integer getTamanhoDecimal() {
		return tamanhoDecimal;
	}

	public void setTamanhoDecimal(Integer tamanhoDecimal) {
		this.tamanhoDecimal = tamanhoDecimal;
	}

	@Override
	public boolean isTheSameObject(IEntity<String> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		CampoAdicional other = (CampoAdicional) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((descricao == null) ? 0 : descricao.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((tamanho == null) ? 0 : tamanho.hashCode());
		result = prime * result + ((tamanhoDecimal == null) ? 0 : tamanhoDecimal.hashCode());
		result = prime * result + ((tipoCampo == null) ? 0 : tipoCampo.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof CampoAdicional))
			return false;
		CampoAdicional other = (CampoAdicional) obj;
		if (descricao == null) {
			if (other.descricao != null)
				return false;
		} else if (!descricao.equals(other.descricao))
			return false;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (tamanho == null) {
			if (other.tamanho != null)
				return false;
		} else if (!tamanho.equals(other.tamanho))
			return false;
		if (tamanhoDecimal == null) {
			if (other.tamanhoDecimal != null)
				return false;
		} else if (!tamanhoDecimal.equals(other.tamanhoDecimal))
			return false;
		if (tipoCampo == null) {
			if (other.tipoCampo != null)
				return false;
		} else if (!tipoCampo.equals(other.tipoCampo))
			return false;
		return true;
	}
}
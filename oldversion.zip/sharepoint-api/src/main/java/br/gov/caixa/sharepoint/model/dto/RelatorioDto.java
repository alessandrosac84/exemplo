/**
 * 
 */
package br.gov.caixa.sharepoint.model.dto;

import java.util.Calendar;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Fabio Iwakoshi
 *
 */
@XmlRootElement(name="relatorio")
public class RelatorioDto {
	private Calendar apuracao;
	
	private List<SistemaDto> sistemas;

	public Calendar getApuracao() {
		return apuracao;
	}

	public void setApuracao(Calendar apuracao) {
		this.apuracao = apuracao;
	}

	@XmlElementWrapper(name="sistemas")
    @XmlElement(name="sistema")
	public List<SistemaDto> getSistemas() {
		return sistemas;
	}

	public void setSistemas(List<SistemaDto> sistemas) {
		this.sistemas = sistemas;
	}
}

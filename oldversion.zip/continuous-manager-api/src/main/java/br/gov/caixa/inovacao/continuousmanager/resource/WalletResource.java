/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.resource;

import javax.annotation.security.RolesAllowed;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.config.roles.Roles;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.service.BuildLogService;
import br.gov.caixa.inovacao.continuousmanager.service.BuildService;
import br.gov.caixa.inovacao.continuousmanager.service.CommitService;
import br.gov.caixa.inovacao.continuousmanager.service.DeployService;
import br.gov.caixa.inovacao.continuousmanager.service.JobService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectService;
import br.gov.caixa.inovacao.continuousmanager.service.RebuildService;
import br.gov.caixa.inovacao.continuousmanager.service.VersionService;
import br.gov.caixa.inovacao.continuousmanager.service.WalletService;
import br.gov.caixa.inovacao.continuousmanager.util.Util;

/**
 * Classe responsavel por receber as requisicoes dos usuários para manutenção
 * das Folders do Jenkins
 * 
 * Todas as chamadas a classe são interceptadas pela classe LoggerInterceptor
 * atraves da anotacao @Interceptors.
 * 
 * Como estamos trabalhando com Rest, utilizar sempre o escopo @RequestScoped
 * para nao sobrecarregar o servidor desnecessariamente.
 * 
 * @author Fabio Iwakoshi
 *
 */
@Path("wallets")
@RequestScoped
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class WalletResource {

	@Inject
	private WalletService walletService;

	@Inject
	private ProjectService projectService;

	@Inject
	private JobService jobService;

	@Inject
	private BuildService buildService;

	@Inject
	private BuildLogService buildLogService;

	@Inject
	private CommitService commitService;

	@Inject
	private RebuildService rebuildService;

	@Inject
	private VersionService versionService;

	@Inject
	private DeployService deployService;

	/**
	 * Metodo responsavel por listar as Folders (Response pagination). Utilizar
	 * sempre lista Paginada para evitar sobrecarga desnecessaria do Servidor.
	 * 
	 * Por Default ( @DefaultValue ) o metodo sempre retorna de 30 em 30 registros,
	 * limitando ao maximo de 100. Utilizar @QueryParam para paginacao.
	 * 
	 * Exemplos de chamada: <i>GET</i> <b>api/folders</b>
	 * <b>api/folders?offset=0&limit=30</b>
	 * <b>api/folders?offset=0&limit=30&search=manager</b>
	 * 
	 * @param offset
	 *            - registro inicial
	 * @param limit
	 *            - quantidade de registros na requisição
	 * @param search
	 *            - criterio de pesquisa
	 * @param sort
	 *            - campo de ordenação
	 * @param order
	 *            - campo de direcao da ordenação - ASC ou DESC
	 * @return Lista de Folders do Jenkins
	 */
	@GET
	@JsonView(ViewJson.WalletView.class)
	public Response getWallets(@QueryParam("offset") @DefaultValue(value = "0") int offset,
			@QueryParam("limit") @Max(value = 100) @DefaultValue(value = "30") int limit,
			@QueryParam("search") @DefaultValue(value = "") String search,
			@QueryParam("sort") @DefaultValue(value = "id") String sort,
			@QueryParam("order") @DefaultValue(value = "ASC") AscDesc order) {
		return Util.paginacao(walletService.countAll(search), walletService.findAll(offset, limit, search, sort, order),
				offset, limit);
	}

	@GET
	@JsonView(ViewJson.WalletView.class)
	@Path("{wallet:[a-z\\-]+}")
	public Response getWallet(@PathParam("wallet") String wallet) {
		return Response.ok(walletService.findById(wallet)).build();
	}

	@GET
	@JsonView(ViewJson.ProjectView.class)
	@Path("{wallet:[a-z\\-]+}/projects")
	public Response getProjects(@PathParam("wallet") String wallet,
			@QueryParam("offset") @DefaultValue(value = "0") int offset,
			@QueryParam("limit") @Max(value = 100) @DefaultValue(value = "30") int limit,
			@QueryParam("search") @DefaultValue(value = "") String search,
			@QueryParam("sort") @DefaultValue(value = "id") String sort,
			@QueryParam("order") @DefaultValue(value = "ASC") AscDesc order) {
		return Util.paginacao(projectService.countAll(wallet, search),
				projectService.findAll(wallet, offset, limit, search, sort, order), offset, limit);
	}

	@GET
	@JsonView(ViewJson.ProjectView.class)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}")
	public Response getProject(@PathParam("wallet") String wallet, @PathParam("project") String project) {
		return Response.ok(projectService.findById(wallet, project)).build();
	}

	@GET
	@JsonView(ViewJson.JobView.class)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/jobs")
	public Response getJobs(@PathParam("wallet") String wallet, @PathParam("project") String project,
			@QueryParam("offset") @DefaultValue(value = "0") int offset,
			@QueryParam("limit") @Max(value = 100) @DefaultValue(value = "30") int limit,
			@QueryParam("search") @DefaultValue(value = "") String search,
			@QueryParam("sort") @DefaultValue(value = "id") String sort,
			@QueryParam("order") @DefaultValue(value = "ASC") AscDesc order) {
		return Util.paginacao(jobService.countAll(wallet, project, search),
				jobService.findAll(wallet, project, offset, limit, search, sort, order), offset, limit);
	}

	@GET
	@JsonView(ViewJson.JobView.class)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/jobs/{job:[a-z\\-]+}")
	public Response getJob(@PathParam("wallet") String wallet, @PathParam("project") String project,
			@PathParam("job") String job) {
		return Response.ok(jobService.findById(wallet, project, job)).build();
	}

	@GET
	@JsonView(ViewJson.BuildView.class)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/jobs/{job:[a-z\\-]+}/builds")
	public Response getBuilds(@PathParam("wallet") String wallet, // NOSONAR
			@PathParam("project") String project, @PathParam("job") String job,
			@QueryParam("offset") @DefaultValue(value = "0") int offset,
			@QueryParam("limit") @Max(value = 100) @DefaultValue(value = "30") int limit,
			@QueryParam("sort") @DefaultValue(value = "id") String sort,
			@QueryParam("order") @DefaultValue(value = "ASC") AscDesc order) {
		return Util.paginacao(buildService.countAll(wallet, project, job),
				buildService.findAll(wallet, project, job, offset, limit, sort, order), offset, limit);
	}

	@GET
	@JsonView(ViewJson.BuildView.class)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/jobs/{job:[a-z\\-]+}/builds/{build:\\d+}")
	public Response getBuild(@PathParam("wallet") String wallet, @PathParam("project") String project,
			@PathParam("job") String job, @PathParam("build") Integer build) {
		return Response.ok(buildService.findById(wallet, project, job, build)).build();
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/jobs/{job:[a-z\\-]+}/builds/{build:\\d+}/log")
	public Response getLog(@PathParam("wallet") String wallet, @PathParam("project") String project,
			@PathParam("job") String job, @PathParam("build") Integer build) {
		return Response.ok(buildLogService.getLog(wallet, project, job, build)).build();
	}

	@GET
	@JsonView(ViewJson.LogStageView.class)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/jobs/{job:[a-z\\-]+}/builds/{build:\\d+}/log/stages")
	public Response getLogStages(@PathParam("wallet") String wallet, @PathParam("project") String project,
			@PathParam("job") String job, @PathParam("build") Integer build) {
		return Response.ok(buildLogService.getLogStages(wallet, project, job, build)).build();
	}

	@GET
	@RolesAllowed({ Roles.ADMIN, Roles.CAIXA })
	@JsonView(ViewJson.BuildView.class)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/builds/release")
	public Response findAllToRelease(@PathParam("wallet") String wallet, @PathParam("project") String project,
			@QueryParam("result") @DefaultValue(value = "SUCCESS") JenkinsResult result,
			@QueryParam("offset") @DefaultValue(value = "0") int offset,
			@QueryParam("limit") @Max(value = 100) @DefaultValue(value = "30") int limit) {
		return Util.paginacao(buildService.countToReleaseAll(wallet, project, result),
				buildService.findAllToRelease(wallet, project, result, offset, limit), offset, limit);
	}

	@GET
	@RolesAllowed({ Roles.ADMIN, Roles.CAIXA })
	@JsonView(ViewJson.CommitView.class)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/commits")
	public Response getCommits(@PathParam("wallet") String wallet, @PathParam("project") String project,
			@QueryParam("result") @DefaultValue(value = "SUCCESS") JenkinsResult result,
			@QueryParam("offset") @DefaultValue(value = "0") int offset,
			@QueryParam("limit") @Max(value = 100) @DefaultValue(value = "30") int limit) {
		return Util.paginacao(commitService.countByStatus(wallet, project, result),
				commitService.findByStatus(wallet, project, result, offset, limit), offset, limit);
	}

	@POST
	@RolesAllowed({ Roles.ADMIN, Roles.CAIXA })
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/jobs/{job:[a-z\\-]+}/rebuild")
	public Response rebuild(@PathParam("wallet") String wallet, @PathParam("project") String project,
			@PathParam("job") String job, @NotNull String commit) {
		rebuildService.rebuild(wallet, project, job, commit);
		return Response.noContent().build();
	}

	@POST
	@RolesAllowed({ Roles.ADMIN, Roles.CAIXA })
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/version")
	public Response version(@PathParam("wallet") String wallet, @PathParam("project") String project,
			@NotNull Commit commit) {
		versionService.version(wallet, project, commit);
		return Response.noContent().build();
	}

	@POST
	@RolesAllowed({ Roles.ADMIN, Roles.CAIXA })
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("{wallet:[a-z\\-]+}/projects/{project:[a-z\\-]+}/deploy")
	public Response deploy(@PathParam("wallet") String wallet, @PathParam("project") String project,
			@NotNull String version) {
		deployService.deploy(wallet, project, version);
		return Response.noContent().build();
	}
}

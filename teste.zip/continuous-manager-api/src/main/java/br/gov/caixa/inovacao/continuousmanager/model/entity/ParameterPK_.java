package br.gov.caixa.inovacao.continuousmanager.model.entity;

import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-15T10:30:36.549-0300")
@StaticMetamodel(ParameterPK.class)
public class ParameterPK_ {
	public static volatile SingularAttribute<ParameterPK, Environment> environment;
	public static volatile SingularAttribute<ParameterPK, ServerType> serverType;
}

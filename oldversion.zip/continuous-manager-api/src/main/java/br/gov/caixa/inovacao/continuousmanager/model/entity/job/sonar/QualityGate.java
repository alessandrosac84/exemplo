package br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Project;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.Comparator;


/**
 * The persistent class for the quality_gate database table.
 * 
 */
@Entity
@Table(name="quality_gate")
@NamedQuery(name="QualityGate.findAll", query="SELECT q FROM QualityGate q")
public class QualityGate implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private QualityGatePK id;

	@Column(length=2)
	private Comparator comparator;

	@Column(name="error_threshold")
	private String errorThreshold;

	//bi-directional many-to-one association to Measure
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="project", referencedColumnName="id", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private Project project;

	public QualityGate() {
		/* class constructor intentionally left blank */
	}

	public QualityGatePK getId() {
		return this.id;
	}

	public void setId(QualityGatePK id) {
		this.id = id;
	}

	public Comparator getComparator() {
		return this.comparator;
	}

	public void setComparator(Comparator comparator) {
		this.comparator = comparator;
	}

	public String getErrorThreshold() {
		return this.errorThreshold;
	}

	public void setErrorThreshold(String errorThreshold) {
		this.errorThreshold = errorThreshold;
	}

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

}
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Project } from '../../../shared/model/entity/project.model';
import { DashboardService } from '../../../shared/service/dashboard.service';
import { Repository } from '../../../shared/model/entity/repository.model';

@Component({
  selector: 'cm-dashboard',
  templateUrl: './dashboard.component.html',
  styles: []
})
export class DashboardComponent implements OnInit {
  project: Project;
  single: any[];
  cardsLine: any[];
  viewChartLine: any[] = [600, 250];
  repositories$: Observable<Repository[]>;
  repositoriesLength: number;

  // options common
  showXAxis = true;
  showYAxis = true;
  showLegend = true;
  showXAxisLabel = false;
  xAxisLabel = '';
  showYAxisLabel = true;
  autoScale = true;

  // options line chart
  legendTitle = 'Status';
  yAxisLabel = 'Builds';

  constructor(private _dashboardService: DashboardService) {
   }

   colorScheme = { domain: ['#5AA454', '#ad4055', '#5b5b5a', '#AAAAAA', '#bbb', '#587B87' ] };

  ngOnInit() {
    this._dashboardService.getProject(+localStorage.getItem('project')).subscribe(data => this.project = data);
    this._dashboardService.getProjectWeekStatus(this.project).subscribe(dataWeek => this.single = dataWeek);
    this._dashboardService.getProjectInfoSonar(this.project).subscribe(dataSonar => this.cardsLine = dataSonar);

    this.repositories$ = this._dashboardService
        .getRepositories(+localStorage.getItem('project'))
        .pipe(
          map(data => {
            this.repositoriesLength = data.length;
            return data;
          })
        );
        console.log(this.repositories$);
  }

  onSelect(event) {
    console.log(event);
  }
}

# Continuous Manager Web

Projeto gerado com [Angular CLI](https://github.com/angular/angular-cli) versão 1.3.1.
- Angular 4.3.6
- Bootstrap 4.0.0

### Servidor de Desenvolvimento

Execute `ng serve` para executar o server de desenvolvimento. Navegue para `http://localhost:4200/`. A aplicação irá atualizar automaticamente caso algum fonte seja alterado.

### Templates de componentes

Execute `ng generate component component-name` para gerar um novo componente. Você também pode usar `ng generate directive|pipe|service|class|guard|interface|enum|module`.

### Compilando

Execute `ng build` para compilar o projeto. Os artefatos compilados serão armazenados na pasta `dist/`. Use a opção `-prod` para compilação para produção.

### Executando testes de unidade

Execute `ng test` para executar os testes de unidade via [Karma](https://karma-runner.github.io).

### Executando testes end-to-end

Execute `ng e2e` para iniciar testes end-to-end via [Protractor](http://www.protractortest.org/).
Antes de executar os testes, tenha certeza que você está executando-o via `ng serve`.

### Mais informações

Para obter mais informações do Angular CLI use `ng help` ou acesse o projeto [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

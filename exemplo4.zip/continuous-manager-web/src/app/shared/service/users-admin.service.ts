import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { User } from '../model/entity/user.model';

@Injectable({
  providedIn: 'root'
})
export class UsersAdminService {

  constructor(private http: HttpClient) {}

  getUsersAdmin(): Observable<User[]> {
    return this.http.get<User[]>('../../../assets/file/usersAdmin.json');
  }
}

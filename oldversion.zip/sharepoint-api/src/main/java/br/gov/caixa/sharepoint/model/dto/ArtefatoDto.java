/**
 * 
 */
package br.gov.caixa.sharepoint.model.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

/**
 * @author Fabio Iwakoshi
 *
 */
public class ArtefatoDto {
	private String nome;
	
	private List<ArquivoDto> arquivos;

	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

	@XmlElementWrapper(name="arquivos")
    @XmlElement(name="arquivo")
	public List<ArquivoDto> getArquivos() {
		return arquivos;
	}

	public void setArquivos(List<ArquivoDto> arquivos) {
		this.arquivos = arquivos;
	}
}

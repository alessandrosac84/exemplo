package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeFerramentaView;
import br.gov.caixa.api.result.BasicResult;

public class EspecialidadeFerramentaViewResult extends BasicResult {
	private List<EspecialidadeFerramentaView> list;
	private EspecialidadeFerramentaView especialidadeFerramentaView;

	public List<EspecialidadeFerramentaView> getList() {
		return list;
	}

	public void setList(List<EspecialidadeFerramentaView> list) {
		this.list = list;
	}

	public EspecialidadeFerramentaView getEspecialidadeFerramentaView() {
		return especialidadeFerramentaView;
	}

	public void setEspecialidadeFerramentaView(EspecialidadeFerramentaView especialidadeFerramentaView) {
		this.especialidadeFerramentaView = especialidadeFerramentaView;
	}
}
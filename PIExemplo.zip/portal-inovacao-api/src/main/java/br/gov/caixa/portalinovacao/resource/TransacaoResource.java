package br.gov.caixa.portalinovacao.resource;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.gov.caixa.portalinovacao.model.vo.TransacaoVO;
import br.gov.caixa.portalinovacao.service.TransacaoService;

@Path("solicitacao-transacao")
@RequestScoped
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class TransacaoResource {

	@Inject
	private TransacaoService transacaoService;
	
	@POST
	@Path("send")
	public Response send(@Valid TransacaoVO transacao) {
		
		return Response.ok(transacaoService.send(transacao)).build();
		
	}
}

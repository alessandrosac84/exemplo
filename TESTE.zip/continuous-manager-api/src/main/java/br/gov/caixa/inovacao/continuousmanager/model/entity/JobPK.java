package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * The primary key class for the job database table.
 * 
 * @author Fabio Iwakoshi
 */
@Embeddable
public class JobPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@JsonView(ViewJson.JobView.class)
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@JsonView(ViewJson.JobView.class)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String wallet;
	
	@JsonView(ViewJson.JobView.class)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String project;

	public JobPK() {
		/* class constructor intentionally left blank */
	}
	public String getProject() {
		return this.project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getWallet() {
		return this.wallet;
	}
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}
	public String getId() {
		return this.id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof JobPK)) {
			return false;
		}
		JobPK castOther = (JobPK)other;
		return 
			this.project.equals(castOther.project)
			&& this.wallet.equals(castOther.wallet)
			&& this.id.equals(castOther.id);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.project.hashCode();
		hash = hash * prime + this.wallet.hashCode();
		hash = hash * prime + this.id.hashCode();
		
		return hash;
	}
}
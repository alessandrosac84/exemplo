/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.NoResultException;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.CommitRepository;

/**
 * Classe de servicos de Commit.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class CommitService {

	@Inject
	private Logger log;

	@Inject
	private CommitRepository commitRepository;

	public List<Commit> findByStatus(String wallet, String project, JenkinsResult result, int offset, int limit) {
		log.log(Level.FINE, "Listando Commits : offset :: {0} :: limit :: {1} ::", new Object[] { offset, limit });
		return commitRepository.findByStatus(wallet, project, result, offset, limit);
	}

	public Long countByStatus(String wallet, String project, JenkinsResult result) {
		log.log(Level.FINE, "Contando Commits: Carteira :: {0} :: Projeto {1} :: Result {2}",
				new Object[] { wallet, project, result });
		return commitRepository.countByStatus(wallet, project, result);
	}

	public Commit findById(CommitPK id) {
		log.fine("Obtendo Git Repo");
		try {
			return commitRepository.findById(id);
		} catch (NoResultException e) {
			log.log(Level.SEVERE, "Não foram encontrada informações do Commit!");
			return null;
		}
	}
	
	public Commit findVersionByBuild(String wallet, String project, Build build) {
		log.fine("Obtendo Version by Build");
		try {
			return commitRepository.findVersionByBuildId(wallet, project, build);
		} catch (NoResultException e) {
			log.log(Level.SEVERE, "Não foram encontrada informações da Versão!");
			return null;
		}
	}
	
	public Commit save(@Valid Commit commit) {
		log.log(Level.FINE, "Salvando Commit :: {0}", commit.getId());
		return commitRepository.save(commit);
	}

	public Commit update(@Valid Commit commit) {
		log.log(Level.FINE, "Atualizando Commit :: {0}", commit.getId());
		return commitRepository.update(commit);
	}

	public List<Commit> findByVersionOrCommit(String wallet, String project, Commit commit) {
		log.log(Level.FINE,
				"Listando Commits por Versão ou Commit : wallet :: {0} :: project :: {1} :: versao :: {2} :: commit :: {3} ::",
				new Object[] { wallet, project, commit.getVersion(), commit.getId().getCommit() });
		return commitRepository.findByVersionOrCommit(wallet, project, commit);
	}
}

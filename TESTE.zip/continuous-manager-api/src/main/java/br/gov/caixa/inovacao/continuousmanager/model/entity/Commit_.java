package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.util.Calendar;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-05-22T14:16:17.367-0300")
@StaticMetamodel(Commit.class)
public class Commit_ {
	public static volatile SingularAttribute<Commit, CommitPK> id;
	public static volatile SingularAttribute<Commit, String> authorEmail;
	public static volatile SingularAttribute<Commit, String> authorName;
	public static volatile SingularAttribute<Commit, Calendar> authoredDate;
	public static volatile SingularAttribute<Commit, Calendar> committedDate;
	public static volatile SingularAttribute<Commit, String> committerEmail;
	public static volatile SingularAttribute<Commit, String> committerName;
	public static volatile SingularAttribute<Commit, String> message;
	public static volatile SingularAttribute<Commit, String> title;
	public static volatile SingularAttribute<Commit, String> version;
	public static volatile SingularAttribute<Commit, Calendar> versionedAt;
	public static volatile SingularAttribute<Commit, String> versionerUser;
	public static volatile SetAttribute<Commit, Path> paths;
	public static volatile SetAttribute<Commit, ChangeSet> changeSets;
	public static volatile SingularAttribute<Commit, Project> project;
	public static volatile SetAttribute<Commit, Measures> measures;
}

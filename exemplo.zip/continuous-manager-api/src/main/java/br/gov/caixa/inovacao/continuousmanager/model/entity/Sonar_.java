package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.math.BigDecimal;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-01-31T07:42:18.815-0200")
@StaticMetamodel(Sonar.class)
public class Sonar_ {
	public static volatile SingularAttribute<Sonar, SonarPK> id;
	public static volatile SingularAttribute<Sonar, Integer> bugs;
	public static volatile SingularAttribute<Sonar, Integer> codeSmells;
	public static volatile SingularAttribute<Sonar, BigDecimal> coverages;
	public static volatile SingularAttribute<Sonar, Integer> debts;
	public static volatile SingularAttribute<Sonar, BigDecimal> duplications;
	public static volatile SingularAttribute<Sonar, String> key;
	public static volatile SingularAttribute<Sonar, Integer> lines;
	public static volatile SingularAttribute<Sonar, QualityGate> qualityGate;
	public static volatile SingularAttribute<Sonar, Integer> unitTests;
	public static volatile SingularAttribute<Sonar, Integer> vulnerabilities;
	public static volatile SingularAttribute<Sonar, Project> project;
}

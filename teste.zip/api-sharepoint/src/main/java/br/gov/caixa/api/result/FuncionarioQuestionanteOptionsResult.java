package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.FuncionarioQuestionanteOptionsDto;

public class FuncionarioQuestionanteOptionsResult extends BasicResult  {
	private List<FuncionarioQuestionanteOptionsDto> list;
	private FuncionarioQuestionanteOptionsDto funcionarioQuestionanteOptions;	

	public List<FuncionarioQuestionanteOptionsDto> getList() {
		return list;
	}

	public void setList(List<FuncionarioQuestionanteOptionsDto> list) {
		this.list = list;
	}

	public FuncionarioQuestionanteOptionsDto getFuncionarioQuestionanteOptions() {
		return funcionarioQuestionanteOptions;
	}

	public void setFuncionarioQuestionanteOptions(FuncionarioQuestionanteOptionsDto funcionarioQuestionanteOptions) {
		this.funcionarioQuestionanteOptions = funcionarioQuestionanteOptions;
	}	
}

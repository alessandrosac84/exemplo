package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public enum LocalError {
	@JsonProperty("Sonar")
	SONAR("Sonar");

	private final String formatted;

	LocalError(String formatted) {
		this.formatted = formatted;
	}

	@JsonCreator // This is the factory method and must be static
	public static LocalError fromString(String string) {
		return Optional.ofNullable(formatMap.get(string)).orElseThrow(() -> new IllegalArgumentException(string));
	}

	private static Map<String, LocalError> formatMap = Stream.of(LocalError.values())
			.collect(Collectors.toMap(s -> s.formatted, Function.identity()));
}

package br.gov.caixa.api.controller;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.dto.EspecialidadeAtividadeDto;
import br.gov.caixa.api.result.EspecialidadeAtividadeResult;
import br.gov.caixa.api.services.EspecialidadeAtividadeService;

@RestController
public class EspecialidadeAtividadeController {

	@Inject
	EspecialidadeAtividadeService service;

	@RequestMapping(value = "/api/especialidadeAtividade/all", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeAtividadeResult listAll() {
		return service.listAll();
	}

	@RequestMapping(value="/api/especialidadeAtividade/save", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeAtividadeResult save(@RequestBody EspecialidadeAtividadeDto especialidadeAtividadeDto) {
		
		return service.save(especialidadeAtividadeDto);
	}
	
	@RequestMapping(value="/api/especialidadeAtividade/delete", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeAtividadeResult delete(@RequestBody EspecialidadeAtividadeDto especialidadeAtividadeDto) {
		
		return service.delete(especialidadeAtividadeDto);
	}
	
	@RequestMapping(value="/api/especialidadeAtividade/obterEspecialidadeAtividadePorIdEspecialidade/{idEspecialidade}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeAtividadeResult obterAtivoPorIdCategoria(@PathVariable Long idEspecialidade) {
		
		return service.listEspecialidadeAtividadesByIdAtividade(idEspecialidade);
	}


}

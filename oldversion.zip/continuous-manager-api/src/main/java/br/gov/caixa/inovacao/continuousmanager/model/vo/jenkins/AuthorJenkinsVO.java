/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;

/**
 * Classe de representação do Build do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class AuthorJenkinsVO implements Serializable {

	private static final long serialVersionUID = 8902956963594506219L;

	private String fullName;

	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
}

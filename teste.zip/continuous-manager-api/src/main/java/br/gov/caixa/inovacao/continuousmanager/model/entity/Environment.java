package br.gov.caixa.inovacao.continuousmanager.model.entity;

/**
 * Enum de Ambientes
 * 
 * @author Fabio Iwakoshi
 */
public enum Environment {

	DES("Desenvolvimento"), TQS("Teste de Qualidade de Software"), HMP("Homologação"), PRD("Produção");
	
	private String description;
	
	private Environment(String description) {
		this.description = description;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
}

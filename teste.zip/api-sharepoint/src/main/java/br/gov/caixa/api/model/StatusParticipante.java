package br.gov.caixa.api.model;

public enum StatusParticipante {
	NENHUM(0),
	CONVIDADO(1), 
	INSCRITO(2),
	CONFIRMADO(3),
	ESPERA(4),
	RECUSADO(5),
	REMOVIDO(6),
	CANCELADO(6),
	PRESENTE(8),
	AUSENTE(9),
	ININSCRITO(10),
	INCONFIRMADO(11),
	PRESENTIN(12),
	PRESENTOUT(13),
	ENQUETE(14);
	
	private final int codigo;
	
	StatusParticipante(int codigo) { this.codigo = codigo; }
	
	int codigo() { return codigo; }
	
	public static StatusParticipante porCodigo(int codigo) {
        for (StatusParticipante statusParticipante: StatusParticipante.values()) {
            if (codigo == statusParticipante.codigo()) return statusParticipante;
        }
        throw new IllegalArgumentException("Status invalido");
    }
}

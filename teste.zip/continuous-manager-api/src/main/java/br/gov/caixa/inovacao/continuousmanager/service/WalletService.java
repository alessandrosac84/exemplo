/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Wallet;
import br.gov.caixa.inovacao.continuousmanager.model.repository.WalletRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de servicos de Folder.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class WalletService {

	@Inject
	private Logger log;

	@Inject
	private WalletRepository walletRepository;

	public Wallet findById(String id) {
		log.fine("Obtendo Carteira");
		return walletRepository.findById(id);
	}

	public List<Wallet> findAll(int offset, int limit, String search, String sort, AscDesc order) {
		log.log(Level.FINE,
				"Listando Carteiras : offset :: {0} :: limit :: {1} :: search :: {2} :: sort :: {3} :: order :: {4}",
				new Object[] { offset, limit, search, sort, order });
		return walletRepository.findAll(offset, limit, search, sort, order);
	}

	public Long countAll(String search) {
		log.log(Level.FINE, "Contando Carteiras:: search :: {0}", search);
		return walletRepository.countAll(search);
	}

	public Wallet save(@Valid Wallet wallet) {
		log.log(Level.FINE, "Salvando Carteira :: {0}", wallet.getId());
		return walletRepository.save(wallet);
	}
}

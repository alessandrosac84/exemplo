package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-04-16T14:14:37.213-0300")
@StaticMetamodel(BuildLogPK.class)
public class BuildLogPK_ {
	public static volatile SingularAttribute<BuildLogPK, Integer> build;
	public static volatile SingularAttribute<BuildLogPK, String> project;
	public static volatile SingularAttribute<BuildLogPK, String> wallet;
	public static volatile SingularAttribute<BuildLogPK, String> job;
}

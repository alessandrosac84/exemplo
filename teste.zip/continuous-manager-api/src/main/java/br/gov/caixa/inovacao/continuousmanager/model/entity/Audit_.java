package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.util.Calendar;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-02-06T15:22:51.018-0200")
@StaticMetamodel(Audit.class)
public class Audit_ {
	public static volatile SingularAttribute<Audit, Long> id;
	public static volatile SingularAttribute<Audit, Action> action;
	public static volatile SingularAttribute<Audit, String> entity;
	public static volatile SingularAttribute<Audit, String> functionality;
	public static volatile SingularAttribute<Audit, String> ipEvent;
	public static volatile SingularAttribute<Audit, Calendar> timestampEvent;
	public static volatile SingularAttribute<Audit, String> userEvent;
}

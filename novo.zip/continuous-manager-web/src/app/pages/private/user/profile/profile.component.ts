import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../shared/service/user.service';
import { User } from '../../../../shared/model/entity/user.model';
import { UserProject } from '../../../../shared/model/entity/userproject.model';
import { UserProjectService } from '../../../../shared/service/user-project.service';

@Component({
  selector: 'cm-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
user: User;
userProjects: UserProject[];

  constructor(private _userService: UserService,
              private _userProjectService: UserProjectService) { }

  color = 'primary';
  checked = false;
  disabled = false;

  ngOnInit() {
    this._userService.getUser().subscribe(data => this.user = data);
    this._userProjectService.getUserProjects().subscribe(data => this.userProjects = data);
  }

}


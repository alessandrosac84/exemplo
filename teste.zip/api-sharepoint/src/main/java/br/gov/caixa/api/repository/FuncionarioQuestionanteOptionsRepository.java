package br.gov.caixa.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.FuncionarioQuestionanteOptions;

public interface FuncionarioQuestionanteOptionsRepository extends JpaRepository<FuncionarioQuestionanteOptions, Long> {

	@Query("select f from FuncionarioQuestionanteOptions f where (f.questionarioId is null or f.questionarioId = ?1)")
	public List<FuncionarioQuestionanteOptions> findByQuestionarioAndNulls(Long questionarioId);
		
	@Query("select f from FuncionarioQuestionanteOptions f where f.questionarioId = ?1 and f.participacao = true)")
	public List<FuncionarioQuestionanteOptions> findByQuestionarioByQuestionarioId(Long questionarioId);

}




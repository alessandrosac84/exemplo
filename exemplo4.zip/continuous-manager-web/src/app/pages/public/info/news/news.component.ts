import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'cm-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {
  displayedColumns = ['version', 'date', 'description'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  constructor() {}

  ngOnInit() {}

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
}

export interface Element {
  date: string;
  version: string;
  description: string;
}

const ELEMENT_DATA: Element[] = [
  { version: '3.0 - Bauru', date: '01.09.2018', description: '- Upgrade Design - Utilizando Material' },
  // tslint:disable-next-line:max-line-length
  { version: '2.0 - Misto Quente', date: '01.08.2018', description: '- Inclusão de acesso via SSO<br>- Visualização do dashboard<br>- Opção de rebuild para builds de DEV<br>- Tela de Informações: Melhores Práticas/FAQ<br>- Melhorias no design das telas<br>- Correções de bugs' },
  { version: '1.1 - Pão na Chapa c/ Requeijão', date: '22.11.2017', description: '- Melhoria na visualização do log através de steps' },
  { version: '1.0 - Pão na Chapa', date: '31.10.2017', description: '- Visualização do Log do Jenkins' }
];

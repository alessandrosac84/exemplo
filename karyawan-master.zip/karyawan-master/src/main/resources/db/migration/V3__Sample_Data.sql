INSERT INTO karyawan (id, nama, keterangan) VALUES ('1', 'Monkey.D Luffy', 'Kapten bajak laut topi jerami');
INSERT INTO karyawan (id, nama, keterangan) VALUES ('2', 'Roronoa Zorro', 'Pengguna Pedang No.1 didunia');
INSERT INTO karyawan (id, nama, keterangan) VALUES ('3', 'Ussop', 'Penembak jitu');
INSERT INTO karyawan (id, nama, keterangan) VALUES ('4', 'Nami', 'Navigator kapal');
INSERT INTO karyawan (id, nama, keterangan) VALUES ('5', 'Tony tony Chopper', 'Dokter');
INSERT INTO karyawan (id, nama, keterangan) VALUES ('6', 'Robin', 'Arkeolog');
INSERT INTO karyawan (id, nama, keterangan) VALUES ('7', 'Sanji', 'Juru masak / koki');
INSERT INTO karyawan (id, nama, keterangan) VALUES ('8', 'Broook', 'Manusia Tengkorak');
INSERT INTO karyawan (id, nama, keterangan) VALUES ('9', 'Franky', 'Tukang Kapal');


INSERT INTO alamat (id, nama, alamat, id_karyawan) VALUES ('1', 'Malang', 'jawa timur', '1');
INSERT INTO alamat (id, nama, alamat, id_karyawan) VALUES ('2', 'Sidoarjo', 'jawa timur', '1');
INSERT INTO alamat (id, nama, alamat, id_karyawan) VALUES ('3', 'Surabaya', 'jawa timur', '1');
INSERT INTO alamat (id, nama, alamat, id_karyawan) VALUES ('4', 'Surabaya', 'jawa timur', '1');
INSERT INTO alamat (id, nama, alamat, id_karyawan) VALUES ('5', 'Surabaya', 'jawa timur', '1');
INSERT INTO alamat (id, nama, alamat, id_karyawan) VALUES ('6', 'Sidoarjo', 'jawa timur', '1');



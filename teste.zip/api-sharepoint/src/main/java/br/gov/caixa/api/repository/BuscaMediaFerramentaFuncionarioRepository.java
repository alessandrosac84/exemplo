package br.gov.caixa.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.gov.caixa.api.model.BuscaMediaFerramentaFuncionario;

public interface BuscaMediaFerramentaFuncionarioRepository extends JpaRepository<BuscaMediaFerramentaFuncionario, Long>  {
	
}

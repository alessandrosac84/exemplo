import { Token } from './../../model/token.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Login } from '../../model/login.model';

import { environment } from './../../../../environments/environment';

@Injectable()
export class AuthService {

  private token: Token;

  private loginUrl = `${environment.apiBaseUrl}api/auth/login`;

  constructor(private http: HttpClient) { }

  login(login: Login) {
    return this.http.post(`${this.loginUrl}`, login);
  }

  isAuthenticated() {

    if (localStorage.getItem('jwt')) {
      this.token = JSON.parse(atob(localStorage.getItem('jwt').split('.')[1]));
      const now = new Date;
      const dateToken = new Date(this.token.exp).getTime() * 1000;
      if (new Date(dateToken) > now) {
        return !!localStorage.getItem('jwt');
      } else {
        return false;
      }
    }
    // return !!localStorage.getItem('jwt');
  }

  logout() {
    return localStorage.removeItem('jwt');
  }
}

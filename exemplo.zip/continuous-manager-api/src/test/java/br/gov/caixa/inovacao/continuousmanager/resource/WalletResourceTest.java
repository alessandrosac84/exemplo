package br.gov.caixa.inovacao.continuousmanager.resource;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Job;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JobPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ProjectPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Wallet;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.service.BuildService;
import br.gov.caixa.inovacao.continuousmanager.service.JobService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectService;
import br.gov.caixa.inovacao.continuousmanager.service.WalletService;

/**
 * Classe de testes do WalletResource.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class WalletResourceTest {

	@Mock
	private Response response;

	@Mock
	private ResponseBuilder responseBuilder;

	@Mock
	private WalletService walletService;

	@Mock
	private ProjectService projectService;

	@Mock
	private JobService jobService;
	
	@Mock
	private BuildService buildService;

	@InjectMocks
	private WalletResource walletResource;

	private List<Wallet> wallets;

	private List<Project> projects;

	private List<Job> jobs;

	private List<Build> builds;

	@Before
	public void before() {
		wallets = new ArrayList<>();
		Wallet w = new Wallet();
		w.setId("inovacao");
		wallets.add(w);
		Wallet w2 = new Wallet();
		w2.setId("backoffice");
		wallets.add(w2);
		
		
		projects = new ArrayList<>();
		Project p = new Project();
		p.setId(new ProjectPK());
		p.getId().setId("portal-inovacao");
		p.getId().setWallet("inovacao");
		projects.add(p);
		Project p2 = new Project();
		p2.setId(new ProjectPK());
		p2.getId().setId("jenkinsman");
		p2.getId().setWallet("inovacao");
		projects.add(p2);
		
		jobs = new ArrayList<>();
		Job j = new Job();
		j.setId(new JobPK());
		j.getId().setId("portal-inovacao-ci-dev");
		j.getId().setProject("portal-inovacao");
		j.getId().setWallet("inovacao");
		jobs.add(j);
		Job j2 = new Job();
		j2.setId(new JobPK());
		j2.getId().setId("portal-inovacao-cd-tqs");
		j2.getId().setProject("portal-inovacao");
		j2.getId().setWallet("inovacao");
		jobs.add(j2);
		
		builds = new ArrayList<>();
		Build b = new Build();
		b.setId(new BuildPK());
		b.getId().setId(1);
		b.getId().setWallet("inovacao");
		b.getId().setProject("portal-inovacao");
		b.getId().setJob("portal-inovacao-ci-dev");
		builds.add(b);
		Build b2 = new Build();
		b2.setId(new BuildPK());
		b2.getId().setId(2);
		b2.getId().setWallet("inovacao");
		b2.getId().setProject("portal-inovacao");
		b2.getId().setJob("portal-inovacao-ci-dev");
		builds.add(b2);
		
		
	}

	/**
	 * Listar todas as Wallets.
	 */
	@Test
	public void testListAllWalletsDefault() {
		// Arrange
		Mockito.when(walletService.findAll(0, 30, "", "id", AscDesc.ASC)).thenReturn(wallets);
		Mockito.when(walletService.countAll("")).thenReturn((long) wallets.size());

		// Act
		Response response = walletResource.getWallets(0, 30, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertEquals("rows 0-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Listar a primeira página da lista de Sistemas
	 */
	@Test
	public void testListAllWalletsPagination() {
		// Arrange
		Mockito.when(walletService.findAll(0, 1, "", "id", AscDesc.ASC)).thenReturn(wallets.subList(0, 1));
		Mockito.when(walletService.countAll("")).thenReturn((long) wallets.size());

		// Act
		Response response = walletResource.getWallets(0, 1, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.PARTIAL_CONTENT.getStatusCode(), response.getStatus());
		assertEquals("rows 0-1/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Listar a segunda página da lista de Wallets
	 */
	@Test
	public void testListAllWalletsPaginationPage2() {
		// Arrange
		Mockito.when(walletService.findAll(1, 1, "", "id", AscDesc.ASC)).thenReturn(wallets.subList(1, 2));
		Mockito.when(walletService.countAll("")).thenReturn((long) wallets.size());

		// Act
		Response response = walletResource.getWallets(1, 1, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.PARTIAL_CONTENT.getStatusCode(), response.getStatus());
		assertEquals("rows 1-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Listar a primeira página da lista de Jobs
	 */
	@Test
	public void testListAllProjectsPagination() {
		// Arrange
		Mockito.when(projectService.findAll("inovacao", 0, 30, "", "id", AscDesc.ASC)).thenReturn(projects);
		Mockito.when(projectService.countAll("inovacao", "")).thenReturn((long) projects.size());

		// Act
		Response response = walletResource.getProjects("inovacao", 0, 30, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertEquals("rows 0-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Listar a primeira página da lista de Jobs
	 */
	@Test
	public void testListAllJobsPagination() {
		// Arrange
		Mockito.when(jobService.findAll("inovacao", "portal-inovacao", 0, 30, "", "id", AscDesc.ASC)).thenReturn(jobs);
		Mockito.when(jobService.countAll("inovacao", "portal-inovacao", "")).thenReturn((long) jobs.size());

		// Act
		Response response = walletResource.getJobs("inovacao", "portal-inovacao", 0, 30, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertEquals("rows 0-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}

	/**
	 * Listar a primeira página da lista de Builds
	 */
	@Test
	public void testListAllBuildsPagination() {
		// Arrange
		Mockito.when(buildService.findAll("inovacao", "portal-inovacao", "portal-inovacao-ci-dev", 0, 30, "", "id", AscDesc.ASC)).thenReturn(builds);
		Mockito.when(buildService.countAll("inovacao", "portal-inovacao", "portal-inovacao-ci-dev", "")).thenReturn((long) builds.size());

		// Act
		Response response = walletResource.getBuilds("inovacao", "portal-inovacao", "portal-inovacao-ci-dev", 0, 30, "", "id", AscDesc.ASC);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertEquals("rows 0-2/2", response.getHeaderString("Content-Range"));
		assertNotNull(response.getEntity());
	}
	
	@Test
	public void testGetBuildLog() {
		// Arrange
		Mockito.when(buildService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt())).thenReturn("log ypsilon\nbuild 42");
		String carteira = "inovacao";
		String projeto = "sharepoint";
		String job = "sharepoint-api-cd-tqs";
		int build = 2;

		// Act
		Response response = walletResource.getLog(carteira, projeto, job, build);

		// Then
		assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
		assertNotNull(response.getEntity());
	}
}

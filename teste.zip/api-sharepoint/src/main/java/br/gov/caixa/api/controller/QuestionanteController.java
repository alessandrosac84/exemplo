package br.gov.caixa.api.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.dto.QuestionanteDto;
import br.gov.caixa.api.result.QuestionanteResult;
import br.gov.caixa.api.services.QuestionanteService;

@RestController
public class QuestionanteController {
	
	@Inject
	QuestionanteService service;
	
	@RequestMapping(value="/api/questionante/save", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public QuestionanteResult save(@RequestBody QuestionanteDto dto) {
		return service.save(dto);
	}
	
	@RequestMapping(value="/api/questionante/saveList", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public QuestionanteResult save(@RequestBody List<QuestionanteDto> dto) {
		return service.saveList(dto);
	}
	
	@RequestMapping(value="/api/questionante/delete/{id}", method=RequestMethod.POST,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public QuestionanteResult delte(@PathVariable Long id) {
		return service.delete(id);
	}
	
	@RequestMapping(value="/api/questionante/get/{id}", method=RequestMethod.GET,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public QuestionanteResult get(@PathVariable Long id) {
		return service.getOne(id);
	}
	
	@RequestMapping(value="/api/questionante/getAll", method=RequestMethod.GET,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public QuestionanteResult getAll() {
		return service.getAll();
	}
	
	@RequestMapping(value="/api/questionante/getByQuestionario/{id}", method=RequestMethod.GET,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public QuestionanteResult getByQuestionario(@PathVariable Long id) {
		return service.getByQuestionario(id);
	}
	
	@RequestMapping(value="/api/questionante/getByFuncionario/{id}", method=RequestMethod.GET,  produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public QuestionanteResult getByFuncionario(@PathVariable Long id) {
		return service.getByFuncionario(id);
	}	
}

package br.gov.caixa.api.dto;

import br.gov.caixa.api.model.FeedbackMedia;

public class FeedbackMediaDto {

	private Double qualidadeInfoMaterial;
	private Double duracao;
	private Double desempenhoConhecimentoInstrautor;
	private Double satisfacaoGeral;
	private Long turmaId;
		
	public Double getQualidadeInfoMaterial() {
		return qualidadeInfoMaterial;
	}

	public void setQualidadeInfoMaterial(Double qualidadeInfoMaterial) {
		this.qualidadeInfoMaterial = qualidadeInfoMaterial;
	}

	public Double getDuracao() {
		return duracao;
	}

	public void setDuracao(Double duracao) {
		this.duracao = duracao;
	}

	public Double getDesempenhoConhecimentoInstrautor() {
		return desempenhoConhecimentoInstrautor;
	}

	public void setDesempenhoConhecimentoInstrautor(Double desempenhoConhecimentoInstrautor) {
		this.desempenhoConhecimentoInstrautor = desempenhoConhecimentoInstrautor;
	}

	public Double getSatisfacaoGeral() {
		return satisfacaoGeral;
	}

	public void setSatisfacaoGeral(Double satisfacaoGeral) {
		this.satisfacaoGeral = satisfacaoGeral;
	}
	
	public Long getTurmaId() {
		return turmaId;
	}

	public void setTurmaId(Long turmaId) {
		this.turmaId = turmaId;
	}

	public static FeedbackMediaDto fromFeedbackMediaToDto(FeedbackMedia feedbackMedia) {
		FeedbackMediaDto dto = new FeedbackMediaDto();
				
		dto.setQualidadeInfoMaterial(feedbackMedia.getQualidadeInfoMaterial());
		dto.setDuracao(feedbackMedia.getDuracao());
		dto.setDesempenhoConhecimentoInstrautor(feedbackMedia.getDesempenhoConhecimentoInstrautor());
		dto.setSatisfacaoGeral(feedbackMedia.getSatisfacaoGeral());
		dto.setTurmaId(feedbackMedia.getTurmaId());
		return dto;
	}
	
//	public static List<FeedbackMediaDto> fromFeedbackMediaToListDto(List<FeedbackMedia> listaFeedbackMedia) {
//	
//		List<FeedbackMediaDto> listResult = new ArrayList<FeedbackMediaDto>();
//		for (FeedbackMedia feedbackMedia : listaFeedbackMedia) {
//			listResult.add(fromFeedbackMediaToDto(feedbackMedia));
//		}
//		return listResult;
//		
//	}
	
	
}
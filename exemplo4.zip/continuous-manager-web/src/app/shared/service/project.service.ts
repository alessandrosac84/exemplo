import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { Repository } from '../model/entity/repository.model';
import { Branch } from '../model/entity/branch.model';
import { Project } from '../model/entity/project.model';
import { Build } from '../model/entity/build.model';
import { Stage } from '../model/vo/stage.model';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private http: HttpClient) {}

  getProjects(): Observable<Project[]> {
    return this.http.get<Project[]>('../../../assets/file/projects.json');
  }

  getProject(project: number): Observable<Project> {
    return this.http.get<Project>('../../../assets/file/project.json');
  }

  getRepositories(project: number): Observable<Repository[]> {
    return this.http.get<Repository[]>('../../../assets/file/repositories.json');
  }

  getRepository(project: number, repository: string): Observable<Repository> {
    return this.http.get<Repository>('../../../assets/file/repository.json');
  }

  getBuild(project: number, repository: string, build: number): Observable<Build> {
    return this.http.get<Build>('../../../assets/file/build.json');
  }

  getBuilds(project: number, repository: string): Observable<Build[]> {
    return this.http.get<Build[]>('../../../assets/file/builds.json');
  }

  getBuildLogStages(project: number, repository: string, build: number): Observable<Stage[]> {
    return this.http.get<Stage[]>('../../../assets/file/build-log.json');
  }

  getBranch(project: number, repository: string, branch: string): Observable<Branch> {
    return this.http.get<Branch>('../../../assets/file/branch.json');
  }

  getBranches(project: number, repository: string): Observable<Branch[]> {
    return this.http.get<Branch[]>('../../../assets/file/branches.json');
  }
}

package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.model.views.EspecialidadeProcessoView;
import br.gov.caixa.api.repository.views.EspecialidadeProcessoViewRepository;
import br.gov.caixa.api.result.views.EspecialidadeProcessoViewResult;

@Named
public class EspecialidadeProcessoViewService {
	
	@Inject
	EspecialidadeProcessoViewRepository repository;
	
	public EspecialidadeProcessoViewResult listAll() {

		EspecialidadeProcessoViewResult result = new EspecialidadeProcessoViewResult();
		try {
			List<EspecialidadeProcessoView> lista = repository.findAll();

			if (lista != null) {
				result.setList(lista);
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma especialidadeProcessoView.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}
	
	public EspecialidadeProcessoViewResult listEspecialidadeProcessoViewsByIdEspecialidade(Long idEspecialidade) {
		EspecialidadeProcessoViewResult result = new EspecialidadeProcessoViewResult();
		try {
						
			List<EspecialidadeProcessoView> lista = repository.findByEspecialidadeId(idEspecialidade);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Processo para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

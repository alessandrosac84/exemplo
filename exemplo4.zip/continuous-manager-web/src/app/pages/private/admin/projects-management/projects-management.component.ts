import { Component, OnInit, Inject } from '@angular/core';
import { ProjectService } from '../../../../shared/service/project.service';
import { MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material';
import { Project } from '../../../../shared/model/entity/project.model';
import { AddProjectComponent } from './add-project/add-project.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'cm-projects-management',
  templateUrl: './projects-management.component.html',
  styleUrls: ['./projects-management.component.scss']
})
export class ProjectsManagementComponent implements OnInit {

  dataSource: any;
  lengthList: number;
  displayedColumns: string[] = [
    'carteira',
    'sistema',
    'coordenacao',
    'descricao'
  ];

  constructor(private _projectService: ProjectService, public dialog: MatDialog, private _router: Router,
    private _activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this._projectService.getProjects().subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
      this.lengthList = data.length;
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  openAddProject() {
    this._router.navigate(['add'], { relativeTo: this._activatedRoute });
    }
}


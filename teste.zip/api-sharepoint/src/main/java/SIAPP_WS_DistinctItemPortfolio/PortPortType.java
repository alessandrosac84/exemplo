/**
 * PortPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package SIAPP_WS_DistinctItemPortfolio;

public interface PortPortType extends java.rmi.Remote {
    public SIAPP_WS_DistinctItemPortfolio.OutputMapping5GetListValues[] getList(java.lang.String qualification, java.lang.String startRecord, java.lang.String maxLimit) throws java.rmi.RemoteException;
}

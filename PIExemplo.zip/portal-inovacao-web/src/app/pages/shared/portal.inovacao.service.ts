import { Sistema } from './model/sistema';
import { Transacao } from './model/transacao';
import { Observable } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Http, Response, Headers } from '@angular/http';

import { environment } from '../../../environments/environment';

@Injectable()
export class PortalInovacaoService {

    private solicitacaoUrl = `${environment.apiBaseUrl}solicitacao-transacao`;
    private sistemaUrl = `${environment.apiSharepointBaseUrl}ativo/tipo-ativo/1`;
    private listaSistemas: Sistema[] = [];

    constructor(private http: HttpClient) { }


    send(transacao: Transacao): Observable<any> {
        return this.http.post(`${this.solicitacaoUrl}/send`, transacao,
            { responseType: 'text' });
    }


    getSistemasUnico(): Sistema[] {
        if (this.listaSistemas.length === 0) {
            this.getSistemas().subscribe(data => {
                if (data.length > 0) {
                    data.forEach(element => {
                        this.listaSistemas.push(element);
                    });
                }
            });
        }
        return this.listaSistemas;
    }

    private getSistemas(): Observable<any> {
        return this.http.get<Sistema[]>(this.sistemaUrl);
    }
}




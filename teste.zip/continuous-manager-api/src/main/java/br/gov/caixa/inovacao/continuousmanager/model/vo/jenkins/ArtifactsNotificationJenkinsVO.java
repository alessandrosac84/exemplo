package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;

/**
 * Classe de representação do Artifacts de Notificacao do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class ArtifactsNotificationJenkinsVO implements Serializable {

	private static final long serialVersionUID = 1390312400679365357L;

}

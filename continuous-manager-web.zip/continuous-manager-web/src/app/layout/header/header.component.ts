import { Component, OnInit, Input } from '@angular/core';

import { KeycloakService } from '../../core/keycloak/keycloak.service';
import { EventItem } from '../../core/keycloak/keycloak-event';


@Component({
  selector: 'cm-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  logged = false;

  constructor(
    private _keyCloakService: KeycloakService
  ) {}

  ngOnInit() { }

  login() {
    this._keyCloakService.login();
  }

  logout() {
    this._keyCloakService.logout(window.location.origin + '/log');
  }

  @Input()
  set keycloakEvent(event: EventItem) {
    if (event) {
      this.logged = event.event.args.authenticated;
    }
  }
}

package br.gov.caixa.inovacao.continuousmanager.config.filter.response;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Priority;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.Context;
import javax.ws.rs.ext.Provider;

@Provider
@Priority(Priorities.AUTHENTICATION)
public class TokenResponseFilter implements ContainerResponseFilter {

	@Context
	private HttpServletRequest request;
	
	@Context
	private HttpServletResponse response;

	@SuppressWarnings("unchecked")
	@Override
	public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext)
			throws IOException {
		Logger log = Logger.getLogger(this.getClass().getName());
		log.fine("Executando Token Response Filter... ");
		
		if (requestContext.getMethod().equalsIgnoreCase("OPTIONS")) {
			responseContext.setStatus(200);
			return;
		}

		try {
			if (request.getAttribute("jwt") != null) {
				responseContext.getHeaders().put("jwt", (List<Object>) request.getAttribute("jwt"));
			}
			
			request.getSession().invalidate();
			request.logout();
		} catch (ServletException e) {
			log.log(Level.SEVERE, "Erro executando Response Filter... ", e);
		}
	}
}

package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

public enum TypeServer {
	APRESENTACAO("Apresentação"), APLICACAO("Aplicação");

	private String description;

	private TypeServer(String description) {
		this.description = description;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
}

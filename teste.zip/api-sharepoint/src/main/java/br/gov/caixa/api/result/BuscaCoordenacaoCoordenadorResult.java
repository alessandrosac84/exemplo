package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.BuscaCoordenacaoCoordenadorDto;

public class BuscaCoordenacaoCoordenadorResult extends BasicResult {

	private List<BuscaCoordenacaoCoordenadorDto> list;
	private BuscaCoordenacaoCoordenadorDto buscaCoordenacaoCoordenadorDto;

	public List<BuscaCoordenacaoCoordenadorDto> getList() {
		return list;
	}

	public void setList(List<BuscaCoordenacaoCoordenadorDto> list) {
		this.list = list;
	}

	public BuscaCoordenacaoCoordenadorDto getBuscaCoordenacaoCoordenadorDto() {
		return buscaCoordenacaoCoordenadorDto;
	}

	public void setBuscaCoordenacaoCoordenadorDto(
			BuscaCoordenacaoCoordenadorDto buscaCoordenacaoCoordenadorDto) {
		this.buscaCoordenacaoCoordenadorDto = buscaCoordenacaoCoordenadorDto;
	}

}

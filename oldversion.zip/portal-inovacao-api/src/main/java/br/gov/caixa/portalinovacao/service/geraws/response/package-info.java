@javax.xml.bind.annotation.XmlSchema(namespace = "http://caixa.gov.br/geraws/response", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED, 
attributeFormDefault=javax.xml.bind.annotation.XmlNsForm.UNQUALIFIED)
package br.gov.caixa.portalinovacao.service.geraws.response;

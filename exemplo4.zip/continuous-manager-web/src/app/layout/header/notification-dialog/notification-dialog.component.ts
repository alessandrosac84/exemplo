import { Component, OnInit, Inject } from '@angular/core';
import { Notification } from '../../../shared/model/entity/notification.model';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'cm-notification-dialog',
  templateUrl: './notification-dialog.component.html',
  styleUrls: ['./notification-dialog.component.scss']
})
export class NotificationDialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<NotificationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public notifications: Notification[],
    private _router: Router) { }

  ngOnInit() { }

  remove(notification) {
    this.notifications.splice(this.notifications.indexOf(notification), 1);
    if (this.notifications.length === 0 ) {
      this.dialogRef.close();
    }
  }

  close() {
    this.dialogRef.close();
  }

  redirect(notification) {
    this.remove(notification);
    this.dialogRef.close();
    this._router.navigateByUrl(notification.url);
  }

  getClassSideDiv(result) {
    switch (result) {
      case 'SUCCESS':
        return 'passed';
      case 'FAILURE':
        return 'not-passed';
      default:
        return 'not-compiled';
    }
  }
}

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.rest;

import static org.junit.Assert.*;

import org.junit.Test;

import br.gov.caixa.inovacao.continuousmanager.config.rest.JaxRsActivator;

/**
 * @author Fabio Iwakoshi
 *
 */
public class JaxRsActivatorTest {

	@Test
	public void testCreateJaxRsActivator() {
		assertNotNull(new JaxRsActivator());
	}

}

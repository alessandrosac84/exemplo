package br.gov.caixa.inovacao.continuousmanager.model.entity.job;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-04-16T16:54:49.568-0300")
@StaticMetamodel(JobPK.class)
public class JobPK_ {
	public static volatile SingularAttribute<JobPK, String> id;
	public static volatile SingularAttribute<JobPK, String> wallet;
	public static volatile SingularAttribute<JobPK, String> project;
}

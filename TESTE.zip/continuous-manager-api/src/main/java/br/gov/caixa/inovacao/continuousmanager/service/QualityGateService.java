package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.QualityGate;
import br.gov.caixa.inovacao.continuousmanager.model.entity.QualityGatePK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.QualityGateRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.ConditionsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.QualityGateVO;

/**
 * Classe de servicos do Quality Gate.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class QualityGateService {

	@Inject
	private Logger log;
	
	@Inject
	private QualityGateRepository qualityGateRepository;
	
	public void save(String wallet, String project, String commit, QualityGate qualityGate) {
		log.fine("Salvando quality Gate do sonar");
			qualityGateRepository.save(qualityGate);
	}
	
	public void saveAll(String wallet, String project, String commit, QualityGateVO qualityGateVO) {
		log.fine("Salvando quality Gate do sonar");
		
		for (ConditionsVO condition : qualityGateVO.getProjectStatus().getConditions()) {
			QualityGate qualityGate = new QualityGate();
			qualityGate.setId(new QualityGatePK());
			qualityGate.getId().setWallet(wallet);
			qualityGate.getId().setProject(project);
			qualityGate.getId().setCommit(commit);
			qualityGate.getId().setMetricKey(condition.getMetricKey());
			
			qualityGate.setActualValue(condition.getActualValue());
			qualityGate.setComparator(condition.getComparator());
			qualityGate.setErrorThreshold(condition.getErrorThreshold());
			qualityGate.setPeriodIndex(condition.getPeriodIndex());
			qualityGate.setStatus(condition.getStatus());

			save(wallet, project, commit, qualityGate);
		}
		
	}
}

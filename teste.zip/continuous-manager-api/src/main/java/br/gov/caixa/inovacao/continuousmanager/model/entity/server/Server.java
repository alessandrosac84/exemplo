package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;

import java.util.Set;


/**
 * The persistent class for the server database table.
 * 
 */
@Entity
@Table(name="server")
@NamedQuery(name="Server.findAll", query="SELECT s FROM Server s")
public class Server implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	@Column(unique=true, nullable=false, length=15)
	private String ip;

	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	@Column(nullable=false, length=50)
	private String dns;
	
	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	@Enumerated(EnumType.STRING)
	@Column(nullable=false, length=3)
	private Environment environment;

	//bi-directional many-to-one association to Instance
	@JsonIgnore
	@OneToMany(mappedBy="server", fetch = FetchType.LAZY)
	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	private Set<Instance> instances;

	//bi-directional many-to-one association to Flavor
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	@JoinColumn(name="flavor", nullable=false)
	private Flavor flavor;

	//bi-directional many-to-one association to VirtualIp
	@JsonView({ViewJson.JenkisfileView.class})
	@OneToMany(mappedBy="server", fetch = FetchType.LAZY)
	private Set<VirtualIp> virtualIps;

	public Server() {
		/* class constructor intentionally left blank */
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getDns() {
		return this.dns;
	}

	public void setDns(String dns) {
		this.dns = dns;
	}

	public Set<Instance> getInstances() {
		return this.instances;
	}

	public void setInstances(Set<Instance> instances) {
		this.instances = instances;
	}

	public Flavor getFlavor() {
		return this.flavor;
	}

	public void setFlavor(Flavor flavor) {
		this.flavor = flavor;
	}

	public Set<VirtualIp> getVirtualIps() {
		return this.virtualIps;
	}

	public void setVirtualIps(Set<VirtualIp> virtualIps) {
		this.virtualIps = virtualIps;
	}

}
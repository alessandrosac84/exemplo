package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

public enum Comparator {
	GT, LT
}

import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse
} from '@angular/common/http';

import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor() {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      tap(
        event => {},
        error => {
          console.log(error);
          if (error instanceof HttpErrorResponse) {
            switch (error.status) {
              case 500:
                console.log(error.error.messages[0]);
                // this._toastr.error(error.error.messages[0], '');
                break;

              case 504:
                console.log('Não foi possível obter uma comunicação com o servidor!');
                // this._toastr.error('Não foi possível obter uma comunicação com o servidor!', '');
                break;

              case 401:
                console.log('Login ou senha inválido!');
                // this._toastr.error('Login ou senha inválido!', '');
                break;

              case 403:
                console.log('Sessão inválida e/ou sem autorização de acesso!');
                // this._toastr.error('Sessão inválida e/ou sem autorização de acesso!', '');
                break;

              case 400:
                error.error.messages.forEach(message => {
                  console.log(message);
                  // this._toastr.error(message, 'Inválido!');
                });
                break;

              default:
                if (error.status > 500) {
                  console.log(error.error.messages[0]);
                  // this._toastr.error(error.error.messages[0], '');
                }
                break;
            }
          }
        }
      )
    );
  }
}

package br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Project;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.Comparator;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-12T11:31:14.111-0300")
@StaticMetamodel(QualityGate.class)
public class QualityGate_ {
	public static volatile SingularAttribute<QualityGate, QualityGatePK> id;
	public static volatile SingularAttribute<QualityGate, Comparator> comparator;
	public static volatile SingularAttribute<QualityGate, String> errorThreshold;
	public static volatile SingularAttribute<QualityGate, Project> project;
}

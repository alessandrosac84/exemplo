
export class Environment {
    public id: { wallet: string, project: string, job: string, environment: string, build: number };

}

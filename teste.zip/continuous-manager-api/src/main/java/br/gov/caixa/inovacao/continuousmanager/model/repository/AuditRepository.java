package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Audit;

/**
 * Classe de acesso ao banco de dados da entidade Audit.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class AuditRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Salva carteira
	 * 
	 * @param audit
	 * @return wallet
	 */
	public Audit save(Audit audit) {
		entityManager.persist(audit);
		return audit;
	}
}

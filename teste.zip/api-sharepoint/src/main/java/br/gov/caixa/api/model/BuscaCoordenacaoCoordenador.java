package br.gov.caixa.api.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the busca_funcionario_coordencao database table.
 * 
 */
@Entity
@Table(name="busca_coordenacao_coordenador")
@NamedQuery(name="BuscaCoordenacaoCoordenador.findAll", query="SELECT b FROM BuscaCoordenacaoCoordenador b order by b.tipo asc")
public class BuscaCoordenacaoCoordenador implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BuscaCoordenacaoCoordenadorId buscaCoordenacaoCoordenadorId;
	
	public BuscaCoordenacaoCoordenadorId getBuscaCoordenacaoCoordenadorId() {
		return buscaCoordenacaoCoordenadorId;
	}
	
	public void setBuscaCoordenacaoCoordenadorId(BuscaCoordenacaoCoordenadorId buscaCoordenacaoCoordenadorId) {
		this.buscaCoordenacaoCoordenadorId = buscaCoordenacaoCoordenadorId;
	}

	@Column(name="coordenacao_id", nullable=false, insertable=false, updatable=false)
	private Long coordenacaoId;
	
	private Long parent_Id;	
	private Long funcionario_Id;		
	private String titulo;	
	private String matricula;
	private String nome;
	private String cargo;
	private Integer tipo;

	public BuscaCoordenacaoCoordenador() {
		
	}	

	public Long getCoordenacaoId() {
		return this.coordenacaoId;
	}

	public void setCoordenacaoId(Long coordenacaoId) {
		this.coordenacaoId = coordenacaoId;
	}

	public Long getFuncionarioId() {
		return this.funcionario_Id;
	}

	public void setFuncionarioId(Long funcionarioId) {
		this.funcionario_Id = funcionarioId;
	}
	
	public String getMatricula() {
		return this.matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Long getParentId() {
		return parent_Id;
	}

	public void setParentId(Long parentId) {
		this.parent_Id = parentId;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	
	public Integer getTipo() {
		return tipo;
	}

	public void setTipo(Integer tipo) {
		this.tipo = tipo;
	}



}

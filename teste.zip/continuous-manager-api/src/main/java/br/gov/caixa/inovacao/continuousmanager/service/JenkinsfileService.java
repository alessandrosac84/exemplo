/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.net.URLDecoder;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ProjectBranch;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;

/**
 * Classe de servicos de Job.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class JenkinsfileService {

	@Inject
	private Logger log;

	@Inject
	private ProjectBranchService projectBranchService;
	
	@Inject
	private ParameterService parameterService;

	public ProjectBranch getJenkinsfile(String repository, Environment environment, String branch) {
		log.log(Level.FINE, "Obtendo informações do repository {0} e branch {1} para {2}", new Object[] {repository, branch, environment});

		ParameterPK parameterId = new ParameterPK();
		parameterId.setEnvironment(environment);
		parameterId.setServerType(ServerType.JENKINS);

		Parameter parameter = parameterService.findById(parameterId);

		if (parameter == null || !parameter.getHost().contains(HelperThreadLocal.IP.get())) {
			throw new NotFoundException("Erro ao obter informação do sistema!");
		}
		
		try {
			repository = URLDecoder.decode(repository, "UTF-8");
		} catch (Exception e) {
			throw new NotFoundException("Não foi possível identificar o repositório!");
		}
		
		ProjectBranch current = projectBranchService.findByRepository(repository, environment, branch);
		
		if (current != null) {
			return current;
		}
		throw new NotFoundException("Não foi possível encontrar o Projeto solicitado!");
	}
}

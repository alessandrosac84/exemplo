import { Build } from './build.model';
export class ViewCommitsBuilds {
    public id_commit: string;
    public id_short_commit: string;
    public author_commit: string;
    public message_commit: string;
    public author_email_commit: string;
    public committed_date_commit: Date;
    public build_number: number;
    public status_build: string;
    public data_hora_build: Date;
    public versao_release_build: string;
    public list_view_builds: Build[];
}

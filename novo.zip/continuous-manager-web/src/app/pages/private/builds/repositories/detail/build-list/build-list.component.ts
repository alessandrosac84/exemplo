import { Component, OnInit, Input } from '@angular/core';
import { Branch } from '../../../../../../shared/model/entity/branch.model';
import { ProjectService } from '../../../../../../shared/service/project.service';
import { Observable } from 'rxjs';
import { Build } from '../../../../../../shared/model/entity/build.model';
import { ActivatedRoute } from '@angular/router';
import { Repository } from '../../../../../../shared/model/entity/repository.model';

@Component({
  selector: 'cm-build-list',
  templateUrl: './build-list.component.html',
  styles: []
})
export class BuildListComponent implements OnInit {

  @Input() branch: Branch;

  builds$: Observable<Build[]>;
  repository: Repository;

  constructor(
    private _projectService: ProjectService,
    private _activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.builds$ = this._projectService.getBuilds(+localStorage.getItem('project'), this.branch.id.id);
    this._projectService.getRepository(+localStorage.getItem('project'), this._activatedRoute.snapshot.params['repository'])
        .subscribe(data => this.repository = data);
  }

  getClassSideDiv(build: Build) {
    switch (build.result) {
      case 'SUCCESS':
        return 'passed';
      case 'FAILURE':
        return 'not-passed';
      default:
        return 'not-compiled';
    }
  }
}

import { Build } from './../../../shared/model/build.model';
import { Stage } from './../../../shared/model/stage.model';
import { Step } from './../../../shared/model/step.model';
import { Wallet } from './../../../shared/model/wallet.model';
import { Title } from '@angular/platform-browser';
import { JenkinsService } from './../../../shared/service/jenkins.service';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jmw-jenkins',
  templateUrl: './jenkins.component.html',
  styleUrls: ['./jenkins.component.scss']
})
export class JenkinsComponent implements OnInit {
  pageTitle = 'Log View';

  logStages: Stage[];
  navTab: string;
  stageSelect: Stage;
  open: Boolean = true;
  walletId: string;
  projectId: string;
  jobId: string;
  buildId: number;

  buildSelected: Build;

  constructor(private route: ActivatedRoute,
    private router: Router, private title: Title,
    private jenkinsService: JenkinsService) {
  }

  ngOnInit() {
    this.title.setTitle(this.pageTitle);

    this.walletId = this.route.snapshot.paramMap.get('wallet');
    this.projectId = this.route.snapshot.paramMap.get('project');
    this.jobId = this.route.snapshot.paramMap.get('job');
    this.buildId = Number(this.route.snapshot.paramMap.get('build'));

    this.jenkinsService.geDetailtBuild(this.walletId, this.projectId, this.jobId, this.buildId).subscribe(data => {
      this.buildSelected = data;
    });

    this.jenkinsService.getLogStages(this.walletId, this.projectId, this.jobId, this.buildId).subscribe(data => {
      this.logStages = data;

      this.goToTab(this.logStages[this.logStages.length - 1]);
    });

  }

  goToTab(stage: Stage) {
    this.stageSelect = null;
    this.stageSelect = stage;

    this.stageSelect.steps.forEach(step => {
      step.openStep = true;
    });
  }

  openStep(step: Step) {
    if (step.openStep === true) {
      step.openStep = false;
    } else {
      step.openStep = true;
    }
  }
}

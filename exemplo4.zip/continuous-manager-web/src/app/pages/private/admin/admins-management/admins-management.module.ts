import { NgModule } from '@angular/core';

import { AdminsManagementRoutingModule } from './admins-management-routing.module';
import { SharedModule } from '../../../../shared/shared.module';

import { AdminsManagementComponent } from './admins-management.component';

@NgModule({
  imports: [
    SharedModule,
    AdminsManagementRoutingModule,
  ],
  declarations: [AdminsManagementComponent]
})
export class AdminsManagementModule { }

package br.gov.caixa.inovacao.continuousmanager.model.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * Classe de representação dos Stages do Build
 * 
 * @author Fabio Iwakoshi
 *
 */
public class Stage {

	@JsonView(ViewJson.LogStageView.class)
	private String name;
	
	@JsonView(ViewJson.LogStageView.class)
	private List<Step> steps;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the steps
	 */
	public List<Step> getSteps() {
		return steps;
	}

	/**
	 * @param steps the steps to set
	 */
	public void setSteps(List<Step> steps) {
		this.steps = steps;
	}
	
}

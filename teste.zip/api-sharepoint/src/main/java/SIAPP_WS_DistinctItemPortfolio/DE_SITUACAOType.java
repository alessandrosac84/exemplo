/**
 * DE_SITUACAOType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package SIAPP_WS_DistinctItemPortfolio;

public class DE_SITUACAOType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected DE_SITUACAOType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _Desenvolvimento = "Desenvolvimento";
    public static final java.lang.String _Homologacao = "Homologacao";
    public static final java.lang.String _Producao = "Producao";
    public static final DE_SITUACAOType Desenvolvimento = new DE_SITUACAOType(_Desenvolvimento);
    public static final DE_SITUACAOType Homologacao = new DE_SITUACAOType(_Homologacao);
    public static final DE_SITUACAOType Producao = new DE_SITUACAOType(_Producao);
    public java.lang.String getValue() { return _value_;}
    public static DE_SITUACAOType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        DE_SITUACAOType enumeration = (DE_SITUACAOType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static DE_SITUACAOType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DE_SITUACAOType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_SITUACAOType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}

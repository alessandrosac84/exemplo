package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.ProjectEnvironment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.ProjectEnvironmentPK;

/**
 * Classe de acesso ao banco de dados da entidade Project Environment.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class ProjectEnvironmentRepository {

	@Inject
	private EntityManager entityManager;

	public ProjectEnvironment save(ProjectEnvironment projectEnvironment) {
		entityManager.persist(projectEnvironment);
		return projectEnvironment;
	}

	public ProjectEnvironment findById(ProjectEnvironmentPK id) {
		return entityManager.find(ProjectEnvironment.class, id);
	}

	/**
	 * Lista ultima versão do projeto por Enviroment
	 * 
	 * @return ultimo versão do projeto por enviroment
	 */
	public ProjectEnvironment findByEnviroment(String wallet, String project, Environment environment) {
		return entityManager
				.createQuery(
						"SELECT p FROM ProjectEnvironment p WHERE p.createdAt = (SELECT MAX(px.createdAt) from ProjectEnvironment px "
								+ "WHERE px.id.wallet = p.id.wallet AND px.id.project = p.id.project AND px.id.environment = p.id.environment) "
								+ "AND p.id.wallet =:wallet AND p.id.project =:project AND p.id.environment =:environment)",
						ProjectEnvironment.class)
				.setParameter("wallet", wallet).setParameter("project", project)
				.setParameter("environment", environment).getSingleResult();
	}
}

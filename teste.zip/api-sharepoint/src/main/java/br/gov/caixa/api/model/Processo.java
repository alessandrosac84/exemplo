package br.gov.caixa.api.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.gov.caixa.api.dto.ProcessoDto;

@Entity
@Table(name = "processo")
public class Processo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "nome")
	private String nome;
	
	@Column(name = "ATIVO", columnDefinition = "boolean default true")
	private Boolean ativo;
	
	@ManyToOne
	@JoinColumn(name = "CATEGORIA_PROCESSO_ID")
	private CategoriaProcesso categoriaProcesso;
	
	@OneToMany(mappedBy="processo", cascade=CascadeType.REMOVE, orphanRemoval=true )
    private Set<RatingProcesso> ratingProcessos = new HashSet<RatingProcesso>();

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

	public CategoriaProcesso getCategoriaProcesso() {
		return categoriaProcesso;
	}

	public void setCategoriaProcesso(CategoriaProcesso categoriaProcesso) {
		this.categoriaProcesso = categoriaProcesso;
	}
	
	public static Processo fromDtoToProcesso(ProcessoDto dto){
		Processo processo = new Processo();
		processo.setUid(dto.getUid());
		processo.setNome(dto.getNome());
		processo.setAtivo(dto.getAtivo());
		
		if(dto.getCategoriaProcesso() != null){
			processo.setCategoriaProcesso(CategoriaProcesso.fromDtoToCategoriaProcesso(dto.getCategoriaProcesso()));
		}
		return processo;
	}
}

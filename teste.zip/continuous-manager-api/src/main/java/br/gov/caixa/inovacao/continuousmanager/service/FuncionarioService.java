package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sharepoint.FuncionarioSharepointVO;

/**
 * Classe de servicos de Funcionário.
 * 
 * @author Alessandro Carvalho
 *
 */

@Logged
@Stateless
public class FuncionarioService {
	
	@Inject
	private Logger log;

	@Inject
	private LdapService ldapService;
	
	public List<FuncionarioSharepointVO> findById(String filter) {
		log.fine("Finding Funcionario :: " + filter);
		
		List<FuncionarioSharepointVO> current = ldapService.getUser(filter);

		return current;
	}
}

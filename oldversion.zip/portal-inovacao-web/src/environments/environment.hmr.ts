export const environment = {
  production: false,
  apiBaseUrl: 'https://localhost:8443/portal-inovacao-api/api/',
  apiSharepointBaseUrl: 'https://10.116.82.90/sharepoint-api/api/',
  hmr: true
};

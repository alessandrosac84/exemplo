package br.gov.caixa.api.dto;

import java.util.List;

import br.gov.caixa.api.model.StatusParticipante;
import br.gov.caixa.api.model.TipoTreinamento;

public class MailContentDto {	
	
	private List<String> mail;	
	private StatusParticipante status;
	private String nomeTreinamento;
	private TipoTreinamento tipoTreinamento;
	private TurmaDto turma;
		
	public List<String> getMail() {
		return mail;
	}
	public void setMail(List<String> mail) {
		this.mail = mail;
	}
	public StatusParticipante getStatus() {
		return status;
	}
	public void setStatus(StatusParticipante status) {
		this.status = status;
	}	
	public String getNomeTreinamento() {
		return nomeTreinamento;
	}
	public void setNomeTreinamento(String nomeTreinamento) {
		this.nomeTreinamento = nomeTreinamento;
	}	
	public TipoTreinamento getTipoTreinamento() {
		return tipoTreinamento;
	}
	public void setTipoTreinamento(TipoTreinamento tipoTreinamento) {
		this.tipoTreinamento = tipoTreinamento;
	}
	public TurmaDto getTurma() {
		return turma;
	}
	public void setTurma(TurmaDto turma) {
		this.turma = turma;
	}	
		
}

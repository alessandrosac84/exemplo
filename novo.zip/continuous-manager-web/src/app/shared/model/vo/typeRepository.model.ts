
export class TypeRepository {
    public name: string;
    public value: number;
}

/**
 * 
 */
package br.gov.caixa.sharepoint.config.security.token;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.annotation.Priority;
import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.MalformedClaimException;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;
import org.jose4j.lang.JoseException;

import br.gov.caixa.sharepoint.config.security.subject.Principal;
import br.gov.caixa.sharepoint.config.security.subject.PrincipalThreadLocal;
import br.gov.caixa.sharepoint.model.entity.Funcionalidade;
import br.gov.caixa.sharepoint.model.entity.Url;
import br.gov.caixa.sharepoint.model.entity.UrlFuncionalidade;
import br.gov.caixa.sharepoint.resource.AuthenticationResource;
import br.gov.caixa.sharepoint.service.FuncionalidadeService;
import br.gov.caixa.sharepoint.service.UrlService;

/**
 * @author Fabio Iwakoshi
 *
 */
@Provider
@Priority(Priorities.AUTHENTICATION)
public class JWTRequestFilter implements ContainerRequestFilter {

	private static Logger log;

	@Context
	private ResourceInfo resourceInfo;

	@Context
	private HttpServletRequest servletRequest;

	@SuppressWarnings("unchecked")
	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		log = Logger.getLogger(this.getClass().getName());
		log.fine("Executando Request Filter... ");

		Method method = resourceInfo.getResourceMethod();

		// Bloqueio basico de Roles - RolesAllowed annotation esta bloqueada pois deve
		// ser feito pelo sistema
		if ((resourceInfo.getResourceClass().isAnnotationPresent(DenyAll.class)
				&& method.isAnnotationPresent(RolesAllowed.class) == false
				&& method.isAnnotationPresent(PermitAll.class) == false) || method.isAnnotationPresent(DenyAll.class)
				|| method.isAnnotationPresent(RolesAllowed.class)) {
			log.log(Level.SEVERE, "Recurso sem autorizacao");
			requestContext.setProperty("auth-failed", true);
			requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
		}

		// Obtendo JWT
		String authHeader = requestContext.getHeaderString("Authorization2");
		if (authHeader != null && authHeader.startsWith("Bearer")) {
			try {
				log.fine("JWT a ser testada:\n" + authHeader);
				final Principal principal = validate(authHeader);
				if (principal.getUsername() != null) {
					principal.setIp(servletRequest.getRemoteAddr());
					PrincipalThreadLocal.USER.set(principal);
				}

				// Check Path and Method
				if (requestContext.getUriInfo().getPath().replaceAll("^/+|\\{|:.*\\}|/+$", "").matches(getPath())
						&& requestContext.getMethod()
								.equals(checkMethodHttp(method, POST.class, PUT.class, GET.class, DELETE.class))) {
					// Checar se a URL é aberta
					UrlService urlService = ((UrlService) new InitialContext().lookup("java:comp/UrlService"));
					List<Url> urls = urlService.findByFree();
					for (Url url : urls) {
						if (url.getUrl().equals(getPath()) && url.getMetodo()
								.equals(checkMethodHttp(method, POST.class, PUT.class, GET.class, DELETE.class))) {
							return;
						}
					}
					// Checar se o Funcionario possui acesso
					FuncionalidadeService funcionalidadeService = ((FuncionalidadeService) new InitialContext()
							.lookup("java:comp/FuncionalidadeService"));
					List<Funcionalidade> funcionalidades = new ArrayList<>();
					funcionalidades.addAll(funcionalidadeService.findByFuncionario());
					funcionalidades.addAll(funcionalidadeService.findByCargo());

					for (Funcionalidade funcionalidade : funcionalidades) {
						for (UrlFuncionalidade url : funcionalidade.getUrlFuncionalidades()) {
							if (url.getUrl().getUrl().equals(getPath()) && url.getUrl().getMetodo()
									.equals(checkMethodHttp(method, POST.class, PUT.class, GET.class, DELETE.class))) {
								return;
							}
						}
					}
				}
				log.log(Level.SEVERE, "Sem Autorizacao para acessar o recurso");
				requestContext.setProperty("auth-failed", true);
				requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
			} catch (Exception ex) {
				if (isPermitAll(method) && resourceInfo.getResourceClass().equals(AuthenticationResource.class)) {
					PrincipalThreadLocal.USER
							.set(new Principal().username("anonimous").ip(servletRequest.getRemoteAddr()));
					return;
				}
				log.log(Level.SEVERE, "Validacao JWT falhou");
				requestContext.setProperty("auth-failed", true);
				requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
			}
		} else {
			if (isPermitAll(method) || resourceInfo.getResourceClass().equals(AuthenticationResource.class)) {
				PrincipalThreadLocal.USER.set(new Principal().username("anonimous").ip(servletRequest.getRemoteAddr()));
				return;
			}
			log.log(Level.SEVERE, "Sem JWT token!");
			requestContext.setProperty("auth-failed", true);
			requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
		}
	}

	@SuppressWarnings("unchecked")
	private String checkMethodHttp(Method method, Class<? extends Annotation>... classes) {
		for (Class<? extends Annotation> clazz : classes) {
			if (method.getAnnotation(clazz) != null) {
				return clazz.getSimpleName();
			}
		}
		return null;
	}

	private String getPath() {
		StringBuilder path = new StringBuilder();
		path.append(getPath(resourceInfo.getResourceMethod().getDeclaringClass().getAnnotation(Path.class)))
				.append(resourceInfo.getResourceMethod().getAnnotation(Path.class) != null ? "/" : "")
				.append(getPath(resourceInfo.getResourceMethod().getAnnotation(Path.class)));
		return path.toString();
	}

	private String getPath(Path path) {
		if (path != null) {
			if (path.value().contains(":")) {
				return path.value().replaceAll("^/+|/+$|\\}$", "").replaceAll("\\{\\D[^:]+:", "").replaceAll("\\}/",
						"/");
			} else {
				return path.value().replaceAll("^/+|/+$", "").replaceAll("\\{.*\\}", ".*");
			}
		}
		return "";
	}

	private Principal validate(String authHeader) throws InvalidJwtException, MalformedClaimException, JoseException {
		JwtConsumer jwtConsumer = new JwtConsumerBuilder().setRequireSubject()
				.setVerificationKey(RsaKeyProducer.produce().getKey()).build();

		Principal principal = new Principal();
		try {
			JwtClaims jwtClaims = jwtConsumer.processToClaims(authHeader.split(" ")[1]);
			principal.username((String) jwtClaims.getClaimValue("sub"));
			principal.cargo(jwtClaims.getStringClaimValue("cargo"));
			log.fine("JWT validado com sucucesso! " + jwtClaims);
		} catch (InvalidJwtException e) {
			log.warning("Token " + authHeader.split(" ")[1] + " has a problem!");
			jwtConsumer = new JwtConsumerBuilder().setRequireSubject().setDisableRequireSignature()
					.setSkipSignatureVerification().build();
			try {
				JwtClaims jwtClaims = jwtConsumer.processToClaims(authHeader.split(" ")[1]);
				principal.username((String) jwtClaims.getClaimValue("sub"));
				principal.cargo(jwtClaims.getStringClaimValue("cargo"));
				if (jwtClaims.getStringClaimValue("coordenacao") != null) {
					principal.coordenacao(jwtClaims.getStringListClaimValue("coordenacao").stream()
							.map(coordenacao -> Integer.parseInt(coordenacao)).collect(Collectors.toList()));
				}
				log.warning("JWT validado ignorando a chave! " + jwtClaims);
			} catch (InvalidJwtException ex) {
				log.warning("Token " + authHeader.split(" ")[1] + " has a big problem!");
				throw e;
			}
		}
		return principal;
	}

	/**
	 * @param method
	 * @return boolean
	 */
	private boolean isPermitAll(Method method) {
		return (resourceInfo.getResourceClass().isAnnotationPresent(PermitAll.class)
				&& !method.isAnnotationPresent(RolesAllowed.class) && !method.isAnnotationPresent(DenyAll.class))
				|| method.isAnnotationPresent(PermitAll.class);
	}
}

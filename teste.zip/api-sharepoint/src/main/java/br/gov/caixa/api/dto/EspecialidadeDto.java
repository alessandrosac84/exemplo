package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.Especialidade;

public class EspecialidadeDto {

	private Long uid;
	private String nome;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public static EspecialidadeDto fromEspecialidadeToDto(Especialidade especialidade) {
		EspecialidadeDto dto = new EspecialidadeDto();
		dto.setUid(especialidade.getUid());
		dto.setNome(especialidade.getNome());
		return dto;
	}
	
	public static List<EspecialidadeDto> fromEspecialidadeToListDto(List<Especialidade> list) {
		
		List<EspecialidadeDto> returnList = new ArrayList<EspecialidadeDto>();
		
		for (Especialidade especialidade   : list) {
			
			EspecialidadeDto dto = new EspecialidadeDto();
			
			dto.setUid(especialidade.getUid());
			dto.setNome(especialidade.getNome());
			
			returnList.add(dto);
		}
		
		return returnList;
		
	}
}

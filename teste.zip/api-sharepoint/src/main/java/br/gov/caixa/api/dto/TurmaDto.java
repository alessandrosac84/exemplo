package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.gov.caixa.api.model.Turma;

public class TurmaDto {

	private Long uid;
	private String nome;
	private Date data;
	private Date data2;
	private Integer carga;
	private String instrutor;
	private String local;
	private String horaEntrada;	
	private String horaSaida;
	private Integer nivel;
	private Integer vagas;
	private String detalhe;
	private TreinamentoDto treinamento;
	private Double nota;
	private boolean encerrado;
	private boolean fechado;
	private boolean autoInscricao;
	private boolean expirou;
	private Integer inscritos;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}
	
	public Date getData2() {
		return data2;
	}

	public void setData2(Date data2) {
		this.data2 = data2;
	}

	public Integer getCarga() {
		return carga;
	}

	public void setCarga(Integer carga) {
		this.carga = carga;
	}

	public String getInstrutor() {
		return instrutor;
	}

	public void setInstrutor(String instrutor) {
		this.instrutor = instrutor;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}
	
	public String getHoraEntrada() {
		return horaEntrada;
	}

	public void setHoraEntrada(String horaEntrada) {
		this.horaEntrada = horaEntrada;
	}

	public String getHoraSaida() {
		return horaSaida;
	}

	public void setHoraSaida(String horaSaida) {
		this.horaSaida = horaSaida;
	}

	public Integer getNivel() {
		return nivel;
	}

	public void setNivel(Integer nivel) {
		this.nivel = nivel;
	}
	
	public Integer getVagas() {
		return vagas;
	}

	public void setVagas(Integer vagas) {
		this.vagas = vagas;
	}

	public String getDetalhe() {
		return detalhe;
	}

	public void setDetalhe(String detalhe) {
		this.detalhe = detalhe;
	}

	public TreinamentoDto getTreinamento() {
		return treinamento;
	}

	public void setTreinamento(TreinamentoDto treinamento) {
		this.treinamento = treinamento;
	}

	public Double getNota() {
		return nota;
	}

	public void setNota(Double nota) {
		this.nota = nota;
	}

	public boolean isEncerrado() {
		return encerrado;
	}

	public void setEncerrado(boolean encerrado) {
		this.encerrado = encerrado;
	}	

	public boolean isAutoInscricao() {
		return autoInscricao;
	}

	public void setAutoInscricao(boolean autoInscricao) {
		this.autoInscricao = autoInscricao;
	}	

	public Integer getInscritos() {
		return inscritos;
	}

	public void setInscritos(Integer inscritos) {
		this.inscritos = inscritos;
	}

	public boolean isExpirou() {
		return expirou;
	}

	public void setExpirou(boolean expirou) {
		this.expirou = expirou;
	}	

	public boolean isFechado() {
		return fechado;
	}

	public void setFechado(boolean fechado) {
		this.fechado = fechado;
	}

	public static TurmaDto fromTurmaToDto(Turma turma) {
		TurmaDto dto = new TurmaDto();
		dto.setUid(turma.getUid());
		dto.setNome(turma.getNome());
		dto.setData(turma.getData());
		dto.setData2(turma.getData2());
		dto.setCarga(turma.getCarga());
		dto.setInstrutor(turma.getInstrutor());
		dto.setLocal(turma.getLocal());
		dto.setHoraEntrada(turma.getHoraEntrada());
		dto.setHoraSaida(turma.getHoraSaida());
		dto.setNivel(turma.getNivel());
		dto.setVagas(turma.getVagas());
		dto.setDetalhe(turma.getDetalhe());
		dto.setTreinamento(TreinamentoDto.fromTreinamentoToDto(turma.getTreinamento()));
		dto.setNota(turma.getNota());
		dto.setEncerrado(turma.isEncerrado());
		dto.setFechado(turma.isFechado());
		dto.setAutoInscricao(turma.isAutoInscricao());
		dto.setInscritos(turma.getInscritos());
		
		return dto;
	}

	public static List<TurmaDto> fromTurmaToListaDto(List<Turma> listaTurma) {
		List<TurmaDto> result = new ArrayList<TurmaDto>(); 
		for (Turma turma : listaTurma) {
			result.add(fromTurmaToDto(turma));
		}
		return result;
	}
}

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.filter.request;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.Principal;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.UriInfo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * Classe de Teste de AuthenticationTokenRequestFilter
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class AuthenticationTokenRequestFilterTest {

	@Mock
	private HttpServletRequest request;

	@Mock
	private ContainerRequestContext containerRequestContext;

	@Mock
	private UriInfo uriInfo;

	@Mock
	private Principal principal;

	@InjectMocks
	private AuthenticationTokenRequestFilter authenticationTokenRequestFilter;

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilter() throws IOException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/auth/login");
		Mockito.when(containerRequestContext.hasEntity()).thenReturn(true);
		Mockito.when(containerRequestContext.getEntityStream()).thenReturn(new ByteArrayInputStream(
				"{\"username\":\"f771274\",\"password\":\"123456\"}".getBytes(StandardCharsets.UTF_8.name())));

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilterAnyElsePath() throws IOException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/sistema");

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilterAnyElsePathAuthorized() throws IOException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/sistema");
		Mockito.when(request.getUserPrincipal()).thenReturn(principal);
		Mockito.when(containerRequestContext.getHeaderString("Authorization")).thenReturn(
				"Bearer eyJhbGciOiJSUzI1NiJ9.eyJleHAiOjE1MTYyOTk1OTYsImp0aSI6IklYRnpyV3hQcTV2b1ZzeUJfVEZR"
				+ "X1EiLCJpYXQiOjE1MTYyOTg2OTYsInN1YiI6ImY3NzEyNzQiLCJlbWFpbCI6bnVsbCwicm9sZXMiOlsiQ0VBU0F"
				+ "QIiwiQkFNQURNIiwiV0tMREVQTE9ZRVIiLCJXQVNERVBMT1lFUiIsIkNFQVNBUCIsIkJBTUFETSIsIldLTERFUEx"
				+ "PWUVSIiwiV0FTREVQTE9ZRVIiXX0.oCJR-Xpy5djsnSkVGX6Zxfv4gZXWvkU5gp5sLZTQZIDY26gl4qM5_-9OPAXX"
				+ "-zXiAXsuJv7Q5NO1r1fFZR2a20QQpYprlSxrZ-EMu8zIpMTk3pjcI4aoj70tU5vXZltweozZ0tZOwTHVPYj2p68ANp"
				+ "YYOMGBvGlTBI_uL6j-ZAfEG4pp_a3vhr3VbNNzIu9af3OhYfNs0wdn5r2Dgb3GvptcUv_ZyZuIQvPETftB6xKl3a-V"
				+ "8iM4XKbr24E_V8mr3gnbLRUtbu-7iQ75Y60Vcre0foH-oOITIUVHCIiuD79f2oAtRnNxsG3Wou4BXggCOdjvnldM2uqtfEBcmxuirg");

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 * @throws ServletException 
	 */
	@Test
	public void testFilterAnyElsePathAuthorizedFailed() throws IOException, ServletException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/sistema");
		Mockito.when(containerRequestContext.getHeaderString("Authorization")).thenReturn(
				"Bearer eyJhbGciOiJSUzI1NiJ9.eyJleHAiOjE1MTYyOTk1OTYsImp0aSI6IklYRnpyV3hQcTV2b1ZzeUJfVEZR"
				+ "X1EiLCJpYXQiOjE1MTYyOTg2OTYsInN1YiI6ImY3NzEyNzQiLCJlbWFpbCI6bnVsbCwicm9sZXMiOlsiQ0VBU0F"
				+ "QIiwiQkFNQURNIiwiV0tMREVQTE9ZRVIiLCJXQVNERVBMT1lFUiIsIkNFQVNBUCIsIkJBTUFETSIsIldLTERFUEx"
				+ "PWUVSIiwiV0FTREVQTE9ZRVIiXX0.oCJR-Xpy5djsnSkVGX6Zxfv4gZXWvkU5gp5sLZTQZIDY26gl4qM5_-9OPAXX"
				+ "-zXiAXsuJv7Q5NO1r1fFZR2a20QQpYprlSxrZ-EMu8zIpMTk3pjcI4aoj70tU5vXZltweozZ0tZOwTHVPYj2p68ANp"
				+ "YYOMGBvGlTBI_uL6j-ZAfEG4pp_a3vhr3VbNNzIu9af3OhYfNs0wdn5r2Dgb3GvptcUv_ZyZuIQvPETftB6xKl3a-V"
				+ "8iM4XKbr24E_V8mr3gnbLRUtbu-7iQ75Y60Vcre0foH-oOITIUVHCIiuD79f2oAtRnNxsG3Wou4BXggCOdjvnldM2uqtfEBcmxuirg");
		Mockito.doThrow(new ServletException()).when(request).login("", "");

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilterNoEntity() throws IOException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/auth/login");
		Mockito.when(containerRequestContext.hasEntity()).thenReturn(false);

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilterHasEntityEmpty() throws IOException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/auth/login");
		Mockito.when(containerRequestContext.hasEntity()).thenReturn(true);
		Mockito.when(containerRequestContext.getEntityStream())
				.thenReturn(new ByteArrayInputStream("".getBytes(StandardCharsets.UTF_8.name())));
		Mockito.when(request.getUserPrincipal()).thenReturn(principal);

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

	/**
	 * Test method for
	 * {@link br.gov.caixa.inovacao.continuousmanager.config.filter.AuthenticationTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testFilterErrorReadEntity() throws IOException {

		Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);
		Mockito.when(uriInfo.getPath()).thenReturn("/auth/login");
		Mockito.when(containerRequestContext.hasEntity()).thenReturn(true);

		authenticationTokenRequestFilter.filter(containerRequestContext);
	}

}

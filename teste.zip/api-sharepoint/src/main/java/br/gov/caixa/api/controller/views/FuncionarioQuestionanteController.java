package br.gov.caixa.api.controller.views;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.result.views.FuncionarioQuestionanteResult;
import br.gov.caixa.api.services.views.FuncionarioQuestionanteService;

@RestController
public class FuncionarioQuestionanteController {
	
	@Inject
	FuncionarioQuestionanteService service;
	
	@RequestMapping(value="/api/funcionarioQuestionante/all", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public FuncionarioQuestionanteResult listAll() {
		
		return service.listAll();
	}
	
	@RequestMapping(value="/api/funcionarioQuestionante/listFuncionariosQuestionantesByQuestionarioId/{questionarioId}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public FuncionarioQuestionanteResult listFuncionariosQuestionantesByQuestionarioId(@PathVariable Long questionarioId) {
		
		return service.listFuncionariosQuestionantesByQuestionarioId(questionarioId);
	}
	
	
}

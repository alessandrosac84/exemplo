package br.gov.caixa.inovacao.continuousmanager.model.entity;

import org.junit.Test;


/**
 * Classe para testes superficiais de Enums
 * 
 * @author Fabio Iwakoshi
 *
 */
public class StaticMetamodelTest {

	/**
	 * Listar todas as Wallets.
	 */
	@Test
	public void testListAllWalletsDefault() {
		// Act
		new Audit_();
		new Build_();
		new BuildPK_();
		new ChangeSets_();
		new ChangeSetsPK_();
		new GitRepo_();
		new GitRepoPK_();
		new Job_();
		new JobPK_();
		new Parameter_();
		new ParameterPK_();
		new Project_();
		new ProjectPK_();
		new ProjectEnvironment_();
		new ProjectEnvironmentPK_();
		new Sonar_();
		new SonarPK_();
		new Wallet_();
	}
	
}

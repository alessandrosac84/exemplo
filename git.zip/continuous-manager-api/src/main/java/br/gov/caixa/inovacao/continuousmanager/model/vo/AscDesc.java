package br.gov.caixa.inovacao.continuousmanager.model.vo;

public enum AscDesc {
	ASC, DESC
}

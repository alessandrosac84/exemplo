import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminsManagementRoutingModule } from './admins-management-routing.module';
import { AdminsManagementComponent } from './admins-management.component';

@NgModule({
  imports: [
    CommonModule,
    AdminsManagementRoutingModule
  ],
  declarations: [AdminsManagementComponent]
})
export class AdminsManagementModule { }

package br.com.opussolutions.service;

import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.opussolutions.model.entity.Cliente;
import br.com.opussolutions.model.repository.OpusRepository;


@Stateless
public class OpusService {
	
	@Inject
	private Logger log;

	@Inject
	private OpusRepository opusRepository;
	
	public Cliente findById(String id) {
		log.fine("Obtendo Cliente por ID");
		return opusRepository.findById(id);
	}
}

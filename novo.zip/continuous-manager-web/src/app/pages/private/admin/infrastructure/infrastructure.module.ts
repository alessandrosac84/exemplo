import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InfrastructureRoutingModule } from './infrastructure-routing.module';
import { InfrastructureComponent } from './infrastructure.component';

import { FlexLayoutModule } from '@angular/flex-layout';
import { AddServerDialogComponent } from './add-server-dialog/add-server-dialog.component';
import { MaterialModule } from '../../../../core/material/material.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    FlexLayoutModule,
    InfrastructureRoutingModule
  ],
  declarations: [InfrastructureComponent, AddServerDialogComponent]
})
export class InfrastructureModule { }

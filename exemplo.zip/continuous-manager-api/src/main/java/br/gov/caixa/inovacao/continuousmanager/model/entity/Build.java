package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.deser.std.DateDeserializers.DateDeserializer;
import com.fasterxml.jackson.databind.ser.std.DateSerializer;


/**
 * The persistent class for the build database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Table(name="build")
@NamedQuery(name="Build.findAll", query="SELECT b FROM Build b")
public class Build implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BuildPK id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_at", nullable=false)
	private Calendar createdAt;

	@Column(nullable=false, length=200)
	private String description;

	@Temporal(TemporalType.TIME)
	@JsonSerialize(using = DateSerializer.class)
    @JsonDeserialize(using = DateDeserializer.class)
	@Column(nullable=false)
	private Date duration;

	@Temporal(TemporalType.TIME)
	@JsonSerialize(using = DateSerializer.class)
    @JsonDeserialize(using = DateDeserializer.class)
	@Column(name="estimate_duration", nullable=false)
	private Date estimateDuration;

	@JsonIgnore
	@Column(nullable=false, columnDefinition = "TEXT")
	private String log;

	@Enumerated(EnumType.STRING)
	@Column(nullable=false, length=9)
	private JenkinsResult result;

	//bi-directional many-to-one association to Job
	@JsonIgnore
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="job", referencedColumnName="id", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="project", referencedColumnName="project", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private Job job;

	//bi-directional many-to-many association to GitRepo
	@JsonIgnore
	@OneToMany(mappedBy="builds")
	private Set<ChangeSets> changeSets;

	//bi-directional many-to-one association to ProjectEnvironment
	@JsonIgnore
	@OneToMany(mappedBy="build")
	private Set<ProjectEnvironment> projectEnvironments;

	public Build() {
		/* class constructor intentionally left blank */
	}

	public BuildPK getId() {
		return this.id;
	}

	public void setId(BuildPK id) {
		this.id = id;
	}

	public Calendar getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Calendar createdAt) {
		this.createdAt = createdAt;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDuration() {
		return this.duration;
	}

	public void setDuration(Date duration) {
		this.duration = duration;
	}

	public Date getEstimateDuration() {
		return this.estimateDuration;
	}

	public void setEstimateDuration(Date estimateDuration) {
		this.estimateDuration = estimateDuration;
	}

	public String getLog() {
		return this.log;
	}

	public void setLog(String log) {
		this.log = log;
	}

	public JenkinsResult getResult() {
		return this.result;
	}

	public void setResult(JenkinsResult result) {
		this.result = result;
	}

	public Job getJob() {
		return this.job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public Set<ChangeSets> getChangeSets() {
		return this.changeSets;
	}

	public void setChangeSets(Set<ChangeSets> changeSets) {
		this.changeSets = changeSets;
	}

	public Set<ProjectEnvironment> getProjectEnvironments() {
		return this.projectEnvironments;
	}

	public void setProjectEnvironments(Set<ProjectEnvironment> projectEnvironments) {
		this.projectEnvironments = projectEnvironments;
	}

	public ProjectEnvironment addProjectEnvironment(ProjectEnvironment projectEnvironment) {
		getProjectEnvironments().add(projectEnvironment);
		projectEnvironment.setBuild(this);

		return projectEnvironment;
	}

	public ProjectEnvironment removeProjectEnvironment(ProjectEnvironment projectEnvironment) {
		getProjectEnvironments().remove(projectEnvironment);
		projectEnvironment.setBuild(null);

		return projectEnvironment;
	}

}
package br.gov.caixa.api.repository.views;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.views.EspecialidadeFuncionarioView;

public interface EspecialidadeFuncionarioViewRepository extends JpaRepository<EspecialidadeFuncionarioView, Long> {
	
	@Query("SELECT b FROM EspecialidadeFuncionarioView b where b.especialidadeId = ?1 order by b.nome asc, b.tipo")
	List<EspecialidadeFuncionarioView> findByEspecialidadeId(Long especialidadeId);

}

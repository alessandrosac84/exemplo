package br.gov.caixa.sharepoint.config.security.token;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.jwk.RsaJwkGenerator;
import org.jose4j.lang.JoseException;

/**
 * @author f771274
 *
 */
public class RsaKeyProducer {
	
	private static Logger logger = Logger.getLogger(RsaKeyProducer.class.getName());

	private RsaKeyProducer() {
	}

	private static RsaJsonWebKey jsonWebKey;

	public synchronized static RsaJsonWebKey produce() throws JoseException {
		if (jsonWebKey == null) {
			jsonWebKey = RsaJwkGenerator.generateJwk(2048);
		}
		logger.log(Level.FINE, "RSA Key setup... " + jsonWebKey.hashCode());
		return jsonWebKey;
	}
}

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe de representação do Crumb Issuer do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class CrumbIssuerJenkinsVO implements Serializable {
	
	private static final long serialVersionUID = -4430436777856848125L;

	@JsonProperty("_class")
	private String clazz;
	
	private String crumb;
	
	private String crumbRequestField;

	/**
	 * @return the clazz
	 */
	public String getClazz() {
		return clazz;
	}

	/**
	 * @param clazz the clazz to set
	 */
	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	/**
	 * @return the crumb
	 */
	public String getCrumb() {
		return crumb;
	}

	/**
	 * @param crumb the crumb to set
	 */
	public void setCrumb(String crumb) {
		this.crumb = crumb;
	}

	/**
	 * @return the crumbRequestField
	 */
	public String getCrumbRequestField() {
		return crumbRequestField;
	}

	/**
	 * @param crumbRequestField the crumbRequestField to set
	 */
	public void setCrumbRequestField(String crumbRequestField) {
		this.crumbRequestField = crumbRequestField;
	}

}

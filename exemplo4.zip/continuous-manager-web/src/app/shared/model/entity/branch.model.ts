import { Build } from './build.model';
import { Parameter } from '../vo/parameter.model';
import { Server } from './server.model';
import { BranchInstance } from './branch-instance.model';

export class Branch {
  id: { id: string };
  buildCount: number;
  lastBuild: Build;
  parameters: Parameter[];
  servers: BranchInstance[];
}

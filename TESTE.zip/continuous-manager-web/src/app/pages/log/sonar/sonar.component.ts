/* Angular Imports */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jmw-sonar',
  templateUrl: './sonar.component.html',
  styleUrls: ['./sonar.component.scss']
})
export class SonarComponent implements OnInit {
  pageTitle = 'Sonar View';
  navTab = 'bugs';

  constructor() { }

  ngOnInit() {
  }

  goToTab(tab: string) {
    this.navTab = tab;
  }
}

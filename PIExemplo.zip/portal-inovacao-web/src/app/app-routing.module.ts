import { NotFoundComponent } from './pages/not-found/not-found.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './guards/auth.guard';

import { MapaAmbienteComponent } from './pages/mapa-ambiente/mapa-ambiente.component';
import { HomeComponent } from './pages/home/home.component';
import { TransacaoComponent } from './pages/transacao/transacao.component';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'mapa-ambiente',
    loadChildren: 'app/pages/mapa-ambiente/mapa-ambiente.module#MapaAmbienteModule',
    canActivate: [AuthGuard],
    canLoad: [AuthGuard]
  },
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  {
    path: 'transacao',
    component: TransacaoComponent,
    children: []
  },
  {
    path: '**',
    component: NotFoundComponent
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

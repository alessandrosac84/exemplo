package br.gov.caixa.sharepoint.config.provider;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class EntityProvider {

	@Produces
    @PersistenceContext
    private EntityManager entityManager;
}

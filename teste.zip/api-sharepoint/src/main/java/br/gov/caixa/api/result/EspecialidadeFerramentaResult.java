package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.EspecialidadeFerramentaDto;

public class EspecialidadeFerramentaResult extends BasicResult {
	private List<EspecialidadeFerramentaDto> list;
	private EspecialidadeFerramentaDto especialidadeFerramenta;

	public List<EspecialidadeFerramentaDto> getList() {
		return list;
	}

	public void setList(List<EspecialidadeFerramentaDto> list) {
		this.list = list;
	}

	public EspecialidadeFerramentaDto getEspecialidadeFerramenta() {
		return especialidadeFerramenta;
	}

	public void setEspecialidadeFerramenta(EspecialidadeFerramentaDto especialidadeFerramenta) {
		this.especialidadeFerramenta = especialidadeFerramenta;
	}
}
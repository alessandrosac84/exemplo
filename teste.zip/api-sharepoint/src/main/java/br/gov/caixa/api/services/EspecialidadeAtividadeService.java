package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.EspecialidadeAtividadeDto;
import br.gov.caixa.api.model.Especialidade;
import br.gov.caixa.api.model.EspecialidadeAtividade;
import br.gov.caixa.api.repository.EspecialidadeAtividadeRepository;
import br.gov.caixa.api.result.EspecialidadeAtividadeResult;

@Named
public class EspecialidadeAtividadeService {
	
	@Inject
	EspecialidadeAtividadeRepository repository;
	
	public EspecialidadeAtividadeResult listAll() {

		EspecialidadeAtividadeResult result = new EspecialidadeAtividadeResult();
		
		try {
			List<EspecialidadeAtividade> lista = repository.findAll();

			if (lista != null) {
				result.setList(EspecialidadeAtividadeDto.fromEspecialidadeAtividadeToListDto(lista));
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma especialidadeAtividade.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}

	public EspecialidadeAtividadeResult save(EspecialidadeAtividadeDto dto) {
		
		EspecialidadeAtividade especialidadeAtividade = EspecialidadeAtividade.fromDtoToEspecialidadeAtividade(dto);
				
		especialidadeAtividade = repository.save(especialidadeAtividade);		
		dto.setUid(especialidadeAtividade.getUid());
		
		EspecialidadeAtividadeResult result = new EspecialidadeAtividadeResult();
		result.setEspecialidadeAtividade(dto);
		result.setMessage("Executado com sucesso.");
		
		return result;
	}

	public EspecialidadeAtividadeResult delete(EspecialidadeAtividadeDto dto) {

		EspecialidadeAtividadeResult result;
		
		EspecialidadeAtividade especialidadeAtividade = repository.findOne(dto.getUid());
		
		try {
			repository.delete(especialidadeAtividade);
			
			result = new EspecialidadeAtividadeResult();
			result.setMessage("Executado com sucesso.");
			
		} catch (Exception e) {
			result = new EspecialidadeAtividadeResult();
			
			result.setIsError(true);
			result.setMessage("Existe(m) Rating(s) Associados a esta EspecialidadeAtividade.");
			
			e.printStackTrace();
		}		
		return result;
	}
	
	public EspecialidadeAtividadeResult listEspecialidadeAtividadesByIdAtividade(Long idEspecialidade) {
		EspecialidadeAtividadeResult result = new EspecialidadeAtividadeResult();
		try {
			
			Especialidade especialidade = new Especialidade();
			especialidade.setUid(idEspecialidade);
			
			List<EspecialidadeAtividade> lista = repository.findByEspecialidade(especialidade);				
			
			if (lista != null) {
				result.setList(EspecialidadeAtividadeDto.fromEspecialidadeAtividadeToListDto(lista));					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Atividade para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

package br.gov.caixa.api.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class BuscaCoordenacaoCoordenadorId implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "coordenacao_id")
	private Long coordenacao_id;
	
	public Long getCoordenacao_id() {
		return coordenacao_id;
	}
	public void setCoordencao_id(Long coordencao_id) {
		this.coordenacao_id = coordencao_id;
	}
		
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((coordenacao_id == null) ? 0 : coordenacao_id.hashCode());	
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BuscaCoordenacaoCoordenadorId other = (BuscaCoordenacaoCoordenadorId) obj;
		if (coordenacao_id == null) {
			if (other.coordenacao_id != null)
				return false;
		} else if (!coordenacao_id.equals(other.coordenacao_id))
			return false;		
		return true;
	}

}

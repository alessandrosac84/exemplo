package br.gov.caixa.inovacao.continuousmanager.model;

import java.util.Calendar;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-01-31T14:07:31.438-0200")
@StaticMetamodel(AuditedEntity.class)
public class AuditedEntity_ {
	public static volatile SingularAttribute<AuditedEntity, String> userInsert;
	public static volatile SingularAttribute<AuditedEntity, Calendar> createdAt;
	public static volatile SingularAttribute<AuditedEntity, String> userUpdate;
	public static volatile SingularAttribute<AuditedEntity, Calendar> updatedAt;
}

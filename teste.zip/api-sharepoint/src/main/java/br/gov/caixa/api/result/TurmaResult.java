package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.TurmaDto;

public class TurmaResult extends BasicResult {

	private List<TurmaDto> list;
	private TurmaDto turma;

	public List<TurmaDto> getList() {
		return list;
	}

	public void setList(List<TurmaDto> list) {
		this.list = list;
	}

	public TurmaDto getTurma() {
		return turma;
	}

	public void setTurma(TurmaDto turma) {
		this.turma = turma;
	}
}

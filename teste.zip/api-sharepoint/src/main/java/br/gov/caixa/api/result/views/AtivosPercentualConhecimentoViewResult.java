package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.AtivosPercentualConhecimentoView;
import br.gov.caixa.api.result.BasicResult;

public class AtivosPercentualConhecimentoViewResult extends BasicResult {
	private List<AtivosPercentualConhecimentoView> list;
	private AtivosPercentualConhecimentoView ativosPercentualConhecimentoView;

	public List<AtivosPercentualConhecimentoView> getList() {
		return list;
	}

	public void setList(List<AtivosPercentualConhecimentoView> list) {
		this.list = list;
	}

	public AtivosPercentualConhecimentoView ativosPercentualConhecimentoView() {
		return ativosPercentualConhecimentoView;
	}

	public void setAtivosPercentualConhecimentoView(AtivosPercentualConhecimentoView ativosPercentualConhecimentoView) {
		this.ativosPercentualConhecimentoView = ativosPercentualConhecimentoView;
	}
}
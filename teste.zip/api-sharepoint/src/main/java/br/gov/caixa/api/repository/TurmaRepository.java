package br.gov.caixa.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import br.gov.caixa.api.model.Treinamento;
import br.gov.caixa.api.model.Turma;

public interface TurmaRepository extends JpaRepository<Turma, Long>  {
	
	List<Turma> findByTreinamento(Treinamento treinamento);
	
	List<Turma> findByTreinamentoAndEncerradoFalse(Treinamento treinamento);
	
	@Modifying
	@Transactional
	@Query("update Turma t set t.inscritos = t.inscritos + 1 where t.uid = ?1")
	int addInscritos(Long uid);
	
	@Modifying
	@Transactional
	@Query("update Turma t set t.inscritos = t.inscritos - 1 where t.uid = ?1")
	int removeInscritos(Long uid);
	
}

package br.gov.caixa.api.controller.views;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.result.views.EspecialidadeFuncionarioAtividadeViewResult;
import br.gov.caixa.api.services.views.EspecialidadeFuncionarioAtividadeViewService;

@RestController
public class EspecialidadeFuncionarioAtividadeViewController {

	@Inject
	EspecialidadeFuncionarioAtividadeViewService service;

	@RequestMapping(value = "/api/especialidadeFuncionarioFuncionarioAtividadeView/all", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)	
	public EspecialidadeFuncionarioAtividadeViewResult listAll() {
		return service.listAll();
	}

	@RequestMapping(value="/api/especialidadeFuncionarioAtividadeView/obterEspecialidadeFuncionarioAtividadeViewPorIdAtividade/{idAtividade}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeFuncionarioAtividadeViewResult obterAtivoPorIdAtividade(@PathVariable Long idAtividade) {
		
		return service.listEspecialidadeFuncionarioAtividadeViewsByIdAtividade(idAtividade);
	}
	                                                    
	@RequestMapping(value="/api/especialidadeFuncionarioAtividadeView/obterEspecialidadeFuncionarioAtividadeViewPorIdsAtividade", 
			method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeFuncionarioAtividadeViewResult obterAtivoPorIdsAtividade(@RequestBody List<Long> idsAtividade) {
		
		return service.listEspecialidadeFuncionarioAtividadesViewByIdsAtividade(idsAtividade);
	}
	                                                                   
	@RequestMapping(value="/api/especialidadeFuncionarioAtividadeView/obterEspecialidadeFuncionarioAtividadeViewPorIdsAtividadeAndEspecialidade/{idEspecialidade}", 
			method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeFuncionarioAtividadeViewResult obterAtivoPorIdsAtividade(@RequestBody List<Long> idsAtividade, @PathVariable Long idEspecialidade) {
		
		return service.listEspecialidadeFuncionarioAtividadesViewByIdsAtividadeAndEspecialidadeId(idsAtividade, idEspecialidade);
	}
	
	
	@RequestMapping(value="/api/especialidadeFuncionarioAtividadeView/teste", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeFuncionarioAtividadeViewResult obterAtivoPorIdsAtividadeTeste() {		
		
		List<Long> teste = new ArrayList<Long>();
		
		teste.add((long) 34 );
		teste.add((long) 35 );
		teste.add((long) 36 );
		
		
		return service.listEspecialidadeFuncionarioAtividadesViewByIdsAtividade(teste);
	}


}

package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGate;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGatePK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.QualityGateRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.Comparator;

/**
 * Classe de testes do QualityGateService.
 * 
 * @author Alessandro Carvalho
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class QualityGateServiceTest {

	@Mock
	private QualityGateRepository qualityGateRepository;

	@InjectMocks
	private QualityGateService qualityGateService;

	@Before
	public void before() {
		UtilReflection.setField(qualityGateService, "log", Logger.getLogger(AuditService.class.getName()));
	}
	
	@Test
	public void testSaveAll() {
		// Arrange
		QualityGate qualityGate = new QualityGate();
		qualityGate.setId(new QualityGatePK());
		qualityGate.getId().setWallet("inovacao");
		qualityGate.getId().setProject("continuous-manager-web");
		qualityGate.getId().setMetricKey("asdsdasd");
		qualityGate.setComparator(Comparator.GT);
		qualityGate.setErrorThreshold("1");
		Mockito.when(qualityGateRepository.save(Mockito.<QualityGate>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		
		// Act
		qualityGateService.save(qualityGate);
	}
}

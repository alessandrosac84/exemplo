/**
 * OutputMapping5GetListValues.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package SIAPP_WS_DistinctItemPortfolio;

@SuppressWarnings({ "rawtypes", "serial" })
public class OutputMapping5GetListValues  implements java.io.Serializable {
    private java.lang.String NU_ITEM;

    private java.lang.String NO_APELIDO;

    private java.lang.String NO_GE;

    private java.lang.String NO_UNID_DES;

    private java.lang.String DE_ABRANGENCIA_USO;

    private java.lang.String DE_CRITICIDADE_NEGOCIO;

    private java.lang.String DE_CRITICIDADE_TECNICA;

    private java.lang.String NO_SIGLA;

    private SIAPP_WS_DistinctItemPortfolio.DE_ESTADOType DE_ESTADO;

    private SIAPP_WS_DistinctItemPortfolio.DE_TIPOType DE_TIPO;

    private java.lang.String NO_PADRAO_DES;

    private java.lang.String DE_OBJETIVO;

    private java.lang.String DE_BENF_ESPERADO;

    private java.util.Date DH_INICIO;

    private java.util.Date DH_CONCLUSAO;

    private java.lang.Integer NU_CRITICIDADE;

    private java.lang.String DE_CARTEIRA;

    private SIAPP_WS_DistinctItemPortfolio.NU_GRAU_INTERNALIZACAOType NU_GRAU_INTERNALIZACAO;

    private java.lang.String NO_BD;

    private SIAPP_WS_DistinctItemPortfolio.IC_ESPECIALType IC_ESPECIAL;

    private java.lang.String NO_PROJETO_ESPECIAL;

    private java.lang.String DE_COORD_TI;

    private java.lang.String DE_COORD_PROJ_TI;

    private java.lang.String DE_ALIAS;

    private java.lang.String DE_CONSIDE_GERAIS;

    private SIAPP_WS_DistinctItemPortfolio.DE_SITUACAO_DOCUMENTACAOType DE_SITUACAO_DOCUMENTACAO;

    private java.util.Date DH_ULTIMA_ATUALIZACAO;

    private SIAPP_WS_DistinctItemPortfolio.DE_PRONTO_ATENDIMENTOType DE_PRONTO_ATENDIMENTO;

    private java.lang.String NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL;

    private SIAPP_WS_DistinctItemPortfolio.IC_DESINTERNOType IC_DESINTERNO;

    private java.lang.String DE_BIP;

    private java.lang.String NO_NAVEGACAO;

    private java.lang.String DE_PROCESSO;

    private java.lang.String DE_CENARIO;

    private java.lang.String DE_FASE;

    private java.lang.String NO_LINGUAGEM_PRO;

    private SIAPP_WS_DistinctItemPortfolio.DE_SITUACAOType DE_SITUACAO;

    private java.util.Date DH_MODICACAO;

    private java.lang.String NO_FORMAACESSO;

    private java.lang.String NO_SO;

    private java.lang.String NO_SUPORTE_DES;

    private java.lang.String NO_AMBIENTE;

    private java.lang.String NO_SERVIDOR_APP;

    private java.lang.String NO_SERVIDOR_WEB;

    private java.lang.String NO_REDE;

    private java.lang.String NO_PLATAFORMA;

    private java.lang.String NO_TECNOLOGIA_SUPORTE;

    private java.lang.String NO_COMPONENTES;

    private java.lang.String NO_INTEGRACAO;

    private java.lang.String NO_INTERFACE;

    private java.lang.String NO_AUTENTICACAO;

    private java.lang.String NO_AUTORIZACAO;

    private java.lang.String NO_CERTIFICADO_DG;

    private SIAPP_WS_DistinctItemPortfolio.NU_GRAU_INTERNALIZACAOType NO_META;

    private java.util.Date DH_CRIACAO;

    private java.lang.String NO_PARTICAO;

    private java.lang.String NO_FERRAMENTA;

    private java.lang.String NO_AMBIENTE_ACESSO;

    private java.lang.String NO_ACESSO;

    private java.lang.String DE_OBSERVACAO;

    private SIAPP_WS_DistinctItemPortfolio.IC_VPNType IC_VPN;

    private java.lang.String DE_CRONOGRAMA_VIGENTE;

    private java.lang.String ID_PROJETO_RTC;

    private SIAPP_WS_DistinctItemPortfolio.IC_VPNType IC_MPAS;

    private SIAPP_WS_DistinctItemPortfolio.IC_VPNType IC_TRILHA;

    private java.lang.String DH_MODIFICACAO;
        
    private java.lang.String ID_SISTEMA;

	public OutputMapping5GetListValues() {
    }

    public OutputMapping5GetListValues(
           java.lang.String NU_ITEM,
           java.lang.String NO_APELIDO,
           java.lang.String NO_GE,
           java.lang.String NO_UNID_DES,
           java.lang.String DE_ABRANGENCIA_USO,
           java.lang.String DE_CRITICIDADE_NEGOCIO,
           java.lang.String DE_CRITICIDADE_TECNICA,
           java.lang.String NO_SIGLA,
           SIAPP_WS_DistinctItemPortfolio.DE_ESTADOType DE_ESTADO,
           SIAPP_WS_DistinctItemPortfolio.DE_TIPOType DE_TIPO,
           java.lang.String NO_PADRAO_DES,
           java.lang.String DE_OBJETIVO,
           java.lang.String DE_BENF_ESPERADO,
           java.util.Date DH_INICIO,
           java.util.Date DH_CONCLUSAO,
           java.lang.Integer NU_CRITICIDADE,
           java.lang.String DE_CARTEIRA,
           SIAPP_WS_DistinctItemPortfolio.NU_GRAU_INTERNALIZACAOType NU_GRAU_INTERNALIZACAO,
           java.lang.String NO_BD,
           SIAPP_WS_DistinctItemPortfolio.IC_ESPECIALType IC_ESPECIAL,
           java.lang.String NO_PROJETO_ESPECIAL,
           java.lang.String DE_COORD_TI,
           java.lang.String DE_COORD_PROJ_TI,
           java.lang.String DE_ALIAS,
           java.lang.String DE_CONSIDE_GERAIS,
           SIAPP_WS_DistinctItemPortfolio.DE_SITUACAO_DOCUMENTACAOType DE_SITUACAO_DOCUMENTACAO,
           java.util.Date DH_ULTIMA_ATUALIZACAO,
           SIAPP_WS_DistinctItemPortfolio.DE_PRONTO_ATENDIMENTOType DE_PRONTO_ATENDIMENTO,
           java.lang.String NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL,
           SIAPP_WS_DistinctItemPortfolio.IC_DESINTERNOType IC_DESINTERNO,
           java.lang.String DE_BIP,
           java.lang.String NO_NAVEGACAO,
           java.lang.String DE_PROCESSO,
           java.lang.String DE_CENARIO,
           java.lang.String DE_FASE,
           java.lang.String NO_LINGUAGEM_PRO,
           SIAPP_WS_DistinctItemPortfolio.DE_SITUACAOType DE_SITUACAO,
//           java.util.Date DH_MODICACAO,
           java.lang.String NO_FORMAACESSO,
           java.lang.String NO_SO,
           java.lang.String NO_SUPORTE_DES,
           java.lang.String NO_AMBIENTE,
           java.lang.String NO_SERVIDOR_APP,
           java.lang.String NO_SERVIDOR_WEB,
           java.lang.String NO_REDE,
           java.lang.String NO_PLATAFORMA,
           java.lang.String NO_TECNOLOGIA_SUPORTE,
           java.lang.String NO_COMPONENTES,
           java.lang.String NO_INTEGRACAO,
           java.lang.String NO_INTERFACE,
           java.lang.String NO_AUTENTICACAO,
           java.lang.String NO_AUTORIZACAO,
           java.lang.String NO_CERTIFICADO_DG,
           SIAPP_WS_DistinctItemPortfolio.NU_GRAU_INTERNALIZACAOType NO_META,
           java.util.Date DH_CRIACAO,
           java.lang.String NO_PARTICAO,
           java.lang.String NO_FERRAMENTA,
           java.lang.String NO_AMBIENTE_ACESSO,
           java.lang.String NO_ACESSO,
           java.lang.String DE_OBSERVACAO,
           SIAPP_WS_DistinctItemPortfolio.IC_VPNType IC_VPN,
           java.lang.String DE_CRONOGRAMA_VIGENTE,
           java.lang.String ID_PROJETO_RTC,
           SIAPP_WS_DistinctItemPortfolio.IC_VPNType IC_MPAS,
           SIAPP_WS_DistinctItemPortfolio.IC_VPNType IC_TRILHA,
           java.lang.String DH_MODIFICACAO,
           java.lang.String ID_SISTEMA) {
           this.NU_ITEM = NU_ITEM;
           this.NO_APELIDO = NO_APELIDO;
           this.NO_GE = NO_GE;
           this.NO_UNID_DES = NO_UNID_DES;
           this.DE_ABRANGENCIA_USO = DE_ABRANGENCIA_USO;
           this.DE_CRITICIDADE_NEGOCIO = DE_CRITICIDADE_NEGOCIO;
           this.DE_CRITICIDADE_TECNICA = DE_CRITICIDADE_TECNICA;
           this.NO_SIGLA = NO_SIGLA;
           this.DE_ESTADO = DE_ESTADO;
           this.DE_TIPO = DE_TIPO;
           this.NO_PADRAO_DES = NO_PADRAO_DES;
           this.DE_OBJETIVO = DE_OBJETIVO;
           this.DE_BENF_ESPERADO = DE_BENF_ESPERADO;
           this.DH_INICIO = DH_INICIO;
           this.DH_CONCLUSAO = DH_CONCLUSAO;
           this.NU_CRITICIDADE = NU_CRITICIDADE;
           this.DE_CARTEIRA = DE_CARTEIRA;
           this.NU_GRAU_INTERNALIZACAO = NU_GRAU_INTERNALIZACAO;
           this.NO_BD = NO_BD;
           this.IC_ESPECIAL = IC_ESPECIAL;
           this.NO_PROJETO_ESPECIAL = NO_PROJETO_ESPECIAL;
           this.DE_COORD_TI = DE_COORD_TI;
           this.DE_COORD_PROJ_TI = DE_COORD_PROJ_TI;
           this.DE_ALIAS = DE_ALIAS;
           this.DE_CONSIDE_GERAIS = DE_CONSIDE_GERAIS;
           this.DE_SITUACAO_DOCUMENTACAO = DE_SITUACAO_DOCUMENTACAO;
           this.DH_ULTIMA_ATUALIZACAO = DH_ULTIMA_ATUALIZACAO;
           this.DE_PRONTO_ATENDIMENTO = DE_PRONTO_ATENDIMENTO;
           this.NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL = NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL;
           this.IC_DESINTERNO = IC_DESINTERNO;
           this.DE_BIP = DE_BIP;
           this.NO_NAVEGACAO = NO_NAVEGACAO;
           this.DE_PROCESSO = DE_PROCESSO;
           this.DE_CENARIO = DE_CENARIO;
           this.DE_FASE = DE_FASE;
           this.NO_LINGUAGEM_PRO = NO_LINGUAGEM_PRO;
           this.DE_SITUACAO = DE_SITUACAO;
           //this.DH_MODICACAO = DH_MODICACAO;
           this.NO_FORMAACESSO = NO_FORMAACESSO;
           this.NO_SO = NO_SO;
           this.NO_SUPORTE_DES = NO_SUPORTE_DES;
           this.NO_AMBIENTE = NO_AMBIENTE;
           this.NO_SERVIDOR_APP = NO_SERVIDOR_APP;
           this.NO_SERVIDOR_WEB = NO_SERVIDOR_WEB;
           this.NO_REDE = NO_REDE;
           this.NO_PLATAFORMA = NO_PLATAFORMA;
           this.NO_TECNOLOGIA_SUPORTE = NO_TECNOLOGIA_SUPORTE;
           this.NO_COMPONENTES = NO_COMPONENTES;
           this.NO_INTEGRACAO = NO_INTEGRACAO;
           this.NO_INTERFACE = NO_INTERFACE;
           this.NO_AUTENTICACAO = NO_AUTENTICACAO;
           this.NO_AUTORIZACAO = NO_AUTORIZACAO;
           this.NO_CERTIFICADO_DG = NO_CERTIFICADO_DG;
           this.NO_META = NO_META;
           this.DH_CRIACAO = DH_CRIACAO;
           this.NO_PARTICAO = NO_PARTICAO;
           this.NO_FERRAMENTA = NO_FERRAMENTA;
           this.NO_AMBIENTE_ACESSO = NO_AMBIENTE_ACESSO;
           this.NO_ACESSO = NO_ACESSO;
           this.DE_OBSERVACAO = DE_OBSERVACAO;
           this.IC_VPN = IC_VPN;
           this.DE_CRONOGRAMA_VIGENTE = DE_CRONOGRAMA_VIGENTE;
           this.ID_PROJETO_RTC = ID_PROJETO_RTC;
           this.IC_MPAS = IC_MPAS;
           this.IC_TRILHA = IC_TRILHA;
           this.DH_MODIFICACAO = DH_MODIFICACAO;
           this.ID_SISTEMA = ID_SISTEMA;
    }


    /**
     * Gets the NU_ITEM value for this OutputMapping5GetListValues.
     * 
     * @return NU_ITEM
     */
    public java.lang.String getNU_ITEM() {
        return NU_ITEM;
    }


    /**
     * Sets the NU_ITEM value for this OutputMapping5GetListValues.
     * 
     * @param NU_ITEM
     */
    public void setNU_ITEM(java.lang.String NU_ITEM) {
        this.NU_ITEM = NU_ITEM;
    }


    /**
     * Gets the NO_APELIDO value for this OutputMapping5GetListValues.
     * 
     * @return NO_APELIDO
     */
    public java.lang.String getNO_APELIDO() {
        return NO_APELIDO;
    }


    /**
     * Sets the NO_APELIDO value for this OutputMapping5GetListValues.
     * 
     * @param NO_APELIDO
     */
    public void setNO_APELIDO(java.lang.String NO_APELIDO) {
        this.NO_APELIDO = NO_APELIDO;
    }


    /**
     * Gets the NO_GE value for this OutputMapping5GetListValues.
     * 
     * @return NO_GE
     */
    public java.lang.String getNO_GE() {
        return NO_GE;
    }


    /**
     * Sets the NO_GE value for this OutputMapping5GetListValues.
     * 
     * @param NO_GE
     */
    public void setNO_GE(java.lang.String NO_GE) {
        this.NO_GE = NO_GE;
    }


    /**
     * Gets the NO_UNID_DES value for this OutputMapping5GetListValues.
     * 
     * @return NO_UNID_DES
     */
    public java.lang.String getNO_UNID_DES() {
        return NO_UNID_DES;
    }


    /**
     * Sets the NO_UNID_DES value for this OutputMapping5GetListValues.
     * 
     * @param NO_UNID_DES
     */
    public void setNO_UNID_DES(java.lang.String NO_UNID_DES) {
        this.NO_UNID_DES = NO_UNID_DES;
    }


    /**
     * Gets the DE_ABRANGENCIA_USO value for this OutputMapping5GetListValues.
     * 
     * @return DE_ABRANGENCIA_USO
     */
    public java.lang.String getDE_ABRANGENCIA_USO() {
        return DE_ABRANGENCIA_USO;
    }


    /**
     * Sets the DE_ABRANGENCIA_USO value for this OutputMapping5GetListValues.
     * 
     * @param DE_ABRANGENCIA_USO
     */
    public void setDE_ABRANGENCIA_USO(java.lang.String DE_ABRANGENCIA_USO) {
        this.DE_ABRANGENCIA_USO = DE_ABRANGENCIA_USO;
    }


    /**
     * Gets the DE_CRITICIDADE_NEGOCIO value for this OutputMapping5GetListValues.
     * 
     * @return DE_CRITICIDADE_NEGOCIO
     */
    public java.lang.String getDE_CRITICIDADE_NEGOCIO() {
        return DE_CRITICIDADE_NEGOCIO;
    }


    /**
     * Sets the DE_CRITICIDADE_NEGOCIO value for this OutputMapping5GetListValues.
     * 
     * @param DE_CRITICIDADE_NEGOCIO
     */
    public void setDE_CRITICIDADE_NEGOCIO(java.lang.String DE_CRITICIDADE_NEGOCIO) {
        this.DE_CRITICIDADE_NEGOCIO = DE_CRITICIDADE_NEGOCIO;
    }


    /**
     * Gets the DE_CRITICIDADE_TECNICA value for this OutputMapping5GetListValues.
     * 
     * @return DE_CRITICIDADE_TECNICA
     */
    public java.lang.String getDE_CRITICIDADE_TECNICA() {
        return DE_CRITICIDADE_TECNICA;
    }


    /**
     * Sets the DE_CRITICIDADE_TECNICA value for this OutputMapping5GetListValues.
     * 
     * @param DE_CRITICIDADE_TECNICA
     */
    public void setDE_CRITICIDADE_TECNICA(java.lang.String DE_CRITICIDADE_TECNICA) {
        this.DE_CRITICIDADE_TECNICA = DE_CRITICIDADE_TECNICA;
    }


    /**
     * Gets the NO_SIGLA value for this OutputMapping5GetListValues.
     * 
     * @return NO_SIGLA
     */
    public java.lang.String getNO_SIGLA() {
        return NO_SIGLA;
    }


    /**
     * Sets the NO_SIGLA value for this OutputMapping5GetListValues.
     * 
     * @param NO_SIGLA
     */
    public void setNO_SIGLA(java.lang.String NO_SIGLA) {
        this.NO_SIGLA = NO_SIGLA;
    }


    /**
     * Gets the DE_ESTADO value for this OutputMapping5GetListValues.
     * 
     * @return DE_ESTADO
     */
    public SIAPP_WS_DistinctItemPortfolio.DE_ESTADOType getDE_ESTADO() {
        return DE_ESTADO;
    }


    /**
     * Sets the DE_ESTADO value for this OutputMapping5GetListValues.
     * 
     * @param DE_ESTADO
     */
    public void setDE_ESTADO(SIAPP_WS_DistinctItemPortfolio.DE_ESTADOType DE_ESTADO) {
        this.DE_ESTADO = DE_ESTADO;
    }


    /**
     * Gets the DE_TIPO value for this OutputMapping5GetListValues.
     * 
     * @return DE_TIPO
     */
    public SIAPP_WS_DistinctItemPortfolio.DE_TIPOType getDE_TIPO() {
        return DE_TIPO;
    }


    /**
     * Sets the DE_TIPO value for this OutputMapping5GetListValues.
     * 
     * @param DE_TIPO
     */
    public void setDE_TIPO(SIAPP_WS_DistinctItemPortfolio.DE_TIPOType DE_TIPO) {
        this.DE_TIPO = DE_TIPO;
    }


    /**
     * Gets the NO_PADRAO_DES value for this OutputMapping5GetListValues.
     * 
     * @return NO_PADRAO_DES
     */
    public java.lang.String getNO_PADRAO_DES() {
        return NO_PADRAO_DES;
    }


    /**
     * Sets the NO_PADRAO_DES value for this OutputMapping5GetListValues.
     * 
     * @param NO_PADRAO_DES
     */
    public void setNO_PADRAO_DES(java.lang.String NO_PADRAO_DES) {
        this.NO_PADRAO_DES = NO_PADRAO_DES;
    }


    /**
     * Gets the DE_OBJETIVO value for this OutputMapping5GetListValues.
     * 
     * @return DE_OBJETIVO
     */
    public java.lang.String getDE_OBJETIVO() {
        return DE_OBJETIVO;
    }


    /**
     * Sets the DE_OBJETIVO value for this OutputMapping5GetListValues.
     * 
     * @param DE_OBJETIVO
     */
    public void setDE_OBJETIVO(java.lang.String DE_OBJETIVO) {
        this.DE_OBJETIVO = DE_OBJETIVO;
    }


    /**
     * Gets the DE_BENF_ESPERADO value for this OutputMapping5GetListValues.
     * 
     * @return DE_BENF_ESPERADO
     */
    public java.lang.String getDE_BENF_ESPERADO() {
        return DE_BENF_ESPERADO;
    }


    /**
     * Sets the DE_BENF_ESPERADO value for this OutputMapping5GetListValues.
     * 
     * @param DE_BENF_ESPERADO
     */
    public void setDE_BENF_ESPERADO(java.lang.String DE_BENF_ESPERADO) {
        this.DE_BENF_ESPERADO = DE_BENF_ESPERADO;
    }


    /**
     * Gets the DH_INICIO value for this OutputMapping5GetListValues.
     * 
     * @return DH_INICIO
     */
    public java.util.Date getDH_INICIO() {
        return DH_INICIO;
    }


    /**
     * Sets the DH_INICIO value for this OutputMapping5GetListValues.
     * 
     * @param DH_INICIO
     */
    public void setDH_INICIO(java.util.Date DH_INICIO) {
        this.DH_INICIO = DH_INICIO;
    }


    /**
     * Gets the DH_CONCLUSAO value for this OutputMapping5GetListValues.
     * 
     * @return DH_CONCLUSAO
     */
    public java.util.Date getDH_CONCLUSAO() {
        return DH_CONCLUSAO;
    }


    /**
     * Sets the DH_CONCLUSAO value for this OutputMapping5GetListValues.
     * 
     * @param DH_CONCLUSAO
     */
    public void setDH_CONCLUSAO(java.util.Date DH_CONCLUSAO) {
        this.DH_CONCLUSAO = DH_CONCLUSAO;
    }


    /**
     * Gets the NU_CRITICIDADE value for this OutputMapping5GetListValues.
     * 
     * @return NU_CRITICIDADE
     */
    public java.lang.Integer getNU_CRITICIDADE() {
        return NU_CRITICIDADE;
    }


    /**
     * Sets the NU_CRITICIDADE value for this OutputMapping5GetListValues.
     * 
     * @param NU_CRITICIDADE
     */
    public void setNU_CRITICIDADE(java.lang.Integer NU_CRITICIDADE) {
        this.NU_CRITICIDADE = NU_CRITICIDADE;
    }


    /**
     * Gets the DE_CARTEIRA value for this OutputMapping5GetListValues.
     * 
     * @return DE_CARTEIRA
     */
    public java.lang.String getDE_CARTEIRA() {
        return DE_CARTEIRA;
    }


    /**
     * Sets the DE_CARTEIRA value for this OutputMapping5GetListValues.
     * 
     * @param DE_CARTEIRA
     */
    public void setDE_CARTEIRA(java.lang.String DE_CARTEIRA) {
        this.DE_CARTEIRA = DE_CARTEIRA;
    }


    /**
     * Gets the NU_GRAU_INTERNALIZACAO value for this OutputMapping5GetListValues.
     * 
     * @return NU_GRAU_INTERNALIZACAO
     */
    public SIAPP_WS_DistinctItemPortfolio.NU_GRAU_INTERNALIZACAOType getNU_GRAU_INTERNALIZACAO() {
        return NU_GRAU_INTERNALIZACAO;
    }


    /**
     * Sets the NU_GRAU_INTERNALIZACAO value for this OutputMapping5GetListValues.
     * 
     * @param NU_GRAU_INTERNALIZACAO
     */
    public void setNU_GRAU_INTERNALIZACAO(SIAPP_WS_DistinctItemPortfolio.NU_GRAU_INTERNALIZACAOType NU_GRAU_INTERNALIZACAO) {
        this.NU_GRAU_INTERNALIZACAO = NU_GRAU_INTERNALIZACAO;
    }


    /**
     * Gets the NO_BD value for this OutputMapping5GetListValues.
     * 
     * @return NO_BD
     */
    public java.lang.String getNO_BD() {
        return NO_BD;
    }


    /**
     * Sets the NO_BD value for this OutputMapping5GetListValues.
     * 
     * @param NO_BD
     */
    public void setNO_BD(java.lang.String NO_BD) {
        this.NO_BD = NO_BD;
    }


    /**
     * Gets the IC_ESPECIAL value for this OutputMapping5GetListValues.
     * 
     * @return IC_ESPECIAL
     */
    public SIAPP_WS_DistinctItemPortfolio.IC_ESPECIALType getIC_ESPECIAL() {
        return IC_ESPECIAL;
    }


    /**
     * Sets the IC_ESPECIAL value for this OutputMapping5GetListValues.
     * 
     * @param IC_ESPECIAL
     */
    public void setIC_ESPECIAL(SIAPP_WS_DistinctItemPortfolio.IC_ESPECIALType IC_ESPECIAL) {
        this.IC_ESPECIAL = IC_ESPECIAL;
    }


    /**
     * Gets the NO_PROJETO_ESPECIAL value for this OutputMapping5GetListValues.
     * 
     * @return NO_PROJETO_ESPECIAL
     */
    public java.lang.String getNO_PROJETO_ESPECIAL() {
        return NO_PROJETO_ESPECIAL;
    }


    /**
     * Sets the NO_PROJETO_ESPECIAL value for this OutputMapping5GetListValues.
     * 
     * @param NO_PROJETO_ESPECIAL
     */
    public void setNO_PROJETO_ESPECIAL(java.lang.String NO_PROJETO_ESPECIAL) {
        this.NO_PROJETO_ESPECIAL = NO_PROJETO_ESPECIAL;
    }


    /**
     * Gets the DE_COORD_TI value for this OutputMapping5GetListValues.
     * 
     * @return DE_COORD_TI
     */
    public java.lang.String getDE_COORD_TI() {
        return DE_COORD_TI;
    }


    /**
     * Sets the DE_COORD_TI value for this OutputMapping5GetListValues.
     * 
     * @param DE_COORD_TI
     */
    public void setDE_COORD_TI(java.lang.String DE_COORD_TI) {
        this.DE_COORD_TI = DE_COORD_TI;
    }


    /**
     * Gets the DE_COORD_PROJ_TI value for this OutputMapping5GetListValues.
     * 
     * @return DE_COORD_PROJ_TI
     */
    public java.lang.String getDE_COORD_PROJ_TI() {
        return DE_COORD_PROJ_TI;
    }


    /**
     * Sets the DE_COORD_PROJ_TI value for this OutputMapping5GetListValues.
     * 
     * @param DE_COORD_PROJ_TI
     */
    public void setDE_COORD_PROJ_TI(java.lang.String DE_COORD_PROJ_TI) {
        this.DE_COORD_PROJ_TI = DE_COORD_PROJ_TI;
    }


    /**
     * Gets the DE_ALIAS value for this OutputMapping5GetListValues.
     * 
     * @return DE_ALIAS
     */
    public java.lang.String getDE_ALIAS() {
        return DE_ALIAS;
    }


    /**
     * Sets the DE_ALIAS value for this OutputMapping5GetListValues.
     * 
     * @param DE_ALIAS
     */
    public void setDE_ALIAS(java.lang.String DE_ALIAS) {
        this.DE_ALIAS = DE_ALIAS;
    }


    /**
     * Gets the DE_CONSIDE_GERAIS value for this OutputMapping5GetListValues.
     * 
     * @return DE_CONSIDE_GERAIS
     */
    public java.lang.String getDE_CONSIDE_GERAIS() {
        return DE_CONSIDE_GERAIS;
    }


    /**
     * Sets the DE_CONSIDE_GERAIS value for this OutputMapping5GetListValues.
     * 
     * @param DE_CONSIDE_GERAIS
     */
    public void setDE_CONSIDE_GERAIS(java.lang.String DE_CONSIDE_GERAIS) {
        this.DE_CONSIDE_GERAIS = DE_CONSIDE_GERAIS;
    }


    /**
     * Gets the DE_SITUACAO_DOCUMENTACAO value for this OutputMapping5GetListValues.
     * 
     * @return DE_SITUACAO_DOCUMENTACAO
     */
    public SIAPP_WS_DistinctItemPortfolio.DE_SITUACAO_DOCUMENTACAOType getDE_SITUACAO_DOCUMENTACAO() {
        return DE_SITUACAO_DOCUMENTACAO;
    }


    /**
     * Sets the DE_SITUACAO_DOCUMENTACAO value for this OutputMapping5GetListValues.
     * 
     * @param DE_SITUACAO_DOCUMENTACAO
     */
    public void setDE_SITUACAO_DOCUMENTACAO(SIAPP_WS_DistinctItemPortfolio.DE_SITUACAO_DOCUMENTACAOType DE_SITUACAO_DOCUMENTACAO) {
        this.DE_SITUACAO_DOCUMENTACAO = DE_SITUACAO_DOCUMENTACAO;
    }


    /**
     * Gets the DH_ULTIMA_ATUALIZACAO value for this OutputMapping5GetListValues.
     * 
     * @return DH_ULTIMA_ATUALIZACAO
     */
    public java.util.Date getDH_ULTIMA_ATUALIZACAO() {
        return DH_ULTIMA_ATUALIZACAO;
    }


    /**
     * Sets the DH_ULTIMA_ATUALIZACAO value for this OutputMapping5GetListValues.
     * 
     * @param DH_ULTIMA_ATUALIZACAO
     */
    public void setDH_ULTIMA_ATUALIZACAO(java.util.Date DH_ULTIMA_ATUALIZACAO) {
        this.DH_ULTIMA_ATUALIZACAO = DH_ULTIMA_ATUALIZACAO;
    }


    /**
     * Gets the DE_PRONTO_ATENDIMENTO value for this OutputMapping5GetListValues.
     * 
     * @return DE_PRONTO_ATENDIMENTO
     */
    public SIAPP_WS_DistinctItemPortfolio.DE_PRONTO_ATENDIMENTOType getDE_PRONTO_ATENDIMENTO() {
        return DE_PRONTO_ATENDIMENTO;
    }


    /**
     * Sets the DE_PRONTO_ATENDIMENTO value for this OutputMapping5GetListValues.
     * 
     * @param DE_PRONTO_ATENDIMENTO
     */
    public void setDE_PRONTO_ATENDIMENTO(SIAPP_WS_DistinctItemPortfolio.DE_PRONTO_ATENDIMENTOType DE_PRONTO_ATENDIMENTO) {
        this.DE_PRONTO_ATENDIMENTO = DE_PRONTO_ATENDIMENTO;
    }


    /**
     * Gets the NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL value for this OutputMapping5GetListValues.
     * 
     * @return NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL
     */
    public java.lang.String getNO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL() {
        return NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL;
    }


    /**
     * Sets the NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL value for this OutputMapping5GetListValues.
     * 
     * @param NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL
     */
    public void setNO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL(java.lang.String NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL) {
        this.NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL = NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL;
    }


    /**
     * Gets the IC_DESINTERNO value for this OutputMapping5GetListValues.
     * 
     * @return IC_DESINTERNO
     */
    public SIAPP_WS_DistinctItemPortfolio.IC_DESINTERNOType getIC_DESINTERNO() {
        return IC_DESINTERNO;
    }


    /**
     * Sets the IC_DESINTERNO value for this OutputMapping5GetListValues.
     * 
     * @param IC_DESINTERNO
     */
    public void setIC_DESINTERNO(SIAPP_WS_DistinctItemPortfolio.IC_DESINTERNOType IC_DESINTERNO) {
        this.IC_DESINTERNO = IC_DESINTERNO;
    }


    /**
     * Gets the DE_BIP value for this OutputMapping5GetListValues.
     * 
     * @return DE_BIP
     */
    public java.lang.String getDE_BIP() {
        return DE_BIP;
    }


    /**
     * Sets the DE_BIP value for this OutputMapping5GetListValues.
     * 
     * @param DE_BIP
     */
    public void setDE_BIP(java.lang.String DE_BIP) {
        this.DE_BIP = DE_BIP;
    }


    /**
     * Gets the NO_NAVEGACAO value for this OutputMapping5GetListValues.
     * 
     * @return NO_NAVEGACAO
     */
    public java.lang.String getNO_NAVEGACAO() {
        return NO_NAVEGACAO;
    }


    /**
     * Sets the NO_NAVEGACAO value for this OutputMapping5GetListValues.
     * 
     * @param NO_NAVEGACAO
     */
    public void setNO_NAVEGACAO(java.lang.String NO_NAVEGACAO) {
        this.NO_NAVEGACAO = NO_NAVEGACAO;
    }


    /**
     * Gets the DE_PROCESSO value for this OutputMapping5GetListValues.
     * 
     * @return DE_PROCESSO
     */
    public java.lang.String getDE_PROCESSO() {
        return DE_PROCESSO;
    }


    /**
     * Sets the DE_PROCESSO value for this OutputMapping5GetListValues.
     * 
     * @param DE_PROCESSO
     */
    public void setDE_PROCESSO(java.lang.String DE_PROCESSO) {
        this.DE_PROCESSO = DE_PROCESSO;
    }


    /**
     * Gets the DE_CENARIO value for this OutputMapping5GetListValues.
     * 
     * @return DE_CENARIO
     */
    public java.lang.String getDE_CENARIO() {
        return DE_CENARIO;
    }


    /**
     * Sets the DE_CENARIO value for this OutputMapping5GetListValues.
     * 
     * @param DE_CENARIO
     */
    public void setDE_CENARIO(java.lang.String DE_CENARIO) {
        this.DE_CENARIO = DE_CENARIO;
    }


    /**
     * Gets the DE_FASE value for this OutputMapping5GetListValues.
     * 
     * @return DE_FASE
     */
    public java.lang.String getDE_FASE() {
        return DE_FASE;
    }


    /**
     * Sets the DE_FASE value for this OutputMapping5GetListValues.
     * 
     * @param DE_FASE
     */
    public void setDE_FASE(java.lang.String DE_FASE) {
        this.DE_FASE = DE_FASE;
    }


    /**
     * Gets the NO_LINGUAGEM_PRO value for this OutputMapping5GetListValues.
     * 
     * @return NO_LINGUAGEM_PRO
     */
    public java.lang.String getNO_LINGUAGEM_PRO() {
        return NO_LINGUAGEM_PRO;
    }


    /**
     * Sets the NO_LINGUAGEM_PRO value for this OutputMapping5GetListValues.
     * 
     * @param NO_LINGUAGEM_PRO
     */
    public void setNO_LINGUAGEM_PRO(java.lang.String NO_LINGUAGEM_PRO) {
        this.NO_LINGUAGEM_PRO = NO_LINGUAGEM_PRO;
    }


    /**
     * Gets the DE_SITUACAO value for this OutputMapping5GetListValues.
     * 
     * @return DE_SITUACAO
     */
    public SIAPP_WS_DistinctItemPortfolio.DE_SITUACAOType getDE_SITUACAO() {
        return DE_SITUACAO;
    }


    /**
     * Sets the DE_SITUACAO value for this OutputMapping5GetListValues.
     * 
     * @param DE_SITUACAO
     */
    public void setDE_SITUACAO(SIAPP_WS_DistinctItemPortfolio.DE_SITUACAOType DE_SITUACAO) {
        this.DE_SITUACAO = DE_SITUACAO;
    }


    /**
     * Gets the DH_MODICACAO value for this OutputMapping5GetListValues.
     * 
     * @return DH_MODICACAO
     */
    public java.util.Date getDH_MODICACAO() {
        return DH_MODICACAO;
    }


    /**
     * Sets the DH_MODICACAO value for this OutputMapping5GetListValues.
     * 
     * @param DH_MODICACAO
     */
    public void setDH_MODICACAO(java.util.Date DH_MODICACAO) {
        this.DH_MODICACAO = DH_MODICACAO;
    }
    
    public java.lang.String getID_SISTEMA() {
		return ID_SISTEMA;
	}

	public void setID_SISTEMA(java.lang.String iD_SISTEMA) {
		ID_SISTEMA = iD_SISTEMA;
	}


    /**
     * Gets the NO_FORMAACESSO value for this OutputMapping5GetListValues.
     * 
     * @return NO_FORMAACESSO
     */
    public java.lang.String getNO_FORMAACESSO() {
        return NO_FORMAACESSO;
    }


    /**
     * Sets the NO_FORMAACESSO value for this OutputMapping5GetListValues.
     * 
     * @param NO_FORMAACESSO
     */
    public void setNO_FORMAACESSO(java.lang.String NO_FORMAACESSO) {
        this.NO_FORMAACESSO = NO_FORMAACESSO;
    }


    /**
     * Gets the NO_SO value for this OutputMapping5GetListValues.
     * 
     * @return NO_SO
     */
    public java.lang.String getNO_SO() {
        return NO_SO;
    }


    /**
     * Sets the NO_SO value for this OutputMapping5GetListValues.
     * 
     * @param NO_SO
     */
    public void setNO_SO(java.lang.String NO_SO) {
        this.NO_SO = NO_SO;
    }


    /**
     * Gets the NO_SUPORTE_DES value for this OutputMapping5GetListValues.
     * 
     * @return NO_SUPORTE_DES
     */
    public java.lang.String getNO_SUPORTE_DES() {
        return NO_SUPORTE_DES;
    }


    /**
     * Sets the NO_SUPORTE_DES value for this OutputMapping5GetListValues.
     * 
     * @param NO_SUPORTE_DES
     */
    public void setNO_SUPORTE_DES(java.lang.String NO_SUPORTE_DES) {
        this.NO_SUPORTE_DES = NO_SUPORTE_DES;
    }


    /**
     * Gets the NO_AMBIENTE value for this OutputMapping5GetListValues.
     * 
     * @return NO_AMBIENTE
     */
    public java.lang.String getNO_AMBIENTE() {
        return NO_AMBIENTE;
    }


    /**
     * Sets the NO_AMBIENTE value for this OutputMapping5GetListValues.
     * 
     * @param NO_AMBIENTE
     */
    public void setNO_AMBIENTE(java.lang.String NO_AMBIENTE) {
        this.NO_AMBIENTE = NO_AMBIENTE;
    }


    /**
     * Gets the NO_SERVIDOR_APP value for this OutputMapping5GetListValues.
     * 
     * @return NO_SERVIDOR_APP
     */
    public java.lang.String getNO_SERVIDOR_APP() {
        return NO_SERVIDOR_APP;
    }


    /**
     * Sets the NO_SERVIDOR_APP value for this OutputMapping5GetListValues.
     * 
     * @param NO_SERVIDOR_APP
     */
    public void setNO_SERVIDOR_APP(java.lang.String NO_SERVIDOR_APP) {
        this.NO_SERVIDOR_APP = NO_SERVIDOR_APP;
    }


    /**
     * Gets the NO_SERVIDOR_WEB value for this OutputMapping5GetListValues.
     * 
     * @return NO_SERVIDOR_WEB
     */
    public java.lang.String getNO_SERVIDOR_WEB() {
        return NO_SERVIDOR_WEB;
    }


    /**
     * Sets the NO_SERVIDOR_WEB value for this OutputMapping5GetListValues.
     * 
     * @param NO_SERVIDOR_WEB
     */
    public void setNO_SERVIDOR_WEB(java.lang.String NO_SERVIDOR_WEB) {
        this.NO_SERVIDOR_WEB = NO_SERVIDOR_WEB;
    }


    /**
     * Gets the NO_REDE value for this OutputMapping5GetListValues.
     * 
     * @return NO_REDE
     */
    public java.lang.String getNO_REDE() {
        return NO_REDE;
    }


    /**
     * Sets the NO_REDE value for this OutputMapping5GetListValues.
     * 
     * @param NO_REDE
     */
    public void setNO_REDE(java.lang.String NO_REDE) {
        this.NO_REDE = NO_REDE;
    }


    /**
     * Gets the NO_PLATAFORMA value for this OutputMapping5GetListValues.
     * 
     * @return NO_PLATAFORMA
     */
    public java.lang.String getNO_PLATAFORMA() {
        return NO_PLATAFORMA;
    }


    /**
     * Sets the NO_PLATAFORMA value for this OutputMapping5GetListValues.
     * 
     * @param NO_PLATAFORMA
     */
    public void setNO_PLATAFORMA(java.lang.String NO_PLATAFORMA) {
        this.NO_PLATAFORMA = NO_PLATAFORMA;
    }


    /**
     * Gets the NO_TECNOLOGIA_SUPORTE value for this OutputMapping5GetListValues.
     * 
     * @return NO_TECNOLOGIA_SUPORTE
     */
    public java.lang.String getNO_TECNOLOGIA_SUPORTE() {
        return NO_TECNOLOGIA_SUPORTE;
    }


    /**
     * Sets the NO_TECNOLOGIA_SUPORTE value for this OutputMapping5GetListValues.
     * 
     * @param NO_TECNOLOGIA_SUPORTE
     */
    public void setNO_TECNOLOGIA_SUPORTE(java.lang.String NO_TECNOLOGIA_SUPORTE) {
        this.NO_TECNOLOGIA_SUPORTE = NO_TECNOLOGIA_SUPORTE;
    }


    /**
     * Gets the NO_COMPONENTES value for this OutputMapping5GetListValues.
     * 
     * @return NO_COMPONENTES
     */
    public java.lang.String getNO_COMPONENTES() {
        return NO_COMPONENTES;
    }


    /**
     * Sets the NO_COMPONENTES value for this OutputMapping5GetListValues.
     * 
     * @param NO_COMPONENTES
     */
    public void setNO_COMPONENTES(java.lang.String NO_COMPONENTES) {
        this.NO_COMPONENTES = NO_COMPONENTES;
    }


    /**
     * Gets the NO_INTEGRACAO value for this OutputMapping5GetListValues.
     * 
     * @return NO_INTEGRACAO
     */
    public java.lang.String getNO_INTEGRACAO() {
        return NO_INTEGRACAO;
    }


    /**
     * Sets the NO_INTEGRACAO value for this OutputMapping5GetListValues.
     * 
     * @param NO_INTEGRACAO
     */
    public void setNO_INTEGRACAO(java.lang.String NO_INTEGRACAO) {
        this.NO_INTEGRACAO = NO_INTEGRACAO;
    }


    /**
     * Gets the NO_INTERFACE value for this OutputMapping5GetListValues.
     * 
     * @return NO_INTERFACE
     */
    public java.lang.String getNO_INTERFACE() {
        return NO_INTERFACE;
    }


    /**
     * Sets the NO_INTERFACE value for this OutputMapping5GetListValues.
     * 
     * @param NO_INTERFACE
     */
    public void setNO_INTERFACE(java.lang.String NO_INTERFACE) {
        this.NO_INTERFACE = NO_INTERFACE;
    }


    /**
     * Gets the NO_AUTENTICACAO value for this OutputMapping5GetListValues.
     * 
     * @return NO_AUTENTICACAO
     */
    public java.lang.String getNO_AUTENTICACAO() {
        return NO_AUTENTICACAO;
    }


    /**
     * Sets the NO_AUTENTICACAO value for this OutputMapping5GetListValues.
     * 
     * @param NO_AUTENTICACAO
     */
    public void setNO_AUTENTICACAO(java.lang.String NO_AUTENTICACAO) {
        this.NO_AUTENTICACAO = NO_AUTENTICACAO;
    }


    /**
     * Gets the NO_AUTORIZACAO value for this OutputMapping5GetListValues.
     * 
     * @return NO_AUTORIZACAO
     */
    public java.lang.String getNO_AUTORIZACAO() {
        return NO_AUTORIZACAO;
    }


    /**
     * Sets the NO_AUTORIZACAO value for this OutputMapping5GetListValues.
     * 
     * @param NO_AUTORIZACAO
     */
    public void setNO_AUTORIZACAO(java.lang.String NO_AUTORIZACAO) {
        this.NO_AUTORIZACAO = NO_AUTORIZACAO;
    }


    /**
     * Gets the NO_CERTIFICADO_DG value for this OutputMapping5GetListValues.
     * 
     * @return NO_CERTIFICADO_DG
     */
    public java.lang.String getNO_CERTIFICADO_DG() {
        return NO_CERTIFICADO_DG;
    }


    /**
     * Sets the NO_CERTIFICADO_DG value for this OutputMapping5GetListValues.
     * 
     * @param NO_CERTIFICADO_DG
     */
    public void setNO_CERTIFICADO_DG(java.lang.String NO_CERTIFICADO_DG) {
        this.NO_CERTIFICADO_DG = NO_CERTIFICADO_DG;
    }


    /**
     * Gets the NO_META value for this OutputMapping5GetListValues.
     * 
     * @return NO_META
     */
    public SIAPP_WS_DistinctItemPortfolio.NU_GRAU_INTERNALIZACAOType getNO_META() {
        return NO_META;
    }


    /**
     * Sets the NO_META value for this OutputMapping5GetListValues.
     * 
     * @param NO_META
     */
    public void setNO_META(SIAPP_WS_DistinctItemPortfolio.NU_GRAU_INTERNALIZACAOType NO_META) {
        this.NO_META = NO_META;
    }


    /**
     * Gets the DH_CRIACAO value for this OutputMapping5GetListValues.
     * 
     * @return DH_CRIACAO
     */
    public java.util.Date getDH_CRIACAO() {
        return DH_CRIACAO;
    }


    /**
     * Sets the DH_CRIACAO value for this OutputMapping5GetListValues.
     * 
     * @param DH_CRIACAO
     */
    public void setDH_CRIACAO(java.util.Date DH_CRIACAO) {
        this.DH_CRIACAO = DH_CRIACAO;
    }


    /**
     * Gets the NO_PARTICAO value for this OutputMapping5GetListValues.
     * 
     * @return NO_PARTICAO
     */
    public java.lang.String getNO_PARTICAO() {
        return NO_PARTICAO;
    }


    /**
     * Sets the NO_PARTICAO value for this OutputMapping5GetListValues.
     * 
     * @param NO_PARTICAO
     */
    public void setNO_PARTICAO(java.lang.String NO_PARTICAO) {
        this.NO_PARTICAO = NO_PARTICAO;
    }


    /**
     * Gets the NO_FERRAMENTA value for this OutputMapping5GetListValues.
     * 
     * @return NO_FERRAMENTA
     */
    public java.lang.String getNO_FERRAMENTA() {
        return NO_FERRAMENTA;
    }


    /**
     * Sets the NO_FERRAMENTA value for this OutputMapping5GetListValues.
     * 
     * @param NO_FERRAMENTA
     */
    public void setNO_FERRAMENTA(java.lang.String NO_FERRAMENTA) {
        this.NO_FERRAMENTA = NO_FERRAMENTA;
    }


    /**
     * Gets the NO_AMBIENTE_ACESSO value for this OutputMapping5GetListValues.
     * 
     * @return NO_AMBIENTE_ACESSO
     */
    public java.lang.String getNO_AMBIENTE_ACESSO() {
        return NO_AMBIENTE_ACESSO;
    }


    /**
     * Sets the NO_AMBIENTE_ACESSO value for this OutputMapping5GetListValues.
     * 
     * @param NO_AMBIENTE_ACESSO
     */
    public void setNO_AMBIENTE_ACESSO(java.lang.String NO_AMBIENTE_ACESSO) {
        this.NO_AMBIENTE_ACESSO = NO_AMBIENTE_ACESSO;
    }


    /**
     * Gets the NO_ACESSO value for this OutputMapping5GetListValues.
     * 
     * @return NO_ACESSO
     */
    public java.lang.String getNO_ACESSO() {
        return NO_ACESSO;
    }


    /**
     * Sets the NO_ACESSO value for this OutputMapping5GetListValues.
     * 
     * @param NO_ACESSO
     */
    public void setNO_ACESSO(java.lang.String NO_ACESSO) {
        this.NO_ACESSO = NO_ACESSO;
    }


    /**
     * Gets the DE_OBSERVACAO value for this OutputMapping5GetListValues.
     * 
     * @return DE_OBSERVACAO
     */
    public java.lang.String getDE_OBSERVACAO() {
        return DE_OBSERVACAO;
    }


    /**
     * Sets the DE_OBSERVACAO value for this OutputMapping5GetListValues.
     * 
     * @param DE_OBSERVACAO
     */
    public void setDE_OBSERVACAO(java.lang.String DE_OBSERVACAO) {
        this.DE_OBSERVACAO = DE_OBSERVACAO;
    }


    /**
     * Gets the IC_VPN value for this OutputMapping5GetListValues.
     * 
     * @return IC_VPN
     */
    public SIAPP_WS_DistinctItemPortfolio.IC_VPNType getIC_VPN() {
        return IC_VPN;
    }


    /**
     * Sets the IC_VPN value for this OutputMapping5GetListValues.
     * 
     * @param IC_VPN
     */
    public void setIC_VPN(SIAPP_WS_DistinctItemPortfolio.IC_VPNType IC_VPN) {
        this.IC_VPN = IC_VPN;
    }


    /**
     * Gets the DE_CRONOGRAMA_VIGENTE value for this OutputMapping5GetListValues.
     * 
     * @return DE_CRONOGRAMA_VIGENTE
     */
    public java.lang.String getDE_CRONOGRAMA_VIGENTE() {
        return DE_CRONOGRAMA_VIGENTE;
    }


    /**
     * Sets the DE_CRONOGRAMA_VIGENTE value for this OutputMapping5GetListValues.
     * 
     * @param DE_CRONOGRAMA_VIGENTE
     */
    public void setDE_CRONOGRAMA_VIGENTE(java.lang.String DE_CRONOGRAMA_VIGENTE) {
        this.DE_CRONOGRAMA_VIGENTE = DE_CRONOGRAMA_VIGENTE;
    }


    /**
     * Gets the ID_PROJETO_RTC value for this OutputMapping5GetListValues.
     * 
     * @return ID_PROJETO_RTC
     */
    public java.lang.String getID_PROJETO_RTC() {
        return ID_PROJETO_RTC;
    }


    /**
     * Sets the ID_PROJETO_RTC value for this OutputMapping5GetListValues.
     * 
     * @param ID_PROJETO_RTC
     */
    public void setID_PROJETO_RTC(java.lang.String ID_PROJETO_RTC) {
        this.ID_PROJETO_RTC = ID_PROJETO_RTC;
    }


    /**
     * Gets the IC_MPAS value for this OutputMapping5GetListValues.
     * 
     * @return IC_MPAS
     */
    public SIAPP_WS_DistinctItemPortfolio.IC_VPNType getIC_MPAS() {
        return IC_MPAS;
    }


    /**
     * Sets the IC_MPAS value for this OutputMapping5GetListValues.
     * 
     * @param IC_MPAS
     */
    public void setIC_MPAS(SIAPP_WS_DistinctItemPortfolio.IC_VPNType IC_MPAS) {
        this.IC_MPAS = IC_MPAS;
    }


    /**
     * Gets the IC_TRILHA value for this OutputMapping5GetListValues.
     * 
     * @return IC_TRILHA
     */
    public SIAPP_WS_DistinctItemPortfolio.IC_VPNType getIC_TRILHA() {
        return IC_TRILHA;
    }


    /**
     * Sets the IC_TRILHA value for this OutputMapping5GetListValues.
     * 
     * @param IC_TRILHA
     */
    public void setIC_TRILHA(SIAPP_WS_DistinctItemPortfolio.IC_VPNType IC_TRILHA) {
        this.IC_TRILHA = IC_TRILHA;
    }


    /**
     * Gets the DH_MODIFICACAO value for this OutputMapping5GetListValues.
     * 
     * @return DH_MODIFICACAO
     */
    public java.lang.String getDH_MODIFICACAO() {
        return DH_MODIFICACAO;
    }


    /**
     * Sets the DH_MODIFICACAO value for this OutputMapping5GetListValues.
     * 
     * @param DH_MODIFICACAO
     */
    public void setDH_MODIFICACAO(java.lang.String DH_MODIFICACAO) {
        this.DH_MODIFICACAO = DH_MODIFICACAO;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OutputMapping5GetListValues)) return false;
        OutputMapping5GetListValues other = (OutputMapping5GetListValues) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.NU_ITEM==null && other.getNU_ITEM()==null) || 
             (this.NU_ITEM!=null &&
              this.NU_ITEM.equals(other.getNU_ITEM()))) &&
            ((this.NO_APELIDO==null && other.getNO_APELIDO()==null) || 
             (this.NO_APELIDO!=null &&
              this.NO_APELIDO.equals(other.getNO_APELIDO()))) &&
            ((this.NO_GE==null && other.getNO_GE()==null) || 
             (this.NO_GE!=null &&
              this.NO_GE.equals(other.getNO_GE()))) &&
            ((this.NO_UNID_DES==null && other.getNO_UNID_DES()==null) || 
             (this.NO_UNID_DES!=null &&
              this.NO_UNID_DES.equals(other.getNO_UNID_DES()))) &&
            ((this.DE_ABRANGENCIA_USO==null && other.getDE_ABRANGENCIA_USO()==null) || 
             (this.DE_ABRANGENCIA_USO!=null &&
              this.DE_ABRANGENCIA_USO.equals(other.getDE_ABRANGENCIA_USO()))) &&
            ((this.DE_CRITICIDADE_NEGOCIO==null && other.getDE_CRITICIDADE_NEGOCIO()==null) || 
             (this.DE_CRITICIDADE_NEGOCIO!=null &&
              this.DE_CRITICIDADE_NEGOCIO.equals(other.getDE_CRITICIDADE_NEGOCIO()))) &&
            ((this.DE_CRITICIDADE_TECNICA==null && other.getDE_CRITICIDADE_TECNICA()==null) || 
             (this.DE_CRITICIDADE_TECNICA!=null &&
              this.DE_CRITICIDADE_TECNICA.equals(other.getDE_CRITICIDADE_TECNICA()))) &&
            ((this.NO_SIGLA==null && other.getNO_SIGLA()==null) || 
             (this.NO_SIGLA!=null &&
              this.NO_SIGLA.equals(other.getNO_SIGLA()))) &&
            ((this.DE_ESTADO==null && other.getDE_ESTADO()==null) || 
             (this.DE_ESTADO!=null &&
              this.DE_ESTADO.equals(other.getDE_ESTADO()))) &&
            ((this.DE_TIPO==null && other.getDE_TIPO()==null) || 
             (this.DE_TIPO!=null &&
              this.DE_TIPO.equals(other.getDE_TIPO()))) &&
            ((this.NO_PADRAO_DES==null && other.getNO_PADRAO_DES()==null) || 
             (this.NO_PADRAO_DES!=null &&
              this.NO_PADRAO_DES.equals(other.getNO_PADRAO_DES()))) &&
            ((this.DE_OBJETIVO==null && other.getDE_OBJETIVO()==null) || 
             (this.DE_OBJETIVO!=null &&
              this.DE_OBJETIVO.equals(other.getDE_OBJETIVO()))) &&
            ((this.DE_BENF_ESPERADO==null && other.getDE_BENF_ESPERADO()==null) || 
             (this.DE_BENF_ESPERADO!=null &&
              this.DE_BENF_ESPERADO.equals(other.getDE_BENF_ESPERADO()))) &&
            ((this.DH_INICIO==null && other.getDH_INICIO()==null) || 
             (this.DH_INICIO!=null &&
              this.DH_INICIO.equals(other.getDH_INICIO()))) &&
            ((this.DH_CONCLUSAO==null && other.getDH_CONCLUSAO()==null) || 
             (this.DH_CONCLUSAO!=null &&
              this.DH_CONCLUSAO.equals(other.getDH_CONCLUSAO()))) &&
            ((this.NU_CRITICIDADE==null && other.getNU_CRITICIDADE()==null) || 
             (this.NU_CRITICIDADE!=null &&
              this.NU_CRITICIDADE.equals(other.getNU_CRITICIDADE()))) &&
            ((this.DE_CARTEIRA==null && other.getDE_CARTEIRA()==null) || 
             (this.DE_CARTEIRA!=null &&
              this.DE_CARTEIRA.equals(other.getDE_CARTEIRA()))) &&
            ((this.NU_GRAU_INTERNALIZACAO==null && other.getNU_GRAU_INTERNALIZACAO()==null) || 
             (this.NU_GRAU_INTERNALIZACAO!=null &&
              this.NU_GRAU_INTERNALIZACAO.equals(other.getNU_GRAU_INTERNALIZACAO()))) &&
            ((this.NO_BD==null && other.getNO_BD()==null) || 
             (this.NO_BD!=null &&
              this.NO_BD.equals(other.getNO_BD()))) &&
            ((this.IC_ESPECIAL==null && other.getIC_ESPECIAL()==null) || 
             (this.IC_ESPECIAL!=null &&
              this.IC_ESPECIAL.equals(other.getIC_ESPECIAL()))) &&
            ((this.NO_PROJETO_ESPECIAL==null && other.getNO_PROJETO_ESPECIAL()==null) || 
             (this.NO_PROJETO_ESPECIAL!=null &&
              this.NO_PROJETO_ESPECIAL.equals(other.getNO_PROJETO_ESPECIAL()))) &&
            ((this.DE_COORD_TI==null && other.getDE_COORD_TI()==null) || 
             (this.DE_COORD_TI!=null &&
              this.DE_COORD_TI.equals(other.getDE_COORD_TI()))) &&
            ((this.DE_COORD_PROJ_TI==null && other.getDE_COORD_PROJ_TI()==null) || 
             (this.DE_COORD_PROJ_TI!=null &&
              this.DE_COORD_PROJ_TI.equals(other.getDE_COORD_PROJ_TI()))) &&
            ((this.DE_ALIAS==null && other.getDE_ALIAS()==null) || 
             (this.DE_ALIAS!=null &&
              this.DE_ALIAS.equals(other.getDE_ALIAS()))) &&
            ((this.DE_CONSIDE_GERAIS==null && other.getDE_CONSIDE_GERAIS()==null) || 
             (this.DE_CONSIDE_GERAIS!=null &&
              this.DE_CONSIDE_GERAIS.equals(other.getDE_CONSIDE_GERAIS()))) &&
            ((this.DE_SITUACAO_DOCUMENTACAO==null && other.getDE_SITUACAO_DOCUMENTACAO()==null) || 
             (this.DE_SITUACAO_DOCUMENTACAO!=null &&
              this.DE_SITUACAO_DOCUMENTACAO.equals(other.getDE_SITUACAO_DOCUMENTACAO()))) &&
            ((this.DH_ULTIMA_ATUALIZACAO==null && other.getDH_ULTIMA_ATUALIZACAO()==null) || 
             (this.DH_ULTIMA_ATUALIZACAO!=null &&
              this.DH_ULTIMA_ATUALIZACAO.equals(other.getDH_ULTIMA_ATUALIZACAO()))) &&
            ((this.DE_PRONTO_ATENDIMENTO==null && other.getDE_PRONTO_ATENDIMENTO()==null) || 
             (this.DE_PRONTO_ATENDIMENTO!=null &&
              this.DE_PRONTO_ATENDIMENTO.equals(other.getDE_PRONTO_ATENDIMENTO()))) &&
            ((this.NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL==null && other.getNO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL()==null) || 
             (this.NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL!=null &&
              this.NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL.equals(other.getNO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL()))) &&
            ((this.IC_DESINTERNO==null && other.getIC_DESINTERNO()==null) || 
             (this.IC_DESINTERNO!=null &&
              this.IC_DESINTERNO.equals(other.getIC_DESINTERNO()))) &&
            ((this.DE_BIP==null && other.getDE_BIP()==null) || 
             (this.DE_BIP!=null &&
              this.DE_BIP.equals(other.getDE_BIP()))) &&
            ((this.NO_NAVEGACAO==null && other.getNO_NAVEGACAO()==null) || 
             (this.NO_NAVEGACAO!=null &&
              this.NO_NAVEGACAO.equals(other.getNO_NAVEGACAO()))) &&
            ((this.DE_PROCESSO==null && other.getDE_PROCESSO()==null) || 
             (this.DE_PROCESSO!=null &&
              this.DE_PROCESSO.equals(other.getDE_PROCESSO()))) &&
            ((this.DE_CENARIO==null && other.getDE_CENARIO()==null) || 
             (this.DE_CENARIO!=null &&
              this.DE_CENARIO.equals(other.getDE_CENARIO()))) &&
            ((this.DE_FASE==null && other.getDE_FASE()==null) || 
             (this.DE_FASE!=null &&
              this.DE_FASE.equals(other.getDE_FASE()))) &&
            ((this.NO_LINGUAGEM_PRO==null && other.getNO_LINGUAGEM_PRO()==null) || 
             (this.NO_LINGUAGEM_PRO!=null &&
              this.NO_LINGUAGEM_PRO.equals(other.getNO_LINGUAGEM_PRO()))) &&
            ((this.DE_SITUACAO==null && other.getDE_SITUACAO()==null) || 
             (this.DE_SITUACAO!=null &&
              this.DE_SITUACAO.equals(other.getDE_SITUACAO()))) &&
            ((this.DH_MODICACAO==null && other.getDH_MODICACAO()==null) || 
             (this.DH_MODICACAO!=null &&
              this.DH_MODICACAO.equals(other.getDH_MODICACAO()))) &&
            ((this.NO_FORMAACESSO==null && other.getNO_FORMAACESSO()==null) || 
             (this.NO_FORMAACESSO!=null &&
              this.NO_FORMAACESSO.equals(other.getNO_FORMAACESSO()))) &&
            ((this.NO_SO==null && other.getNO_SO()==null) || 
             (this.NO_SO!=null &&
              this.NO_SO.equals(other.getNO_SO()))) &&
            ((this.NO_SUPORTE_DES==null && other.getNO_SUPORTE_DES()==null) || 
             (this.NO_SUPORTE_DES!=null &&
              this.NO_SUPORTE_DES.equals(other.getNO_SUPORTE_DES()))) &&
            ((this.NO_AMBIENTE==null && other.getNO_AMBIENTE()==null) || 
             (this.NO_AMBIENTE!=null &&
              this.NO_AMBIENTE.equals(other.getNO_AMBIENTE()))) &&
            ((this.NO_SERVIDOR_APP==null && other.getNO_SERVIDOR_APP()==null) || 
             (this.NO_SERVIDOR_APP!=null &&
              this.NO_SERVIDOR_APP.equals(other.getNO_SERVIDOR_APP()))) &&
            ((this.NO_SERVIDOR_WEB==null && other.getNO_SERVIDOR_WEB()==null) || 
             (this.NO_SERVIDOR_WEB!=null &&
              this.NO_SERVIDOR_WEB.equals(other.getNO_SERVIDOR_WEB()))) &&
            ((this.NO_REDE==null && other.getNO_REDE()==null) || 
             (this.NO_REDE!=null &&
              this.NO_REDE.equals(other.getNO_REDE()))) &&
            ((this.NO_PLATAFORMA==null && other.getNO_PLATAFORMA()==null) || 
             (this.NO_PLATAFORMA!=null &&
              this.NO_PLATAFORMA.equals(other.getNO_PLATAFORMA()))) &&
            ((this.NO_TECNOLOGIA_SUPORTE==null && other.getNO_TECNOLOGIA_SUPORTE()==null) || 
             (this.NO_TECNOLOGIA_SUPORTE!=null &&
              this.NO_TECNOLOGIA_SUPORTE.equals(other.getNO_TECNOLOGIA_SUPORTE()))) &&
            ((this.NO_COMPONENTES==null && other.getNO_COMPONENTES()==null) || 
             (this.NO_COMPONENTES!=null &&
              this.NO_COMPONENTES.equals(other.getNO_COMPONENTES()))) &&
            ((this.NO_INTEGRACAO==null && other.getNO_INTEGRACAO()==null) || 
             (this.NO_INTEGRACAO!=null &&
              this.NO_INTEGRACAO.equals(other.getNO_INTEGRACAO()))) &&
            ((this.NO_INTERFACE==null && other.getNO_INTERFACE()==null) || 
             (this.NO_INTERFACE!=null &&
              this.NO_INTERFACE.equals(other.getNO_INTERFACE()))) &&
            ((this.NO_AUTENTICACAO==null && other.getNO_AUTENTICACAO()==null) || 
             (this.NO_AUTENTICACAO!=null &&
              this.NO_AUTENTICACAO.equals(other.getNO_AUTENTICACAO()))) &&
            ((this.NO_AUTORIZACAO==null && other.getNO_AUTORIZACAO()==null) || 
             (this.NO_AUTORIZACAO!=null &&
              this.NO_AUTORIZACAO.equals(other.getNO_AUTORIZACAO()))) &&
            ((this.NO_CERTIFICADO_DG==null && other.getNO_CERTIFICADO_DG()==null) || 
             (this.NO_CERTIFICADO_DG!=null &&
              this.NO_CERTIFICADO_DG.equals(other.getNO_CERTIFICADO_DG()))) &&
            ((this.NO_META==null && other.getNO_META()==null) || 
             (this.NO_META!=null &&
              this.NO_META.equals(other.getNO_META()))) &&
            ((this.DH_CRIACAO==null && other.getDH_CRIACAO()==null) || 
             (this.DH_CRIACAO!=null &&
              this.DH_CRIACAO.equals(other.getDH_CRIACAO()))) &&
            ((this.NO_PARTICAO==null && other.getNO_PARTICAO()==null) || 
             (this.NO_PARTICAO!=null &&
              this.NO_PARTICAO.equals(other.getNO_PARTICAO()))) &&
            ((this.NO_FERRAMENTA==null && other.getNO_FERRAMENTA()==null) || 
             (this.NO_FERRAMENTA!=null &&
              this.NO_FERRAMENTA.equals(other.getNO_FERRAMENTA()))) &&
            ((this.NO_AMBIENTE_ACESSO==null && other.getNO_AMBIENTE_ACESSO()==null) || 
             (this.NO_AMBIENTE_ACESSO!=null &&
              this.NO_AMBIENTE_ACESSO.equals(other.getNO_AMBIENTE_ACESSO()))) &&
            ((this.NO_ACESSO==null && other.getNO_ACESSO()==null) || 
             (this.NO_ACESSO!=null &&
              this.NO_ACESSO.equals(other.getNO_ACESSO()))) &&
            ((this.DE_OBSERVACAO==null && other.getDE_OBSERVACAO()==null) || 
             (this.DE_OBSERVACAO!=null &&
              this.DE_OBSERVACAO.equals(other.getDE_OBSERVACAO()))) &&
            ((this.IC_VPN==null && other.getIC_VPN()==null) || 
             (this.IC_VPN!=null &&
              this.IC_VPN.equals(other.getIC_VPN()))) &&
            ((this.DE_CRONOGRAMA_VIGENTE==null && other.getDE_CRONOGRAMA_VIGENTE()==null) || 
             (this.DE_CRONOGRAMA_VIGENTE!=null &&
              this.DE_CRONOGRAMA_VIGENTE.equals(other.getDE_CRONOGRAMA_VIGENTE()))) &&
            ((this.ID_PROJETO_RTC==null && other.getID_PROJETO_RTC()==null) || 
             (this.ID_PROJETO_RTC!=null &&
              this.ID_PROJETO_RTC.equals(other.getID_PROJETO_RTC()))) &&
            ((this.IC_MPAS==null && other.getIC_MPAS()==null) || 
             (this.IC_MPAS!=null &&
              this.IC_MPAS.equals(other.getIC_MPAS()))) &&
            ((this.IC_TRILHA==null && other.getIC_TRILHA()==null) || 
             (this.IC_TRILHA!=null &&
              this.IC_TRILHA.equals(other.getIC_TRILHA()))) &&      
            ((this.ID_SISTEMA==null && other.getID_SISTEMA()==null) || 
                    (this.ID_SISTEMA!=null &&
                     this.ID_SISTEMA.equals(other.getID_SISTEMA()))) &&
            ((this.DH_MODIFICACAO==null && other.getDH_MODIFICACAO()==null) || 
             (this.DH_MODIFICACAO!=null &&
              this.DH_MODIFICACAO.equals(other.getDH_MODIFICACAO())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNU_ITEM() != null) {
            _hashCode += getNU_ITEM().hashCode();
        }
        if (getNO_APELIDO() != null) {
            _hashCode += getNO_APELIDO().hashCode();
        }
        if (getNO_GE() != null) {
            _hashCode += getNO_GE().hashCode();
        }
        if (getNO_UNID_DES() != null) {
            _hashCode += getNO_UNID_DES().hashCode();
        }
        if (getDE_ABRANGENCIA_USO() != null) {
            _hashCode += getDE_ABRANGENCIA_USO().hashCode();
        }
        if (getDE_CRITICIDADE_NEGOCIO() != null) {
            _hashCode += getDE_CRITICIDADE_NEGOCIO().hashCode();
        }
        if (getDE_CRITICIDADE_TECNICA() != null) {
            _hashCode += getDE_CRITICIDADE_TECNICA().hashCode();
        }
        if (getNO_SIGLA() != null) {
            _hashCode += getNO_SIGLA().hashCode();
        }
        if (getDE_ESTADO() != null) {
            _hashCode += getDE_ESTADO().hashCode();
        }
        if (getDE_TIPO() != null) {
            _hashCode += getDE_TIPO().hashCode();
        }
        if (getNO_PADRAO_DES() != null) {
            _hashCode += getNO_PADRAO_DES().hashCode();
        }
        if (getDE_OBJETIVO() != null) {
            _hashCode += getDE_OBJETIVO().hashCode();
        }
        if (getDE_BENF_ESPERADO() != null) {
            _hashCode += getDE_BENF_ESPERADO().hashCode();
        }
        if (getDH_INICIO() != null) {
            _hashCode += getDH_INICIO().hashCode();
        }
        if (getDH_CONCLUSAO() != null) {
            _hashCode += getDH_CONCLUSAO().hashCode();
        }
        if (getNU_CRITICIDADE() != null) {
            _hashCode += getNU_CRITICIDADE().hashCode();
        }
        if (getDE_CARTEIRA() != null) {
            _hashCode += getDE_CARTEIRA().hashCode();
        }
        if (getNU_GRAU_INTERNALIZACAO() != null) {
            _hashCode += getNU_GRAU_INTERNALIZACAO().hashCode();
        }
        if (getNO_BD() != null) {
            _hashCode += getNO_BD().hashCode();
        }
        if (getIC_ESPECIAL() != null) {
            _hashCode += getIC_ESPECIAL().hashCode();
        }
        if (getNO_PROJETO_ESPECIAL() != null) {
            _hashCode += getNO_PROJETO_ESPECIAL().hashCode();
        }
        if (getDE_COORD_TI() != null) {
            _hashCode += getDE_COORD_TI().hashCode();
        }
        if (getDE_COORD_PROJ_TI() != null) {
            _hashCode += getDE_COORD_PROJ_TI().hashCode();
        }
        if (getDE_ALIAS() != null) {
            _hashCode += getDE_ALIAS().hashCode();
        }
        if (getDE_CONSIDE_GERAIS() != null) {
            _hashCode += getDE_CONSIDE_GERAIS().hashCode();
        }
        if (getDE_SITUACAO_DOCUMENTACAO() != null) {
            _hashCode += getDE_SITUACAO_DOCUMENTACAO().hashCode();
        }
        if (getDH_ULTIMA_ATUALIZACAO() != null) {
            _hashCode += getDH_ULTIMA_ATUALIZACAO().hashCode();
        }
        if (getDE_PRONTO_ATENDIMENTO() != null) {
            _hashCode += getDE_PRONTO_ATENDIMENTO().hashCode();
        }
        if (getNO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL() != null) {
            _hashCode += getNO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL().hashCode();
        }
        if (getIC_DESINTERNO() != null) {
            _hashCode += getIC_DESINTERNO().hashCode();
        }
        if (getDE_BIP() != null) {
            _hashCode += getDE_BIP().hashCode();
        }
        if (getNO_NAVEGACAO() != null) {
            _hashCode += getNO_NAVEGACAO().hashCode();
        }
        if (getDE_PROCESSO() != null) {
            _hashCode += getDE_PROCESSO().hashCode();
        }
        if (getDE_CENARIO() != null) {
            _hashCode += getDE_CENARIO().hashCode();
        }
        if (getDE_FASE() != null) {
            _hashCode += getDE_FASE().hashCode();
        }
        if (getNO_LINGUAGEM_PRO() != null) {
            _hashCode += getNO_LINGUAGEM_PRO().hashCode();
        }
        if (getDE_SITUACAO() != null) {
            _hashCode += getDE_SITUACAO().hashCode();
        }
        if (getDH_MODICACAO() != null) {
            _hashCode += getDH_MODICACAO().hashCode();
        }
        if (getNO_FORMAACESSO() != null) {
            _hashCode += getNO_FORMAACESSO().hashCode();
        }
        if (getNO_SO() != null) {
            _hashCode += getNO_SO().hashCode();
        }
        if (getNO_SUPORTE_DES() != null) {
            _hashCode += getNO_SUPORTE_DES().hashCode();
        }
        if (getNO_AMBIENTE() != null) {
            _hashCode += getNO_AMBIENTE().hashCode();
        }
        if (getNO_SERVIDOR_APP() != null) {
            _hashCode += getNO_SERVIDOR_APP().hashCode();
        }
        if (getNO_SERVIDOR_WEB() != null) {
            _hashCode += getNO_SERVIDOR_WEB().hashCode();
        }
        if (getNO_REDE() != null) {
            _hashCode += getNO_REDE().hashCode();
        }
        if (getNO_PLATAFORMA() != null) {
            _hashCode += getNO_PLATAFORMA().hashCode();
        }
        if (getNO_TECNOLOGIA_SUPORTE() != null) {
            _hashCode += getNO_TECNOLOGIA_SUPORTE().hashCode();
        }
        if (getNO_COMPONENTES() != null) {
            _hashCode += getNO_COMPONENTES().hashCode();
        }
        if (getNO_INTEGRACAO() != null) {
            _hashCode += getNO_INTEGRACAO().hashCode();
        }
        if (getNO_INTERFACE() != null) {
            _hashCode += getNO_INTERFACE().hashCode();
        }
        if (getNO_AUTENTICACAO() != null) {
            _hashCode += getNO_AUTENTICACAO().hashCode();
        }
        if (getNO_AUTORIZACAO() != null) {
            _hashCode += getNO_AUTORIZACAO().hashCode();
        }
        if (getNO_CERTIFICADO_DG() != null) {
            _hashCode += getNO_CERTIFICADO_DG().hashCode();
        }
        if (getNO_META() != null) {
            _hashCode += getNO_META().hashCode();
        }
        if (getDH_CRIACAO() != null) {
            _hashCode += getDH_CRIACAO().hashCode();
        }
        if (getNO_PARTICAO() != null) {
            _hashCode += getNO_PARTICAO().hashCode();
        }
        if (getNO_FERRAMENTA() != null) {
            _hashCode += getNO_FERRAMENTA().hashCode();
        }
        if (getNO_AMBIENTE_ACESSO() != null) {
            _hashCode += getNO_AMBIENTE_ACESSO().hashCode();
        }
        if (getNO_ACESSO() != null) {
            _hashCode += getNO_ACESSO().hashCode();
        }
        if (getDE_OBSERVACAO() != null) {
            _hashCode += getDE_OBSERVACAO().hashCode();
        }
        if (getIC_VPN() != null) {
            _hashCode += getIC_VPN().hashCode();
        }
        if (getDE_CRONOGRAMA_VIGENTE() != null) {
            _hashCode += getDE_CRONOGRAMA_VIGENTE().hashCode();
        }
        if (getID_PROJETO_RTC() != null) {
            _hashCode += getID_PROJETO_RTC().hashCode();
        }
        if (getIC_MPAS() != null) {
            _hashCode += getIC_MPAS().hashCode();
        }
        if (getIC_TRILHA() != null) {
            _hashCode += getIC_TRILHA().hashCode();
        }
        if (getDH_MODIFICACAO() != null) {
            _hashCode += getDH_MODIFICACAO().hashCode();
        }        
        if (getID_SISTEMA() != null) {
            _hashCode += getID_SISTEMA().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OutputMapping5GetListValues.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", ">OutputMapping5>getListValues"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NU_ITEM");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NU_ITEM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_APELIDO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_APELIDO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_GE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_GE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_UNID_DES");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_UNID_DES"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_ABRANGENCIA_USO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_ABRANGENCIA_USO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_CRITICIDADE_NEGOCIO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_CRITICIDADE_NEGOCIO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_CRITICIDADE_TECNICA");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_CRITICIDADE_TECNICA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_SIGLA");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_SIGLA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_ESTADO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_ESTADO"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_ESTADOType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_TIPO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_TIPO"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_TIPOType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_PADRAO_DES");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_PADRAO_DES"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_OBJETIVO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_OBJETIVO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_BENF_ESPERADO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_BENF_ESPERADO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DH_INICIO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DH_INICIO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DH_CONCLUSAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DH_CONCLUSAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NU_CRITICIDADE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NU_CRITICIDADE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_CARTEIRA");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_CARTEIRA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NU_GRAU_INTERNALIZACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NU_GRAU_INTERNALIZACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NU_GRAU_INTERNALIZACAOType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_BD");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_BD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IC_ESPECIAL");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "IC_ESPECIAL"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "IC_ESPECIALType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_PROJETO_ESPECIAL");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_PROJETO_ESPECIAL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_COORD_TI");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_COORD_TI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_COORD_PROJ_TI");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_COORD_PROJ_TI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_ALIAS");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_ALIAS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_CONSIDE_GERAIS");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_CONSIDE_GERAIS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_SITUACAO_DOCUMENTACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_SITUACAO_DOCUMENTACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_SITUACAO_DOCUMENTACAOType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DH_ULTIMA_ATUALIZACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DH_ULTIMA_ATUALIZACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_PRONTO_ATENDIMENTO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_PRONTO_ATENDIMENTO"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_PRONTO_ATENDIMENTOType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_SITUACAO_CODIGO_FONTO_REPOSITO_CENTRAL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IC_DESINTERNO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "IC_DESINTERNO"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "IC_DESINTERNOType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_BIP");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_BIP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_NAVEGACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_NAVEGACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_PROCESSO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_PROCESSO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_CENARIO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_CENARIO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_FASE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_FASE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_LINGUAGEM_PRO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_LINGUAGEM_PRO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_SITUACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_SITUACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_SITUACAOType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DH_MODICACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DH_MODICACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_FORMAACESSO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_FORMAACESSO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_SO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_SO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_SUPORTE_DES");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_SUPORTE_DES"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_AMBIENTE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_AMBIENTE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_SERVIDOR_APP");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_SERVIDOR_APP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_SERVIDOR_WEB");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_SERVIDOR_WEB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_REDE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_REDE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_PLATAFORMA");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_PLATAFORMA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_TECNOLOGIA_SUPORTE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_TECNOLOGIA_SUPORTE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_COMPONENTES");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_COMPONENTES"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_INTEGRACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_INTEGRACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_INTERFACE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_INTERFACE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_AUTENTICACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_AUTENTICACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_AUTORIZACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_AUTORIZACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_CERTIFICADO_DG");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_CERTIFICADO_DG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_META");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_META"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NU_GRAU_INTERNALIZACAOType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DH_CRIACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DH_CRIACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_PARTICAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_PARTICAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_FERRAMENTA");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_FERRAMENTA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_AMBIENTE_ACESSO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_AMBIENTE_ACESSO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NO_ACESSO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "NO_ACESSO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_OBSERVACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_OBSERVACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IC_VPN");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "IC_VPN"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "IC_VPNType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DE_CRONOGRAMA_VIGENTE");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_CRONOGRAMA_VIGENTE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ID_PROJETO_RTC");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "ID_PROJETO_RTC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IC_MPAS");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "IC_MPAS"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "IC_VPNType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IC_TRILHA");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "IC_TRILHA"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "IC_VPNType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ID_SISTEMA");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "ID_SISTEMA"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DH_MODIFICACAO");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DH_MODIFICACAO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

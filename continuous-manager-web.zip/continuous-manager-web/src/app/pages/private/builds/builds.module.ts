import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BuildsRoutingModule } from './builds-routing.module';
import { BuildsComponent } from './builds.component';

@NgModule({
  imports: [
    CommonModule,
    BuildsRoutingModule
  ],
  declarations: [BuildsComponent]
})
export class BuildsModule { }

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.persistence.NoResultException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.CommitRepository;

/**
 * Classe de testes do CommitService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CommitServiceTest {

	@Mock
	private CommitRepository commitRepository;

	@InjectMocks
	private CommitService commitService;

	private Commit commit;

	@Before
	public void before() {
		commit = EntityBuilder.createProjects().get(0).getCommits().stream().findFirst().get();
		UtilReflection.setField(commitService, "log", Logger.getLogger(AuditService.class.getName()));
	}

	@Test
	public void testSave() {
		// Arrange
		Mockito.when(commitRepository.save(Mockito.<Commit>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());

		// Act
		Commit savedCommit = commitService.save(commit);

		// Then
		Assert.assertNotNull(savedCommit);
	}

	@Test
	public void testUpdate() {
		// Arrange
		Mockito.when(commitRepository.update(Mockito.<Commit>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());

		// Act
		Commit savedCommit = commitService.update(commit);

		// Then
		Assert.assertNotNull(savedCommit);
	}

	@Test
	public void testFindByIdException() {
		// Arrange
		Mockito.when(commitRepository.findById(Mockito.<CommitPK>any())).thenThrow(NoResultException.class);

		// Act
		Commit savedCommit = commitService.findById(commit.getId());

		Assert.assertNull(savedCommit);
	}
	
	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(commitRepository.findById(Mockito.<CommitPK>any())).thenReturn(commit);

		// Act
		Commit savedCommit = commitService.findById(commit.getId());

		// Then
		Assert.assertNotNull(savedCommit);
	}
	
	@Test
	public void testFindVersionByBuild() {
		// Arrange
		Mockito.when(commitRepository.findVersionByBuildId(Mockito.anyString(), Mockito.anyString(), Mockito.<Build>any())).thenReturn(commit);

		// Act
		Commit savedCommit = commitService.findVersionByBuild("inovacao", "continuous-manager-web", new Build());

		// Then
		Assert.assertNotNull(savedCommit);
	}
	
	@Test
	public void testFindVersionByBuildException() {
		// Arrange
		Mockito.when(commitRepository.findVersionByBuildId(Mockito.anyString(), Mockito.anyString(), Mockito.<Build>any())).thenThrow(NoResultException.class);
		// Act
		Commit savedCommit = commitService.findVersionByBuild("inovacao", "continuous-manager-web", new Build());

		Assert.assertNull(savedCommit);
	}
	
	@Test
	public void testFindByVersionOrCommit() {
		// Arrange
		Mockito.when(commitRepository.findByVersionOrCommit(Mockito.anyString(), Mockito.anyString(), Mockito.<Commit>any())).thenReturn(new ArrayList<>());
		// Act
		List<Commit> listCommit = commitService.findByVersionOrCommit("inovacao", "continuous-manager-web", commit);

		Assert.assertNotNull(listCommit);
	}

	@Test
	public void testFindByStatus() {
		// Arrange
		Mockito.when(commitRepository.findByStatus(Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(new ArrayList<>(EntityBuilder.createProjects().get(0).getCommits()));

		// Act
		List<Commit> savedCommits = commitService.findByStatus("inovacao", "continuous-manager-web", JenkinsResult.SUCCESS, 0, 30);

		// Then
		Assert.assertNotNull(savedCommits);
	}

	@Test
	public void testCountByStatus() {
		// Arrange
		Mockito.when(commitRepository.countByStatus(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(1L);

		// Act
		Long commits = commitService.countByStatus("inovacao", "continuous-manager-web", JenkinsResult.SUCCESS);

		// Then
		Assert.assertEquals(1L, commits.longValue());
	}
}

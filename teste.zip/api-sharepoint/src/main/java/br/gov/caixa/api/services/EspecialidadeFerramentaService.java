package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.EspecialidadeFerramentaDto;
import br.gov.caixa.api.model.Especialidade;
import br.gov.caixa.api.model.EspecialidadeFerramenta;
import br.gov.caixa.api.repository.EspecialidadeFerramentaRepository;
import br.gov.caixa.api.result.EspecialidadeFerramentaResult;

@Named
public class EspecialidadeFerramentaService {
	
	@Inject
	EspecialidadeFerramentaRepository repository;
	
	public EspecialidadeFerramentaResult listAll() {

		EspecialidadeFerramentaResult result = new EspecialidadeFerramentaResult();
		
		try {
			List<EspecialidadeFerramenta> lista = repository.findAll();

			if (lista != null) {
				result.setList(EspecialidadeFerramentaDto.fromEspecialidadeFerramentaToListDto(lista));
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma especialidadeFerramenta.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}

	public EspecialidadeFerramentaResult save(EspecialidadeFerramentaDto dto) {
		
		EspecialidadeFerramenta especialidadeFerramenta = EspecialidadeFerramenta.fromDtoToEspecialidadeFerramenta(dto);
				
		especialidadeFerramenta = repository.save(especialidadeFerramenta);		
		dto.setUid(especialidadeFerramenta.getUid());
		
		EspecialidadeFerramentaResult result = new EspecialidadeFerramentaResult();
		result.setEspecialidadeFerramenta(dto);
		result.setMessage("Executado com sucesso.");
		
		return result;
	}

	public EspecialidadeFerramentaResult delete(EspecialidadeFerramentaDto dto) {
		
		//EspecialidadeFerramenta especialidadeFerramenta = EspecialidadeFerramenta.fromDtoToEspecialidadeFerramenta(dto);
		EspecialidadeFerramentaResult result;
		
		EspecialidadeFerramenta especialidadeFerramenta = repository.findOne(dto.getUid());
		
		try {
			repository.delete(especialidadeFerramenta);
			
			result = new EspecialidadeFerramentaResult();
			result.setMessage("Executado com sucesso.");
			
		} catch (Exception e) {
			result = new EspecialidadeFerramentaResult();
			
			result.setIsError(true);
			result.setMessage("Existe(m) Rating(s) Associados a esta EspecialidadeFerramenta.");
			
			e.printStackTrace();
		}		
		return result;
	}
	
	public EspecialidadeFerramentaResult listEspecialidadeFerramentasByIdFerramenta(Long idEspecialidade) {
		EspecialidadeFerramentaResult result = new EspecialidadeFerramentaResult();
		try {
			
			Especialidade especialidade = new Especialidade();
			especialidade.setUid(idEspecialidade);
			
			List<EspecialidadeFerramenta> lista = repository.findByEspecialidade(especialidade);				
			
			if (lista != null) {
				result.setList(EspecialidadeFerramentaDto.fromEspecialidadeFerramentaToListDto(lista));					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Ferramenta para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

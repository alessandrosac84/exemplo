package br.gov.caixa.inovacao.continuousmanager.config.threadlocal;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import org.junit.Assert;
import org.junit.Test;

public class HelperThreadLocalTest {

	@Test
	public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InstantiationException,
			IllegalArgumentException, InvocationTargetException {
		// Arrange
		Constructor<HelperThreadLocal> constructor = HelperThreadLocal.class.getDeclaredConstructor();
		constructor.setAccessible(true);
		
		// Act
		constructor.newInstance();
		
		// Then
		Assert.assertTrue(Modifier.isPrivate(constructor.getModifiers()));
	}

}

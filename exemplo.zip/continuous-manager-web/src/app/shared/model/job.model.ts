import { HealthReport } from './health-report.model';
import { Build } from './build.model';

export class Job {
  public fullName: string;
  public name: string;
  public buildable: boolean;
  public builds: Build[];
  public color: string;
  public healthReport: HealthReport[];
}

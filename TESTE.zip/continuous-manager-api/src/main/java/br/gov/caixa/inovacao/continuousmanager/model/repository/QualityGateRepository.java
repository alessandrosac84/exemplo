package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.gov.caixa.inovacao.continuousmanager.model.entity.QualityGate;

/**
 * Classe de acesso ao banco de dados da entidade Parameter.
 * 
 * @author Alessandro Carvalho
 *
 */
@ApplicationScoped
public class QualityGateRepository {
	
	@Inject
	private EntityManager entityManager;
	
	/**
	 * Salva Quality Gate
	 * 
	 * @param QualityGate
	 * @return QualityGate
	 */
	public QualityGate save(QualityGate qualityGate) {
		entityManager.persist(qualityGate);
		return qualityGate;
	}
}

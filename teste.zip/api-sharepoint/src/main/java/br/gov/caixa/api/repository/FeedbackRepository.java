package br.gov.caixa.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.gov.caixa.api.model.Feedback;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

}

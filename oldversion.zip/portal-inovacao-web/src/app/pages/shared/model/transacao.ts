
export class Transacao {
    public sistemaId: string;
    public nomeSistema: string;
    public uri: string;
    public programa: string;
    public flag: string;
    public bookEntrada: string;
    public bookSaida: string;
    public diretorioEntrada: string;
    public diretorioSaida: string;
}



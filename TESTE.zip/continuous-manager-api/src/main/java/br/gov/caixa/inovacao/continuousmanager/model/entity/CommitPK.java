package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * The primary key class for the git_repo database table.
 * 
 * @author Fabio Iwakoshi
 */
@Embeddable
public class CommitPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@JsonView({ViewJson.BuildView.class, ViewJson.CommitView.class})
	@Column(unique=true, nullable=false, length=40)
	private String commit;

	@JsonView(ViewJson.CommitView.class)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String project;

	@JsonView(ViewJson.CommitView.class)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String wallet;

	public CommitPK() {
		/* class constructor intentionally left blank */
	}
	public String getCommit() {
		return this.commit;
	}
	public void setCommit(String commit) {
		this.commit = commit;
	}
	public String getProject() {
		return this.project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getWallet() {
		return this.wallet;
	}
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CommitPK)) {
			return false;
		}
		CommitPK castOther = (CommitPK)other;
		return 
			this.commit.equals(castOther.commit)
			&& this.project.equals(castOther.project)
			&& this.wallet.equals(castOther.wallet);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.commit.hashCode();
		hash = hash * prime + this.project.hashCode();
		hash = hash * prime + this.wallet.hashCode();
		
		return hash;
	}
}
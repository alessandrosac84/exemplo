package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-01-30T16:53:57.792-0200")
@StaticMetamodel(BuildPK.class)
public class BuildPK_ {
	public static volatile SingularAttribute<BuildPK, Integer> id;
	public static volatile SingularAttribute<BuildPK, String> project;
	public static volatile SingularAttribute<BuildPK, String> wallet;
	public static volatile SingularAttribute<BuildPK, String> job;
}

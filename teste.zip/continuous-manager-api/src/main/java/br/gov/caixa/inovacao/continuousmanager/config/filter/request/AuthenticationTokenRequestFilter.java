/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.filter.request;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.annotation.Priority;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.PreMatching;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.config.exception.ErrorEntity;
import br.gov.caixa.inovacao.continuousmanager.config.filter.vo.Authentication;
import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;

/**
 * Filtro de autenticação da aplicação
 * 
 * @author Fabio Iwakoshi
 *
 */
@Provider
@PreMatching
@Priority(Priorities.AUTHENTICATION)
public class AuthenticationTokenRequestFilter implements ContainerRequestFilter {

	private static final String AUTH_FAILED = "auth-failed";

	@Context
	private HttpServletRequest request;

	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		Logger log = Logger.getLogger(this.getClass().getName());
		log.fine("Executando Request Filter Authentication... ");
		
		if (requestContext.getMethod().equals("OPTIONS")) {
			requestContext.abortWith(Response.status(Response.Status.OK).build());
			return;
		}

		if (requestContext.getUriInfo().getPath().contains("/auth/login")) {
			try {
				Authentication authentication = new Authentication().username("").password("");
				if (requestContext.hasEntity()) {
					String entity = new BufferedReader(new InputStreamReader(requestContext.getEntityStream())).lines()
							.collect(Collectors.joining("\n"));
					if (!entity.isEmpty()) {
						authentication = new ObjectMapper().readValue(entity, Authentication.class);
					}
				}
				request.login(authentication.getUsername(), authentication.getPassword());
				HelperThreadLocal.USER.set(request.getUserPrincipal().getName());
				requestContext.abortWith(Response.status(Response.Status.OK).build());
			} catch (Exception e) {
				log.log(Level.SEVERE, "Erro na autenticação!", e);
				requestContext.setProperty(AUTH_FAILED, true);
				requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
			}
		} else {
			if (requestContext.getHeaderString("Authorization") != null) {
				try {
					request.login("", "");
					HelperThreadLocal.USER.set(request.getUserPrincipal().getName());
				} catch (ServletException e) {
					log.log(Level.SEVERE, "Erro ao validar o token!", e);
					requestContext.setProperty(AUTH_FAILED, true);
					requestContext.abortWith(Response.status(Response.Status.FORBIDDEN).build());
				}
			}
		}
	}
}

/**
 * 
 */
package br.gov.caixa.sharepoint.config.security.subject;

/**
 * @author Fabio Iwakoshi
 *
 */
public class PrincipalThreadLocal {

	public static final ThreadLocal<Principal> USER = new ThreadLocal<>();
}

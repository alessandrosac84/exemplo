/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpMethod;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpProtocol;
import br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab.CommitGitLabVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab.SimpleUserGitLabVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab.UserGitLabVO;
import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;
import br.gov.caixa.inovacao.continuousmanager.service.integration.HttpService.IEntity;

/**
 * Classe de servicos do GitLab.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class GitLabService {

	@Inject
	private Logger log;

	@Inject
	private ParameterService parameterService;

	/**
	 * Obtem as listas de carteiras
	 * 
	 * @return Lista de Carteiras
	 */
	public CommitGitLabVO getCommit(String wallet, String project, String commit) {
		log.fine("Obtendo Commit");
		try {
			return callGitLab(
					Environment.DES, HttpMethod.GET, "/api/v4/projects/"
							+ URLEncoder.encode(wallet + "/" + project, "UTF-8") + "/repository/commits/" + commit,
					null, null, new TypeReference<CommitGitLabVO>() {
					});
		} catch (UnsupportedEncodingException e) {
			throw new ServiceUnavailableException("Erro ao obter Commit no GitLab!");
		}
	}

	public List<CommitGitLabVO> getCommits(String wallet, String project) {
		log.fine("Obtendo Commits");
		try {
			return callGitLab(
					Environment.DES, HttpMethod.GET, "/api/v4/projects/"
							+ URLEncoder.encode(wallet + "/" + project, "UTF-8") + "/repository/commits",
					null, null, new TypeReference<List<CommitGitLabVO>>() {
					});
		} catch (UnsupportedEncodingException e) {
			throw new ServiceUnavailableException("Erro ao obter Commits no GitLab!");
		}
	}

	public UserGitLabVO getUserByMatricula(String matricula) {
		log.fine("Obtendo Usuario do GitLab pela Matricula");
		return callGitLab(Environment.DES, HttpMethod.GET, "/api/v4/users/" + getSimpleUserByMatricula(matricula).getId(),
				null, null, new TypeReference<UserGitLabVO>() {
				});
	}

	public SimpleUserGitLabVO getSimpleUserByMatricula(String matricula) {
		log.fine("Obtendo Usuario do GitLab");
		Map<String, String> query = new HashMap<>();
		query.put("active", "true");
		query.put("username", matricula);
		List<SimpleUserGitLabVO> users = callGitLab(Environment.DES, HttpMethod.GET, "/api/v4/users", query, null,
				new TypeReference<List<SimpleUserGitLabVO>>() {
				});
		if (users != null && !users.isEmpty()) {
			return users.get(0);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	private <T> T callGitLab(Environment environment, HttpMethod httpMethod, String path, Map<String, String> queries,
			Entity<?> entity, TypeReference<T> typeReference) {

		ParameterPK parameterId = new ParameterPK();
		parameterId.setEnvironment(environment);
		parameterId.setServerType(ServerType.GITLAB);

		Parameter parameter = parameterService.findById(parameterId);

		if (parameter == null) {
			throw new NotFoundException("Erro ao obter informação do sistema!");
		}

		IEntity build = HttpService.httpProtocol(HttpProtocol.HTTP).httpMethod(httpMethod).host(parameter.getHost())
				.path(path).queries(queries).header("PRIVATE-TOKEN", parameter.getPrincipal());

		Response response = build.entity(entity).build();

		if (response.hasEntity() && response.getStatus() == 200) {
			try {
				String resposta = response.readEntity(String.class);
				if (typeReference.getType().getTypeName().equals("java.lang.String")) {
					return (T) resposta;
				}
				return new ObjectMapper().readValue(resposta, typeReference);
			} catch (IOException e) {
				log.log(Level.SEVERE, "Erro ao transformar informações do GitLab!", e);
				throw new ServiceUnavailableException("Erro ao obter informações do GitLab!");
			}
		} else if (response.getStatus() == 201 || response.getStatus() == 204) {
			return null;
		}
		throw new NotFoundException("Nenhuma informação encontrada!");
	}
}

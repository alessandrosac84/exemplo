package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.views.FuncionarioQuestionanteDto;
import br.gov.caixa.api.model.views.FuncionarioQuestionante;
import br.gov.caixa.api.repository.views.FuncionarioQuestionanteRepository;
import br.gov.caixa.api.result.views.FuncionarioQuestionanteResult;

@Named
public class FuncionarioQuestionanteService {
	
	@Inject
	private FuncionarioQuestionanteRepository repository;
	
	public FuncionarioQuestionanteResult listAll() {
		List<FuncionarioQuestionante> lista = (repository.findAll());
		FuncionarioQuestionanteResult result = new FuncionarioQuestionanteResult();
		
		result.setList(FuncionarioQuestionanteDto.fromFuncionarioQuestionanteToListDto(lista));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}

	public FuncionarioQuestionanteResult listFuncionariosQuestionantesByQuestionarioId(Long questionarioId) {
		List<FuncionarioQuestionante> lista = repository.findByQuestionarioAndNulls(questionarioId);
		
		FuncionarioQuestionanteResult result = new FuncionarioQuestionanteResult();
		
		result.setList(FuncionarioQuestionanteDto.fromFuncionarioQuestionanteToListDto(lista));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}	
	
}

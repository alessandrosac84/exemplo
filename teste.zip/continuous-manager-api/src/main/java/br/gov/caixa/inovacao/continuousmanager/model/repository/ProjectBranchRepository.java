package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ProjectBranch;

/**
 * Classe de acesso ao banco de dados da entidade Parameter.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class ProjectBranchRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Metodo responsavel pela pela consulta por Repository
	 * 
	 * @param repository
	 * @return Project
	 */
	public ProjectBranch findByRepository(String repository, Environment environment, String branch) {
		return entityManager.createQuery(
				"SELECT DISTINCT pb FROM ProjectBranch pb JOIN FETCH pb.project p JOIN FETCH pb.branchInstances bi JOIN FETCH bi.instance i "
				+ "LEFT JOIN FETCH pb.branchParameters bp JOIN FETCH i.server s JOIN FETCH s.flavor f "
				+ "WHERE p.gitRepo = :repository AND pb.id.branch = :branch AND s.environment = :environment",
				ProjectBranch.class).setParameter("repository", repository).setParameter("branch", branch)
				.setParameter("environment", environment).getSingleResult();
	}
}

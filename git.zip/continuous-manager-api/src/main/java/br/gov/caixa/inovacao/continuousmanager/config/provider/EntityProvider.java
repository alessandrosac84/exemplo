package br.gov.caixa.inovacao.continuousmanager.config.provider;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class EntityProvider {

	@Produces
    @PersistenceContext
    private EntityManager entityManager;
}

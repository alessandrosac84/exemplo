package br.gov.caixa.api.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.gov.caixa.api.dto.FuncionarioQuestionanteOptionsDto;

@Entity
@Table(name = "funcionario_questionante_options")
public class FuncionarioQuestionanteOptions {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "NOME", nullable = false)
	private String nome;

	@Column(name = "MATRICULA", nullable = false)
	private String matricula;

	@Column(name = "CARGO", nullable = true)
	private String cargo;
	
	@Column(name = "QUESTIONANTE_ID")
	private Long questionanteId;
	
	@Column(name = "PARTICIPACAO", nullable = true, columnDefinition = "boolean default false")
	private Boolean participacao;

	@Column(name = "QUESTIONARIO_ID")
	private Long questionarioId;
	
	@Column(name = "QUESTAO")
	private String questao;
	
	@Column(name = "OPTION1")
	private String option1;

	@Column(name = "OPTION2")
	private String option2;
	
	@Column(name = "OPTION3")
	private String option3;
	
		
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	
	public Long getQuestionanteId() {
		return questionanteId;
	}

	public void setQuestionanteId(Long questionanteId) {
		this.questionanteId = questionanteId;
	}

	public Boolean isParticipacao() {
		return participacao;
	}

	public void setParticipacao(Boolean participacao) {
		this.participacao = participacao;
	}

	public Long getQuestionarioId() {
		return questionarioId;
	}

	public void setQuestionarioId(Long questionarioId) {
		this.questionarioId = questionarioId;
	}

	public String getQuestao() {
		return questao;
	}

	public void setQuestao(String questao) {
		this.questao = questao;
	}
	
	public String getOption1() {
		return option1;
	}

	public void setOption1(String option1) {
		this.option1 = option1;
	}

	public String getOption2() {
		return option2;
	}

	public void setOption2(String option2) {
		this.option2 = option2;
	}

	public String getOption3() {
		return option3;
	}

	public void setOption3(String option3) {
		this.option3 = option3;
	}
	
	public static FuncionarioQuestionanteOptions fromDtoToFuncionarioQuestionanteOptions(FuncionarioQuestionanteOptionsDto funcionarioQuestionanteOptionsDto) {
		
		FuncionarioQuestionanteOptions funcionarioQuestionanteOptions = new FuncionarioQuestionanteOptions();
		
		funcionarioQuestionanteOptions.setUid(funcionarioQuestionanteOptionsDto.getUid());
		funcionarioQuestionanteOptions.setNome(funcionarioQuestionanteOptionsDto.getNome());
		funcionarioQuestionanteOptions.setMatricula(funcionarioQuestionanteOptionsDto.getMatricula());
		funcionarioQuestionanteOptions.setCargo(funcionarioQuestionanteOptionsDto.getCargo());				
		funcionarioQuestionanteOptions.setQuestionanteId(funcionarioQuestionanteOptionsDto.getQuestionanteId());
		funcionarioQuestionanteOptions.setParticipacao(funcionarioQuestionanteOptionsDto.isParticipacao());
		funcionarioQuestionanteOptions.setQuestionarioId(funcionarioQuestionanteOptionsDto.getQuestionarioId());		
		funcionarioQuestionanteOptions.setQuestao(funcionarioQuestionanteOptionsDto.getQuestao());
		funcionarioQuestionanteOptions.setOption1(funcionarioQuestionanteOptionsDto.getOption1());
		funcionarioQuestionanteOptions.setOption2(funcionarioQuestionanteOptionsDto.getOption2());
		funcionarioQuestionanteOptions.setOption3(funcionarioQuestionanteOptionsDto.getOption3());
		
		return funcionarioQuestionanteOptions;
	}

	public static List<FuncionarioQuestionanteOptions> fromDtoToListFuncionarioQuestionanteOptions(List<FuncionarioQuestionanteOptionsDto> funcionariosQuestionanteOptionssDto) {
		 List<FuncionarioQuestionanteOptions> result = new ArrayList<FuncionarioQuestionanteOptions>();
		 
		 for (Iterator<FuncionarioQuestionanteOptionsDto> iterator = funcionariosQuestionanteOptionssDto.iterator(); iterator.hasNext();) {
			FuncionarioQuestionanteOptionsDto dto = (FuncionarioQuestionanteOptionsDto) iterator.next();
			result.add(fromDtoToFuncionarioQuestionanteOptions(dto));
		}
		 
		return result;
	}
}
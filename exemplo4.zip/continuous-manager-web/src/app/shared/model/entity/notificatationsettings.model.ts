export class NotificationSettings {
  environment: string;
  request: boolean;
  deploy: boolean;
}

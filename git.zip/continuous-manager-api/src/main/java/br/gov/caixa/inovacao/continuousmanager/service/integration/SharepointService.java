/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpMethod;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sharepoint.AtivoSharepointVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sharepoint.FuncionarioSharepointVO;
import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;
import br.gov.caixa.inovacao.continuousmanager.service.integration.HttpService.IEntity;

/**
 * Classe de servicos do Sharepoint.
 * 
 * @author Fabio Iwakoshi
 *
 */
@Logged
@Stateless
public class SharepointService {

	@Inject
	private Logger log;

	@Inject
	private ParameterService parameterService;

	/**
	 * Obtem as listas de Ativos
	 * 
	 * @return Lista de Ativos
	 */
	public List<AtivoSharepointVO> getAtivos(String matricula) {
		log.log(Level.FINE, "Obtendo Ativos do Usuário {0}", matricula);
		Map<String, String> query = new HashMap<>();
		query.put("tipo-ativo", "1");
		return callSharepoint(Environment.DES, HttpMethod.GET, "/sharepoint-api/api/funcionario/" + matricula + "/ativo", query, null,
				new TypeReference<List<AtivoSharepointVO>>() {
				});
	}

	public FuncionarioSharepointVO getFuncionario(String matricula) {
		log.log(Level.FINE, "Obtendo Usuário {0}", matricula);
		return callSharepoint(Environment.DES, HttpMethod.GET, "/sharepoint-api/api/funcionario/" + matricula, null, null,
				new TypeReference<FuncionarioSharepointVO>() {
				});
	}

	private <T> T callSharepoint(Environment environment, HttpMethod httpMethod, String path,
			Map<String, String> queries, Entity<?> entity, TypeReference<T> typeReference) {

		ParameterPK parameterId = new ParameterPK();
		parameterId.setEnvironment(environment);
		parameterId.setServerType(ServerType.SHAREPOINT);

		Parameter parameter = parameterService.findById(parameterId);

		if (parameter == null) {
			throw new NotFoundException("Erro ao obter informação do sistema!");
		}
		
		IEntity build = HttpService.httpMethod(httpMethod).host(parameter.getHost())
				.path(path).queries(queries).header("", "");

		Response response = build.entity(entity).build();

		if (response.hasEntity() && response.getStatus() == 200) {
			try {
				return new ObjectMapper().readValue(response.readEntity(String.class), typeReference);
			} catch (IOException e) {
				log.log(Level.SEVERE, "Erro ao transformar informações do Sharepoint!", e);
				throw new ServiceUnavailableException("Erro ao obter informações do Sharepoint!");
			}
		}
		throw new NotFoundException("Nenhuma informação encontrada!");
	}
}

import { ReleaseComponent } from './release.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { ReleaseRoutingModule } from './release-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ReleaseRoutingModule,
    FormsModule,
    NgbModule.forRoot()
  ],
  declarations: [
    ReleaseComponent
  ]
})
export class ReleaseModule { }

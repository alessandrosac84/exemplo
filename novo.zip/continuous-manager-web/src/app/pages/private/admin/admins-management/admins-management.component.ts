import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cm-admins-management',
  templateUrl: './admins-management.component.html',
  styles: []
})
export class AdminsManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

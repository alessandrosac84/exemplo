/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildLog;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildLogPK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.BuildLogRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.Stage;
import br.gov.caixa.inovacao.continuousmanager.model.vo.Step;

/**
 * Classe de servicos de BuildLog.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class BuildLogService {

	@Inject
	private Logger log;

	@Inject
	private BuildLogRepository buildLogRepository;
	
	public BuildLog findById(String wallet, String project, String job, Integer build) {
		log.fine("Obtendo BuildLog IDs");
		BuildLogPK id = new BuildLogPK();
		id.setWallet(wallet);
		id.setProject(project);
		id.setJob(job);
		id.setBuild(build);
		
		return findById(id);
	}
	
	public BuildLog findById(BuildLogPK id) {
		log.fine("Obtendo BuildLog IDs");
		return buildLogRepository.findById(id);
	}
	
	public String getLog(String wallet, String project, String job, Integer build) {
		log.fine("Obtendo Log");
		return findById(wallet, project, job, build).getLog();
	}
	
	public List<Stage> getLogStages(String wallet, String project, String job, Integer build) { //NOSONAR
		log.fine("Obtendo Log em estagios");
		String logFile = getLog(wallet, project, job, build);
		
		List<Stage> stages = new ArrayList<>();
		Stage currentStage = null;
		Step currentStep = null;
		StringBuilder currentLine = new StringBuilder();
			
		String[] stageFiles = Arrays.stream(logFile.split("\\[Pipeline\\] stage")).skip(1).toArray(String[]::new);
		for (String stage : stageFiles) {
			String[] steps = stage.split("\\[Pipeline\\] ");
			for (String step : steps) {
				String[] lines = step.split("\n");
				for (String line : lines) {
					if (line.trim().equals("}") || line.trim().equals("{") || line.trim().matches("// \\w*") || line.trim().isEmpty()) {
						continue;
					}
					Pattern p = Pattern.compile("\\{ \\(([\\w\\s]+)\\)");
					Matcher match = p.matcher(line);
					if (match.find()) {
						log.log(Level.FINER, "::>> Stage {0}", match.group(1));
						currentStage = new Stage();
						currentStage.setName(match.group(1));
						currentStage.setSteps(new ArrayList<>());
						stages.add(currentStage);
					} else {
						if (lines[0] == line) {
							log.log(Level.FINER, "    ::>> Step {0}", line);
							if (currentStep != null) {
								currentStep.setLines(currentLine.toString());
								currentLine = new StringBuilder();
							}
							currentStep = new Step();
							currentStep.setName(line);
							if (currentStage != null) {
								currentStage.getSteps().add(currentStep);
							}
						} else {						
							log.log(Level.FINER, "        >{0}<", line);
							currentLine = currentLine.append(line).append("\n");
						}
					}
				}
			}
		}
		if (currentStep != null) {
			currentStep.setLines(currentLine.toString());
		}
		return stages;
	}

	public BuildLog save(@Valid BuildLog buildLog) {
		log.log(Level.FINE, "Salvando BuildLog :: {0}", buildLog.getId());
		return buildLogRepository.save(buildLog);
	}

	public BuildLog update(BuildLog buildLog) {
		log.log(Level.FINE, "Atualizando BuildLog :: {0}", buildLog.getId());
		return buildLogRepository.update(buildLog);
	}
}

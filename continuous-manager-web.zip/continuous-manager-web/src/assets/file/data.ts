export let single = [
    {
        'name': 'SIXXX',
        'value': 8940000
    },
    {
        'name': 'SIAAA',
        'value': 7040000
    },
    {
        'name': 'SIBBB',
        'value': 3040000
    },
];

export let multi = [
    {
        'name': 'CEDESA',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 20
            },
            {
                'name': 'FAIL',
                'value': 9
            },
            {
                'name': 'ABORT',
                'value': 15
            }
        ]
    },
    {
        'name': 'CEDESB',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 12
            },
            {
                'name': 'FAIL',
                'value': 8
            },
            {
                'name': 'ABORT',
                'value': 5
            }
        ]
    },
    {
        'name': 'CEDESC',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 2
            },
            {
                'name': 'FAIL',
                'value': 10
            },
            {
                'name': 'ABORT',
                'value': 1
            }
        ]
    },
    {
        'name': 'CEDESD',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 55
            },
            {
                'name': 'FAIL',
                'value': 37
            },
            {
                'name': 'ABORT',
                'value': 28
            }
        ]
    },
    {
        'name': 'CEDESE',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 15
            },
            {
                'name': 'FAIL',
                'value': 20
            },
            {
                'name': 'ABORT',
                'value': 18
            }
        ]
    },
    {
        'name': 'CEDESF',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 50
            },
            {
                'name': 'FAIL',
                'value': 10
            },
            {
                'name': 'ABORT',
                'value': 20
            }
        ]
    },
    {
        'name': 'CEDESG',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 48
            },
            {
                'name': 'FAIL',
                'value': 5
            },
            {
                'name': 'ABORT',
                'value': 11
            }
        ]
    },
    {
        'name': 'CEDESH',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 16
            },
            {
                'name': 'FAIL',
                'value': 3
            },
            {
                'name': 'ABORT',
                'value': 20
            }
        ]
    },
    {
        'name': 'CEDESI',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 2
            },
            {
                'name': 'FAIL',
                'value': 17
            },
            {
                'name': 'ABORT',
                'value': 3
            }
        ]
    },
    {
        'name': 'CEDESJ',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 88
            },
            {
                'name': 'FAIL',
                'value': 18
            },
            {
                'name': 'ABORT',
                'value': 10
            }
        ]
    },
    {
        'name': 'CEDESK',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 30
            },
            {
                'name': 'FAIL',
                'value': 1
            },
            {
                'name': 'ABORT',
                'value': 20
            }
        ]
    },
    {
        'name': 'CEDESL',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 33
            },
            {
                'name': 'FAIL',
                'value': 27
            },
            {
                'name': 'ABORT',
                'value': 8
            }
        ]
    },
    {
        'name': 'CEDESM',
        'series': [
            {
                'name': 'SUCCESS',
                'value': 60
            },
            {
                'name': 'FAIL',
                'value': 18
            },
            {
                'name': 'ABORT',
                'value': 15
            }
        ]
    },
];


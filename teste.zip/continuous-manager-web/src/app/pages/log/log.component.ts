import { HttpHeaders } from '@angular/common/http';
import { HeaderComponent } from './../../layout/header/header.component';
import { ChangeSet } from './../../shared/model/changeset.model';
import { GitRepo } from './../../shared/model/gitrepo.model';
import { Project } from './../../shared/model/project.model';
import { Wallet } from './../../shared/model/wallet.model';
import { ViewLog } from './../../shared/model/view-log.model';
import { Commit } from './../../shared/model/commit.model';
import { Observable } from 'rxjs/Rx';
import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { JenkinsService } from '../../shared/service/jenkins.service';

import { Build } from '../../shared/model/build.model';
import { Job } from '../../shared/model/job.model';

@Component({
  selector: 'jmw-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.scss']
})
export class LogComponent implements OnInit {
  pageTitle = 'Log do Jenkins';

  walletId: Wallet;
  listaWallets: Wallet[] = [];
  listaProjects: Project[] = [];
  projectId: Project;
  jobId: Job;
  listaJobs: Job[] = [];
  listaChangeSets: ChangeSet[] = [];
  listaViewLog: ViewLog[] = [];
  log;
  page: number;
  total: number;
  updated: Date;

  constructor(private title: Title,
    private jenkinsService: JenkinsService) {
  }

  ngOnInit() {
    this.title.setTitle(this.pageTitle);
    this.jenkinsService.getWallets().subscribe(data => {
      this.listaWallets = data;
    });

    this.page = 1;

    /*this.jenkinsService.getJSON().subscribe(data => {
      this.listaCommits = data;
    });*/
  }

  public chargeProjects() {
    this.listaProjects = [];
    this.projectId = undefined;
    this.jobId = undefined;
    if (!!this.walletId) {
      this.jenkinsService.getProjects(this.walletId.id).subscribe(data => {
        this.listaProjects = data;
      });
    }
  }

  public chargeJobs() {
    this.listaJobs = [];
    this.jobId = undefined;
    if (!!this.projectId) {
      this.jenkinsService.getJobs(this.walletId.id, this.projectId.id.id).subscribe(data => {
        this.listaJobs = data;
      });
    }
  }

  public chargeBuilds() {
    if (!!this.jobId) {
      this.jenkinsService.getBuilds(this.walletId.id, this.projectId.id.id, this.jobId.id.id, this.page).subscribe((res: any) => {
        console.log(res);
        this.listaViewLog.length = 0;
        res.body.forEach(build => {
          const itemBuild: ViewLog = new ViewLog;
          itemBuild.number_build = build.id.id;
          itemBuild.result_build = build.result;
          itemBuild.localError = build.localError;
          itemBuild.timestamp_build = build.createdAt;
          if (build.changeSets.length > 0) {
            itemBuild.short_id_commit = build.changeSets[0].id.commit.substring(0, 8);
            if (build.changeSets[0].gitRepo.title.length > 32) {
              itemBuild.title_commit = build.changeSets[0].gitRepo.title.substring(0, 25) + '...';
            } else {
              itemBuild.title_commit = build.changeSets[0].gitRepo.title;
            }
            itemBuild.author_name_commit = build.changeSets[0].gitRepo.authorName;

            build.changeSets.forEach(item => {
              item.id.commit = item.id.commit.substring(0, 8);
            });
          }
          itemBuild.changeSets = build.changeSets;
          this.listaViewLog.push(itemBuild);
        });
        this.total = res.headers.get('Content-Range').substring(res.headers.get('Content-Range').indexOf('/') + 1);
        this.updated = new Date();
      });
    }
  }

  downloadfile(buildId) {
    this.jenkinsService.getLog(this.walletId.id, this.projectId.id.id, this.jobId.id.id, buildId).subscribe(
      res => this.exportData(res, buildId),
      (error: any) => Observable.throw(error || 'Server error')
    );
  }

  exportData(res: string, buildId) {
    const blob = res;
    const myBlob: Blob = new Blob([res], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(myBlob);
    a.download = 'Log - ' + this.walletId.name + ' - Job - ' + this.jobId.name + ' - Build - ' + buildId + '.txt';
    document.body.appendChild(a);
    a.click();
  }

  pageChanged(event) {
    if ((this.updated.getTime() + 500) < new Date().getTime()) {
      this.page = event;
      this.chargeBuilds();
    }
  }
}

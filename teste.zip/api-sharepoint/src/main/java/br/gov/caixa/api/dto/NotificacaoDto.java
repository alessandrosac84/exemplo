package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.gov.caixa.api.model.Notificacao;
import br.gov.caixa.api.model.Notificacao.TipoNotificacao;

public class NotificacaoDto {

	private Long uid;
	private FuncionarioDto funcionario;
	private TipoNotificacao tipoNotificacao;
	private Long idOrigem;
	private Date dataExpiracao;
	private Boolean lido;
	private Integer quantidade;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public FuncionarioDto getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(FuncionarioDto funcionario) {
		this.funcionario = funcionario;
	}

	public TipoNotificacao getTipoNotificacao() {
		return tipoNotificacao;
	}

	public void setTipoNotificacao(TipoNotificacao tipoNotificacao) {
		this.tipoNotificacao = tipoNotificacao;
	}
	
	public Long getIdOrigem() {
		return idOrigem;
	}

	public void setIdOrigem(Long idOrigem) {
		this.idOrigem = idOrigem;
	}

	public Date getDataExpiracao() {
		return dataExpiracao;
	}

	public void setDataExpiracao(Date dataExpiracao) {
		this.dataExpiracao = dataExpiracao;
	}

	public Boolean getLido() {
		return lido;
	}

	public void setLido(Boolean lido) {
		this.lido = lido;
	}

	public Integer getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}
	
	public static NotificacaoDto fromNotificacaoToDto(Notificacao notificacao){
		NotificacaoDto dto = new NotificacaoDto();
		dto.setUid(notificacao.getUid());
		dto.setFuncionario(FuncionarioDto.fromFuncionarioToDto(notificacao.getFuncionario()));
		dto.setTipoNotificacao(notificacao.getTipoNotificacao());
		dto.setIdOrigem(notificacao.getIdOrigem());
		dto.setDataExpiracao(notificacao.getDataExpiracao());
		dto.setLido(notificacao.getLido());
		dto.setQuantidade(notificacao.getQuantidade());
		return dto;
	}
	
	public static List<NotificacaoDto> fromNotificacaoToListDto(List<Notificacao> listaNotificacao){
		List<NotificacaoDto> listResult = new ArrayList<NotificacaoDto>();
		for (Notificacao notificacao : listaNotificacao) {
			listResult.add(fromNotificacaoToDto(notificacao));
		}
		return listResult;
	}
}

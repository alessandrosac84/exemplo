package br.gov.caixa.inovacao.continuousmanager.model.vo.sharepoint;

import java.io.Serializable;

/**
 * 
 * @author Fabio Iwakoshi
 * 
 */
public class AtivoSharepointVO implements Serializable {

	private static final long serialVersionUID = 6451349609914725913L;

	private Integer id;

	private String descricao;

	private String nome;

	private Boolean situacaoAtivo;

	private transient Object coordenacao;

	private transient Object tipoAtivo;

	private transient Object ativoCampos;

	public AtivoSharepointVO() {
		/* class constructor intentionally left blank */
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the situacaoAtivo
	 */
	public Boolean getSituacaoAtivo() {
		return situacaoAtivo;
	}

	/**
	 * @param situacaoAtivo the situacaoAtivo to set
	 */
	public void setSituacaoAtivo(Boolean situacaoAtivo) {
		this.situacaoAtivo = situacaoAtivo;
	}

	/**
	 * @return the coordenacao
	 */
	public Object getCoordenacao() {
		return coordenacao;
	}

	/**
	 * @param coordenacao the coordenacao to set
	 */
	public void setCoordenacao(Object coordenacao) {
		this.coordenacao = coordenacao;
	}

	/**
	 * @return the tipoAtivo
	 */
	public Object getTipoAtivo() {
		return tipoAtivo;
	}

	/**
	 * @param tipoAtivo the tipoAtivo to set
	 */
	public void setTipoAtivo(Object tipoAtivo) {
		this.tipoAtivo = tipoAtivo;
	}

	/**
	 * @return the ativoCampos
	 */
	public Object getAtivoCampos() {
		return ativoCampos;
	}

	/**
	 * @param ativoCampos the ativoCampos to set
	 */
	public void setAtivoCampos(Object ativoCampos) {
		this.ativoCampos = ativoCampos;
	}
}
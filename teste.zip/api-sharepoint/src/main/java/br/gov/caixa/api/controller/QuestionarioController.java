package br.gov.caixa.api.controller;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.dto.QuestionarioDto;
import br.gov.caixa.api.result.QuestionarioResult;
import br.gov.caixa.api.services.QuestionarioService;

@RestController
public class QuestionarioController {
	
	@Inject
	QuestionarioService service;
	
	@RequestMapping(value="/api/questionario/getAll", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public QuestionarioResult get() {
		return service.getAll();
	}
	
	@RequestMapping(value="/api/questionario/save", 
			method=RequestMethod.POST,
			consumes = "application/json",  
			produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public QuestionarioResult save(@RequestBody QuestionarioDto dto) {
		
		return service.save(dto);
	}
	
	@RequestMapping(value="/api/questionario/delete/{id}", method=RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public QuestionarioResult delete(@PathVariable Long id) {
		return service.delete(id);
	}
	
}
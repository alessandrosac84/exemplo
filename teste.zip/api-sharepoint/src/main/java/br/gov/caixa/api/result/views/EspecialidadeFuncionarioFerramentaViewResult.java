package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeFuncionarioFerramentaView;
import br.gov.caixa.api.result.BasicResult;

public class EspecialidadeFuncionarioFerramentaViewResult extends BasicResult {
	private List<EspecialidadeFuncionarioFerramentaView> list;
	private EspecialidadeFuncionarioFerramentaView especialidadeFuncionarioFerramentaView;

	public List<EspecialidadeFuncionarioFerramentaView> getList() {
		return list;
	}

	public void setList(List<EspecialidadeFuncionarioFerramentaView> list) {
		this.list = list;
	}

	public EspecialidadeFuncionarioFerramentaView getEspecialidadeFuncionarioFerramentaView() {
		return especialidadeFuncionarioFerramentaView;
	}

	public void setEspecialidadeFuncionarioFerramentaView(EspecialidadeFuncionarioFerramentaView especialidadeFuncionarioFerramentaView) {
		this.especialidadeFuncionarioFerramentaView = especialidadeFuncionarioFerramentaView;
	}
}
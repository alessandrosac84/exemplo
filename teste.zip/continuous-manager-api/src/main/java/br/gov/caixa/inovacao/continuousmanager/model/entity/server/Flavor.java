package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

import java.util.Set;


/**
 * The persistent class for the flavor database table.
 * 
 */
@Entity
@Table(name="flavor")
@NamedQuery(name="Flavor.findAll", query="SELECT f FROM Flavor f")
public class Flavor implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false)
	private Integer id;
	
	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	@Column(nullable=false, length=255)
	private String description;

	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	@Column(name="java_version", length=5)
	private String javaVersion;

	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	@Column(name="path_home", nullable=false, length=255)
	private String pathHome;

	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	@Column(name = "owner_id", nullable=false, length=15)
	private String ownerId;

	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	@Enumerated(EnumType.STRING)
	@Column(name="type_server", nullable=false, length=12)
	private TypeServer typeServer;

	@JsonView({ViewJson.JenkisfileView.class, ViewJson.ServerView.class})
	@Column(nullable=false, length=15)
	private String version;

	//bi-directional many-to-one association to Server
	@JsonIgnore
	@OneToMany(mappedBy="flavor", fetch = FetchType.LAZY)
	private Set<Server> servers;

	public Flavor() {
		/* class constructor intentionally left blank */
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getJavaVersion() {
		return this.javaVersion;
	}

	public void setJavaVersion(String javaVersion) {
		this.javaVersion = javaVersion;
	}

	public String getPathHome() {
		return this.pathHome;
	}

	public void setPathHome(String pathHome) {
		this.pathHome = pathHome;
	}

	public TypeServer getTypeServer() {
		return this.typeServer;
	}

	public void setTypeServer(TypeServer typeServer) {
		this.typeServer = typeServer;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Set<Server> getServers() {
		return this.servers;
	}

	public void setServers(Set<Server> servers) {
		this.servers = servers;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
}
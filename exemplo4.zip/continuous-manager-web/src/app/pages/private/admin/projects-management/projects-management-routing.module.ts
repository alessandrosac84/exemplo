import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProjectsManagementComponent } from './projects-management.component';
import { AddProjectComponent } from './add-project/add-project.component';
import { AddRepositoryComponent } from './add-project/add-repository/add-repository.component';

const routes: Routes = [
  { path: '', component: ProjectsManagementComponent, pathMatch: 'full'},
  { path: 'add', component: AddProjectComponent}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectsManagementRoutingModule { }

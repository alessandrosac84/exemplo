import { Job } from './job.model';
import { Wallet } from './wallet.model';

export class Project {
  id: { id: number };
  name: string;
  coordenationSharepoint: string;
  descriptionSharepoint: string;
  photo: string;
  wallet: Wallet;
}

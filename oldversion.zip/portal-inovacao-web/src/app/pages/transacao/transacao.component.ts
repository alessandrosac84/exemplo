import { Transacao } from './../shared/model/transacao';
import { HeaderComponent } from './../../layout/header/header.component';
import { CommonModule } from '@angular/common';
import { Sistema } from './../shared/model/sistema';
import { PortalInovacaoService } from './../shared/portal.inovacao.service';

import { Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import { NgbModal, NgbModalOptions, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'pi-transacao',
  templateUrl: './transacao.component.html',
  styleUrls: ['./transacao.component.scss']
})

export class TransacaoComponent {

  public listaSistemas: Sistema[] = [];
  public transacaoEnvio: Transacao = new Transacao;
  public sistemaEnvio: Sistema = new Sistema;
  public flagView;
  public retornoEnvio: String;
  public closeResult: string;

  constructor(private portalInovacaoService: PortalInovacaoService, private _http: Http, private modalService: NgbModal) {
    if (this.listaSistemas.length === 0) {
      this.getSistemas();
    }
  }
  private getSistemas() {
    this.listaSistemas = this.portalInovacaoService.getSistemasUnico();
  }

  send(transacaoEnvio, sistemaEnvio, content) {
    this.retornoEnvio = null;

    transacaoEnvio.nomeSistema = sistemaEnvio.sistema;
    transacaoEnvio.sistemaId = sistemaEnvio.alias;
    transacaoEnvio.programa = transacaoEnvio.programa.toUpperCase();
    transacaoEnvio.bookEntrada = transacaoEnvio.bookEntrada.toUpperCase();
    transacaoEnvio.bookSaida = transacaoEnvio.bookSaida.toUpperCase();
    transacaoEnvio.uri = transacaoEnvio.uri.toLowerCase();
    transacaoEnvio.diretorioEntrada = transacaoEnvio.diretorioEntrada.toLowerCase();
    transacaoEnvio.diretorioSaida = transacaoEnvio.diretorioSaida.toLowerCase();

    if (this.flagView === '1') {
      this.transacaoEnvio.flag = 'COMMAREA';
    } else if (this.flagView === '2') {
      this.transacaoEnvio.flag = 'CONTAINER';
    }
    this.portalInovacaoService.send(transacaoEnvio).subscribe(data => {
      this.retornoEnvio = data;
    });

    const options: NgbModalOptions = {
      windowClass: 'modal',
    };
    this.modalService.open(content, options).result.then((result) => {
      this.closeResult = 'Closed with: ${result}';
    }, (reason) => {
      this.closeResult = 'Dismissed ${this.getDismissReason(reason)}';
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return 'with: $(reason)';
    }
  }
}


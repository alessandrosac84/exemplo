import { FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import {
  trigger,
  transition,
  query,
  animate,
  stagger,
  style
} from '@angular/animations';

import { User } from '../../../../shared/model/entity/user.model';
import { UsersAdminService } from '../../../../shared/service/users-admin.service';
import { Router } from '@angular/router';
import { startWith, map, debounceTime, switchMap, distinctUntilChanged } from 'rxjs/operators';

import { Observable } from 'rxjs';
import { SharepointService } from '../../../../shared/service/sharepoint.service';
import { CaixaEmployee } from '../../../../shared/model/vo/sharepoint/caixa-employee.model';
@Component({
  selector: 'cm-admins-management',
  templateUrl: './admins-management.component.html',
  styleUrls: [],
  animations: [
    trigger('listStagger', [
      transition('* => *', [
        // each time the binding value changes
        query(
          ':enter',
          [
            style({ opacity: 0 }),
            stagger(200, [animate('0.5s', style({ opacity: 1 }))])
          ],
          { optional: true }
        ),
        query(
          ':leave',
          [stagger(200, [animate('0.5s', style({ opacity: 0 }))])],
          { optional: true }
        )
      ])
    ])
  ]
})
export class AdminsManagementComponent implements OnInit {
  usersAdmin: User[] = [];
  member: User[];

  myControl = new FormControl();
  filteredOptions: Observable<CaixaEmployee[]>;

  constructor(
    private _usersAdminService: UsersAdminService,
    private _sharepointService: SharepointService) {}

  ngOnInit() {
    this._usersAdminService
      .getUsersAdmin()
      .subscribe(data => (this.usersAdmin = data));

    this.filteredOptions = this.myControl.valueChanges
      .pipe(startWith(''),
        debounceTime(200),
        distinctUntilChanged(),
        switchMap(val => {
          return this._sharepointService.getMembers(val);
        })
      );
  }

  displayFn(user?: CaixaEmployee): string | undefined {
    return user ? user.nome : undefined;
  }

  addUserAdmin() {
    const userAdmin = new User();
    userAdmin.id = this.myControl.value.matricula;
    userAdmin.name = this.myControl.value.nome;
    userAdmin.email = this.myControl.value.email;
    this.usersAdmin.push(userAdmin);
  }

  remove(userAdmin) {
    this.usersAdmin.splice(this.usersAdmin.indexOf(userAdmin), 1);
  }
}

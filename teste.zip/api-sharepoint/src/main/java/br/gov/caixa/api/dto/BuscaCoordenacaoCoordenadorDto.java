package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.BuscaCoordenacaoCoordenador;

public class BuscaCoordenacaoCoordenadorDto {

	private Long coordenacaoId;	
	private Long funcionarioId;
	private Long parentId;	
	private String titulo;	
	private String matricula;
	private String nome;
	private String cargo;
	private Integer tipo;
	
	public Long getCoordenacaoId() {
		return coordenacaoId;
	}
	public void setCoordenacaoId(Long coordenacaoId) {
		this.coordenacaoId = coordenacaoId;
	}
	public Long getFuncionarioId() {
		return funcionarioId;
	}	
	public void setFuncionarioId(Long funcionarioId) {
		this.funcionarioId = funcionarioId;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	
	public Integer getTipo() {
		return tipo;
	}
	public void setTipo(Integer tipo) {
		this.tipo = tipo;
	}
	public static List<BuscaCoordenacaoCoordenadorDto> fromBuscaCoordenacaoCoordenadorToListDto(List<BuscaCoordenacaoCoordenador> lista) {
		
		List<BuscaCoordenacaoCoordenadorDto> listaRetorno = new ArrayList<BuscaCoordenacaoCoordenadorDto>();
		
		for (BuscaCoordenacaoCoordenador buscaCoordenacaoCoordenador : lista) {
			BuscaCoordenacaoCoordenadorDto dto = new BuscaCoordenacaoCoordenadorDto();
			
			dto.setCoordenacaoId(buscaCoordenacaoCoordenador.getBuscaCoordenacaoCoordenadorId().getCoordenacao_id());
			dto.setFuncionarioId(buscaCoordenacaoCoordenador.getFuncionarioId());			
			dto.setParentId(buscaCoordenacaoCoordenador.getParentId());
			dto.setMatricula(buscaCoordenacaoCoordenador.getMatricula());
			dto.setTitulo(buscaCoordenacaoCoordenador.getTitulo());			
			dto.setNome(buscaCoordenacaoCoordenador.getNome());
			dto.setCargo(buscaCoordenacaoCoordenador.getCargo());
			dto.setTipo(buscaCoordenacaoCoordenador.getTipo());
			
			listaRetorno.add(dto);
		}
		return listaRetorno;
	}
}
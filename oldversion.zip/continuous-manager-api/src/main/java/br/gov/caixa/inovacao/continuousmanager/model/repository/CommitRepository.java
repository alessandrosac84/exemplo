package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildPK_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSet_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.CommitPK_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit_;

/**
 * Classe de acesso ao banco de dados da entidade Commit.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class CommitRepository {

	private static final String WALLET = "wallet";
	private static final String PROJECT = "project";

	@Inject
	private EntityManager entityManager;

	public List<Commit> findByStatus(String wallet, String project, JenkinsResult result, int offset, int limit) {
		return entityManager.createQuery("SELECT c FROM Commit c JOIN FETCH c.changeSets cs JOIN FETCH cs.build b "
				+ "WHERE c.id.wallet = :wallet AND c.id.project = :project AND b.result = :result AND b.id.job LIKE '%-ci-dev' "
				+ "ORDER BY c.committedDate DESC", Commit.class).setFirstResult(offset).setMaxResults(limit)
				.setParameter(WALLET, wallet).setParameter(PROJECT, project).setParameter("result", result)
				.getResultList();
	}

	public List<Commit> findByVersionOrCommit(String wallet, String project, Commit commit) {
		return entityManager.createQuery(
				"SELECT c FROM Commit c WHERE c.id.wallet = :wallet AND c.id.project = :project AND (LOWER(c.version) = :version OR c.id.commit = :commit) ",
				Commit.class).setParameter(WALLET, wallet).setParameter(PROJECT, project)
				.setParameter("commit", commit.getId().getCommit()).setParameter("version", commit.getVersion().toLowerCase())
				.getResultList();
	}

	public Long countByStatus(String wallet, String project, JenkinsResult result) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);

		Root<Commit> from = query.from(Commit.class);
		Join<ChangeSet, Build> fromB = from.join(Commit_.changeSets, JoinType.INNER).join(ChangeSet_.build,
				JoinType.INNER);

		Predicate predicate = builder.equal(from.get(Commit_.id).get(CommitPK_.wallet), wallet);
		predicate = builder.and(predicate, builder.equal(from.get(Commit_.id).get(CommitPK_.project), project));
		if (result != null)
			predicate = builder.and(predicate, builder.equal(fromB.get(Build_.result), result));
		predicate = builder.and(predicate, builder.like(fromB.get(Build_.id).get(BuildPK_.job), "%-ci-dev"));

		return entityManager.createQuery(query.select(builder.countDistinct(from)).where(predicate)).getSingleResult();
	}

	public Commit save(Commit commit) {
		entityManager.persist(commit);
		return commit;
	}

	public Commit findById(CommitPK id) {
		return entityManager.find(Commit.class, id);
	}
	
	public Commit findVersionByBuildId(String wallet, String project, Build build ) {
		
		return entityManager.createQuery("SELECT c FROM Commit c JOIN c.changeSets cs WHERE c.id.wallet =:wallet AND c.id.project =:project" +
										" AND cs.build =:build AND c.version IS NOT NULL",Commit.class)
				.setParameter(WALLET, wallet).setParameter(PROJECT, project).setParameter("build", build).getSingleResult(); 
	}


	public Commit update(Commit commit) {
		return entityManager.merge(commit);
	}
}

package br.gov.caixa.api.services;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;

import br.gov.caixa.api.dto.NotificacaoDto;
import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.Notificacao;
import br.gov.caixa.api.model.Notificacao.TipoNotificacao;
import br.gov.caixa.api.repository.NotificacaoRepository;
import br.gov.caixa.api.result.NotificacaoResult;

@Named
public class NotificacaoService {

	@Inject
	NotificacaoRepository repository;

	@Inject
	EntityManager entityManager;
	
	public NotificacaoResult save(NotificacaoDto dto) {
		NotificacaoResult result = new NotificacaoResult();
		repository.save(Notificacao.fromDtoToNotificacao(dto));
		result.setMessage("Executado com sucesso.");
		return result;
	}

	public NotificacaoResult saveList(List<NotificacaoDto> lista) {

		NotificacaoResult result = new NotificacaoResult();

		repository.save(Notificacao.fromDtoToListNotificacao(lista));

		result.setMessage("Executado com sucesso.");
		return result;
	}

	public NotificacaoResult delete(NotificacaoDto dto) {
		NotificacaoResult result = new NotificacaoResult();
		repository.delete(dto.getUid());
		result.setMessage("Executado com sucesso.");
		return result;
	}

	public NotificacaoResult findAllByUser(Long funcionarioId) {
		NotificacaoResult result = new NotificacaoResult();
		Funcionario funcionario = new Funcionario();
		funcionario.setUid(funcionarioId);

		List<Notificacao> listNotificacao = repository.findByFuncionario(funcionario);

		result.setList(NotificacaoDto.fromNotificacaoToListDto(listNotificacao));
		result.setMessage("Executado com sucesso.");
		return result;
	}

	public NotificacaoResult setLido(NotificacaoDto dto) {
		NotificacaoResult result = new NotificacaoResult();
		repository.setLido(dto.getLido(), dto.getUid());
		result.setMessage("Executado com sucesso.");
		return result;
	}

	public NotificacaoResult setLidoPorFuncionario(Long funcionarioId, TipoNotificacao tipoNotificacao) {

		Funcionario funcionario = new Funcionario();
		funcionario.setUid(funcionarioId);

		NotificacaoResult result = new NotificacaoResult();
		repository.setLidoPorFuncionario(true, funcionario, tipoNotificacao);
		result.setMessage("Executado com sucesso.");
		return result;
	}

	public NotificacaoResult deleteOnePorTipoFuncionario(Long funcionarioId, TipoNotificacao tipoNotificacao) {

		Funcionario funcionario = new Funcionario();
		funcionario.setUid(funcionarioId);

		List<Notificacao> listNotificacao = repository.findByFuncionarioAndTipoNotificacao(funcionario,
				tipoNotificacao);

		if (listNotificacao != null) {

			for (Notificacao item : listNotificacao) {

				repository.delete(item.getUid());
				break;
			}

		}

		NotificacaoResult result = new NotificacaoResult();
		result.setMessage("Executado com sucesso.");
		return result;
	}

	public NotificacaoResult deleteOnePorTipoFuncionarioData(Long funcionarioId, TipoNotificacao tipoNotificacao, Date dataFim) {

		Funcionario funcionario = new Funcionario();
		funcionario.setUid(funcionarioId);

		List<Notificacao> listNotificacao = repository.findByFuncionarioAndTipoNotificacaoAndDataExpiracao(funcionario,
				tipoNotificacao, dataFim);

		if (listNotificacao != null) {

			for (Notificacao item : listNotificacao) {

				repository.delete(item.getUid());
				break;
			}

		}

		NotificacaoResult result = new NotificacaoResult();
		result.setMessage("Executado com sucesso.");
		return result;
	}

}

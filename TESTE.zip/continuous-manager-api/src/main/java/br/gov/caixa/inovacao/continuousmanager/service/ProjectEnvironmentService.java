package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.NoResultException;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ProjectEnvironment;
import br.gov.caixa.inovacao.continuousmanager.model.repository.ProjectEnvironmentRepository;

/**
 * Classe de servicos de Project Environment.
 * 
 * @author Fabio Iwakoshi
 *
 */
@Logged
@Stateless
public class ProjectEnvironmentService {

	@Inject
	private Logger log;
	
	@Inject
	private ProjectEnvironmentRepository projectEnvironmentRepository;
	
	/**
	 * Deploy uma versão do projeto para TQS
	 * 
	 * @param wallet
	 * @param project
	 * @param commit
	 * @param version
	 */
	public void update(ProjectEnvironment projectEnvironment) {
		log.fine("Salvando project Environment");
		projectEnvironmentRepository.update(projectEnvironment);
	}
	
	public List<ProjectEnvironment> findByEnviroment(String wallet, String project){
		log.fine("Buscando ultimo deploy de cada ambiente por project Environment");
		
		List<ProjectEnvironment> listEnviroment = new ArrayList<ProjectEnvironment>();
		ProjectEnvironment enviroment = new ProjectEnvironment();
		
		try {
			enviroment = projectEnvironmentRepository.findByEnviroment(wallet, project, Environment.DES);
			if(enviroment != null){
				listEnviroment.add(enviroment);
			}
		} catch (NoResultException e) {
			log.log(Level.SEVERE, "Não foi encontrada Build de Desenvolvimento!");
		}
		
		
		try {
			enviroment = projectEnvironmentRepository.findByEnviroment(wallet, project, Environment.TQS);
			if(enviroment != null){
				listEnviroment.add(enviroment);
			}
			
		} catch (NoResultException e) {
			log.log(Level.SEVERE, "Não foi encontrada Build de TQS!");
		}
		
		try {
			enviroment = projectEnvironmentRepository.findByEnviroment(wallet, project, Environment.PRD);
			if(enviroment != null){
				listEnviroment.add(enviroment);
			}
			
		} catch (NoResultException e) {
			log.log(Level.SEVERE, "Não foi encontrada Build de PRD!");
		}
		
		return listEnviroment;
	}
}
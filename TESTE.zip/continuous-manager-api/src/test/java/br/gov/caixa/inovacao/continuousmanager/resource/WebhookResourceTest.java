package br.gov.caixa.inovacao.continuousmanager.resource;

import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.PayloadNotificationJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.service.integration.WebhookService;

/**
 * Classe de testes do WalletResource.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class WebhookResourceTest {

	@Mock
	private WebhookService webhookService;

	@InjectMocks
	private WebhookResource webhookResource;

	@Before
	public void before() {
		UtilReflection.setField(webhookResource, "log", Logger.getLogger(WebhookResource.class.getName()));
	}
	
	/**
	 * Listar todas as Wallets.
	 * @throws InterruptedException 
	 */
	@Test
	public void testListAllWalletsDefault() throws InterruptedException {
		PayloadNotificationJenkinsVO payload = new PayloadNotificationJenkinsVO();
		
		// Act
		webhookResource.createJob(payload);
	}
}

package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-02-06T08:57:07.900-0200")
@StaticMetamodel(ChangeSetPK.class)
public class ChangeSetPK_ {
	public static volatile SingularAttribute<ChangeSetPK, String> project;
	public static volatile SingularAttribute<ChangeSetPK, String> wallet;
	public static volatile SingularAttribute<ChangeSetPK, String> job;
	public static volatile SingularAttribute<ChangeSetPK, Integer> build;
	public static volatile SingularAttribute<ChangeSetPK, String> commit;
}

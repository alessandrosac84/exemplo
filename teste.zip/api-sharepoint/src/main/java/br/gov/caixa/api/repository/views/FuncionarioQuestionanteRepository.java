package br.gov.caixa.api.repository.views;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.views.FuncionarioQuestionante;

public interface FuncionarioQuestionanteRepository extends JpaRepository<FuncionarioQuestionante, Long> {

	@Query("select f from FuncionarioQuestionante f where (f.questionarioId is null or f.questionarioId = ?1)")
	public List<FuncionarioQuestionante> findByQuestionarioAndNulls(Long questionarioId);

}




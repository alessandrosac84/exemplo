import { DashboardComponent } from './dashboard.component';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NvD3Module } from 'ng2-nvd3';

import 'd3';
import 'nvd3';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DetailComponent } from './detail/detail.component';

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    FormsModule,
    NvD3Module
  ],
  declarations: [
    DashboardComponent,
    DetailComponent
  ]
})
export class DashboardModule { }

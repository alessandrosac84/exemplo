package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.http.ssl.SSLContexts;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpMethod;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpProtocol;

/**
 * Classe de testes do HttpService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ SSLContexts.class, ClientBuilder.class })
@PowerMockIgnore("javax.net.ssl.*")
public class HttpServiceTest {
	
	@Rule
	public MockitoRule mrule = MockitoJUnit.rule();
	
	@Mock
	private ClientBuilder clientBuilder;

	@Mock
	private Client client;

	@Mock
	private WebTarget target;
	
	@Mock 
	private Invocation.Builder builder;

	@Mock
	private Response response;

	@Test
	public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InstantiationException,
			IllegalArgumentException, InvocationTargetException {
		// Arrange
		Constructor<HttpService> constructor = HttpService.class.getDeclaredConstructor();
		constructor.setAccessible(true);

		// Act
		constructor.newInstance();

		// Then
		Assert.assertTrue(Modifier.isPrivate(constructor.getModifiers()));
	}

	@Test
	public void testCallHttp() throws Exception {
		// Arrange
		MultivaluedMap<String, Object> headers = new MultivaluedHashMap<>();
		headers.add("Authorization", "hashdljkasndktybdvkjsdfga");
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(builder.headers(Mockito.any())).thenReturn(builder);
	    Mockito.when(builder.get()).thenReturn(response);
		

		// Act
		Response callHttp = HttpService.httpProtocol(HttpProtocol.HTTPS).httpMethod(HttpMethod.GET).host("https://jenkins.caixa").path("/api/json").query("tree",
				"jobs[name,displayName]").header("Authorization", "hashdljkasndktybdvkjsdfga").build();

		// Then
		Assert.assertNotNull(callHttp);
	}

	@Test(expected = ServiceUnavailableException.class)
	public void testCallHttpException() {
		// Arrange
		PowerMockito.mockStatic(SSLContexts.class);
		PowerMockito.when(SSLContexts.custom()).thenThrow(ServiceUnavailableException.class);

		// Act
		HttpService.httpProtocol(HttpProtocol.HTTPS).httpMethod(HttpMethod.GET).host("https://jenkins.caixa").path("/api/json").query("tree",
				"jobs[name,displayName]").header(null, null).build();
	}

}

package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;

/**
 * @author Fabio Iwakoshi
 *
 */
public class ConditionVO implements Serializable {

	private static final long serialVersionUID = -7155679762811447521L;
	
	private Integer id;

	private String metric;

	private Comparator op;

	private String error;

	private Integer period;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the metric
	 */
	public String getMetric() {
		return metric;
	}

	/**
	 * @param metric the metric to set
	 */
	public void setMetric(String metric) {
		this.metric = metric;
	}

	/**
	 * @return the op
	 */
	public Comparator getOp() {
		return op;
	}

	/**
	 * @param op the op to set
	 */
	public void setOp(Comparator op) {
		this.op = op;
	}

	/**
	 * @return the error
	 */
	public String getError() {
		return error;
	}

	/**
	 * @param error the error to set
	 */
	public void setError(String error) {
		this.error = error;
	}

	/**
	 * @return the period
	 */
	public Integer getPeriod() {
		return period;
	}

	/**
	 * @param period the period to set
	 */
	public void setPeriod(Integer period) {
		this.period = period;
	}
}

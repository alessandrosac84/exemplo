/**
 * DE_SITUACAO_DOCUMENTACAOType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package SIAPP_WS_DistinctItemPortfolio;

@SuppressWarnings({ "rawtypes", "serial", "unchecked" })
public class DE_SITUACAO_DOCUMENTACAOType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected DE_SITUACAO_DOCUMENTACAOType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _value1 = "Completa atualizada";
    public static final java.lang.String _value2 = "Completa desatualizada";
    public static final java.lang.String _value3 = "Incompleta atualizada";
    public static final java.lang.String _value4 = "Incompleta desatualizada";
    public static final java.lang.String _value5 = "Inexistente";
    public static final DE_SITUACAO_DOCUMENTACAOType value1 = new DE_SITUACAO_DOCUMENTACAOType(_value1);
    public static final DE_SITUACAO_DOCUMENTACAOType value2 = new DE_SITUACAO_DOCUMENTACAOType(_value2);
    public static final DE_SITUACAO_DOCUMENTACAOType value3 = new DE_SITUACAO_DOCUMENTACAOType(_value3);
    public static final DE_SITUACAO_DOCUMENTACAOType value4 = new DE_SITUACAO_DOCUMENTACAOType(_value4);
    public static final DE_SITUACAO_DOCUMENTACAOType value5 = new DE_SITUACAO_DOCUMENTACAOType(_value5);
    public java.lang.String getValue() { return _value_;}
    public static DE_SITUACAO_DOCUMENTACAOType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        DE_SITUACAO_DOCUMENTACAOType enumeration = (DE_SITUACAO_DOCUMENTACAOType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static DE_SITUACAO_DOCUMENTACAOType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DE_SITUACAO_DOCUMENTACAOType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_SITUACAO_DOCUMENTACAOType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}

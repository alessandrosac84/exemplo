package br.gov.caixa.inovacao.continuousmanager.model.entity;

import org.junit.Test;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpProtocol;


/**
 * Classe para testes superficiais de Enums
 * 
 * @author Fabio Iwakoshi
 *
 */
public class EnumTest {

	/**
	 * Listar todas as Wallets.
	 */
	@Test
	public void testListAllWalletsDefault() {
		// Act
		UtilReflection.superficialEnumCodeCoverage(Action.class);
		UtilReflection.superficialEnumCodeCoverage(AscDesc.class);
		UtilReflection.superficialEnumCodeCoverage(HttpProtocol.class);
		UtilReflection.superficialEnumCodeCoverage(Environment.class);
		UtilReflection.superficialEnumCodeCoverage(JenkinsResult.class);
		UtilReflection.superficialEnumCodeCoverage(QualityGate.class);
		UtilReflection.superficialEnumCodeCoverage(ServerType.class);
		Environment.DES.getDescription();
	}
	
}

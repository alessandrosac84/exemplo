package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the audit database table.
 * 
 */
@Entity
@Table(name="audit")
@NamedQuery(name="Audit.findAll", query="SELECT a FROM Audit a")
public class Audit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Long id;

	@Enumerated(EnumType.STRING)
	@Column(nullable=false, length=7)
	private Action action;

	@Column(nullable=false, columnDefinition = "TEXT")
	private String entity;

	@Column(nullable=false, length=100)
	private String functionality;

	@Column(name="ip_event", nullable=false, length=30)
	private String ipEvent;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="timestamp_event", nullable=false)
	private Calendar timestampEvent;

	@Column(name="user_event", nullable=false, length=7)
	private String userEvent;

	public Audit() {
		/* class constructor intentionally left blank */
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Action getAction() {
		return this.action;
	}

	public void setAction(Action action) {
		this.action = action;
	}

	public String getEntity() {
		return this.entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getFunctionality() {
		return this.functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}

	public String getIpEvent() {
		return this.ipEvent;
	}

	public void setIpEvent(String ipEvent) {
		this.ipEvent = ipEvent;
	}

	public Calendar getTimestampEvent() {
		return this.timestampEvent;
	}

	public void setTimestampEvent(Calendar timestampEvent) {
		this.timestampEvent = timestampEvent;
	}

	public String getUserEvent() {
		return this.userEvent;
	}

	public void setUserEvent(String userEvent) {
		this.userEvent = userEvent;
	}

}
package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;


/**
 * 
 * @author Alessandro Carvalho
 * 
 */
public class VersionProjectVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5430417915461464183L;
	
	/**
	 * 
	 */
	@JsonView(ViewJson.VersionProjectVO.class)
	private Environment ambiente;
	
	/**
	 * 
	 */
	@JsonView(ViewJson.VersionProjectVO.class)
	private String version;


	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * @return the ambiente
	 */
	public Environment getAmbiente() {
		return ambiente;
	}

	/**
	 * @param ambiente the ambiente to set
	 */
	public void setAmbiente(Environment ambiente) {
		this.ambiente = ambiente;
	}

}

import { Flavor } from './flavor.model';

export class Server {
  ip: string;
  dns: string;
  environment: string;
  flavor: Flavor;
}

package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.QuestionanteDto;

public class QuestionanteResult extends BasicResult {

	private List<QuestionanteDto> list;
	private QuestionanteDto questionante;

	public List<QuestionanteDto> getList() {
		return list;
	}

	public void setList(List<QuestionanteDto> list) {
		this.list = list;
	}

	public QuestionanteDto getQuestionante() {
		return questionante;
	}

	public void setQuestionante(QuestionanteDto questionante) {
		this.questionante = questionante;
	}
}

import { Build } from './build.model';
export class Job {
  public id: { id: string, wallet: string, project: string };
  public name: string;
  public builds: Build[];
}

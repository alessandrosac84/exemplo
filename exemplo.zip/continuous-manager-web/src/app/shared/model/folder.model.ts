import { Job } from './job.model';
import { HealthReport } from './health-report.model';

export class Folder {
  public description: string;
  public fullName: string;
  public name: string;
  public displayName: string;
  public healthReport: HealthReport[];
  public jobs: Job[];
}

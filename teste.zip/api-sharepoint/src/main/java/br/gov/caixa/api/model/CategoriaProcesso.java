package br.gov.caixa.api.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.gov.caixa.api.dto.CategoriaProcessoDto;



@Entity
@Table(name = "categoria_processo")
public class CategoriaProcesso {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "nome")
	private String nome;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public static CategoriaProcesso fromDtoToCategoriaProcesso(CategoriaProcessoDto dto){
		CategoriaProcesso categoriaProcesso = new CategoriaProcesso();
		categoriaProcesso.setUid(dto.getUid());
		categoriaProcesso.setNome(dto.getNome());
		return categoriaProcesso;
	}
}

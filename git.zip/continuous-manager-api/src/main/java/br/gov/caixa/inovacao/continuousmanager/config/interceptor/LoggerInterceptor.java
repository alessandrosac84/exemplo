/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.interceptor;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;

/**
 * Classe responsável por interceptar métodos das classes que possuem a
 * interface @Logged .
 * 
 * @author Fabio Iwakoshi
 *
 */
@Logged
@Interceptor
public class LoggerInterceptor {

	@Inject
	private Logger log;

	@Resource
	private EJBContext context;

	@AroundInvoke
	public Object intercept(InvocationContext ic) throws Exception {
		log.entering(ic.getTarget().getClass().getName(), ic.getMethod().getName());
		log.log(Level.INFO, ">>> user {0} invoced the method {1}.{2}()",
				new Object[] { context.getCallerPrincipal().getName(), ic.getTarget().getClass().getName(),
						ic.getMethod().getName() });
		
		Object proceed = ic.proceed();
		
		log.exiting(ic.getTarget().getClass().getName(), ic.getMethod().getName());
		log.log(Level.INFO, "<<< {0} - {1}",
				new Object[] { ic.getTarget().getClass().getName(), ic.getMethod().getName() });

		return proceed;
	}
}

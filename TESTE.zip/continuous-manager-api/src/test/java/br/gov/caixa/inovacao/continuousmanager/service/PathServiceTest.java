/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Path;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.repository.PathRepository;

/**
 * Classe de testes do PathService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class PathServiceTest {

	@Mock
	private PathRepository pathRepository;

	@InjectMocks
	private PathService pathService;

	private Path path;

	@Before
	public void before() {
		path = null; //EntityBuilder.createProjects().get(0).getCommits().stream().findFirst().get().getPaths().stream().findFirst().get();
		UtilReflection.setField(pathService, "log", Logger.getLogger(AuditService.class.getName()));
	}

	@Test
	public void testSave() {
		// Arrange
		Mockito.when(pathRepository.save(Mockito.<Path>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());

		// Act
		Path savedPath = pathService.save(path);

		// Then
		Assert.assertNotNull(savedPath);
	}
}

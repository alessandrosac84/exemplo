import { Environment } from './../model/environment.model';
import { Measure } from './../model/measure.model';
import { Observable } from 'rxjs/Rx';
import { Dashboard } from './../model/dashboard.model';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { environment } from '../../../environments/environment';

@Injectable()
export class DashBoardService {

    private dashboardtUrl = `${environment.apiBaseUrl}api/dashboards`;
    private carteiraUrl = `/wallets`;
    private projectBuildsUrl = `/projects`;
    private projectDetailUrl = `/commit`;
    private environmentsUrl = `/environments`;

    constructor(private http: HttpClient) { }

    getProjects(): Observable<Dashboard[]> {
        return this.http.get<Dashboard[]>(`${this.dashboardtUrl}${this.projectBuildsUrl}`);
    }

    getDetailProject(carteiraId: string, projectId: string, commit: string): Observable<Measure> {
        return this.http.get<Measure>
            (`${this.dashboardtUrl}${this.carteiraUrl}/${carteiraId}${this.projectBuildsUrl}/${projectId}` +
            `${this.projectDetailUrl}/${commit}`);
    }

    getProjectBuildsById(carteiraId: string, projectId: string): Observable<any> {
        return this.http.get<any>(`${this.dashboardtUrl}${this.carteiraUrl}/${carteiraId}${this.projectBuildsUrl}/${projectId}`);
    }

    getVersions(carteiraId: string, projectId: string): Observable<Environment[]> {
        return this.http.get<Environment[]>
            (`${this.dashboardtUrl}${this.carteiraUrl}/${carteiraId}${this.projectBuildsUrl}/${projectId}${this.environmentsUrl}`);
    }

    /*getJSON(): Observable<any> {
        return this.http.get('../../../assets/files/dashboard.json')
            .map((response: Response) => {
                const data = response;
                return data;
            });
    }*/
}

package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the experiencia_profissional database table.
 * 
 */
@Entity
@Table(name="experiencia_profissional")
@NamedQueries({	
	@NamedQuery(name="ExperienciaProfissional.findAll", query="SELECT e FROM ExperienciaProfissional e"),
	@NamedQuery(name = "ExperienciaProfissional.findByAKs", query = "SELECT e FROM ExperienciaProfissional e WHERE e.id <> :id AND (e.empresa = :empresa OR e.cargo = :cargo OR e.anoInicio = :anoInicio OR e.anoFim = :anoFim)"),
	@NamedQuery(name="ExperienciaProfissional.findAllByFuncionario", query="SELECT e FROM ExperienciaProfissional e WHERE e.funcionario.matricula = :matricula"),
})
public class ExperienciaProfissional extends AuditedEntity implements Serializable, IEntity<Integer> {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Max(value=2050)
	@Min(value=1950)
	@Column(name="ano_fim", nullable=false, precision=4)
	private Integer anoFim;

	@Max(value=2050)
	@Min(value=1950)
	@NotNull
	@Column(name="ano_inicio", nullable=false, precision=4)
	private Integer anoInicio;

	@NotEmpty
	@Size(min=5)
	@Column(nullable=false, length=70)
	private String cargo;

	@NotEmpty
	@Size(min=3)
	@Column(nullable=false, length=70)
	private String empresa;

	@NotEmpty
	@Size(min=10)
	@Column(name="resumo_atividades", nullable=false, columnDefinition="TEXT")
	private String resumoAtividades;

	@JsonIgnore
	//bi-directional many-to-one association to Funcionario
	@ManyToOne
	@JoinColumn(name="funcionario", nullable=false)
	private Funcionario funcionario;

	public ExperienciaProfissional() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAnoFim() {
		return this.anoFim;
	}

	public void setAnoFim(Integer anoFim) {
		this.anoFim = anoFim;
	}

	public Integer getAnoInicio() {
		return this.anoInicio;
	}

	public void setAnoInicio(Integer anoInicio) {
		this.anoInicio = anoInicio;
	}

	public String getCargo() {
		return this.cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getEmpresa() {
		return this.empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getResumoAtividades() {
		return this.resumoAtividades;
	}

	public void setResumoAtividades(String resumoAtividades) {
		this.resumoAtividades = resumoAtividades;
	}

	public Funcionario getFuncionario() {
		return this.funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}
	
	@Override
	public boolean isTheSameObject(IEntity<Integer> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		ExperienciaProfissional other = (ExperienciaProfissional) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
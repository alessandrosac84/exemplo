package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpMethod;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.InfoSonarVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.MeasureHistorySonarVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.QualityGateVO;
import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;
import br.gov.caixa.inovacao.continuousmanager.service.integration.HttpService.IEntity;

/**
 * Classe de servicos do Sonar.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class SonarService {

	private String metricKeys = "bugs,code_smells,comment_lines,comment_lines_density,complexity,coverage,duplicated_lines,"
			+ "duplicated_lines_density,files,lines,new_bugs,new_code_smells,new_coverage,new_duplicated_lines,"
			+ "new_duplicated_lines_density,new_lines,new_maintainability_rating,new_reliability_rating,new_security_rating,"
			+ "new_violations,new_vulnerabilities,tests,violations,vulnerabilities,reliability_rating,security_rating,sqale_rating";

	@Inject
	private Logger log;

	@Inject
	private ParameterService parameterService;

	/**
	 * Obtem as metricas de um projeto do sonar
	 * 
	 * @return
	 * 
	 * @return Lista de metricas
	 */
	public MeasureHistorySonarVO getMeasuresHistory(String component, String from, String to) {
		log.fine("Obtendo Measures Sonar");
		try {
			Map<String, String> query = new HashMap<>();
			query.put("component", component);
			query.put("metrics", this.metricKeys);
			query.put("from", from);
			query.put("to", to);
			return callSonar(Environment.DES, HttpMethod.GET, "/api/measures/search_history", query, null,
					new TypeReference<MeasureHistorySonarVO>() {
					});
		} catch (Exception e) {
			log.log(Level.SEVERE, "Erro ao obter métricas do Sonar!");
			return null;
		}
	}

	/**
	 * Obtem as informações de um projeto do sonar
	 * 
	 * @return
	 * 
	 * @return Lista de informações
	 */
	public InfoSonarVO getInfoSonar(String keySonar) {
		log.fine("Obtendo Informações Sonar");
		try {
			Map<String, String> query = new HashMap<>();
			query.put("id", keySonar);
			return callSonar(Environment.DES, HttpMethod.GET, "/api/ce/task", query, null,
					new TypeReference<InfoSonarVO>() {
					});
		} catch (Exception e) {
			throw new ServiceUnavailableException("Erro ao obter informações de Compute Engine do Sonar!");
		}
	}

	/**
	 * Obtem quality gate de um projeto do sonar
	 * 
	 * @return
	 * 
	 * @return Lista de quality gate
	 */
	public QualityGateVO getQualityGates() {
		log.fine("Obtendo Quality Gate Sonar");
		try {
			Map<String, String> query = new HashMap<>();
			query.put("name", "SonarQube way");
			return callSonar(Environment.DES, HttpMethod.GET, "/api/qualitygates/show", query, null,
					new TypeReference<QualityGateVO>() {
					});
		} catch (Exception e) {
			throw new ServiceUnavailableException("Erro ao obter quality Gate do Sonar!");
		}
	}

	@SuppressWarnings("unchecked")
	private <T> T callSonar(Environment environment, HttpMethod httpMethod, String path, Map<String, String> queries,
			Entity<?> entity, TypeReference<T> typeReference) {

		ParameterPK parameterId = new ParameterPK();
		parameterId.setEnvironment(environment);
		parameterId.setServerType(ServerType.SONAR);

		Parameter parameter = parameterService.findById(parameterId);

		if (parameter == null) {
			throw new NotFoundException("Erro ao obter informações do Sonar!");
		}

		IEntity build = HttpService.httpMethod(httpMethod).host(parameter.getHost()).path(path).queries(queries)
				.header("Authorization", parameter.getPrincipal());

		Response response = build.entity(entity).build();

		if (response.hasEntity() && response.getStatus() == 200) {
			try {
				String resposta = response.readEntity(String.class);
				if (typeReference.getType().getTypeName().equals("java.lang.String")) {
					return (T) resposta;
				}
				return new ObjectMapper().readValue(resposta, typeReference);
			} catch (IOException e) {
				log.log(Level.SEVERE, "Erro ao transformar informações do Sonar!", e);
				throw new ServiceUnavailableException("Erro ao obter informações do Sonar!");
			}
		}
		log.log(Level.SEVERE, "Nenhuma informação encontrada!");
		return null;
	}
}

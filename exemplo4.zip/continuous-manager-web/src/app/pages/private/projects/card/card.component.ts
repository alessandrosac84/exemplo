import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

import { Project } from '../../../../shared/model/entity/project.model';

@Component({
  selector: 'cm-card-project',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {
  @Input() project: Project;

  constructor(private _router: Router) {}

  ngOnInit() {}

  storeProject(project: number) {
    localStorage.setItem('project', project.toString());
    this._router.navigateByUrl('/builds');
  }
}

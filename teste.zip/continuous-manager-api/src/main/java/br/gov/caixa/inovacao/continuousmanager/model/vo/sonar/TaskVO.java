package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;
import java.util.Date;

/**
 * Classe de representação de informações de projeto no Sonar
 * 
 * @author Alessandro Carvalho
 *
 */
public class TaskVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5157243590422278891L;

	private String organization;
    private String id;
    private String type;
    private String componentId;
    private String componentKey;
    private String componentName;
    private String componentQualifier;
    private String analysisId;
    private String status;
    private Date submittedAt;
    private String submitterLogin;
    private Date startedAt;
    private Date executedAt;
    private Long executionTimeMs;
    private Boolean logs;
    private Boolean hasScannerContext;
	/**
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}
	/**
	 * @param organization the organization to set
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the componentId
	 */
	public String getComponentId() {
		return componentId;
	}
	/**
	 * @param componentId the componentId to set
	 */
	public void setComponentId(String componentId) {
		this.componentId = componentId;
	}
	/**
	 * @return the componentKey
	 */
	public String getComponentKey() {
		return componentKey;
	}
	/**
	 * @param componentKey the componentKey to set
	 */
	public void setComponentKey(String componentKey) {
		this.componentKey = componentKey;
	}
	/**
	 * @return the componentName
	 */
	public String getComponentName() {
		return componentName;
	}
	/**
	 * @param componentName the componentName to set
	 */
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
	/**
	 * @return the componentQualifier
	 */
	public String getComponentQualifier() {
		return componentQualifier;
	}
	/**
	 * @param componentQualifier the componentQualifier to set
	 */
	public void setComponentQualifier(String componentQualifier) {
		this.componentQualifier = componentQualifier;
	}
	/**
	 * @return the analysisId
	 */
	public String getAnalysisId() {
		return analysisId;
	}
	/**
	 * @param analysisId the analysisId to set
	 */
	public void setAnalysisId(String analysisId) {
		this.analysisId = analysisId;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the submittedAt
	 */
	public Date getSubmittedAt() {
		return submittedAt;
	}
	/**
	 * @param submittedAt the submittedAt to set
	 */
	public void setSubmittedAt(Date submittedAt) {
		this.submittedAt = submittedAt;
	}
	/**
	 * @return the submitterLogin
	 */
	public String getSubmitterLogin() {
		return submitterLogin;
	}
	/**
	 * @param submitterLogin the submitterLogin to set
	 */
	public void setSubmitterLogin(String submitterLogin) {
		this.submitterLogin = submitterLogin;
	}
	/**
	 * @return the startedAt
	 */
	public Date getStartedAt() {
		return startedAt;
	}
	/**
	 * @param startedAt the startedAt to set
	 */
	public void setStartedAt(Date startedAt) {
		this.startedAt = startedAt;
	}
	/**
	 * @return the executedAt
	 */
	public Date getExecutedAt() {
		return executedAt;
	}
	/**
	 * @param executedAt the executedAt to set
	 */
	public void setExecutedAt(Date executedAt) {
		this.executedAt = executedAt;
	}
	/**
	 * @return the executionTimeMs
	 */
	public Long getExecutionTimeMs() {
		return executionTimeMs;
	}
	/**
	 * @param executionTimeMs the executionTimeMs to set
	 */
	public void setExecutionTimeMs(Long executionTimeMs) {
		this.executionTimeMs = executionTimeMs;
	}
	/**
	 * @return the logs
	 */
	public Boolean getLogs() {
		return logs;
	}
	/**
	 * @param logs the logs to set
	 */
	public void setLogs(Boolean logs) {
		this.logs = logs;
	}
	/**
	 * @return the hasScannerContext
	 */
	public Boolean getHasScannerContext() {
		return hasScannerContext;
	}
	/**
	 * @param hasScannerContext the hasScannerContext to set
	 */
	public void setHasScannerContext(Boolean hasScannerContext) {
		this.hasScannerContext = hasScannerContext;
	}
	
}

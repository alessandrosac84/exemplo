package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-04-25T12:48:02.830-0300")
@StaticMetamodel(CommitPK.class)
public class CommitPK_ {
	public static volatile SingularAttribute<CommitPK, String> commit;
	public static volatile SingularAttribute<CommitPK, String> project;
	public static volatile SingularAttribute<CommitPK, String> wallet;
}

import { ViewCommitsBuilds } from './../../shared/model/view-commits-builds.model';
import { Commit } from './../../shared/model/commit.model';
import { Build } from './../../shared/model/build.model';
import { Job } from './../../shared/model/job.model';
import { JenkinsService } from './../../shared/service/jenkins.service';
import { Title } from '@angular/platform-browser';
import { Folder } from './../../shared/model/folder.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jmw-release',
  templateUrl: './release.component.html',
  styleUrls: ['./release.component.scss']
})
export class ReleaseComponent implements OnInit {

  pageTitle = 'Release Manager';
  listaFolders: Folder[] = [];
  folderId: Folder;
  listaJobs: Job[] = [];
  listaBuilds: Build[] = [];
  listaCommits: Commit[] = [];
  listaViewTqs: ViewCommitsBuilds[] = [];
  jobId: Job;

  statusBuildTqsLiberada: Boolean = false;

  constructor(private title: Title,
    private jenkinsService: JenkinsService) {

  }

  ngOnInit() {
    this.title.setTitle(this.pageTitle);
    this.jenkinsService.getFolders().subscribe(data => {
      this.listaFolders = data;
    });

    this.jenkinsService.getJSON().subscribe(data => {
      this.listaCommits = data;
    });
  }

  public changeSistema(option) {
    this.jobId = undefined;
    this.folderId = option;
    this.listaJobs = [];
    if (option !== undefined) {
      this.jenkinsService.getJobs(option.name).subscribe(data => {
        this.listaJobs = data;
      });
    }
  }

  public changeJob(job) {
    if (job !== undefined) {
      this.jenkinsService.getBuilds(this.folderId.name, job.name).subscribe(data => {
        this.listaBuilds = data;

        this.listaCommits.forEach(commit => {
          const item: ViewCommitsBuilds = new ViewCommitsBuilds;
          item.id_commit = commit.id;
          item.id_short_commit = commit.short_id;
          item.author_commit = commit.author_name;
          item.author_email_commit = commit.author_email;
          item.message_commit = commit.title;
          item.versao_release_build = null;

          const dateCommitString = commit.committed_date;
          const dateCommitDate = new Date(dateCommitString);
          item.committed_date_commit = dateCommitDate;

          item.list_view_builds = [];

          this.listaBuilds.filter((build: Build) => {
            if (build.actions.length > 0) {
              if (build.actions[0].lastBuiltRevision.SHA1 === commit.id) {
                const item_build = new Build;
                item_build.number = build.number;
                item_build.timestamp = build.timestamp;
                item_build.result = build.result;
                item.list_view_builds.push(item_build);
              }
            }
          });

          item.list_view_builds.forEach(build => {

            if (build.result === 'SUCCESS') {
              this.listaViewTqs.push(item);
            }
          });
        });
      });
    }
  }

}

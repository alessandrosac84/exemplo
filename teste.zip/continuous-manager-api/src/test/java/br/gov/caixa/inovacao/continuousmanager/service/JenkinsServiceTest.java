package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ServerType;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;

/**
 * Classe de testes do JenkinsService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class JenkinsServiceTest {
	
	@Mock
	private ParameterService parameterService;
	
	@InjectMocks
	private JenkinsService jenkinsService;
	
	private Parameter parameter;
	
	@Before
	public void before() {
		parameter = new Parameter();
		parameter.setId(new ParameterPK());
		parameter.getId().setEnvironment(Environment.DES);
		parameter.getId().setServerType(ServerType.JENKINS);
		parameter.setCredential("");
		parameter.setHost("https://jenkins.caixa");
		parameter.setPrincipal("jenkins");
		UtilReflection.setField(jenkinsService, "log", Logger.getLogger(JenkinsService.class.getName()));
	}

	@Test(expected=Exception.class)
	public void testListWallets() {
		// Arrange
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.listWallets();
	}

	@Test(expected=Exception.class)
	public void testListProjects() {
		// Arrange
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.listProjects("inovacao");
	}

	@Test(expected=Exception.class)
	public void testListJobs() {
		// Arrange
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.listJobs("inovacao", "portal-inovacao");
	}

	@Test(expected=Exception.class)
	public void testListBuilds() {
		// Arrange
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.listBuilds("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev");
	}

	@Test(expected=Exception.class)
	public void testGetLog() {
		// Arrange
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.getLog("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 1);
	}

}

package br.gov.caixa.inovacao.continuousmanager.model.entity;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity_;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-04-17T16:22:11.056-0300")
@StaticMetamodel(Project.class)
public class Project_ extends AuditedEntity_ {
	public static volatile SingularAttribute<Project, ProjectPK> id;
	public static volatile SingularAttribute<Project, String> gitRepo;
	public static volatile SingularAttribute<Project, String> name;
}

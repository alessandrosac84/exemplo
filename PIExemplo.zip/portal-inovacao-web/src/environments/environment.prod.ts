export const environment = {
  production: true,
  apiBaseUrl: '/portal-inovacao-api/api/',
  apiSharepointBaseUrl: 'https://10.1.32.240:8092/sharepoint-api/api/',
  hmr: false
};

package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.SetJoin;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildPK_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Build_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.CommitPK_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Commit_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de acesso ao banco de dados da entidade Commit.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class CommitRepository {

	@Inject
	private EntityManager entityManager;

	public List<Commit> findByStatus(String wallet, String project, int offset, int limit, String sort,
			AscDesc order) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Commit> query = builder.createQuery(Commit.class);
		
		Root<Commit> from = query.from(Commit.class);
		from.fetch(Commit_.changeSets, JoinType.INNER).fetch(ChangeSet_.build, JoinType.INNER);
		SetJoin<Commit, ChangeSet> fromCS = from.join(Commit_.changeSets, JoinType.INNER);
		Join<ChangeSet, Build> fromB = fromCS.join(ChangeSet_.build, JoinType.INNER);
		
		Predicate predicate = builder.equal(from.get(Commit_.id).get(CommitPK_.wallet), wallet);
		predicate = builder.and(predicate, builder.equal(from.get(Commit_.id).get(CommitPK_.project), project));
		predicate = builder.and(predicate, builder.equal(fromB.get(Build_.result), JenkinsResult.SUCCESS));
		predicate = builder.and(predicate, builder.like(fromB.get(Build_.id).get(BuildPK_.job), "%-ci-dev"));
		
		Order ascDesc = builder.asc(from.get(sort));
		if (order != AscDesc.ASC) {
			ascDesc = builder.desc(from.get(sort));
		}

		return entityManager
				.createQuery(query.select(from).distinct(true).where(predicate).orderBy(ascDesc))
				.setFirstResult(offset).setMaxResults(limit).getResultList();
	}

	public Long countByStatus(String wallet, String project) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);
		Root<Commit> from = query.from(Commit.class);
		
		SetJoin<Commit, ChangeSet> fromCS = from.join(Commit_.changeSets, JoinType.INNER);
		Join<ChangeSet, Build> fromB = fromCS.join(ChangeSet_.build, JoinType.INNER);

		Predicate predicate = builder.equal(from.get(Commit_.id).get(CommitPK_.wallet), wallet);
		predicate = builder.and(predicate, builder.equal(from.get(Commit_.id).get(CommitPK_.project), project));
		predicate = builder.and(predicate, builder.equal(fromB.get(Build_.result), JenkinsResult.SUCCESS));
		predicate = builder.and(predicate, builder.like(fromB.get(Build_.id).get(BuildPK_.job), "%-ci-dev"));

		return entityManager.createQuery(query.select(builder.countDistinct(from)).where(predicate)).getSingleResult();
	}

	public Commit save(Commit commit) {
		entityManager.persist(commit);
		return commit;
	}

	public Commit findById(CommitPK id) {
		return entityManager.find(Commit.class, id);
	}

	public Integer maxSequence(String wallet, String project) {
		return entityManager.createQuery(
				"SELECT MAX(g.sequential) FROM Commit g WHERE g.id.wallet = :wallet AND g.id.project = :project",
				Integer.class).setParameter("wallet", wallet).setParameter("project", project).getSingleResult();
	}

	public Commit update(Commit commit) {
		return entityManager.merge(commit);
	}
}

import { TestBed, async, inject } from '@angular/core/testing';

import { MapaAmbienteGuard } from './mapa-ambiente.guard';

describe('MapaAmbienteGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MapaAmbienteGuard]
    });
  });

  it('should ...', inject([MapaAmbienteGuard], (guard: MapaAmbienteGuard) => {
    expect(guard).toBeTruthy();
  }));
});

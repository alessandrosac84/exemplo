/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Commit;

/**
 * Classe de testes de ChangeSetRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CommitRepositoryTest {

	@Mock
	private EntityManager em;

	@InjectMocks
	private CommitRepository commitRepository;

	private Commit commit;

	@Before
	public void before() {
		commit = null;//EntityBuilder.createProjects().get(0).getGitRepos().stream().findAny().get();
	}

	@Test
	public void testSave() {
		// Act
		Commit save = commitRepository.save(commit);
		// Then
		Assert.assertEquals(commit.getId(), save.getId());
	}

}

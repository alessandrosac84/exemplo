import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';

import { Observable } from 'rxjs';

import { Stage } from './../model/stage.model';
import { Build } from '../model/build.model';
import { Job } from '../model/job.model';
import { Wallet } from '../model/wallet.model';
import { Project } from '../model/project.model';
import { Commit } from '../model/commit.model';

import { environment } from '../../../environments/environment';

@Injectable()
export class WalletService {

  private walletUrl = `${environment.apiBaseUrl}api/wallets`;
  private projectsUrl = '/projects';
  private jobUrl = '/jobs';
  private buildUrl = '/builds';
  private buildReleaseUrl = '/builds/release';
  private logUrl = '/log';
  private logStagesUrl = '/log/stages';
  private currentBuildsUrl = '/currentBuilds';
  private commitUrl = '/commits';
  private rebuildUrl = '/rebuild';
  private versionUrl = '/version';
  private deployUrl = '/deploy';
  private limit = 10;

  constructor(private http: HttpClient) { }

  getWallets(): Observable<Wallet[]> {
    return this.http.get<Wallet[]>(`${this.walletUrl}`);
  }

  getWallet(walletName: string): Observable<Wallet> {
    return this.http.get<Wallet>(`${this.walletUrl}/${walletName}`);
  }

  getProjects(walletName: string): Observable<Project[]> {
    return this.http.get<Project[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}`);
  }

  getProject(walletName: string, projectName: string): Observable<Project> {
    return this.http.get<Project>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}`);
  }

  getJobs(walletName: string, projectName: string): Observable<Job[]> {
    return this.http.get<Job[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}`);
  }

  getJob(walletName: string, projectName: string, jobName: string): Observable<Job> {
    return this.http.get<Job>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}/${jobName}`);
  }

  getBuilds(walletName: string, projectName: string, jobName: string, page: number): Observable<HttpResponse<Build[]>> {
    const p = (page - 1) * this.limit;
    return this.http.get<Build[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/` +
      `${projectName}${this.jobUrl}/${jobName}${this.buildUrl}?order=DESC&limit=${this.limit}&offset=${p}`, { observe: 'response' });
  }

  getBuildsToRelease(walletName: string, projectName: string, page: number): Observable<HttpResponse<Build[]>> {
    const p = (page - 1) * this.limit;
    return this.http.get<Build[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/` +
      `${projectName}${this.buildReleaseUrl}?limit=${this.limit}&offset=${p}&result=SUCCESS`, { observe: 'response' });
  }

  geDetailtBuild(walletName: string, projectName: string, jobName: string, build: number): Observable<any> {
    return this.http.get(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}/${jobName}` +
      `${this.buildUrl}/${build}`);
  }

  getLog(walletName: string, projectName: string, jobName: string, build: number): Observable<any> {
    return this.http.get(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}` +
      `${this.jobUrl}/${jobName}${this.buildUrl}/${build}${this.logUrl}`,
      { responseType: 'text' });
  }

  getLogStages(walletName: string, projectName: string, jobName: string, build: number): Observable<Stage[]> {
    return this.http.get<Stage[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}` +
      `${this.jobUrl}/${jobName}${this.buildUrl}/${build}${this.logStagesUrl}`);
  }

  getCurrentBuilds(walletName: string): Observable<Build[]> {
    return this.http.get<Build[]>(`${this.walletUrl}/${walletName}${this.currentBuildsUrl}`);
  }

  getCommitsSuccess(walletName: string, projectName: string, page: number): Observable<HttpResponse<Commit[]>> {
    const p = (page - 1) * this.limit;
    return this.http.get<Commit[]>(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}` +
      `${this.commitUrl}?limit=${this.limit}&offset=${p}&result=SUCCESS`, { observe: 'response' });
  }

  rebuild(walletName: string, projectName: string, jobName: string, build: number, commit: string): Observable<any> {
    return this.http.post(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.jobUrl}/${jobName}` +
      `${this.rebuildUrl}`, commit);
  }

  version(walletName: string, projectName: string, commit: Commit): Observable<any> {
    return this.http.post(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}` +
      `${this.versionUrl}`, commit);
  }

  deploy(walletName: string, projectName: string, version: string): Observable<any> {
    return this.http.post(`${this.walletUrl}/${walletName}${this.projectsUrl}/${projectName}${this.deployUrl}`, version);
  }
}

package br.gov.caixa.api.repository.views;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.gov.caixa.api.model.views.EspecialidadeTreinamentoView;

public interface EspecialidadeTreinamentoViewRepository extends JpaRepository<EspecialidadeTreinamentoView, Long> {

	List<EspecialidadeTreinamentoView> findByEspecialidadeId(Long especialidadeId);

}

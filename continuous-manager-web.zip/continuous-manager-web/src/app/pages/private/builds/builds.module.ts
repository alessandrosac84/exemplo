import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';

import { MaterialModule } from '../../../core/material/material.module';
import { BuildsRoutingModule } from './builds-routing.module';
import { BuildsComponent } from './builds.component';

@NgModule({
  imports: [
    CommonModule,
    BuildsRoutingModule,
    MaterialModule,
    FlexLayoutModule
  ],
  declarations: [BuildsComponent]
})
export class BuildsModule { }

package br.gov.caixa.sharepoint.config.provider;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.enterprise.inject.Produces;

public class MessageProvider {

	@Produces
	public ResourceBundle getBundle() {
		return ResourceBundle.getBundle("messages", new Locale("pt", "BR"));
	}
}

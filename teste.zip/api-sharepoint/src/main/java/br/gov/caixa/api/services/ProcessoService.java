package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.ProcessoDto;
import br.gov.caixa.api.model.CategoriaProcesso;
import br.gov.caixa.api.model.Processo;
import br.gov.caixa.api.repository.ProcessoRepository;
import br.gov.caixa.api.result.ProcessoResult;

@Named
public class ProcessoService {
	
	@Inject
	ProcessoRepository repository;
	
	public ProcessoResult listAll() {

		ProcessoResult result = new ProcessoResult();
		try {
			List<Processo> lista = repository.findAll();

			if (lista != null) {
				result.setList(ProcessoDto.fromProcessoToListDto(lista));
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma processo.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}

	public ProcessoResult listProcessosByIdCategoriaTecnologica(Long idCategoriaProcesso) {
		ProcessoResult result = new ProcessoResult();
		try {
			
			CategoriaProcesso categoriaProcesso = new CategoriaProcesso();
			categoriaProcesso.setUid(idCategoriaProcesso);
			
			List<Processo> lista = repository.findByCategoriaProcessoOrder(categoriaProcesso);				
			
			if (lista != null) {
				result.setList(ProcessoDto.fromProcessoToListDto(lista));					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Processo para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}

	public ProcessoResult save(ProcessoDto dto) {
		
		ProcessoResult result = new ProcessoResult();
		
		Processo processo = repository.findByNome(dto.getNome());
		
		if(processo != null) {
			result.setIsError(true);
			result.setMessage("Processo j� Existe em outra Categoria. [" + processo.getCategoriaProcesso().getNome() + "]");			
		}
		else {		
			processo = Processo.fromDtoToProcesso(dto);
			repository.save(processo);			
			result.setMessage("Executado com sucesso.");
		}		
		
		return result;
	}

	public ProcessoResult delete(ProcessoDto dto) {
		Processo processo = Processo.fromDtoToProcesso(dto);
		ProcessoResult result;
		try {
			repository.delete(processo);
			
			result = new ProcessoResult();
			result.setMessage("Executado com sucesso.");
			
		} catch (Exception e) {
			result = new ProcessoResult();
			
			result.setIsError(true);
			result.setMessage("Existe(m) Rating(s) Associados a esta Processo.");
			
			e.printStackTrace();
		}		
		return result;
	}
	
	public ProcessoResult setAtivo(ProcessoDto dto) {
		
		ProcessoResult result = new ProcessoResult();
		repository.setAtivo(dto.getAtivo(), dto.getUid());
		result.setMessage("Executado com sucesso.");
		return result;
	}

}

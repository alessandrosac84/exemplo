import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'admins-management',
    loadChildren: './admins-management/admins-management.module#AdminsManagementModule',
    data: { state: 'admins-management' }
  },
  {
    path: 'projects-management',
    loadChildren: './projects-management/projects-management.module#ProjectsManagementModule',
    data: { state: 'projects-management' }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule {}

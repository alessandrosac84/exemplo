export enum TypeServerEnum {
    APLICACAO = 'APLICAÇÃO',
    APRESENTACAO = 'APRESENTAÇÃO'
}

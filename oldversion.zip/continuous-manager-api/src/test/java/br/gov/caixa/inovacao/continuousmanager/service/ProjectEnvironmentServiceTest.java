package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.ProjectEnvironment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.repository.ProjectEnvironmentRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.VersionProjectVO;

/**
 * Classe de testes do ProjectEnvironmentService.
 * 
 * @author Alessandro Carvalho
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ProjectEnvironmentServiceTest {

	@Mock
	private ProjectEnvironmentRepository projectEnvironmentRepository;

	@Mock
	private CommitService commitService;
	
	@InjectMocks
	private ProjectEnvironmentService projectEnvironmentService;
	
	private ProjectEnvironment projectEnvironment = new ProjectEnvironment();
	
	@Before
	public void before() {
		projectEnvironment.setBuild(new Build());
		projectEnvironment.getBuild().setId(new BuildPK());
		projectEnvironment.getBuild().getId().setId(1);
		UtilReflection.setField(projectEnvironmentService, "log", Logger.getLogger(AuditService.class.getName()));
	}
	
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(projectEnvironmentRepository.save(Mockito.<ProjectEnvironment>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());

		// Act
		projectEnvironmentService.save(projectEnvironment);
	
	}
	
	@Test
	public void testFindByEnviroment() {
		// Arrange
		Mockito.when(projectEnvironmentRepository.findByEnviroment(Mockito.anyString(), Mockito.anyString(), Mockito.any(Environment.class))).thenReturn(projectEnvironment);
		Mockito.when(commitService.findVersionByBuild(Mockito.anyString(), Mockito.anyString(), Mockito.any(Build.class))).thenReturn(new Commit());
		
		// Act		
		List<VersionProjectVO> savedVersions = projectEnvironmentService.findByEnviroment("inovacao", "continuous-manager-web");

		// Then
		Assert.assertNotNull(savedVersions);
	}
	
	@Test
	public void testFindByEnviromentNull() {
		// Arrange
		Mockito.when(projectEnvironmentRepository.findByEnviroment(Mockito.anyString(), Mockito.anyString(), Mockito.any(Environment.class))).thenReturn(null);
		
		// Act		
		List<VersionProjectVO> savedVersions = projectEnvironmentService.findByEnviroment("inovacao", "continuous-manager-web");

		// Then
		Assert.assertNotNull(savedVersions);
	}

}

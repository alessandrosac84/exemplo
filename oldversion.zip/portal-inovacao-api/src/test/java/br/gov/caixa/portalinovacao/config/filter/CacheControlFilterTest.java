package br.gov.caixa.portalinovacao.config.filter;

import java.io.IOException;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.core.MultivaluedMap;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class CacheControlFilterTest {

	@InjectMocks
	private CacheControlFilter cacheControlFilter;
	
	@Mock
	private ContainerRequestContext containerRequestContext;
	
	@Mock
	private ContainerResponseContext containerResponseContext;
	
	@Mock
	private MultivaluedMap<String, Object> headers;
	
	@Test
	public void testFilter() throws IOException {
		// Arrange
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.when(containerResponseContext.getHeaders()).thenReturn(headers);
		
		// Act
		cacheControlFilter.filter(containerRequestContext, containerResponseContext);
		
		// Then
		Assert.assertEquals("GET", containerRequestContext.getMethod());
	}

}

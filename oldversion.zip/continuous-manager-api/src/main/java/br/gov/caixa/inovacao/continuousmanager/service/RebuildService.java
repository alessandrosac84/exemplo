package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;
import br.gov.caixa.inovacao.continuousmanager.service.integration.SharepointService;

/**
 * Classe de servicos de Rebuild.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class RebuildService {

	@Inject
	private Logger log;

	@Inject
	private JenkinsService jenkinsService;

	@Inject
	private SharepointService sharepointService;

	public void rebuild(String wallet, String project, String job, @NotNull @Size(min = 40, max = 40) String commit) {
		log.fine("Iniciando Rebuild");
		String description = "Started ​by ​Continuous Manager ​push ​by "
				+ sharepointService.getFuncionario(HelperThreadLocal.USER.get()).getNome();
		jenkinsService.createBuild(wallet, project, job, description, commit);
	}
}

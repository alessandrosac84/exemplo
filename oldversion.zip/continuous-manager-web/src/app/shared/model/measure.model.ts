import { Commit } from './commit.model';
export class Measure {
    public id: { wallet: string, project: string, commit: string };
    public commit: { project: { name: string } };
    public complexity: number;
    public lines: number;
    public bugs: number;
    public vulnerabilities: number;
    public codeSmells: number;
    public coverage: number;
    public unitTests: number;
    public duplicatedLines: number;
    public newCodeSmells: number;
    public newCoverage: number;
    public newLines: number;
    public newVulnerabilities: number;
    public newBugs: number;
    public commentLines: number;
    public commentLinesPercent: number;
    public duplicatedLinesPercent: number;
    public newDuplicatedLines: number;
    public newDuplicatedLinesPercent: number;
    public violations: number;
    public newViolations: number;
    public sqaleRating: number;
    public quality: string;
    public newMaintainabilityRating: number;
    public securityRating: number;
    public security: string;
    public newSecurityRating: number;
    public reliabilityRating: number;
    public newReliabilityRating: number;
    public files: number;
    public qualityGate: string;
    public version: string;
    public sizeProject: string;
}


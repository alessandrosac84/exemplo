package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeFuncionarioView;
import br.gov.caixa.api.result.BasicResult;

public class EspecialidadeFuncionarioViewResult extends BasicResult {
	private List<EspecialidadeFuncionarioView> list;
	private EspecialidadeFuncionarioView especialidadeFuncionarioView;

	public List<EspecialidadeFuncionarioView> getList() {
		return list;
	}

	public void setList(List<EspecialidadeFuncionarioView> list) {
		this.list = list;
	}

	public EspecialidadeFuncionarioView getEspecialidadeFuncionarioView() {
		return especialidadeFuncionarioView;
	}

	public void setEspecialidadeFuncionarioView(EspecialidadeFuncionarioView especialidadeFuncionarioView) {
		this.especialidadeFuncionarioView = especialidadeFuncionarioView;
	}
}
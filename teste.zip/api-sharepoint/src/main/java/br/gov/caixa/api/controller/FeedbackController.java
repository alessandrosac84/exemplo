package br.gov.caixa.api.controller;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.dto.FeedbackDto;
import br.gov.caixa.api.result.FeedbackResult;
import br.gov.caixa.api.services.FeedbackService;

@RestController
public class FeedbackController {
	
	@Inject
	FeedbackService service;
	
	@RequestMapping(value="/api/feedback/save", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public FeedbackResult save(@RequestBody FeedbackDto feedbackDto) {
		return service.save(feedbackDto);
	}
}
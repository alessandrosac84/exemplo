package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.deser.std.DateDeserializers.DateDeserializer;
import com.fasterxml.jackson.databind.ser.std.DateSerializer;

import br.gov.caixa.sharepoint.config.constraint.ChaveCaixa;
import br.gov.caixa.sharepoint.config.constraint.Email;
import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the funcionario database table.
 * 
 */
@Entity
@Table(name="funcionario")
@NamedQueries ({
	@NamedQuery(name="Funcionario.findAll", query="SELECT f FROM Funcionario f WHERE LOWER(f.nome) LIKE :filter OR LOWER(f.matricula) LIKE :filter ORDER BY f.nome"),
	@NamedQuery(name="Funcionario.countAll", query = "SELECT count(f) FROM Funcionario f WHERE LOWER(f.nome) LIKE :filter OR LOWER(f.matricula) LIKE :filter"),
	@NamedQuery(name="Funcionario.findLikeCargo", query="SELECT f FROM Funcionario f WHERE f.cargoFuncionario.descricao LIKE :cargo"),
	@NamedQuery(name="Funcionario.findByCoordenacao", query="SELECT f FROM Funcionario f WHERE f.coordenacao.id = :coordenacao"),
})
public class Funcionario extends AuditedEntity implements Serializable, IEntity<String> {
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@ChaveCaixa
	@Column(unique=true, nullable=false, length=7)
	private String matricula;

	@Size(min=5)
	@Column(columnDefinition="TEXT")
	private String anotacoes;

	@Column(precision=8)
	private Integer cep;

	@Column(length=200)
	private String cidade;

	@Temporal(TemporalType.DATE)
	@Column(name="data_admissao")
	private Calendar dataAdmissao;

	@Temporal(TemporalType.DATE)
	@Column(name="data_cedes")
	private Calendar dataCedes;

	@Column(length=200)
	private String depto;

	@Email
	@Column(nullable=false, length=100)
	private String email;

	@Column(length=200)
	private String empresa;

	@Column(columnDefinition="TEXT")
	private String foto;

	@Temporal(TemporalType.TIME)
	@Column(name="hora_entrada")
	@JsonSerialize(using = DateSerializer.class)
    @JsonDeserialize(using = DateDeserializer.class)
	private Date horaEntrada;

	@Temporal(TemporalType.TIME)
	@Column(name="hora_saida")
	@JsonSerialize(using = DateSerializer.class)
    @JsonDeserialize(using = DateDeserializer.class)
	private Date horaSaida;

	@Column(length=200)
	private String logradouro;

	@Column(nullable=false, length=150)
	private String nome;

	@Size(min=5)
	@Column(columnDefinition="TEXT")
	private String qualificacoes;

	@Column(length=2)
	private String uf;
	
	@Temporal(TemporalType.DATE)
	@Column(name="status_date")
	private Calendar statusDate;
	
	@Column(length=255, name="status_detail")
	private String statusDetail;
	
	@Column(name = "status")
	private StatusFuncionario status;
	
	@Transient
	private Calendar atualizacaoCadastral;

	@ManyToOne
	@JoinColumn(name="cargo", nullable=false)
	private CargoFuncionario cargoFuncionario;
	
	@JsonIgnore
	//bi-directional many-to-one association to Coordenacao
	@ManyToOne
	@JoinColumn(name="coordenacao")
	private Coordenacao coordenacao;

	@JsonIgnore
	//bi-directional many-to-one association to Certificacao
	@OneToMany(mappedBy="funcionario")
	private Set<Certificacao> certificacaos;

	@JsonIgnore
	//bi-directional many-to-one association to Curso
	@OneToMany(mappedBy="funcionario")
	private Set<Curso> cursos;

	@JsonIgnore
	//bi-directional many-to-one association to ExperienciaProfissional
	@OneToMany(mappedBy="funcionario")
	private Set<ExperienciaProfissional> experienciaProfissionals;

	@JsonIgnore
	//bi-directional many-to-one association to FormacaoAcademica
	@OneToMany(mappedBy="funcionario")
	private Set<FormacaoAcademica> formacaoAcademicas;
	
	@JsonIgnore
	//bi-directional many-to-one association to Coordenacao
	@OneToMany(mappedBy="coordenador")
	private Set<Coordenacao> coordenacoes;

	@JsonIgnore
	//bi-directional many-to-one association to FuncionarioTelefone
	@OneToMany(mappedBy="funcionario")
	private Set<FuncionarioTelefone> funcionarioTelefones;

	@JsonIgnore
	//bi-directional many-to-one association to TurmaFuncionario
	@OneToMany(mappedBy="funcionario")
	private Set<TurmaFuncionario> turmaFuncionarios;

	@JsonIgnore
	//bi-directional many-to-one association to TurmaFuncionario
	@OneToMany(mappedBy="autorizador")
	private Set<TurmaFuncionario> turmaAutorizadores;

	@JsonIgnore
	//bi-directional many-to-one association to TurmaFuncionario
	@OneToMany(mappedBy="confirmador")
	private Set<TurmaFuncionario> turmaConfirmadores;

	@JsonIgnore
	//bi-directional many-to-one association to TurmaQuestaoResposta
	@OneToMany(mappedBy="funcionario")
	private Set<TurmaQuestaoResposta> turmaQuestaoRespostas;

	@JsonIgnore
	//bi-directional many-to-one association to Notificacao
	@OneToMany(mappedBy="funcionario")
	private Set<Notificacao> notificacaos;

	@JsonIgnore
	//bi-directional many-to-one association to RatingAtividade
	@OneToMany(mappedBy="funcionario")
	private Set<RatingAtividade> ratingAtividades;

	@JsonIgnore
	//bi-directional many-to-one association to Timeline
	@OneToMany(mappedBy="funcionario")
	private Set<Timeline> timelines;

	@JsonIgnore
	//bi-directional many-to-one association to AtivoFuncionario
	@OneToMany(mappedBy="funcionario")
	private Set<AtivoFuncionario> ativoFuncionarios;
	
	@JsonIgnore
	//bi-directional many-to-one association to QuestionarioFuncionario
	@OneToMany(mappedBy="funcionario")
	private Set<QuestionarioFuncionario> questionarioFuncionarios;
	
	@JsonIgnore
	//bi-directional many-to-one association to AtividadeFuncionario
	@OneToMany(mappedBy="funcionario")
	private Set<AtividadeFuncionario> atividadeFuncionarios;

	public Funcionario() {
	}

	public String getMatricula() {
		return this.matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getAnotacoes() {
		return this.anotacoes;
	}

	public void setAnotacoes(String anotacoes) {
		this.anotacoes = anotacoes;
	}

	public Integer getCep() {
		return this.cep;
	}

	public void setCep(Integer cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return this.cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public Calendar getDataAdmissao() {
		return this.dataAdmissao;
	}

	public void setDataAdmissao(Calendar dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	public Calendar getDataCedes() {
		return this.dataCedes;
	}

	public void setDataCedes(Calendar dataCedes) {
		this.dataCedes = dataCedes;
	}

	public String getDepto() {
		return this.depto;
	}

	public void setDepto(String depto) {
		this.depto = depto;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmpresa() {
		return this.empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getFoto() {
		return this.foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public Date getHoraEntrada() {
		return this.horaEntrada;
	}

	public void setHoraEntrada(Date horaEntrada) {
		this.horaEntrada = horaEntrada;
	}

	public Date getHoraSaida() {
		return this.horaSaida;
	}

	public void setHoraSaida(Date horaSaida) {
		this.horaSaida = horaSaida;
	}

	public String getLogradouro() {
		return this.logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getQualificacoes() {
		return this.qualificacoes;
	}

	public void setQualificacoes(String qualificacoes) {
		this.qualificacoes = qualificacoes;
	}

	public String getUf() {
		return this.uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	@JsonIgnore
	public Set<Certificacao> getCertificacaos() {
		return this.certificacaos;
	}

	@JsonProperty
	public void setCertificacaos(Set<Certificacao> certificacaos) {
		this.certificacaos = certificacaos;
	}

	public Certificacao addCertificacao(Certificacao certificacao) {
		getCertificacaos().add(certificacao);
		certificacao.setFuncionario(this);

		return certificacao;
	}

	public Certificacao removeCertificacao(Certificacao certificacao) {
		getCertificacaos().remove(certificacao);
		certificacao.setFuncionario(null);

		return certificacao;
	}

	@JsonIgnore
	public Set<Coordenacao> getCoordenacoes() {
		return this.coordenacoes;
	}

	@JsonProperty
	public void setCoordenacoes(Set<Coordenacao> coordenacoes) {
		this.coordenacoes = coordenacoes;
	}

	public Coordenacao addCoordenacao(Coordenacao coordenacao) {
		getCoordenacoes().add(coordenacao);
		coordenacao.setCoordenador(this);

		return coordenacao;
	}

	public Coordenacao removeCoordenacao(Coordenacao coordenacao) {
		getCoordenacoes().remove(coordenacao);
		coordenacao.setCoordenador(null);

		return coordenacao;
	}

	@JsonIgnore
	public Set<Curso> getCursos() {
		return this.cursos;
	}

	@JsonProperty
	public void setCursos(Set<Curso> cursos) {
		this.cursos = cursos;
	}

	public Curso addCurso(Curso curso) {
		getCursos().add(curso);
		curso.setFuncionario(this);

		return curso;
	}

	public Curso removeCurso(Curso curso) {
		getCursos().remove(curso);
		curso.setFuncionario(null);

		return curso;
	}

	@JsonIgnore
	public Set<ExperienciaProfissional> getExperienciaProfissionals() {
		return this.experienciaProfissionals;
	}

	@JsonProperty
	public void setExperienciaProfissionals(Set<ExperienciaProfissional> experienciaProfissionals) {
		this.experienciaProfissionals = experienciaProfissionals;
	}

	public ExperienciaProfissional addExperienciaProfissional(ExperienciaProfissional experienciaProfissional) {
		getExperienciaProfissionals().add(experienciaProfissional);
		experienciaProfissional.setFuncionario(this);

		return experienciaProfissional;
	}

	public ExperienciaProfissional removeExperienciaProfissional(ExperienciaProfissional experienciaProfissional) {
		getExperienciaProfissionals().remove(experienciaProfissional);
		experienciaProfissional.setFuncionario(null);

		return experienciaProfissional;
	}

	@JsonIgnore
	public Set<FormacaoAcademica> getFormacaoAcademicas() {
		return this.formacaoAcademicas;
	}

	@JsonProperty
	public void setFormacaoAcademicas(Set<FormacaoAcademica> formacaoAcademicas) {
		this.formacaoAcademicas = formacaoAcademicas;
	}

	public FormacaoAcademica addFormacaoAcademica(FormacaoAcademica formacaoAcademica) {
		getFormacaoAcademicas().add(formacaoAcademica);
		formacaoAcademica.setFuncionario(this);

		return formacaoAcademica;
	}

	public FormacaoAcademica removeFormacaoAcademica(FormacaoAcademica formacaoAcademica) {
		getFormacaoAcademicas().remove(formacaoAcademica);
		formacaoAcademica.setFuncionario(null);

		return formacaoAcademica;
	}

	public Coordenacao getCoordenacao() {
		return this.coordenacao;
	}

	public void setCoordenacao(Coordenacao coordenacao) {
		this.coordenacao = coordenacao;
	}


	public Set<FuncionarioTelefone> getFuncionarioTelefones() {
		return this.funcionarioTelefones;
	}

	public void setFuncionarioTelefones(Set<FuncionarioTelefone> funcionarioTelefones) {
		this.funcionarioTelefones = funcionarioTelefones;
	}

	public FuncionarioTelefone addFuncionarioTelefone(FuncionarioTelefone funcionarioTelefone) {
		getFuncionarioTelefones().add(funcionarioTelefone);
		funcionarioTelefone.setFuncionario(this);
		funcionarioTelefone.getId().setFuncionario(this.matricula);

		return funcionarioTelefone;
	}

	public FuncionarioTelefone removeFuncionarioTelefone(FuncionarioTelefone funcionarioTelefone) {
		getFuncionarioTelefones().remove(funcionarioTelefone);
		funcionarioTelefone.setFuncionario(null);
		funcionarioTelefone.getId().setFuncionario(null);

		return funcionarioTelefone;
	}

	public Set<TurmaFuncionario> getTurmaFuncionarios() {
		return this.turmaFuncionarios;
	}

	public void setTurmaFuncionarios(Set<TurmaFuncionario> turmaFuncionarios) {
		this.turmaFuncionarios = turmaFuncionarios;
	}

	public TurmaFuncionario addTurmaFuncionarios1(TurmaFuncionario turmaFuncionarios) {
		getTurmaFuncionarios().add(turmaFuncionarios);
		turmaFuncionarios.setFuncionario(this);

		return turmaFuncionarios;
	}

	public TurmaFuncionario removeTurmaFuncionarios1(TurmaFuncionario turmaFuncionarios) {
		getTurmaFuncionarios().remove(turmaFuncionarios);
		turmaFuncionarios.setFuncionario(null);

		return turmaFuncionarios;
	}

	public Set<TurmaFuncionario> getTurmaAutorizadores() {
		return this.turmaAutorizadores;
	}

	public void setTurmaAutorizadores(Set<TurmaFuncionario> turmaAutorizadores) {
		this.turmaAutorizadores = turmaAutorizadores;
	}

	public TurmaFuncionario addTurmaAutorizadores(TurmaFuncionario turmaAutorizadores) {
		getTurmaAutorizadores().add(turmaAutorizadores);
		turmaAutorizadores.setAutorizador(this);

		return turmaAutorizadores;
	}

	public TurmaFuncionario removeTurmaAutorizadores(TurmaFuncionario turmaAutorizadores) {
		getTurmaAutorizadores().remove(turmaAutorizadores);
		turmaAutorizadores.setAutorizador(null);

		return turmaAutorizadores;
	}
	
	public Set<TurmaFuncionario> getTurmaConfirmadores() {
		return this.turmaConfirmadores;
	}

	public void setTurmaConfirmadores(Set<TurmaFuncionario> turmaConfirmadores) {
		this.turmaConfirmadores = turmaConfirmadores;
	}

	public TurmaFuncionario addTurmaConfirmadores(TurmaFuncionario turmaConfirmadores) {
		getTurmaConfirmadores().add(turmaConfirmadores);
		turmaConfirmadores.setConfirmador(this);

		return turmaConfirmadores;
	}

	public TurmaFuncionario removeTurmaConfirmadores(TurmaFuncionario turmaConfirmadores) {
		getTurmaConfirmadores().remove(turmaConfirmadores);
		turmaConfirmadores.setConfirmador(null);

		return turmaConfirmadores;
	}

	public Set<TurmaQuestaoResposta> getTurmaQuestaoRespostas() {
		return this.turmaQuestaoRespostas;
	}

	public void setTurmaQuestaoRespostas(Set<TurmaQuestaoResposta> turmaQuestaoRespostas) {
		this.turmaQuestaoRespostas = turmaQuestaoRespostas;
	}

	public TurmaQuestaoResposta addTurmaQuestaoResposta(TurmaQuestaoResposta turmaQuestaoResposta) {
		getTurmaQuestaoRespostas().add(turmaQuestaoResposta);
		turmaQuestaoResposta.setFuncionario(this);

		return turmaQuestaoResposta;
	}

	public TurmaQuestaoResposta removeTurmaQuestaoResposta(TurmaQuestaoResposta turmaQuestaoResposta) {
		getTurmaQuestaoRespostas().remove(turmaQuestaoResposta);
		turmaQuestaoResposta.setFuncionario(null);

		return turmaQuestaoResposta;
	}

	public Set<Notificacao> getNotificacaos() {
		return this.notificacaos;
	}

	public void setNotificacaos(Set<Notificacao> notificacaos) {
		this.notificacaos = notificacaos;
	}

	public Notificacao addNotificacao(Notificacao notificacao) {
		getNotificacaos().add(notificacao);
		notificacao.setFuncionario(this);

		return notificacao;
	}

	public Notificacao removeNotificacao(Notificacao notificacao) {
		getNotificacaos().remove(notificacao);
		notificacao.setFuncionario(null);

		return notificacao;
	}

	public Set<RatingAtividade> getRatingAtividades() {
		return this.ratingAtividades;
	}

	public void setRatingAtividades(Set<RatingAtividade> ratingAtividades) {
		this.ratingAtividades = ratingAtividades;
	}

	public RatingAtividade addRatingAtividade(RatingAtividade ratingAtividade) {
		getRatingAtividades().add(ratingAtividade);
		ratingAtividade.setFuncionario(this);

		return ratingAtividade;
	}

	public RatingAtividade removeRatingAtividade(RatingAtividade ratingAtividade) {
		getRatingAtividades().remove(ratingAtividade);
		ratingAtividade.setFuncionario(null);

		return ratingAtividade;
	}

	public Set<Timeline> getTimelines() {
		return this.timelines;
	}

	public void setTimelines(Set<Timeline> timelines) {
		this.timelines = timelines;
	}

	public Timeline addTimeline(Timeline timeline) {
		getTimelines().add(timeline);
		timeline.setFuncionario(this);

		return timeline;
	}

	public Timeline removeTimeline(Timeline timeline) {
		getTimelines().remove(timeline);
		timeline.setFuncionario(null);

		return timeline;
	}

	public Calendar getAtualizacaoCadastral() {
		return atualizacaoCadastral;
	}

	public void setAtualizacaoCadastral(Calendar atualizacaoCadastral) {
		this.atualizacaoCadastral = atualizacaoCadastral;
	}

	public Set<AtivoFuncionario> getAtivoFuncionarios() {
		return this.ativoFuncionarios;
	}

	public void setAtivoFuncionarios(Set<AtivoFuncionario> ativoFuncionarios) {
		this.ativoFuncionarios = ativoFuncionarios;
	}

	public AtivoFuncionario addAtivoFuncionario(AtivoFuncionario ativoFuncionario) {
		getAtivoFuncionarios().add(ativoFuncionario);
		ativoFuncionario.setFuncionario(this);

		return ativoFuncionario;
	}

	public AtivoFuncionario removeAtivoFuncionario(AtivoFuncionario ativoFuncionario) {
		getAtivoFuncionarios().remove(ativoFuncionario);
		ativoFuncionario.setFuncionario(null);

		return ativoFuncionario;
	}

	public CargoFuncionario getCargoFuncionario() {
		return this.cargoFuncionario;
	}

	public void setCargoFuncionario(CargoFuncionario cargoFuncionario) {
		this.cargoFuncionario = cargoFuncionario;
	}
	
	public Set<QuestionarioFuncionario> getQuestionarioFuncionarios() {
		return this.questionarioFuncionarios;
	}

	public void setQuestionarioFuncionarios(Set<QuestionarioFuncionario> questionarioFuncionarios) {
		this.questionarioFuncionarios = questionarioFuncionarios;
	}

	public QuestionarioFuncionario addQuestionarioFuncionario(QuestionarioFuncionario questionarioFuncionario) {
		getQuestionarioFuncionarios().add(questionarioFuncionario);
		questionarioFuncionario.setFuncionario(this);

		return questionarioFuncionario;
	}

	public QuestionarioFuncionario removeQuestionarioFuncionario(QuestionarioFuncionario questionarioFuncionario) {
		getQuestionarioFuncionarios().remove(questionarioFuncionario);
		questionarioFuncionario.setFuncionario(null);

		return questionarioFuncionario;
	}
	
	public Set<AtividadeFuncionario> getAtividadeFuncionarios() {
		return this.atividadeFuncionarios;
	}

	public void setAtividadeFuncionarios(Set<AtividadeFuncionario> atividadeFuncionarios) {
		this.atividadeFuncionarios = atividadeFuncionarios;
	}

	public AtividadeFuncionario addAtividadeFuncionario(AtividadeFuncionario atividadeFuncionario) {
		getAtividadeFuncionarios().add(atividadeFuncionario);
		atividadeFuncionario.setFuncionario(this);

		return atividadeFuncionario;
	}

	public AtividadeFuncionario removeAtividadeFuncionario(AtividadeFuncionario atividadeFuncionario) {
		getAtividadeFuncionarios().remove(atividadeFuncionario);
		atividadeFuncionario.setFuncionario(null);

		return atividadeFuncionario;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((anotacoes == null) ? 0 : anotacoes.hashCode());
		result = prime * result + ((cargoFuncionario == null) ? 0 : cargoFuncionario.hashCode());
		result = prime * result + ((cep == null) ? 0 : cep.hashCode());
		result = prime * result + ((cidade == null) ? 0 : cidade.hashCode());
		result = prime * result + ((dataAdmissao == null) ? 0 : dataAdmissao.hashCode());
		result = prime * result + ((dataCedes == null) ? 0 : dataCedes.hashCode());
		result = prime * result + ((depto == null) ? 0 : depto.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((empresa == null) ? 0 : empresa.hashCode());
		result = prime * result + ((foto == null) ? 0 : foto.hashCode());
		result = prime * result + ((horaEntrada == null) ? 0 : horaEntrada.hashCode());
		result = prime * result + ((horaSaida == null) ? 0 : horaSaida.hashCode());
		result = prime * result + ((logradouro == null) ? 0 : logradouro.hashCode());
		result = prime * result + ((matricula == null) ? 0 : matricula.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((qualificacoes == null) ? 0 : qualificacoes.hashCode());
		result = prime * result + ((uf == null) ? 0 : uf.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Funcionario other = (Funcionario) obj;
		if (anotacoes == null) {
			if (other.anotacoes != null)
				return false;
		} else if (!anotacoes.equals(other.anotacoes))
			return false;
		if (cargoFuncionario == null) {
			if (other.cargoFuncionario != null)
				return false;
		} else if (!cargoFuncionario.equals(other.cargoFuncionario))
			return false;
		if (cep == null) {
			if (other.cep != null)
				return false;
		} else if (!cep.equals(other.cep))
			return false;
		if (cidade == null) {
			if (other.cidade != null)
				return false;
		} else if (!cidade.equals(other.cidade))
			return false;
		if (dataAdmissao == null) {
			if (other.dataAdmissao != null)
				return false;
		} else if (!dataAdmissao.equals(other.dataAdmissao))
			return false;
		if (dataCedes == null) {
			if (other.dataCedes != null)
				return false;
		} else if (!dataCedes.equals(other.dataCedes))
			return false;
		if (depto == null) {
			if (other.depto != null)
				return false;
		} else if (!depto.equals(other.depto))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (empresa == null) {
			if (other.empresa != null)
				return false;
		} else if (!empresa.equals(other.empresa))
			return false;
		if (foto == null) {
			if (other.foto != null)
				return false;
		} else if (!foto.equals(other.foto))
			return false;
		if (horaEntrada == null) {
			if (other.horaEntrada != null)
				return false;
		} else if (!horaEntrada.equals(other.horaEntrada))
			return false;
		if (horaSaida == null) {
			if (other.horaSaida != null)
				return false;
		} else if (!horaSaida.equals(other.horaSaida))
			return false;
		if (logradouro == null) {
			if (other.logradouro != null)
				return false;
		} else if (!logradouro.equals(other.logradouro))
			return false;
		if (matricula == null) {
			if (other.matricula != null)
				return false;
		} else if (!matricula.equals(other.matricula))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (qualificacoes == null) {
			if (other.qualificacoes != null)
				return false;
		} else if (!qualificacoes.equals(other.qualificacoes))
			return false;
		if (uf == null) {
			if (other.uf != null)
				return false;
		} else if (!uf.equals(other.uf))
			return false;
		return true;
	}

	@JsonIgnore
	@Override
	public String getId() {
		return this.matricula;
	}

	@Override
	public boolean isTheSameObject(IEntity<String> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		Funcionario other = (Funcionario) object;
		if (matricula == null) {
			if (other.matricula != null)
				return false;
		} else if (!matricula.equals(other.matricula))
			return false;
		return true;
	}

	public Calendar getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(Calendar statusDate) {
		this.statusDate = statusDate;
	}

	public StatusFuncionario getStatus() {
		return status;
	}

	public void setStatus(StatusFuncionario status) {
		this.status = status;
	}

	public String getStatusDetail() {
		return statusDetail;
	}

	public void setStatusDetail(String statusDetail) {
		this.statusDetail = statusDetail;
	}
}
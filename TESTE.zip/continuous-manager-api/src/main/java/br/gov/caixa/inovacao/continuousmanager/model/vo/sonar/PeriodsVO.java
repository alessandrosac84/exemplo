package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;

/**
 * 
 * @author Alessandro Carvalho
 * 
 */
public class PeriodsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3025358593966411034L;
	
	/**
	 * 
	 */
	private Integer index;
	
	/**
	 * 
	 */
	private String value;

	/**
	 * @return the index
	 */
	public Integer getIndex() {
		return index;
	}

	/**
	 * @param index the index to set
	 */
	public void setIndex(Integer index) {
		this.index = index;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}



}

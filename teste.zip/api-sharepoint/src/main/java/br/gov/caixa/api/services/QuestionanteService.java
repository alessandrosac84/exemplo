package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.QuestionanteDto;
import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.Questionante;
import br.gov.caixa.api.model.Questionario;
import br.gov.caixa.api.repository.QuestionanteRepository;
import br.gov.caixa.api.result.QuestionanteResult;

@Named
public class QuestionanteService {
	
	@Inject
	QuestionanteRepository repository;
	
	public QuestionanteResult saveList(List<QuestionanteDto> dtoList){
		
		QuestionanteResult result = new QuestionanteResult();
		List<Questionante> questionantes = Questionante.fromDtoToListQuestionante(dtoList);
		
		repository.save(questionantes);
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public QuestionanteResult save(QuestionanteDto dto){
		QuestionanteResult result = new QuestionanteResult();
		Questionante questionante = Questionante.fromDtoToQuestionante(dto);
		repository.save(questionante);
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public QuestionanteResult delete(Long id){
		QuestionanteResult result = new QuestionanteResult();
		repository.delete(id);
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public QuestionanteResult getOne(Long id){
		QuestionanteResult result = new QuestionanteResult();
		Questionante questionante = repository.findOne(id);
		result.setQuestionante(QuestionanteDto.fromQuestionanteToDto(questionante));
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public QuestionanteResult getAll(){
		QuestionanteResult result = new QuestionanteResult();
		List<Questionante> questionantes = repository.findAll();
		result.setList(QuestionanteDto.fromQuestionanteToListDto(questionantes));
		result.setMessage("Executado com sucesso.");
		return result;
	}	

	public QuestionanteResult getByFuncionario(Long id) {
		QuestionanteResult result = new QuestionanteResult();
		Funcionario funcionario = new Funcionario();
		funcionario.setUid(id);
		
		List<Questionante> questionantes = repository.findByFuncionario(funcionario);
		
		result.setList(QuestionanteDto.fromQuestionanteToListDto(questionantes));
		result.setMessage("Executado com sucesso.");
		return result;
	}

		
	public QuestionanteResult getByQuestionario(Long id){
		
		QuestionanteResult result = new QuestionanteResult();
		Questionario questionario  = new Questionario();
		questionario.setUid(id);
		
		List<Questionante> questionantes = repository.findByQuestionario(questionario);
		result.setList(QuestionanteDto.fromQuestionanteToListDto(questionantes));
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
}

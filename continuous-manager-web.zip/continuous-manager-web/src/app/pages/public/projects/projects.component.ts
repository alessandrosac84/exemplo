import { Component, OnInit } from '@angular/core';
import { Project } from '../../../shared/model/entity/project.model';
import { WalletService } from '../../../shared/service/wallet.service';
import { Observable } from '../../../../../node_modules/rxjs';

@Component({
  selector: 'cm-projects',
  templateUrl: './projects.component.html',
  styles: []
})
export class ProjectsComponent implements OnInit {
  projects$: Observable<Project[]>;

  constructor(private _walletService: WalletService) {}

  ngOnInit() {
    this.projects$ = this._walletService.getProjects();
  }
}

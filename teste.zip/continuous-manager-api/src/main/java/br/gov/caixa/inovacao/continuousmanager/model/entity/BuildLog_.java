package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-02-15T14:03:13.287-0200")
@StaticMetamodel(BuildLog.class)
public class BuildLog_ {
	public static volatile SingularAttribute<BuildLog, BuildLogPK> id;
	public static volatile SingularAttribute<BuildLog, String> log;
	public static volatile SingularAttribute<BuildLog, Build> build;
}

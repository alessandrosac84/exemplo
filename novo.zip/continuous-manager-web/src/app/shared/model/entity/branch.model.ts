import { Build } from './build.model';

export class Branch {
  id: { id: string };
  buildCount: number;
  lastBuild: Build;
}

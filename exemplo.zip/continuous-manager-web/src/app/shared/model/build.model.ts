import { Action } from './action.model';

export class Build {
  public description: string;
  public duration: number;
  public estimatedDuration: number;
  public number: number;
  public result: string;
  public timestamp: Date;
  public actions: Action[];
}

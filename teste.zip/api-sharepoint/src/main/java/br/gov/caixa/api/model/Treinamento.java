package br.gov.caixa.api.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.gov.caixa.api.dto.TreinamentoDto;

@Entity
@Table(name = "treinamento")
public class Treinamento {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "NOME")
	private String nome;
	
	@Column(name = "CODIGO")
	private String codigo;
	
	@Column(name = "DESCRICAO", length=5000)
	private String descricao;
	
	@Column(name = "TIPO_TREINAMENTO", columnDefinition = "int default 0")
	private TipoTreinamento tipoTreinamento;		

	@Enumerated(EnumType.ORDINAL) 
	private TipoTreinamento TipoTreinamento() { 
	    return tipoTreinamento; 
	}	
	
	public TipoTreinamento getTipoTreinamento() {
		return tipoTreinamento;
	}
	
	public void setTipoTreinamento(TipoTreinamento tipoTreinamento) {
		this.tipoTreinamento = tipoTreinamento;
	}
	
	@Column(name = "INICIATIVA_TREINAMENTO", columnDefinition = "int default 0")
	private IniciativaTreinamento iniciativaTreinamento;		

	@Enumerated(EnumType.ORDINAL) 
	private IniciativaTreinamento IniciativaTreinamento() { 
	    return iniciativaTreinamento; 
	}	
	
	public IniciativaTreinamento getIniciativaTreinamento() {
		return iniciativaTreinamento;
	}

	public void setIniciativaTreinamento(IniciativaTreinamento iniciativaTreinamento) {
		this.iniciativaTreinamento = iniciativaTreinamento;
	}

	@ManyToOne(optional = true, fetch=FetchType.EAGER) 
    @JoinColumn(name="FERRAMENTA_ID", nullable = true) 
    private Ferramenta ferramenta;

	@ManyToOne(optional = true, fetch=FetchType.EAGER) 
    @JoinColumn(name="ATIVIDADE_ID", nullable = true) 
    private Atividade atividade;
	
	@ManyToOne(optional = true, fetch=FetchType.EAGER) 
    @JoinColumn(name="PROCESSO_ID", nullable = true) 
    private Processo processo;
	
	@JoinColumn(name="AUTO_INSCRICAO", nullable = true)
	private Boolean autoInscricao;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public Ferramenta getFerramenta() {
		return ferramenta;
	}

	public void setFerramenta(Ferramenta ferramenta) {
		this.ferramenta = ferramenta;
	}
	
	public Atividade getAtividade() {
		return atividade;
	}

	public void setAtividade(Atividade atividade) {
		this.atividade = atividade;
	}
	
	public Processo getProcesso() {
		return processo;
	}

	public void setProcesso(Processo processo) {
		this.processo = processo;
	}	

	public Boolean getAutoInscricao() {
		return autoInscricao;
	}

	public void setAutoInscricao(Boolean autoInscricao) {
		this.autoInscricao = autoInscricao;
	}
	

	public static Treinamento fromDtoToTreinamento(TreinamentoDto dto) {
		Treinamento treinamento = new Treinamento();
		
		treinamento.setUid(dto.getUid());
		treinamento.setTipoTreinamento(dto.getTipoTreinamento());
		treinamento.setIniciativaTreinamento(dto.getIniciativaTreinamento());
		treinamento.setNome(dto.getNome());
		treinamento.setCodigo(dto.getCodigo());
		treinamento.setDescricao(dto.getDescricao());
		treinamento.setAutoInscricao(dto.getAutoInscricao());
		
		if(dto.getAtividadeDto() != null){
			treinamento.setAtividade(Atividade.fromDtoToAtividade(dto.getAtividadeDto()));
		}
		
		if(dto.getFerramentaDto() != null){
			treinamento.setFerramenta(Ferramenta.fromDtoToFerramenta(dto.getFerramentaDto()));
		}
		
		if(dto.getProcessoDto() != null){
			treinamento.setProcesso(Processo.fromDtoToProcesso(dto.getProcessoDto()));
		}
		return treinamento;
	}
}
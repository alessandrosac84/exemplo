/**
 * DE_TIPOType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package SIAPP_WS_DistinctItemPortfolio;

public class DE_TIPOType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected DE_TIPOType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _value1 = "PN - Projeto Novo";
    public static final java.lang.String _value2 = "PE - Projeto Evolutivo";
    public static final java.lang.String _value3 = "MA - Manutencao";
    public static final java.lang.String _value4 = "PM - Projeto de Migracao";
    public static final java.lang.String _value5 = "PD - Projeto de Documentacao";
    public static final DE_TIPOType value1 = new DE_TIPOType(_value1);
    public static final DE_TIPOType value2 = new DE_TIPOType(_value2);
    public static final DE_TIPOType value3 = new DE_TIPOType(_value3);
    public static final DE_TIPOType value4 = new DE_TIPOType(_value4);
    public static final DE_TIPOType value5 = new DE_TIPOType(_value5);
    public java.lang.String getValue() { return _value_;}
    public static DE_TIPOType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        DE_TIPOType enumeration = (DE_TIPOType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static DE_TIPOType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DE_TIPOType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:SIAPP_WS_DistinctItemPortfolio", "DE_TIPOType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}

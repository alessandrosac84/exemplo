package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;

/**
 * Classe de servicos de ReBuild.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class RebuildService {

	@Inject
	private Logger log;
	
	@Inject
	private JenkinsService jenkinsService;
	
	public void rebuild(String wallet, String project, String job, Integer build, String commit) {
		log.fine("Iniciando Rebuild");
		jenkinsService.createBuild(wallet, project, job, commit);
	}
}

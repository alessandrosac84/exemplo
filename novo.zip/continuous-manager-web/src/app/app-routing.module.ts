import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: './pages/public/home/home.module#HomeModule',
    pathMatch: 'full'
  },
  {
    path: 'projects',
    loadChildren: './pages/private/projects/projects.module#ProjectsModule',
    data: { preload: true, state: 'projects' }
  },
  {
    path: 'dashboard',
    loadChildren: './pages/private/dashboard/dashboard.module#DashboardModule',
    data: { state: 'dashboard' }
  },
  {
    path: 'info',
    loadChildren: './pages/public/info/info.module#InfoModule',
    data: { state: 'info' }
  },
  {
    path: 'builds',
    loadChildren: './pages/private/builds/builds.module#BuildsModule',
    data: { state: 'builds' }
  },
  {
    path: 'stage',
    loadChildren: './pages/private/stage/stage.module#StageModule',
    data: { state: 'stage' }
  },
  {
    path: 'admin',
    loadChildren: './pages/private/admin/admin.module#AdminModule',
    data: { state: 'admin' }
  },
  {
    path: 'user',
    loadChildren: './pages/private/user/user.module#UserModule',
    data: { state: 'user' }
  },
  { path: '**', redirectTo: '/projects' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { enableTracing: true })],
  exports: [RouterModule]
})
export class AppRoutingModule {}

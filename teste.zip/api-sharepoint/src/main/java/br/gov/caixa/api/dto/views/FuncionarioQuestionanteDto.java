package br.gov.caixa.api.dto.views;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.views.FuncionarioQuestionante;

public class FuncionarioQuestionanteDto {

	private Long uid;	
	private String nome;
	private String email;
	private String matricula;	
	private String cargo;	
	private Long questionanteId;	
	private Boolean participacao;	
	private Long questionarioId;	
	private String questao;
	
	public Long getUid() {
		return uid;
	}


	public void setUid(Long uid) {
		this.uid = uid;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getMatricula() {
		return matricula;
	}


	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}


	public String getCargo() {
		return cargo;
	}


	public void setCargo(String cargo) {
		this.cargo = cargo;
	}


	public Long getQuestionanteId() {
		return questionanteId;
	}


	public void setQuestionanteId(Long questionanteId) {
		this.questionanteId = questionanteId;
	}


	public Boolean isParticipacao() {
		return participacao;
	}


	public void setParticipacao(Boolean participacao) {
		this.participacao = participacao;
	}


	public Long getQuestionarioId() {
		return questionarioId;
	}


	public void setQuestionarioId(Long questionarioId) {
		this.questionarioId = questionarioId;
	}


	public String getQuestao() {
		return questao;
	}


	public void setQuestao(String questao) {
		this.questao = questao;
	}

	
	public static FuncionarioQuestionanteDto fromFuncionarioQuestionanteToDto(FuncionarioQuestionante funcionarioQuestionante) {
		FuncionarioQuestionanteDto dto = new FuncionarioQuestionanteDto();
		
		dto.setUid(funcionarioQuestionante.getUid());		
		dto.setNome(funcionarioQuestionante.getNome());
		dto.setEmail(funcionarioQuestionante.getEmail());
		dto.setMatricula(funcionarioQuestionante.getMatricula());
		dto.setCargo(funcionarioQuestionante.getCargo());	
		dto.setQuestionanteId(funcionarioQuestionante.getQuestionanteId());
		dto.setParticipacao(funcionarioQuestionante.isParticipacao());
		dto.setQuestionarioId(funcionarioQuestionante.getQuestionarioId());
		dto.setQuestao(funcionarioQuestionante.getQuestao());
		
		return dto;
	}

	public static List<FuncionarioQuestionanteDto> fromFuncionarioQuestionanteToListDto(List<FuncionarioQuestionante> funcionariosQuestionantes) {		
		List<FuncionarioQuestionanteDto> result = new ArrayList<FuncionarioQuestionanteDto>();		
		
		for (FuncionarioQuestionante funcionarioQuestionante : funcionariosQuestionantes) {						
			result.add(fromFuncionarioQuestionanteToDto(funcionarioQuestionante));
		}
		
		return result;
	}


}

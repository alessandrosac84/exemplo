import { Commit } from './commit.model';
import { Build } from './build.model';

export class ChangeSet {
    public id: { project: string, wallet: string, job: string, build: number, commit: string };
    public commit: Commit;
    public build: Build;
}

import { Build } from './build.model';
import { Project } from './project.model';
import { TypeRepository } from '../vo/typeRepository.model';

export class Repository {
  id: { id: string };
  name: string;
  repoGit: string;
  lastBuild: Build;
  project: Project;
  typeRepository: TypeRepository;
}

import { Job } from './job.model';

export class Project {
  id: { id: string; wallet: string };
  name: string;
  type: string;
  gitRepo: string;
  havings: number;
  jobs: Job[];
}

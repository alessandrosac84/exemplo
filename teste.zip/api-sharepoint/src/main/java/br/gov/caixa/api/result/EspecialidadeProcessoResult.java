package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.EspecialidadeProcessoDto;

public class EspecialidadeProcessoResult extends BasicResult {
	private List<EspecialidadeProcessoDto> list;
	private EspecialidadeProcessoDto especialidadeProcesso;

	public List<EspecialidadeProcessoDto> getList() {
		return list;
	}

	public void setList(List<EspecialidadeProcessoDto> list) {
		this.list = list;
	}

	public EspecialidadeProcessoDto getEspecialidadeProcesso() {
		return especialidadeProcesso;
	}

	public void setEspecialidadeProcesso(EspecialidadeProcessoDto especialidadeProcesso) {
		this.especialidadeProcesso = especialidadeProcesso;
	}
}
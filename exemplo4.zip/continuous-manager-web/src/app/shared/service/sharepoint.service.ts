import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment } from '@env/environment';

import { Observable } from 'rxjs';

import { CaixaEmployee } from 'src/app/shared/model/vo/sharepoint/caixa-employee.model';

@Injectable({
  providedIn: 'root'
})
export class SharepointService {

  private employeeUrl = `${environment.apis.sharepoint}/api/funcionario`;

  constructor(private http: HttpClient) { }

  getMembers(filter: string): Observable<CaixaEmployee[]> {
    return this.http.get<CaixaEmployee[]>(`${this.employeeUrl}?filter=${filter}`);
  }
}

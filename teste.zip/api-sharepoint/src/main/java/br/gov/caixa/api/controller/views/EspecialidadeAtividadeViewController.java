package br.gov.caixa.api.controller.views;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.result.views.EspecialidadeAtividadeViewResult;
import br.gov.caixa.api.services.views.EspecialidadeAtividadeViewService;

@RestController
public class EspecialidadeAtividadeViewController {

	@Inject
	EspecialidadeAtividadeViewService service;

	@RequestMapping(value = "/api/especialidadeAtividadeView/all", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)	
	public EspecialidadeAtividadeViewResult listAll() {
		return service.listAll();
	}
	
	@RequestMapping(value="/api/especialidadeAtividadeView/obterEspecialidadeAtividadeViewPorIdEspecialidade/{idEspecialidade}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeAtividadeViewResult obterAtivoPorIdEspecialidade(@PathVariable Long idEspecialidade) {
		
		return service.listEspecialidadeAtividadeViewsByIdEspecialidade(idEspecialidade);
	}


}

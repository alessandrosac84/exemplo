import { Component, OnInit, Input } from '@angular/core';

import { KeycloakService } from '../../core/keycloak/keycloak.service';
import { EventItem } from '../../core/keycloak/keycloak-event';

import { MatDialog, MatDialogConfig } from '@angular/material';
import { NotificationDialogComponent } from './notification-dialog/notification-dialog.component';
import { NotificationService } from '../../shared/service/notification.service';

import { Notification } from '../../shared/model/entity/notification.model';

@Component({
  selector: 'cm-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  logged = false;
  notifications: Notification[] = [];

  constructor(
    private _keyCloakService: KeycloakService,
    private dialog: MatDialog,
    private _notificationService: NotificationService
  ) {}

  ngOnInit() {
    this._notificationService.getNotifications().subscribe(data => this.notifications = data);
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.data = this.notifications;
    if (dialogConfig.data.length) {
      this.dialog.open(NotificationDialogComponent, dialogConfig);
    }
  }
  login() {
    this._keyCloakService.login();
  }

  logout() {
    this._keyCloakService.logout(window.location.origin + '/log');
  }

  @Input()
  set keycloakEvent(event: EventItem) {
    if (event) {
      this.logged = event.event.args.authenticated;
    }
  }
}

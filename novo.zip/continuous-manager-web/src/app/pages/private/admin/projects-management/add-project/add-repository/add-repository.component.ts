import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { TypeRepository } from '../../../../../../shared/model/vo/typeRepository.model';
import { ProjectManagementService } from '../../../../../../shared/service/project-management.service';
import { Repository } from '../../../../../../shared/model/entity/repository.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';


@Component({
  selector: 'cm-add-repository',
  templateUrl: './add-repository.component.html',
  styleUrls: ['./add-repository.component.scss']
})
export class AddRepositoryComponent implements OnInit {

  typeRepositories: TypeRepository[];
  firstFormGroup: FormGroup;
  repositoryData: Repository;
  typeSelected = new FormControl;
  nameRepository = new FormControl;

  constructor(private _formBuilder: FormBuilder, private _projectManagementService: ProjectManagementService,
              public dialogRef: MatDialogRef<AddRepositoryComponent>) { }

  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this._projectManagementService.getTypeRepository().subscribe(data => this.typeRepositories = data);
    this.repositoryData = new Repository();
  }

  addRepository() {
    this.repositoryData.name = this.nameRepository.value;
    this.repositoryData.typeRepository = new TypeRepository();
    this.repositoryData.typeRepository.name = this.typeSelected.value;

    this.dialogRef.close(this.repositoryData);
  }
}

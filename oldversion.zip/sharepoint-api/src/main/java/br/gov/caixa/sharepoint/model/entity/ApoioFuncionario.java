package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the apoio_funcionario database table.
 * 
 */
@Entity
@Table(name="apoio_funcionario")
@NamedQuery(name="ApoioFuncionario.findAll", query="SELECT a FROM ApoioFuncionario a")
public class ApoioFuncionario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=7)
	private String matricula;

	@Temporal(TemporalType.DATE)
	@Column(name="data_admissao")
	private Calendar dataAdmissao;

	@Temporal(TemporalType.DATE)
	@Column(name="data_cedes")
	private Calendar dataCedes;

	public ApoioFuncionario() {
	}

	public String getMatricula() {
		return this.matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public Calendar getDataAdmissao() {
		return this.dataAdmissao;
	}

	public void setDataAdmissao(Calendar dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	public Calendar getDataCedes() {
		return this.dataCedes;
	}

	public void setDataCedes(Calendar dataCedes) {
		this.dataCedes = dataCedes;
	}

}
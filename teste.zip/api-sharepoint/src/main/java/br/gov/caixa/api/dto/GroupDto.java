//package br.gov.caixa.api.dto;
//
//import java.util.List;
//
//public class GroupDto {
//
//	public GroupDto(){
//		
//	}
//	
//	private String cn;
//	private String name;
//	private String sAMAccountName;
//	private List<PersonDto> persons;
//	
//	public String getCn() {
//		return cn;
//	}
//	public void setCn(String cn) {
//		this.cn = cn;
//	}
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
//	public String getsAMAccountName() {
//		return sAMAccountName;
//	}
//	public void setsAMAccountName(String sAMAccountName) {
//		this.sAMAccountName = sAMAccountName;
//	}
//	public List<PersonDto> getPersons() {
//		return persons;
//	}
//	public void setPersons(List<PersonDto> persons) {
//		this.persons = persons;
//	}
//}
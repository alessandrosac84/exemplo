package br.com.opussolutions.model.entity;

public class Cliente {

}

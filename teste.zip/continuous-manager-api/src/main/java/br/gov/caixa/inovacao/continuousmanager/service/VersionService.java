package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;

/**
 * Classe de servicos de Version.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class VersionService {

	@Inject
	private Logger log;
	
	@Inject
	private JenkinsService jenkinsService;
	
	public void version(String wallet, String project, String job, String commit, String version) {
		log.fine("Iniciando Versionamento");
		String newJob = job.substring(0, job.indexOf("-ci-dev")) + "-cd-tqs";
		jenkinsService.createVersion(wallet, project, newJob, commit, version);
	}
}
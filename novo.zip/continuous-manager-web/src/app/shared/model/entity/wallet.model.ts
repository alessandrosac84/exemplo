import { Project } from './project.model';

export class Wallet {
  public id: string;
  public name: string;
  public createdAt: Date;
  public projects: Project[];
}

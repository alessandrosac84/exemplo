import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MapaAmbienteRoutingModule } from './mapa-ambiente-routing.module';
import { MapaAmbienteComponent } from './mapa-ambiente.component';

@NgModule({
  imports: [
    CommonModule,
    MapaAmbienteRoutingModule
  ],
  declarations: [MapaAmbienteComponent]
})
export class MapaAmbienteModule { }

package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the funcionalidade_cargo database table.
 * 
 */
@Embeddable
public class FuncionalidadeCargoPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=50)
	private String funcionalidade;

	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private Integer cargo;

	public FuncionalidadeCargoPK() {
	}
	public String getFuncionalidade() {
		return this.funcionalidade;
	}
	public void setFuncionalidade(String funcionalidade) {
		this.funcionalidade = funcionalidade;
	}
	public Integer getCargo() {
		return this.cargo;
	}
	public void setCargo(Integer cargo) {
		this.cargo = cargo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof FuncionalidadeCargoPK)) {
			return false;
		}
		FuncionalidadeCargoPK castOther = (FuncionalidadeCargoPK)other;
		return 
			this.funcionalidade.equals(castOther.funcionalidade)
			&& this.cargo.equals(castOther.cargo);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.funcionalidade.hashCode();
		hash = hash * prime + this.cargo.hashCode();
		
		return hash;
	}
}
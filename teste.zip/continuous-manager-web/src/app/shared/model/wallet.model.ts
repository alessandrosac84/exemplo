export class Wallet {
  public id: string;
  public name: string;
  public createdAt: Date;
}

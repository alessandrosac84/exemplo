package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.model.views.AtivosPercentualConhecimentoView;
import br.gov.caixa.api.repository.views.AtivosPercentualConhecimentoViewRepository;
import br.gov.caixa.api.result.views.AtivosPercentualConhecimentoViewResult;

@Named
public class AtivosPercentualConhecimentoViewService {
	
	@Inject
	AtivosPercentualConhecimentoViewRepository  repository;
			
	public AtivosPercentualConhecimentoViewResult listAll() {
		
		AtivosPercentualConhecimentoViewResult result = new AtivosPercentualConhecimentoViewResult();
		
		try {
						
			List<AtivosPercentualConhecimentoView> lista = repository.findAll();				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Resgistro.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

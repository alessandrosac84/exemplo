import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'jmw-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.scss']
})
export class InfoComponent implements OnInit {

  constructor(private _modal: NgbModal) {
  }

  ngOnInit() {
  }

  openVersion(modal) {
    this._modal.open(modal, { centered: true, size: 'lg' }).result.then((result) => {
      // Quando Clicar no Incluir - Close OK
    }, (reason) => {
      // Quando clicar no Fechar ou dar ESC
    });
  }

}

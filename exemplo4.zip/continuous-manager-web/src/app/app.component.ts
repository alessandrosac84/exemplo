import { Component, OnInit } from '@angular/core';

import { EventStackService } from './core/keycloak/event-stack.service';
import { EventItem } from './core/keycloak/keycloak-event';
import { routerTransition } from './app-router.animations';

@Component({
  selector: 'cm-root',
  animations: [routerTransition],
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  keycloakEvent: EventItem;
  opened = false;

  constructor(private _eventStackService: EventStackService) {}

  ngOnInit() {
    this._eventStackService.eventTriggered$.subscribe(eventStack => {
      eventStack.forEach(eventItem => this.keycloakEventTriggered(eventItem));
    });
    this._eventStackService.eventStack.forEach(eventItem =>
      this.keycloakEventTriggered(eventItem)
    );
  }

  getState(outlet) {
    return outlet.activatedRouteData.state;
  }

  resizeNav(opened: boolean) {
    this.opened = opened;
  }

  private keycloakEventTriggered(event: EventItem): void {
    if (this.keycloakEvent) {
      if (
        this.keycloakEvent.event.args.authenticated !==
        event.event.args.authenticated
      ) {
        this.keycloakEvent = event;
      }
    } else {
      this.keycloakEvent = event;
    }
    this._eventStackService.purgeEventItem(event._id);
  }
}

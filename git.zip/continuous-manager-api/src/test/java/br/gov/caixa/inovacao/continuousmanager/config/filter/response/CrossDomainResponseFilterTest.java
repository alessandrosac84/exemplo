/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.filter.response;

import java.io.IOException;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.core.MultivaluedMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * Classe de Teste de CrossDomainResponseFilter
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CrossDomainResponseFilterTest {

	@Mock
	private ContainerRequestContext containerRequestContext;
	@Mock
	private ContainerResponseContext containerResponseContext;

	@InjectMocks
	private CrossDomainResponseFilter crossDomainResponseFilter;
	
	@Mock
	private MultivaluedMap<String, Object> headers;
	
	/**
	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.config.filter.CrossDomainResponseFilter#filter(javax.ws.rs.container.ContainerRequestContext, javax.ws.rs.container.ContainerResponseContext)}.
	 * @throws IOException 
	 */
	@Test
	public void testFilter() throws IOException {
		// Arrange
		Mockito.when(containerResponseContext.getHeaders()).thenReturn(headers);
		
		// Act
		crossDomainResponseFilter.filter(containerRequestContext, containerResponseContext);
	}

}

package br.gov.caixa.api.repository;

import java.util.List;

import javax.persistence.OrderBy;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import br.gov.caixa.api.model.CategoriaTecnologica;
import br.gov.caixa.api.model.Coordenacao;

public interface CategoriaTecnologicaRepository extends JpaRepository<CategoriaTecnologica, Long>  {
	
	@OrderBy("uid")
	public List<CategoriaTecnologica> findAll();
	
	public List<CategoriaTecnologica> findByCoordenacao(Coordenacao coordenacao);
	
	@Modifying
	@Transactional
	@Query("update CategoriaTecnologica c set c.coordenacao.uid = ?1 where c.uid = ?2")
	int setCoordenadorFor(Long coordenadorId, Long uid);
	
}

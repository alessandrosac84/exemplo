import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Login } from '../../shared/model/login.model';
import { environment } from '../../../environments/environment';

@Injectable()
export class AuthService {

  private loginUrl = `${environment.apiBaseUrl}api/auth/login`;

  constructor(private http: HttpClient) { }

  login(login: Login) {
    return this.http.post(`${this.loginUrl}`, login);
  }
}

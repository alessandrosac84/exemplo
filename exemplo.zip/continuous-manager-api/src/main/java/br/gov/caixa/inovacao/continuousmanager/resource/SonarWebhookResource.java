/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.resource;

import java.util.logging.Logger;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.gov.caixa.inovacao.continuousmanager.service.integration.SonarWebhookService;

@Path("sonarqube-webhook")
@RequestScoped
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class SonarWebhookResource {

	@Inject
	private Logger log;
	
	@Inject
	private SonarWebhookService sonarWebhookService;

	@POST
	public Response createJob(String payload) {
		log.severe(payload);
		
		sonarWebhookService.checkNews();
		
		return Response.ok().build();
	}
}

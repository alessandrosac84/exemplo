package br.gov.caixa.api.repository.views;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.views.EspecialidadeProcessoView;

public interface EspecialidadeViewRepository extends JpaRepository<EspecialidadeProcessoView, Long> {

		
	@Query("select a from EspecialidadeProcessoView a where (a.especialidadeId = ?1 or a.especialidadeId is null)")
	List<EspecialidadeProcessoView> findByEspecialidadeId(Long especialidadeId);

}

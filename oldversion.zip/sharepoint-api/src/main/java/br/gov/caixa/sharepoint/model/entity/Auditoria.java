package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the auditoria database table.
 * 
 */
@Entity
@Table(name="auditoria")
@NamedQueries({
	@NamedQuery(name="Auditoria.findAll", query="SELECT a FROM Auditoria a WHERE LOWER(a.funcionarioEvento) LIKE :filter OR LOWER(a.funcionalidade) LIKE :filter ORDER BY a.timestampEvento DESC"),
	@NamedQuery(name="Auditoria.countAll", query = "SELECT count(a) FROM Auditoria a WHERE LOWER(a.funcionarioEvento) LIKE :filter OR LOWER(a.funcionalidade) LIKE :filter"),
})
public class Auditoria implements Serializable, IEntity<Integer> {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer uid;

	@Column(name="funcionalidade", length=50)
	private String funcionalidade;

	@Column(name="ip_evento", length=15)
	private String ipEvento;

	@Column(nullable=false, columnDefinition="TEXT")
	private String entidade;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="timestamp_evento")
	private Calendar timestampEvento;

	@Column(name="funcionario_evento", length=7)
	private String funcionarioEvento;

	//bi-directional many-to-one association to TipoAcao
	@ManyToOne
	@JoinColumn(name="tipo_acao_id", nullable=false)
	private TipoAcao tipoAcao;

	public Auditoria() {
	}

	public Integer getUid() {
		return this.uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public TipoAcao getTipoAcao() {
		return this.tipoAcao;
	}

	public void setTipoAcao(TipoAcao tipoAcao) {
		this.tipoAcao = tipoAcao;
	}

	public Calendar getTimestampEvento() {
		return timestampEvento;
	}

	public void setTimestampEvento(Calendar timestampEvento) {
		this.timestampEvento = timestampEvento;
	}

	public String getFuncionarioEvento() {
		return funcionarioEvento;
	}

	public void setFuncionarioEvento(String funcionarioEvento) {
		this.funcionarioEvento = funcionarioEvento;
	}

	public String getEntidade() {
		return entidade;
	}

	public void setEntidade(String entidade) {
		this.entidade = entidade;
	}

	public String getFuncionalidade() {
		return funcionalidade;
	}

	public void setFuncionalidade(String funcionalidade) {
		this.funcionalidade = funcionalidade;
	}

	public String getIpEvento() {
		return ipEvento;
	}

	public void setIpEvento(String ipEvento) {
		this.ipEvento = ipEvento;
	}

	@JsonIgnore
	@Override
	public Integer getId() {
		return this.uid;
	}

	@Override
	public boolean isTheSameObject(IEntity<Integer> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		Auditoria other = (Auditoria) object;
		if (uid == null) {
			if (other.uid != null)
				return false;
		} else if (!uid.equals(other.uid))
			return false;
		return true;
	}
}
***************************************************************************
***************************************************************************
***************** CRIA��O DAS VIEWS ***************************************
-- View: busca_medias

-- DROP VIEW busca_medias;

CREATE OR REPLACE VIEW busca_medias AS 
 SELECT a.disciplina_id, r.funcionario_id, sum(
        CASE
            WHEN r.multiplicador IS TRUE THEN 1
            ELSE 0
        END) AS multiplicador, sum(
        CASE
            WHEN r.conhecer IS TRUE THEN 1
            ELSE 0
        END) AS conhecer, sum(r.rating) AS total_rating, round(round(sum(r.rating)::numeric, 2) / round(count(0)::numeric, 2), 1) AS media_rating, count(0) AS total_atividades
   FROM atividade a
   JOIN rating_atividade r ON a.uid = r.atividade_id
  GROUP BY a.disciplina_id, r.funcionario_id
  ORDER BY a.disciplina_id;

ALTER TABLE busca_medias OWNER TO postgres;

-- View: busca_funcionario_medias

-- DROP VIEW busca_funcionario_medias;

CREATE OR REPLACE VIEW busca_funcionario_medias AS 
 SELECT bm.disciplina_id, bm.funcionario_id, bm.multiplicador, bm.conhecer, bm.total_rating, bm.media_rating, bm.total_atividades, f.nome, f.matricula
   FROM busca_medias bm
   JOIN funcionario f ON bm.funcionario_id = f.uid;

ALTER TABLE busca_funcionario_medias OWNER TO postgres;

***************************************************************************
***************************************************************************
***************************************************************************


*** INSERT SEGMENTO_NEGOCIO

INSERT INTO segmento_negocio (descricao)  values ('SUPORTE');
INSERT INTO segmento_negocio (descricao)  values ('INFRAESTRUTURA');
INSERT INTO segmento_negocio (descricao)  values ('SISTEMAS FINANCEIROS');
INSERT INTO segmento_negocio (descricao)  values ('CAPITA��O / JUDICIAL');
INSERT INTO segmento_negocio (descricao)  values ('CART�ES');
INSERT INTO segmento_negocio (descricao)  values ('ADM e BACKOFFICE');
INSERT INTO segmento_negocio (descricao)  values ('SERVI�OS BANC�RIOS');
INSERT INTO segmento_negocio (descricao)  values ('CANAIS');
INSERT INTO segmento_negocio (descricao)  values ('MOBILIDADE');


*** INSERT COORDENACAO

INSERT INTO public.coordenacao(descricao, grupo, nome, tipo, url) VALUES ('ESCRIT�RIO DE PROJETOS',	   'adm_cedessp010', 'CEDESSP010', '1', '<a href="http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP010.aspx">http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP010.aspx</a>');
INSERT INTO public.coordenacao(descricao, grupo, nome, tipo, url) VALUES ('CAPACIDADE PRODUTIVA',      'adm_cedessp020', 'CEDESSP020', '1', '<a href="http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP020.aspx">http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP020.aspx</a>');
INSERT INTO public.coordenacao(descricao, grupo, nome, tipo, url) VALUES ('SUSTENTA��O � TECNOLOGIA',  'adm_cedessp040', 'CEDESSP040', '1', '<a href="http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP040.aspx">http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP040.aspx</a>');
INSERT INTO public.coordenacao(descricao, grupo, nome, tipo, url) VALUES ('QUALIDADE',                 'adm_cedessp050', 'CEDESSP050', '1', '<a href="http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP050.aspx">http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP050.aspx</a>');

INSERT INTO public.coordenacao(descricao, grupo, nome, tipo, url, parent_id) VALUES ('ADM DE DADOS DE BANCO DE DADOS',	'adm_cedessp041', 'CEDESSP041', '2', '<a href="http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP041.aspx">http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP041.aspx</a>', (select uid from public.coordenacao where nome = 'CEDESSP040'));
INSERT INTO public.coordenacao(descricao, grupo, nome, tipo, url, parent_id) VALUES ('ARQUITETURA E REUSO',				'adm_cedessp042', 'CEDESSP042', '2', '<a href="http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP042.aspx">http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP042.aspx</a>', (select uid from public.coordenacao where nome = 'CEDESSP040'));
INSERT INTO public.coordenacao(descricao, grupo, nome, tipo, url, parent_id) VALUES ('SOA E BARRAMENTO',				'adm_cedessp043', 'CEDESSP043', '2', '<a href="http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP043.aspx">http://unidades/sites/CEDESSP/EQUIPES/SitePages/CEDESSP043.aspx</a>', (select uid from public.coordenacao where nome = 'CEDESSP040'));

*** INSERT funcionario

INSERT INTO public.funcionario(
             cargo, depto, matricula, nome, tipo_funcionario)
    VALUES ('ARQUITETO DE SOFTWARE', 'FABRICA', 'f752766', 'JOAO TEIXEIRA JR', 3);
    
    
    
*** INSERT APOIO FUNCIONARIO
    
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Adilson Inomata','c118039',to_timestamp('15/03/2013', 'DD/MM/YYYY'), to_timestamp('05/12/2011', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Adonai Martinho Moreira','c075219',to_timestamp('11/04/2005', 'DD/MM/YYYY'), to_timestamp('11/04/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Adriana Spacca Martins','c105975',to_timestamp('13/10/2009', 'DD/MM/YYYY'), to_timestamp('05/10/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Adriana Vicente Moda de Carvalho','c091456',to_timestamp('05/03/2007', 'DD/MM/YYYY'), to_timestamp('05/03/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Adylla de Oliveira Tota Mello','c091451',to_timestamp('05/03/2007', 'DD/MM/YYYY'), to_timestamp('05/03/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Afonso Pereira','c077615',to_timestamp('11/07/2005', 'DD/MM/YYYY'), to_timestamp('11/07/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Alan Diamantino Matias','c078090',to_timestamp('01/08/2005', 'DD/MM/YYYY'), to_timestamp('01/08/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Alessandra Bosquilha','c091628',to_timestamp('05/03/2007', 'DD/MM/YYYY'), to_timestamp('05/03/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Alessandra Ribeiro Oliveira','c088691',to_timestamp('04/09/2006', 'DD/MM/YYYY'), to_timestamp('04/09/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Alessandra Yamamoto Martins','c079393',to_timestamp('05/09/2005', 'DD/MM/YYYY'), to_timestamp('05/09/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Alexandre Borges Smania','c064896',to_timestamp('05/01/2004', 'DD/MM/YYYY'), to_timestamp('04/06/2002', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Alexandre Ishida Okabayashi','c074579',to_timestamp('04/04/2005', 'DD/MM/YYYY'), to_timestamp('04/04/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ana Cecilia de Souza','c076759',to_timestamp('03/10/2005', 'DD/MM/YYYY'), to_timestamp('06/06/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ana Lucia Afonso Ruiz','c038030',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('11/10/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ana Paula da Costa e Silva','c091590',to_timestamp('05/03/2007', 'DD/MM/YYYY'), to_timestamp('05/03/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Anderson Diego Barbosa de Lima','c082402',to_timestamp('10/10/2005', 'DD/MM/YYYY'), to_timestamp('10/10/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Anderson Jose Pereira Rodrigues','c076511',to_timestamp('06/06/2005', 'DD/MM/YYYY'), to_timestamp('06/06/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Anderson Pinheiro Balbo','c092581',to_timestamp('07/05/2007', 'DD/MM/YYYY'), to_timestamp('07/05/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Andre Airton de Sena','c131294',to_timestamp('02/07/2014', 'DD/MM/YYYY'), to_timestamp('18/02/2013', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Andre Carlos Antunes de Oliveira','c031745',to_timestamp('24/05/2002', 'DD/MM/YYYY'), to_timestamp('19/07/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Andre Taishi Yamaguchi','c071002',to_timestamp('13/10/2009', 'DD/MM/YYYY'), to_timestamp('01/03/2004', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Angelo Nacinbem Rabacow','c102982',to_timestamp('11/06/1990', 'DD/MM/YYYY'), to_timestamp('06/09/1982', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Antonio Carlos Barbosa','c042219',to_timestamp('24/11/2003', 'DD/MM/YYYY'), to_timestamp('16/11/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Antonio Eduardo Vieira','c064872',to_timestamp('24/11/2003', 'DD/MM/YYYY'), to_timestamp('04/06/2002', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Antonio Saes Caceres Junior','c129424',to_timestamp('10/12/2012', 'DD/MM/YYYY'), to_timestamp('10/12/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Aparecida Maria Aravequia','c111471',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Arnaldo Beraldo','c127091',to_timestamp('05/11/2012', 'DD/MM/YYYY'), to_timestamp('22/10/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Aurelio Carlos Baptista da Silva','c074576',to_timestamp('04/04/2005', 'DD/MM/YYYY'), to_timestamp('04/04/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Breno Costa Marques','c066243',to_timestamp('08/09/2005', 'DD/MM/YYYY'), to_timestamp('03/02/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Caique Vilela','c142000',to_timestamp('24/11/2014', 'DD/MM/YYYY'), to_timestamp('17/11/2014', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Carlos Alberto Martins Machado','c022068',to_timestamp('05/07/2011', 'DD/MM/YYYY'), to_timestamp('16/03/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Carlos Augusto Stresser Neto','c038021',to_timestamp('18/05/2015', 'DD/MM/YYYY'), to_timestamp('11/10/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Carlos de Oliveira Soares','c086039',to_timestamp('23/10/2008', 'DD/MM/YYYY'), to_timestamp('08/05/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Carlos Erik dos Santos','c055428',to_timestamp('17/05/2010', 'DD/MM/YYYY'), to_timestamp('11/12/2000', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Carlos Harari','c092897',to_timestamp('04/06/2007', 'DD/MM/YYYY'), to_timestamp('04/06/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Carlos Jose Mogadouro','c142002',to_timestamp('24/11/2014', 'DD/MM/YYYY'), to_timestamp('17/11/2014', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Carlos Miguel Goncalves','c070790',to_timestamp('22/08/2005', 'DD/MM/YYYY'), to_timestamp('01/03/2004', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Carolina Ladeia de Agustini','c074493',to_timestamp('16/02/2009', 'DD/MM/YYYY'), to_timestamp('11/03/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Celia dos Santos Rodrigues Andrade','c111476',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Celso Lucio da Silva Junior','c071292',to_timestamp('26/05/2008', 'DD/MM/YYYY'), to_timestamp('08/03/2004', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Celso Prado Giardina','c034017',to_timestamp('24/11/2003', 'DD/MM/YYYY'), to_timestamp('23/08/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Celso Ricardo Bossi ','c127094',to_timestamp('05/11/2012', 'DD/MM/YYYY'), to_timestamp('22/10/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Celso Victor','c059643',to_timestamp('05/09/2005', 'DD/MM/YYYY'), to_timestamp('27/08/2001', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Cintia Regina Magalhaes Rhein','c093810',to_timestamp('03/09/2007', 'DD/MM/YYYY'), to_timestamp('03/09/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Cisely Simoes Dias','c094713',to_timestamp('24/03/2008', 'DD/MM/YYYY'), to_timestamp('03/12/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Clarissa do Amaral Moreira Polushin','c080699',to_timestamp('09/05/2010', 'DD/MM/YYYY'), to_timestamp('12/09/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Claudia Emiko Otaki Nakayama','c075109',to_timestamp('11/04/2005', 'DD/MM/YYYY'), to_timestamp('11/04/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Claudineia de Lima Mariano','c095273',to_timestamp('11/02/2008', 'DD/MM/YYYY'), to_timestamp('11/02/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Claudio Povoas Pereira Junior','c111495',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Clovis Ferreira','c093846',to_timestamp('03/09/2007', 'DD/MM/YYYY'), to_timestamp('03/09/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Cristiane Araujo Garcia','c101354',to_timestamp('01/11/2009', 'DD/MM/YYYY'), to_timestamp('05/01/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Cristiane Moreira do Amaral Luz','c054284',to_timestamp('24/11/2003', 'DD/MM/YYYY'), to_timestamp('06/11/2000', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Dalmo Rangel Braga Filho','c088734',to_timestamp('09/04/2010', 'DD/MM/YYYY'), to_timestamp('04/09/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Daniel Bomfim','c105989',to_timestamp('13/10/2009', 'DD/MM/YYYY'), to_timestamp('05/10/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Daniel Cortinhas','c080700',to_timestamp('01/02/2008', 'DD/MM/YYYY'), to_timestamp('12/09/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Daniel Crivelin de Oliveira','c105981',to_timestamp('13/10/2009', 'DD/MM/YYYY'), to_timestamp('05/10/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Daniela Santos','c111482',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Daniella Yuhara','c072298',to_timestamp('11/04/2011', 'DD/MM/YYYY'), to_timestamp('14/06/2004', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Danielle Carrer Lima','c082221',to_timestamp('04/04/2008', 'DD/MM/YYYY'), to_timestamp('10/10/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Danilo Meira e Silva','c093292',to_timestamp('23/01/2012', 'DD/MM/YYYY'), to_timestamp('02/07/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Debora da Silva Barros','c075689',to_timestamp('02/05/2005', 'DD/MM/YYYY'), to_timestamp('02/05/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Denis Marcel Fernandes','c126903',to_timestamp('08/11/2013', 'DD/MM/YYYY'), to_timestamp('15/10/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Denis Ricard Panariello','c111529',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Denise Sayuri Sakai','c141990',to_timestamp('24/11/2014', 'DD/MM/YYYY'), to_timestamp('17/11/2014', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Dennis de Almeida Lopes','c073489',to_timestamp('16/02/2009', 'DD/MM/YYYY'), to_timestamp('12/07/2004', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Douglas Jundi Katayma Koyama','c102996',to_timestamp('09/03/2009', 'DD/MM/YYYY'), to_timestamp('06/09/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Drausio Mazzuchelli de Oliveira','c021764',to_timestamp('24/11/2003', 'DD/MM/YYYY'), to_timestamp('28/09/1998', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Edison Rodrigues da Silva','c024671',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('05/04/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Edmon da Silva','c066331',to_timestamp('08/09/2005', 'DD/MM/YYYY'), to_timestamp('12/05/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Edson Araujo','c039423',to_timestamp('02/07/2010', 'DD/MM/YYYY'), to_timestamp('25/10/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Edson Leme','c077314',to_timestamp('04/07/2005', 'DD/MM/YYYY'), to_timestamp('04/07/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Edson Pereira de Barbara','c075247',to_timestamp('11/04/2005', 'DD/MM/YYYY'), to_timestamp('11/04/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Eduardo Aparecido Koscianski Milan','c085025',to_timestamp('01/09/2008', 'DD/MM/YYYY'), to_timestamp('06/03/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Eduardo de Vasconcelos Belisario','c075682',to_timestamp('02/05/2005', 'DD/MM/YYYY'), to_timestamp('02/05/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Edvaldo Pereira da Silva','c076760',to_timestamp('06/06/2005', 'DD/MM/YYYY'), to_timestamp('06/06/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Eliane Grotti Borges','c022070',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('06/12/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Elika Okubo','c076508',to_timestamp('06/06/2005', 'DD/MM/YYYY'), to_timestamp('06/06/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Elson Massahaki Oka','c127100',to_timestamp('05/11/2012', 'DD/MM/YYYY'), to_timestamp('22/10/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Elton dos Santos','c079422',to_timestamp('15/09/2009', 'DD/MM/YYYY'), to_timestamp('05/09/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ercilia Maria de Sales Silva Soares de Camargo','c090141',to_timestamp('02/02/2009', 'DD/MM/YYYY'), to_timestamp('04/12/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Eric Pignaton','c079590',to_timestamp('05/09/2005', 'DD/MM/YYYY'), to_timestamp('05/09/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Everaldo da Silva Homem','c054153',to_timestamp('08/09/2005', 'DD/MM/YYYY'), to_timestamp('16/10/2000', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fabiana Almeida Monaco','c089717',to_timestamp('06/11/2006', 'DD/MM/YYYY'), to_timestamp('06/11/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fabiane Cristina Priviati','c089711',to_timestamp('06/11/2006', 'DD/MM/YYYY'), to_timestamp('06/11/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fabio Martorano da Cruz','c070138',to_timestamp('17/09/2008', 'DD/MM/YYYY'), to_timestamp('02/02/2004', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fabio Renato Tanaka','c066286',to_timestamp('08/09/2005', 'DD/MM/YYYY'), to_timestamp('02/04/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fabio Romao Prado','c072424',to_timestamp('06/09/2005', 'DD/MM/YYYY'), to_timestamp('14/06/2004', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fabricio Eduardo kubota','c064725',to_timestamp('24/11/2003', 'DD/MM/YYYY'), to_timestamp('22/05/2002', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fatima Cristina Portela Diniz','c095316',to_timestamp('11/02/2008', 'DD/MM/YYYY'), to_timestamp('11/02/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Felipe Vergueiro Otake','c095268',to_timestamp('11/02/2008', 'DD/MM/YYYY'), to_timestamp('11/02/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fernanda Cristina Nicoletti dos Santos','c111493',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fernanda Izepe','c068049',to_timestamp('01/09/2005', 'DD/MM/YYYY'), to_timestamp('01/12/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fernanda Moreira Sena','c051048',to_timestamp('24/11/2003', 'DD/MM/YYYY'), to_timestamp('23/02/1999', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fernando Alves da Silva','c067984',to_timestamp('29/08/2005', 'DD/MM/YYYY'), to_timestamp('01/12/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fernando Candia','c129423',to_timestamp('10/12/2012', 'DD/MM/YYYY'), to_timestamp('10/12/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fernando Geraldo de Oliveira','c134675',to_timestamp('22/07/2013', 'DD/MM/YYYY'), to_timestamp('15/07/2013', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fernando Madeira Nunes','c300518',to_timestamp('25/06/2001', 'DD/MM/YYYY'), to_timestamp('01/02/1982', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fernando Pellisario de Godoy','c050873',to_timestamp('09/04/2001', 'DD/MM/YYYY'), to_timestamp('11/01/1999', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fernando Pereira Rosa','c077162',to_timestamp('04/07/2005', 'DD/MM/YYYY'), to_timestamp('04/07/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Fernando Tadeu Rodrigues','c067277',to_timestamp('22/08/2005', 'DD/MM/YYYY'), to_timestamp('10/11/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Flavia Augusta Martins Dantas de Lima','c041737',to_timestamp('24/01/2008', 'DD/MM/YYYY'), to_timestamp('07/11/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Flavia Ribeiro Pinho Murbach','c040763',to_timestamp('06/07/2009', 'DD/MM/YYYY'), to_timestamp('30/10/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Flaviano Liberato Neto','c302145',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('09/08/1982', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Flavio de Almeida Gagliardi','c083805',to_timestamp('12/12/2005', 'DD/MM/YYYY'), to_timestamp('12/12/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Flavio Santos Costa','c093315',to_timestamp('17/07/2009', 'DD/MM/YYYY'), to_timestamp('02/07/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Gessica Cachoeira dos Santos','c104086',to_timestamp('02/06/2011', 'DD/MM/YYYY'), to_timestamp('04/05/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Gilberto Alves Teixeira','c024567',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('23/08/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Gilberto Gon�alves','c320846',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('28/09/1981', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Gilberto Olimpio dos Santos','c129427',to_timestamp('10/12/2012', 'DD/MM/YYYY'), to_timestamp('10/12/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Gisele Mayumi Suga Utida','c085535',to_timestamp('10/04/2006', 'DD/MM/YYYY'), to_timestamp('10/04/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Guilherme Medeiros Vieira','c109000',to_timestamp('16/11/2011', 'DD/MM/YYYY'), to_timestamp('10/05/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Gustavo Silva Costa','c053780',to_timestamp('17/11/2003', 'DD/MM/YYYY'), to_timestamp('31/08/2000', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Helio Yuji Nakafori','c077166',to_timestamp('04/07/2005', 'DD/MM/YYYY'), to_timestamp('04/07/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Hellen Aparecida Souto Domingos','c076474',to_timestamp('06/06/2005', 'DD/MM/YYYY'), to_timestamp('06/06/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Heloisa Guedes da Cunha Okumura','c099404',to_timestamp('04/08/2008', 'DD/MM/YYYY'), to_timestamp('04/08/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Hermes Jose Rodrigues Junior','c066658',to_timestamp('11/07/2011', 'DD/MM/YYYY'), to_timestamp('15/09/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Homero Oscar Pereira','c058988',to_timestamp('13/05/2008', 'DD/MM/YYYY'), to_timestamp('02/07/2001', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Hulianne Virginia Magalhaes da Silva Martinho','c105982',to_timestamp('13/10/2009', 'DD/MM/YYYY'), to_timestamp('05/10/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Iara Salles Farias','c033951',to_timestamp('21/05/2001', 'DD/MM/YYYY'), to_timestamp('23/08/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Iris do Carmo Xavier da Silva','c052455',to_timestamp('01/09/2008', 'DD/MM/YYYY'), to_timestamp('25/11/1999', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Isaac Santos de Morais','c084776',to_timestamp('26/09/2011', 'DD/MM/YYYY'), to_timestamp('06/03/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Italo Marinho Cippiciani','c101534',to_timestamp('30/07/2010', 'DD/MM/YYYY'), to_timestamp('02/02/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ivete Aparecida Dorizzoti','c110848',to_timestamp('20/09/2010', 'DD/MM/YYYY'), to_timestamp('13/09/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Izac Lins dos Santos','c127162',to_timestamp('05/11/2012', 'DD/MM/YYYY'), to_timestamp('22/10/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jean Sanches Bino','c081512',to_timestamp('03/10/2005', 'DD/MM/YYYY'), to_timestamp('03/10/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Joao Henrique Aroldi','c081566',to_timestamp('03/10/2005', 'DD/MM/YYYY'), to_timestamp('03/10/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Joao Luiz Pedroso Junqueira','c033941',to_timestamp('28/03/2001', 'DD/MM/YYYY'), to_timestamp('13/09/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Joao Paulo da Silva','c093819',to_timestamp('03/09/2007', 'DD/MM/YYYY'), to_timestamp('03/09/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Joao Vicente de Almeida Seabra','c050755',to_timestamp('07/03/2014', 'DD/MM/YYYY'), to_timestamp('16/12/1998', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Johnata William Zorzi','c111489',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Johnny Hess','c081860',to_timestamp('09/04/2007', 'DD/MM/YYYY'), to_timestamp('03/10/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jorge Caetano dos Santos','c426287',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('19/07/1982', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jorge Kasuiuki Ono','c430626',to_timestamp('17/12/2014', 'DD/MM/YYYY'), to_timestamp('03/01/1983', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Alexandre Ferreira Bitencourt','c141997',to_timestamp('24/11/2014', 'DD/MM/YYYY'), to_timestamp('17/11/2014', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Carlos Gaspar','c032672',to_timestamp('03/10/2005', 'DD/MM/YYYY'), to_timestamp('02/08/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Carlos Montes','c077148',to_timestamp('04/07/2005', 'DD/MM/YYYY'), to_timestamp('04/07/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Claudio Crespin','c056389',to_timestamp('24/05/2002', 'DD/MM/YYYY'), to_timestamp('11/01/2001', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Edson Ferreira da Silva','c104587',to_timestamp('01/06/2009', 'DD/MM/YYYY'), to_timestamp('01/06/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Eduardo Ferreira da Silva','c128556',to_timestamp('13/01/2014', 'DD/MM/YYYY'), to_timestamp('19/11/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Eli de Godoi','c062702',to_timestamp('08/09/2005', 'DD/MM/YYYY'), to_timestamp('13/03/1990', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Fernando Antunes de Almeida','c142001',to_timestamp('17/11/2014', 'DD/MM/YYYY'), to_timestamp('24/11/2014', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Luiz de Melo','c133488',to_timestamp('23/12/2015', 'DD/MM/YYYY'), to_timestamp('13/05/2013', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Marcelo Bufarah Caroni','c129421',to_timestamp('10/12/2012', 'DD/MM/YYYY'), to_timestamp('10/12/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Milton Santos','c077203',to_timestamp('10/07/2007', 'DD/MM/YYYY'), to_timestamp('04/07/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Ricardo Epprecht','c134674',to_timestamp('22/07/2013', 'DD/MM/YYYY'), to_timestamp('15/07/2013', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Roberto de Melo Franco Junior','c034781',to_timestamp('01/03/2002', 'DD/MM/YYYY'), to_timestamp('23/08/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Jose Wilson dos Santos Junior','c024534',to_timestamp('05/09/2005', 'DD/MM/YYYY'), to_timestamp('10/05/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Juliana Avila Santos da Silva','c105977',to_timestamp('13/10/2009', 'DD/MM/YYYY'), to_timestamp('05/10/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Karen da Silva Paiva','c076507',to_timestamp('06/06/2005', 'DD/MM/YYYY'), to_timestamp('06/06/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Kazumitsu Thiago Bugs Wakassa','c096489',to_timestamp('03/08/2011', 'DD/MM/YYYY'), to_timestamp('05/05/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Kazuo Sakurai','c019987',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('28/03/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Keiko Nishi','c091965',to_timestamp('09/04/2007', 'DD/MM/YYYY'), to_timestamp('09/04/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Kiyoshi Mada','c056474',to_timestamp('24/05/2002', 'DD/MM/YYYY'), to_timestamp('12/01/2001', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Laudo Eiji Ogata','c075673',to_timestamp('02/05/2005', 'DD/MM/YYYY'), to_timestamp('02/05/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Lawrence Nakamura','c105762',to_timestamp('08/09/2009', 'DD/MM/YYYY'), to_timestamp('08/09/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Leandro Gomes Machado','c083132',to_timestamp('07/11/2005', 'DD/MM/YYYY'), to_timestamp('07/11/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Liliane Onda Rezende Machado','c056464',to_timestamp('27/08/2001', 'DD/MM/YYYY'), to_timestamp('12/01/2001', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Liliane Saemy Tsukamoto','c112312',to_timestamp('23/01/2012', 'DD/MM/YYYY'), to_timestamp('22/11/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Liziane Yasue Miyata','c084329',to_timestamp('14/02/2009', 'DD/MM/YYYY'), to_timestamp('09/01/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luciana Cerqueira da Costa','c062177',to_timestamp('31/12/2009', 'DD/MM/YYYY'), to_timestamp('30/01/2002', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luciano dos Reis de Souza','c064478',to_timestamp('24/10/2011', 'DD/MM/YYYY'), to_timestamp('14/05/2002', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luciano Ricardo de Sousa Monteiro','c058935',to_timestamp('03/10/2005', 'DD/MM/YYYY'), to_timestamp('02/07/2001', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luciano Seite Nishikawa','c052958',to_timestamp('27/08/2008', 'DD/MM/YYYY'), to_timestamp('15/06/2000', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luis Fernando Chefer Borges','c141995',to_timestamp('24/11/2014', 'DD/MM/YYYY'), to_timestamp('17/11/2014', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luis Henrique de Seixas','c093321',to_timestamp('02/07/2007', 'DD/MM/YYYY'), to_timestamp('02/07/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luis Henrique Donda','c084816',to_timestamp('26/05/2011', 'DD/MM/YYYY'), to_timestamp('06/03/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luis Henrique Prando','c061911',to_timestamp('24/11/2003', 'DD/MM/YYYY'), to_timestamp('18/01/2002', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luiz Alberto Ramalho','c088329',to_timestamp('29/01/2007', 'DD/MM/YYYY'), to_timestamp('07/08/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luiz Antonio Eleuterio Lima','c110744',to_timestamp('20/09/2010', 'DD/MM/YYYY'), to_timestamp('13/09/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luiz Fernando Mesashi','c108268',to_timestamp('11/08/2011', 'DD/MM/YYYY'), to_timestamp('05/04/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luiz Henrique Samejima','c055715',to_timestamp('27/04/2005', 'DD/MM/YYYY'), to_timestamp('26/12/2000', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Luiz Vilas Boas','c111484',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcela Cavalcanti dos Santos Corredato','c088273',to_timestamp('07/08/2006', 'DD/MM/YYYY'), to_timestamp('07/08/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcelo de Araujo Maximiano','c129426',to_timestamp('10/12/2012', 'DD/MM/YYYY'), to_timestamp('10/12/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcelo Gutierrez','c091027',to_timestamp('05/02/2007', 'DD/MM/YYYY'), to_timestamp('05/02/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcelo Lopes Camelo','c077159',to_timestamp('04/07/2005', 'DD/MM/YYYY'), to_timestamp('04/07/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcelo Mariano Tedeschi','c075681',to_timestamp('02/05/2005', 'DD/MM/YYYY'), to_timestamp('02/05/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcelo Minami Pollini','c111494',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcelo Pereira Leite Gomes','c078087',to_timestamp('01/08/2005', 'DD/MM/YYYY'), to_timestamp('01/08/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcelo Roberto de Miranda Mesquita','c074557',to_timestamp('04/04/2005', 'DD/MM/YYYY'), to_timestamp('04/04/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcia Coelho Augusto da Cruz','c089812',to_timestamp('06/11/2006', 'DD/MM/YYYY'), to_timestamp('06/11/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcia Teresa Lopes de Souza Dias','c112320',to_timestamp('29/11/2010', 'DD/MM/YYYY'), to_timestamp('22/11/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcio Clei da Silva','c058944',to_timestamp('27/04/2005', 'DD/MM/YYYY'), to_timestamp('02/07/2001', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcio Doine','c062315',to_timestamp('24/11/2003', 'DD/MM/YYYY'), to_timestamp('07/02/2002', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marco Antonio Rodrigues','c093331',to_timestamp('02/07/2007', 'DD/MM/YYYY'), to_timestamp('02/07/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marco Aurelio Ramirez Bazzo','c039489',to_timestamp('02/02/2009', 'DD/MM/YYYY'), to_timestamp('08/11/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marco Fuzaro','c021997',to_timestamp('23/04/2001', 'DD/MM/YYYY'), to_timestamp('05/10/1998', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcos Correia Santos','c024513',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('10/05/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marcos de Almeida Verri','c090751',to_timestamp('08/01/2007', 'DD/MM/YYYY'), to_timestamp('08/01/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Maria Angela Vieira da Rocha','c032688',to_timestamp('01/09/2005', 'DD/MM/YYYY'), to_timestamp('02/08/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Maria Harue Matsumoto','c091880',to_timestamp('09/04/2007', 'DD/MM/YYYY'), to_timestamp('09/04/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Maria Inez Aiolfi Aleixo Rey','c129429',to_timestamp('10/12/2012', 'DD/MM/YYYY'), to_timestamp('10/12/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Maria Lourdes Bucciarelli R.Fernandes','c019944',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('20/03/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Maria Rosemere Degan Melchert','c019983',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('20/03/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Mariana Trajano','c095270',to_timestamp('11/02/2008', 'DD/MM/YYYY'), to_timestamp('11/02/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marilisa Brunelo Neri','c075440',to_timestamp('02/05/2005', 'DD/MM/YYYY'), to_timestamp('02/05/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Mario Edson Pandagis Emygdio','c050420',to_timestamp('28/05/2001', 'DD/MM/YYYY'), to_timestamp('19/10/1998', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Marta de Lima Isaac Siqueira ','c129631',to_timestamp('24/12/2012', 'DD/MM/YYYY'), to_timestamp('10/12/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Mauricio Minoru Saito','c054158',to_timestamp('23/08/2004', 'DD/MM/YYYY'), to_timestamp('16/10/2000', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Mauricio Tarla Menezes','c090053',to_timestamp('19/06/2009', 'DD/MM/YYYY'), to_timestamp('04/12/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Maycon Jefferson Mascelloni','c129481',to_timestamp('10/12/2012', 'DD/MM/YYYY'), to_timestamp('10/12/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Nancy Aparecida Alves Sredoja','c044758',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('03/01/1990', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Nathaly de Jesus Alexandrino','c099406',to_timestamp('04/08/2008', 'DD/MM/YYYY'), to_timestamp('04/08/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Nelson Cartolano','c056467',to_timestamp('01/08/2002', 'DD/MM/YYYY'), to_timestamp('12/01/2001', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Nelson Ruiz Affonseca Junior','c092583',to_timestamp('07/05/2007', 'DD/MM/YYYY'), to_timestamp('07/05/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Nildo Jose Romao','c070474',to_timestamp('25/04/2005', 'DD/MM/YYYY'), to_timestamp('09/02/2004', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Nilson Jose de Campos ','c139608',to_timestamp('17/03/2014', 'DD/MM/YYYY'), to_timestamp('17/03/2014', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Odante Ribeiro Swerts Junior','c110727',to_timestamp('20/09/2010', 'DD/MM/YYYY'), to_timestamp('13/09/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Odete Yumi Morioka','c039418',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('08/11/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Oseias Fernandes Aguiar','c089758',to_timestamp('06/11/2006', 'DD/MM/YYYY'), to_timestamp('06/11/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Paloma Silva Vieira','c105983',to_timestamp('13/10/2009', 'DD/MM/YYYY'), to_timestamp('05/10/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Patricia Donizete Alves Viana','c091449',to_timestamp('05/03/2007', 'DD/MM/YYYY'), to_timestamp('05/03/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Patricia Yuri Rodriguez','c105808',to_timestamp('20/02/2014', 'DD/MM/YYYY'), to_timestamp('08/09/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Paulo Cezar Roma','c123316',to_timestamp('16/09/2013', 'DD/MM/YYYY'), to_timestamp('06/08/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Paulo de Tarso Carozzi de Miranda','c024450',to_timestamp('02/08/2005', 'DD/MM/YYYY'), to_timestamp('10/05/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Paulo Fernando Miranda Sinetti','c090630',to_timestamp('23/11/2007', 'DD/MM/YYYY'), to_timestamp('08/01/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Paulo Roberto Marchesin','c083072',to_timestamp('07/11/2005', 'DD/MM/YYYY'), to_timestamp('07/11/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Paulo Rocha Ferreira','c079463',to_timestamp('05/09/2005', 'DD/MM/YYYY'), to_timestamp('05/09/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Pedro Henrique Boujadi de Sousa Silveira','c083073',to_timestamp('30/05/2008', 'DD/MM/YYYY'), to_timestamp('07/11/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Pedro Nivaldo Pavanelli','c066337',to_timestamp('17/11/2003', 'DD/MM/YYYY'), to_timestamp('12/05/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Priscila de Jesus Almeida','c074555',to_timestamp('04/04/2005', 'DD/MM/YYYY'), to_timestamp('04/04/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rafael Augusto Tanaami Galante','c103527',to_timestamp('08/08/2011', 'DD/MM/YYYY'), to_timestamp('06/04/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rafael Bernardo Ferreira Santos','c086177',to_timestamp('16/02/2009', 'DD/MM/YYYY'), to_timestamp('08/05/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rafael Costa Braga','c111807',to_timestamp('22/08/2011', 'DD/MM/YYYY'), to_timestamp('25/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rafael de Souza Bonetti','c081510',to_timestamp('03/10/2005', 'DD/MM/YYYY'), to_timestamp('03/10/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rafael Dias Sabino ','c065755',to_timestamp('20/08/2012', 'DD/MM/YYYY'), to_timestamp('25/09/2002', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rafael Ferreira Baltazar','c091453',to_timestamp('05/03/2007', 'DD/MM/YYYY'), to_timestamp('05/03/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Raquel de Jesus Silva','c105764',to_timestamp('08/09/2009', 'DD/MM/YYYY'), to_timestamp('08/09/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Raymundo da Silva Campos Junior','c066380',to_timestamp('31/05/2010', 'DD/MM/YYYY'), to_timestamp('09/06/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Regiane Pereira Rondon','c112269',to_timestamp('01/09/2014', 'DD/MM/YYYY'), to_timestamp('22/11/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Regina de Almeida de Custodio','c082353',to_timestamp('10/10/2005', 'DD/MM/YYYY'), to_timestamp('10/10/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Renato Aparecido Sampaio','c111485',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Renato Arnaldo da Silva','c092577',to_timestamp('08/08/2007', 'DD/MM/YYYY'), to_timestamp('07/05/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Renato Galantini','c141999',to_timestamp('24/11/2014', 'DD/MM/YYYY'), to_timestamp('17/11/2014', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ricardo Andrade Soares','c068446',to_timestamp('05/09/2005', 'DD/MM/YYYY'), to_timestamp('08/12/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ricardo Deodato Negrini','c052439',to_timestamp('24/05/2002', 'DD/MM/YYYY'), to_timestamp('11/11/1999', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ricardo Lindon Marques da Silva','c066893',to_timestamp('01/09/2008', 'DD/MM/YYYY'), to_timestamp('03/11/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ricardo Monteiro Ramos','c096210',to_timestamp('07/04/2008', 'DD/MM/YYYY'), to_timestamp('07/04/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ricardo Rocha Cianfrone','c086594',to_timestamp('05/06/2006', 'DD/MM/YYYY'), to_timestamp('05/06/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rinaldo Ferreira Marques','c142161',to_timestamp('19/12/2014', 'DD/MM/YYYY'), to_timestamp('08/12/2014', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Roberto Murbach Junior','c039413',to_timestamp('29/01/2008', 'DD/MM/YYYY'), to_timestamp('25/10/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Robson Ricardo de Macedo','c095070',to_timestamp('07/01/2008', 'DD/MM/YYYY'), to_timestamp('07/01/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rodolfo Zibordi Giao','c071134',to_timestamp('30/08/2005', 'DD/MM/YYYY'), to_timestamp('08/03/2004', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rodrigo de Aguiar Lopes Billa','c094133',to_timestamp('01/10/2007', 'DD/MM/YYYY'), to_timestamp('01/10/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rodrigo Loureto de Rezende','c066367',to_timestamp('12/06/2009', 'DD/MM/YYYY'), to_timestamp('26/05/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rodrigo Prado de Jesus','c090762',to_timestamp('03/08/2015', 'DD/MM/YYYY'), to_timestamp('08/01/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rodrigo Ramos Takata Palma','c074517',to_timestamp('11/03/2005', 'DD/MM/YYYY'), to_timestamp('11/03/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rogerio Costa Glass','c111473',to_timestamp('04/10/2010', 'DD/MM/YYYY'), to_timestamp('04/10/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rogerio de Franca Pimentel','c092912',to_timestamp('28/07/2010', 'DD/MM/YYYY'), to_timestamp('04/06/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rogerio Zgiet Fonseca','c142792',to_timestamp('14/09/2015', 'DD/MM/YYYY'), to_timestamp('02/02/2015', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rommel Gabriel Gon�alves Ramos','c099731',to_timestamp('09/05/2011', 'DD/MM/YYYY'), to_timestamp('04/08/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Ronald Santos Ferreira','c021613',to_timestamp('08/09/2005', 'DD/MM/YYYY'), to_timestamp('21/09/1998', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rosana Cristina Faverao','c050605',to_timestamp('03/11/2003', 'DD/MM/YYYY'), to_timestamp('03/11/1998', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rosane Deganeli de Brito','c034756',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('23/08/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rosangela Pereira Cruz','c037478',to_timestamp('08/11/2005', 'DD/MM/YYYY'), to_timestamp('04/10/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rubens Alves de Souza','c024735',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('11/04/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Rubens Odan da Silva','c142036',to_timestamp('24/11/2014', 'DD/MM/YYYY'), to_timestamp('17/11/2014', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Samuelsen da Cunha Martins','c119059',to_timestamp('28/04/2014', 'DD/MM/YYYY'), to_timestamp('06/02/2012', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Sandra Borba Cerri','c100566',to_timestamp('06/10/2008', 'DD/MM/YYYY'), to_timestamp('06/10/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Sandra Fretes Mendes','c091454',to_timestamp('05/03/2007', 'DD/MM/YYYY'), to_timestamp('05/03/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Selisvaldo Pereira Montalvao','c136847',to_timestamp('14/10/2013', 'DD/MM/YYYY'), to_timestamp('14/10/2013', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Sergio Faustino Marreiros','c077158',to_timestamp('04/07/2005', 'DD/MM/YYYY'), to_timestamp('04/07/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Sergio Martins Dealtry','c101489',to_timestamp('17/07/2009', 'DD/MM/YYYY'), to_timestamp('05/01/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Sergio Ricardo Araujo Vares','c052460',to_timestamp('10/03/2008', 'DD/MM/YYYY'), to_timestamp('25/11/1999', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Shirlei Soares Medeiros Braghetto','c091459',to_timestamp('05/03/2007', 'DD/MM/YYYY'), to_timestamp('05/03/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Sidonio Amorim de Oliveira','c076310',to_timestamp('09/05/2005', 'DD/MM/YYYY'), to_timestamp('09/05/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Silvana Mobst','c062883',to_timestamp('24/11/2003', 'DD/MM/YYYY'), to_timestamp('07/03/2002', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Silvio Fernandes','c076473',to_timestamp('06/06/2005', 'DD/MM/YYYY'), to_timestamp('06/06/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Silvio Osiro','c861167',to_timestamp('09/08/2010', 'DD/MM/YYYY'), to_timestamp('02/08/1982', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Silvio Ricardo Terato','c046543',to_timestamp('15/12/2003', 'DD/MM/YYYY'), to_timestamp('17/01/1990', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Simonia Helena de Andrade','c042629',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('20/12/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Solange Pereira Barbosa da Silva','c094494',to_timestamp('05/11/2007', 'DD/MM/YYYY'), to_timestamp('05/11/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Stephano Ramalho Biazon Gomes','c091457',to_timestamp('05/03/2007', 'DD/MM/YYYY'), to_timestamp('05/03/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Sueli Rodrigues Dias','c136103',to_timestamp('16/09/213', 'DD/MM/YYYY'), to_timestamp('16/09/2013', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Suzana Kawamura','c067223',to_timestamp('20/07/2009', 'DD/MM/YYYY'), to_timestamp('10/11/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Suzy Kubo','c035007',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('13/09/1989', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Sylvio Jose Persson Ceccon','c866855',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('11/05/1981', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Thais Meira Benevides','c091455',to_timestamp('05/03/2007', 'DD/MM/YYYY'), to_timestamp('05/03/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Thiago Bezerra Torres','c054268',to_timestamp('08/09/2005', 'DD/MM/YYYY'), to_timestamp('06/11/2000', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Thiago Figaro Krasauskas','c086804',to_timestamp('16/02/2009', 'DD/MM/YYYY'), to_timestamp('05/06/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Thiago Vinicius de Souza Santos','c093811',to_timestamp('03/09/2007', 'DD/MM/YYYY'), to_timestamp('03/09/2007', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Vagner Fabio Guilherme da Silva','c076514',to_timestamp('06/06/2005', 'DD/MM/YYYY'), to_timestamp('06/06/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Valdir de Souza Junior','c079563',to_timestamp('05/09/2005', 'DD/MM/YYYY'), to_timestamp('05/09/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Vanessa Beuttenmuller Castilho Aguiar','c089715',to_timestamp('06/11/2006', 'DD/MM/YYYY'), to_timestamp('06/11/2006', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Vanessa Messias de Souza','c105765',to_timestamp('08/09/2009', 'DD/MM/YYYY'), to_timestamp('08/09/2009', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Victor Felippe Amaral de Oliveira','c095359',to_timestamp('19/08/2008', 'DD/MM/YYYY'), to_timestamp('11/02/2008', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Vinicius Barbosa Lira','c108464',to_timestamp('12/04/2010', 'DD/MM/YYYY'), to_timestamp('05/04/2010', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Vitor Mendes Guedes','c073404',to_timestamp('09/01/2006', 'DD/MM/YYYY'), to_timestamp('12/07/2004', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Vivian Feltrin','c078130',to_timestamp('01/08/2005', 'DD/MM/YYYY'), to_timestamp('01/08/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Wagner Dellarco De Jule','c877543',to_timestamp('01/01/2014', 'DD/MM/YYYY'), to_timestamp('03/08/1981', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Wendel Lopes dos Santos','c079424',to_timestamp('05/09/2005', 'DD/MM/YYYY'), to_timestamp('05/09/2005', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Willian Rodrigues dos Santos','c066504',to_timestamp('29/08/2008', 'DD/MM/YYYY'), to_timestamp('11/08/2003', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Wladimir Minoru Honda','c889475',to_timestamp('01/11/1998', 'DD/MM/YYYY'), to_timestamp('30/11/1981', 'DD/MM/YYYY'));
insert into apoio_funcionario (nome, matricula, data_cedes, data_admissao) values ('Wladimir Vieira de Souza','c078497',to_timestamp('08/08/2005', 'DD/MM/YYYY'), to_timestamp('08/08/2005', 'DD/MM/YYYY'));    

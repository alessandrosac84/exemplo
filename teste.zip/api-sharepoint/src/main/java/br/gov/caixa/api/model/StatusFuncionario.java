package br.gov.caixa.api.model;

public enum StatusFuncionario {
	OUTROS(0), ATIVO(1), APOSENTADO (2), AFASTADO (3), LICENCIADO(4), DESLIGADO(5), FABRICA(6), TRANSFERIDO(7), LOTACAO_ADM(8), VISITANTE(9);
	
	private final int codigo;
	
	StatusFuncionario(int codigo) { this.codigo = codigo; }

    int codigo() { return codigo; }

    public static StatusFuncionario porCodigo(int codigo) {
        for (StatusFuncionario statusFuncionario: StatusFuncionario.values()) {
            if (codigo == statusFuncionario.codigo()) return statusFuncionario;
        }
        throw new IllegalArgumentException("status invalido");
    }    
}

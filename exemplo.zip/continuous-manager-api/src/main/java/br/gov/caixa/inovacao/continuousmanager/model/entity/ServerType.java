package br.gov.caixa.inovacao.continuousmanager.model.entity;

/**
 * Enum de Tipos de Servidores
 * 
 * @author Fabio Iwakoshi
 */
public enum ServerType {

	JENKINS("Jenkins"), SONAR("Sonarqube"), GITLAB("GitLab");
	
	private String description;
	
	private ServerType(String description) {
		this.description = description;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
}

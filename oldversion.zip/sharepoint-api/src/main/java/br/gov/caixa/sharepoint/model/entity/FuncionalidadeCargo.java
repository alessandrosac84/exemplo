package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the funcionalidade_cargo database table.
 * 
 */
@Entity
@Table(name="funcionalidade_cargo")
@NamedQueries ({
	@NamedQuery(name="FuncionalidadeCargo.findAll", query="SELECT f FROM FuncionalidadeCargo f"),
	@NamedQuery(name="FuncionalidadeCargo.findCargosByFuncionalidade", query="SELECT a FROM FuncionalidadeCargo a WHERE a.id.funcionalidade = :id")
})
public class FuncionalidadeCargo extends AuditedEntity implements Serializable, IEntity<FuncionalidadeCargoPK> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private FuncionalidadeCargoPK id;

	//bi-directional many-to-one association to CargoFuncionario
	@ManyToOne
	@JoinColumn(name="cargo", nullable=false, insertable=false, updatable=false)
	private CargoFuncionario cargoFuncionario;

	//bi-directional many-to-one association to Funcionalidade
	@ManyToOne
	@JoinColumn(name="funcionalidade", nullable=false, insertable=false, updatable=false)
	private Funcionalidade funcionalidade;

	public FuncionalidadeCargo() {
	}

	public FuncionalidadeCargoPK getId() {
		return this.id;
	}

	public void setId(FuncionalidadeCargoPK id) {
		this.id = id;
	}

	public CargoFuncionario getCargoFuncionario() {
		return this.cargoFuncionario;
	}

	public void setCargoFuncionario(CargoFuncionario cargoFuncionario) {
		this.cargoFuncionario = cargoFuncionario;
	}

	public Funcionalidade getFuncionalidade() {
		return this.funcionalidade;
	}

	public void setFuncionalidade(Funcionalidade funcionalidade) {
		this.funcionalidade = funcionalidade;
	}

	@Override
	public boolean isTheSameObject(IEntity<FuncionalidadeCargoPK> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		FuncionalidadeCargo other = (FuncionalidadeCargo) object;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
package br.gov.caixa.inovacao.continuousmanager.model;

/**
 * @author Fabio Iwakoshi
 *
 */
public class ViewJson {
	
	private ViewJson() {}
	
	public static class WalletView {} //NOSONAR
	
	public static class ProjectView {} //NOSONAR
	
	public static class JobView {} //NOSONAR
	
	public static class BuildView {} //NOSONAR
	
	public static class ChangeSetView {} //NOSONAR
	
	public static class LogStageView {} //NOSONAR
	
}

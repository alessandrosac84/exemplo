import { Component, OnInit } from '@angular/core';

import {
  MatDialog,
  MatDialogConfig,
  MatTableDataSource
} from '@angular/material';
import { AddServerDialogComponent } from './add-server-dialog/add-server-dialog.component';
import { ServerService } from '../../../../shared/service/server.service';

@Component({
  selector: 'cm-infrastructure',
  templateUrl: './infrastructure.component.html',
  styleUrls: ['./infrastructure.component.scss']
})
export class InfrastructureComponent implements OnInit {
  serversLength: number;
  dataSource: any;
  displayedColumns: string[] = [
    'ip',
    'dns',
    'ambiente',
    'servidor',
    'tiposervidor',
    'versao'
  ];

  constructor(
    private _serverService: ServerService,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this._serverService.getServers().subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
    });
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;

    this.dialog.open(AddServerDialogComponent, dialogConfig);
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}

export enum EnvironmentEnum {
    DEV = 'DEV',
    TQS = 'TQS'
}

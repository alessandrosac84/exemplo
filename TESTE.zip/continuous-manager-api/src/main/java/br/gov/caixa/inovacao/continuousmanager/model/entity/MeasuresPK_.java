package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-05-18T12:45:44.218-0300")
@StaticMetamodel(MeasuresPK.class)
public class MeasuresPK_ {
	public static volatile SingularAttribute<MeasuresPK, String> project;
	public static volatile SingularAttribute<MeasuresPK, String> wallet;
	public static volatile SingularAttribute<MeasuresPK, String> commit;
}

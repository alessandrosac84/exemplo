package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;

/**
 * Classe de servicos de Version.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class DeployService {

	@Inject
	private Logger log;
	
	@Inject
	private JenkinsService jenkinsService;
	
	/**
	 * Gera uma nova versão do projeto para TQS
	 * 
	 * @param wallet
	 * @param project
	 * @param job
	 * @param commit
	 * @param version
	 */
	public void deploy(String wallet, String project, @NotNull @Pattern(regexp="[a-zA-Z0-9][a-zA-Z0-9\\.]*[a-zA-Z0-9]") String version) {
		log.fine("Iniciando Deploy");
		String job = project + "-cd-tqs";
		jenkinsService.createDeploy(wallet, project, job, version);
	}
}
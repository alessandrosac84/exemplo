package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the atividade_funcionario database table.
 * 
 */
@Entity
@Table(name="atividade_funcionario")
@NamedQueries({		
	@NamedQuery(name="AtividadeFuncionario.findAll", query="SELECT a FROM AtividadeFuncionario a"),
	@NamedQuery(name="AtividadeFuncionario.findByAtividade", query="SELECT a FROM AtividadeFuncionario a WHERE a.id.atividade = :atividade")
})
public class AtividadeFuncionario extends AuditedEntity implements Serializable, IEntity<AtividadeFuncionarioPK> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AtividadeFuncionarioPK id;

	//bi-directional many-to-one association to Atividade
	@ManyToOne
	@JoinColumn(name="atividade", nullable=false, insertable=false, updatable=false)
	private Atividade atividade;

	//bi-directional many-to-one association to Funcionario
	@ManyToOne
	@JoinColumn(name="funcionario", nullable=false, insertable=false, updatable=false)
	private Funcionario funcionario;

	public AtividadeFuncionario() {
	}

	public AtividadeFuncionarioPK getId() {
		return this.id;
	}

	public void setId(AtividadeFuncionarioPK id) {
		this.id = id;
	}

	public Atividade getAtividade() {
		return this.atividade;
	}

	public void setAtividade(Atividade atividade) {
		this.atividade = atividade;
	}

	public Funcionario getFuncionario() {
		return this.funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	@Override
	public boolean isTheSameObject(IEntity<AtividadeFuncionarioPK> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		AtividadeFuncionario other = (AtividadeFuncionario) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof AtividadeFuncionario))
			return false;
		AtividadeFuncionario other = (AtividadeFuncionario) obj;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
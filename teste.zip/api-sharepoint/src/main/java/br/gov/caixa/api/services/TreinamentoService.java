package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.TreinamentoDto;
import br.gov.caixa.api.model.Treinamento;
import br.gov.caixa.api.repository.TreinamentoRepository;
import br.gov.caixa.api.result.TreinamentoResult;

@Named
public class TreinamentoService {
	
	@Inject
	private TreinamentoRepository repository;
	
	public TreinamentoResult save(TreinamentoDto dto) {
		Treinamento treinamento = Treinamento.fromDtoToTreinamento(dto);
		repository.save(treinamento);
		TreinamentoResult result = new TreinamentoResult();
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public TreinamentoResult delete(Long id) {
		TreinamentoResult result = new TreinamentoResult();
		
		try {
			repository.delete(id);			
			result.setMessage("Executado com sucesso.");
		}
		catch(Exception ex)
		{
			result.setIsError(true);
			result.setMessage("OPs! N�o foi Poss�vel Excluir o Treinamento. Detalhes: " + ex.toString());
		}
		return result;
	}
	
	public TreinamentoResult get(Long id) {		
		Treinamento treinamento = repository.findOne(id);
		TreinamentoDto dto = TreinamentoDto.fromTreinamentoToDto(treinamento);
		TreinamentoResult result = new TreinamentoResult();
		result.setTreinamento(dto);
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public TreinamentoResult getAll() {
		List<Treinamento> listaTreinamento = repository.findAll();
		TreinamentoResult result = new TreinamentoResult();
		result.setList(TreinamentoDto.fromTreinamentoToListDto(listaTreinamento));
		result.setMessage("Executado com sucesso.");
		return result;
	}

	public TreinamentoResult getAllAlfa() {
		List<Treinamento> listaTreinamento = repository.findAllOrderByNome();
		TreinamentoResult result = new TreinamentoResult();
		result.setList(TreinamentoDto.fromTreinamentoToListDto(listaTreinamento));
		result.setMessage("Executado com sucesso.");
		return result;
	}
}

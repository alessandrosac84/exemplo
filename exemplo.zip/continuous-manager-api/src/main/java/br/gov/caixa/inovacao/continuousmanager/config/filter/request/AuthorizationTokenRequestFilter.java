/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.filter.request;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Priority;
import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

/**
 * Filtro para validação da Autorização de acesso ao recurso
 * 
 * @author Fabio Iwakoshi
 *
 */
@Provider
@Priority(Priorities.AUTHORIZATION)
public class AuthorizationTokenRequestFilter implements ContainerRequestFilter {

	private static final String AUTH_FAILED = "auth-failed";
	
	@Context
	private ResourceInfo resourceInfo;

	@Context
	private HttpServletRequest request;

	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		Logger log = Logger.getLogger(this.getClass().getName());
		log.fine("Executando Request Filter Authorization... ");

		Method method = resourceInfo.getResourceMethod();

		// Método com DenyAll
		if ((resourceInfo.getResourceClass().isAnnotationPresent(DenyAll.class)
				&& !method.isAnnotationPresent(RolesAllowed.class) && !method.isAnnotationPresent(PermitAll.class))
				|| method.isAnnotationPresent(DenyAll.class)) {
			log.log(Level.SEVERE, "Recurso sem autorizacao");
			requestContext.setProperty(AUTH_FAILED, true);
			requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).build());
		}
	}
}

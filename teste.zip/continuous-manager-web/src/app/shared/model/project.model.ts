import { Job } from './job.model';
export class Project {
  public id: { id: string, wallet: string };
  public name: string;
  public gitRepo: String;
  public jobs: Job[];
}

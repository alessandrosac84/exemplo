package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public enum EditType {
	@JsonProperty("delete")	DELETE("delete"),
	@JsonProperty("add") ADD("add"),
	@JsonProperty("edit") EDIT("edit");
	
	private final String formatted;
	
	EditType(String formatted) {
        this.formatted = formatted;
    }
	
	@JsonCreator // This is the factory method and must be static
    public static EditType fromString(String string) {
        return Optional
            .ofNullable(formatMap.get(string))
            .orElseThrow(() -> new IllegalArgumentException(string));
    }
	
	private static Map<String, EditType> formatMap = Stream
	        .of(EditType.values())
	        .collect(Collectors.toMap(s -> s.formatted, Function.identity()));
}

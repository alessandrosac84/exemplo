/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BuildJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.JobJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ProjectJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.WalletJenkinsVO;

/**
 * Classe para criação de informações do Jenkins.
 * 
 * @author Fabio IWakoshi
 *
 */
public class JenkinsBuilder {
	
	public static List<WalletJenkinsVO> createWallets() {
		// Folder 1
		List<WalletJenkinsVO> wallets = new ArrayList<>();
		
		WalletJenkinsVO walletJenkinsVO1 = new WalletJenkinsVO();
		walletJenkinsVO1.setDisplayName("Inovacao");
		walletJenkinsVO1.setName("inovacao");
		wallets.add(walletJenkinsVO1);
		
		WalletJenkinsVO walletJenkinsVO2 = new WalletJenkinsVO();
		walletJenkinsVO2.setDisplayName("Sharepoint");
		walletJenkinsVO2.setName("sharepoint");
		wallets.add(walletJenkinsVO2);
		
		return wallets;
	}

	public static List<ProjectJenkinsVO> createProjects() {
		// Folder 1
		List<ProjectJenkinsVO> projects = new ArrayList<>();
		
		ProjectJenkinsVO projectJenkinsVO1 = new ProjectJenkinsVO();
		projectJenkinsVO1.setDisplayName("Jenkins Manager");
		projectJenkinsVO1.setName("jenkinsman");
		projects.add(projectJenkinsVO1);
		
		ProjectJenkinsVO projectJenkinsVO2 = new ProjectJenkinsVO();
		projectJenkinsVO2.setDisplayName("Sharepoint");
		projectJenkinsVO2.setName("sharepoint");
		projects.add(projectJenkinsVO2);
		
		return projects;
	}
		
	public static List<JobJenkinsVO> createJobs() {
		// Job 1
		List<JobJenkinsVO> jobs = new ArrayList<>();
		
		JobJenkinsVO jobJenkinsVO1 = new JobJenkinsVO();
		jobJenkinsVO1.setName("jenkinsman-api-cd-tqs");
		jobJenkinsVO1.setDisplayName("jenkinsman-api-cd-tqs");
		jobs.add(jobJenkinsVO1);
		
		JobJenkinsVO jobJenkinsVO2 = new JobJenkinsVO();
		jobJenkinsVO2.setName("jenkinsman-api-ci-dev");
		jobJenkinsVO2.setDisplayName("jenkinsman-api-ci-dev");
		jobs.add(jobJenkinsVO2);
		
		return jobs;
	}
		
	public static List<BuildJenkinsVO> createBuilds() {
		List<BuildJenkinsVO> buildJenkinsVOs = new ArrayList<>();
		
		buildJenkinsVOs.add(createBuild(169168, 169811, 18, JenkinsResult.FAILURE, 1504025849835l, null));
		buildJenkinsVOs.add(createBuild(3919, 169811, 17, JenkinsResult.FAILURE, 1504025707889l, null));
		buildJenkinsVOs.add(createBuild(22739, 169811, 16, JenkinsResult.FAILURE, 1504020675573l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(158769, 169811, 15, JenkinsResult.SUCCESS, 1503058673217l, null));
		buildJenkinsVOs.add(createBuild(181495, 169811, 14, JenkinsResult.SUCCESS, 1502971639390l, null));
		buildJenkinsVOs.add(createBuild(144102, 169811, 13, JenkinsResult.FAILURE, 1502971420388l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(85885, 169811, 12, JenkinsResult.FAILURE, 1502971043985l, null));
		buildJenkinsVOs.add(createBuild(48477, 169811, 11, JenkinsResult.FAILURE, 1502970611439l, null));
		buildJenkinsVOs.add(createBuild(51294, 169811, 10, JenkinsResult.FAILURE, 1502969915716l, null));
		buildJenkinsVOs.add(createBuild(68887, 169811, 9, JenkinsResult.FAILURE, 1502913580294l, null));
		buildJenkinsVOs.add(createBuild(50614, 169811, 8, JenkinsResult.FAILURE, 1502913331800l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(53687, 169811, 7, JenkinsResult.FAILURE, 1502912481760l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(148160, 169811, 6, JenkinsResult.FAILURE, 1502911761721l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(138044, 169811, 5, JenkinsResult.FAILURE, 1502911486703l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(143778, 169811, 4, JenkinsResult.FAILURE, 1502910888307l, null));
		buildJenkinsVOs.add(createBuild(149176, 169811, 3, JenkinsResult.FAILURE, 1502910571658l, "Started by GitLab push by Fabio Luis Iwakoshi da SIlva"));
		buildJenkinsVOs.add(createBuild(140672, 169811, 2, JenkinsResult.SUCCESS, 1502907018727l, null));
		buildJenkinsVOs.add(createBuild(212945, 169811, 1, JenkinsResult.SUCCESS, 1502895775627l, "Started by GitLab push by Alessandro Santos Antunes de Carvalho"));
		
		return buildJenkinsVOs;
	}
	
	private static BuildJenkinsVO createBuild (long duration, long estimated, int number, JenkinsResult result, long timestamp, String description) {
		BuildJenkinsVO buildJenkinsVO = new BuildJenkinsVO();
		buildJenkinsVO.setDescription(description);
		buildJenkinsVO.setDuration(duration);
		buildJenkinsVO.setEstimatedDuration(estimated);
		buildJenkinsVO.setNumber(number);
		buildJenkinsVO.setResult(result);
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp);
		buildJenkinsVO.setTimestamp(calendar);

		return buildJenkinsVO;
	}
}

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Wallet;
import br.gov.caixa.inovacao.continuousmanager.model.repository.WalletRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes do WalletService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class WalletServiceTest {
	
	@Mock
	private WalletRepository walletRepository;

	@InjectMocks
	private WalletService walletService;

	private List<Wallet> wallets;
	
	@Before
	public void before() {
		wallets = EntityBuilder.createWallets();
		UtilReflection.setField(walletService, "log", Logger.getLogger(WalletService.class.getName()));
	}
	
	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(walletRepository.findById(wallets.get(0).getId())).thenReturn(wallets.get(0));
		
		// Act
		Wallet wallet = walletService.findById(wallets.get(0).getId());

		// Then
		Assert.assertEquals("inovacao", wallet.getId());
		Assert.assertNotNull(wallet.getCreatedAt());
		Assert.assertEquals("Inovação", wallet.getName());
		//Assert.assertEquals(2, wallet.getProjects().size());
		Assert.assertNotNull(wallet.getUpdatedAt());
		Assert.assertEquals("f771274", wallet.getUserInsert());
		Assert.assertEquals("f771274", wallet.getUserUpdate());
	}
	
	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(walletRepository.findAll(0, 30, "", "id", AscDesc.ASC)).thenReturn(wallets);
		
		// Act
		List<Wallet> listWallets = walletService.findAll(0, 30, "", "id", AscDesc.ASC);

		// Then
		Assert.assertEquals(2, listWallets.size());
	}
	
	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(walletRepository.countAll("")).thenReturn((long) wallets.size());
		
		// Act
		Long contWallets = walletService.countAll("");

		// Then
		Assert.assertEquals(2, contWallets.longValue());
	}
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(walletRepository.save(wallets.get(0))).thenReturn(wallets.get(0));
		
		// Act
		Wallet wallet = walletService.save(wallets.get(0));

		// Then
		Assert.assertEquals(wallets.get(0).getId(), wallet.getId());
	}
}

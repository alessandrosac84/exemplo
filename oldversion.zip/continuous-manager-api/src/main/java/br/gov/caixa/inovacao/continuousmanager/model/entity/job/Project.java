package br.gov.caixa.inovacao.continuousmanager.model.entity.job;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGate;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ProjectBranch;

/**
 * The persistent class for the project database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name = "project")
@NamedQuery(name = "Project.findAll", query = "SELECT p FROM Project p")
public class Project extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonView(ViewJson.ProjectView.class)
	private ProjectPK id;

	@Column(name = "git_repo", length = 150)
	private String gitRepo;

	@JsonView({ ViewJson.ProjectView.class, ViewJson.SonarView.class })
	@Column(nullable = false, length = 50)
	private String name;
	
	@JsonView(ViewJson.JenkisfileView.class)
	@Column(name = "sonar_key", length = 100)
	private String sonarKey;
	
	@Column(name = "ativo_sharepoint")
	private Integer ativoSharepoint;

	// bi-directional many-to-one association to Wallet
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "wallet", nullable = false, insertable = false, updatable = false)
	private Wallet wallet;

	// bi-directional many-to-one association to Commit
	@JsonIgnore
	@JsonIgnoreProperties("project")
	@OneToMany(mappedBy = "project", fetch = FetchType.LAZY)
	private Set<Commit> commits;

	// bi-directional many-to-one association to Job
	@JsonIgnoreProperties("project")
	@OneToMany(mappedBy = "project", fetch = FetchType.LAZY)
	private Set<Job> jobs;
	
	//bi-directional many-to-one association to ProjectInstance
	@OneToMany(mappedBy="project", fetch = FetchType.LAZY)
	private Set<ProjectBranch> projectBranches;
	
	//bi-directional many-to-one association to QualityGate
	@OneToMany(mappedBy = "project", fetch = FetchType.LAZY)
	private Set<QualityGate> qualityGates;

	public Project() {
		/* class constructor intentionally left blank */
	}

	public ProjectPK getId() {
		return this.id;
	}

	public void setId(ProjectPK id) {
		this.id = id;
	}

	public String getGitRepo() {
		return this.gitRepo;
	}

	public void setGitRepo(String gitRepo) {
		this.gitRepo = gitRepo;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Commit> getCommits() {
		return this.commits;
	}

	public void setCommits(Set<Commit> commits) {
		this.commits = commits;
	}

	public Set<Job> getJobs() {
		return this.jobs;
	}

	public void setJobs(Set<Job> jobs) {
		this.jobs = jobs;
	}

	public Wallet getWallet() {
		return this.wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	/**
	 * @return the ativoSharepoint
	 */
	public Integer getAtivoSharepoint() {
		return ativoSharepoint;
	}

	/**
	 * @param ativoSharepoint the ativoSharepoint to set
	 */
	public void setAtivoSharepoint(Integer ativoSharepoint) {
		this.ativoSharepoint = ativoSharepoint;
	}

	/**
	 * @return the sonarKey
	 */
	public String getSonarKey() {
		return sonarKey;
	}

	/**
	 * @param sonarKey the sonarKey to set
	 */
	public void setSonarKey(String sonarKey) {
		this.sonarKey = sonarKey;
	}
	
	public Set<ProjectBranch> getProjectBranches() {
		return this.projectBranches;
	}

	public void setProjectBranches(Set<ProjectBranch> projectBranches) {
		this.projectBranches = projectBranches;
	}

	/**
	 * @return the qualityGates
	 */
	public Set<QualityGate> getQualityGates() {
		return qualityGates;
	}

	/**
	 * @param qualityGates the qualityGates to set
	 */
	public void setQualityGates(Set<QualityGate> qualityGates) {
		this.qualityGates = qualityGates;
	}
}
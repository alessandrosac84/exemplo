package br.gov.caixa.api.repository.views;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.gov.caixa.api.model.views.EspecialidadeFuncionarioAtividadeView;

public interface EspecialidadeFuncionarioAtividadeViewRepository extends JpaRepository<EspecialidadeFuncionarioAtividadeView, Long> {
		
	List<EspecialidadeFuncionarioAtividadeView> findByAtividadeId(Long atividadeId);
	
	List<EspecialidadeFuncionarioAtividadeView> findByAtividadeIdIn(List<Long> atividadeId);
	
	List<EspecialidadeFuncionarioAtividadeView> findByEspecialidadeIdAndAtividadeIdIn(Long especialidadeId, List<Long> atividadeId);
	
	List<EspecialidadeFuncionarioAtividadeView> findByEspecialidadeId(Long especialidadeId);

}

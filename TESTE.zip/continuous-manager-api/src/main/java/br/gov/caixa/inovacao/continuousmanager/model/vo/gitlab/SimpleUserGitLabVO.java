package br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe de representação do simples do Usuario do GitLab
 * 
 * @author Fabio Iwakoshi
 *
 */
public class SimpleUserGitLabVO implements Serializable {

	private static final long serialVersionUID = 7135215453417845094L;

	private String name;
	
	private String username;
	
	private Integer id;
	
	private String state;
	
	@JsonProperty("avatar_url")
	private String avatarUrl;

	@JsonProperty("web_url")
	private String webUrl;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the avatarUrl
	 */
	public String getAvatarUrl() {
		return avatarUrl;
	}

	/**
	 * @param avatarUrl the avatarUrl to set
	 */
	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}

	/**
	 * @return the webUrl
	 */
	public String getWebUrl() {
		return webUrl;
	}

	/**
	 * @param webUrl the webUrl to set
	 */
	public void setWebUrl(String webUrl) {
		this.webUrl = webUrl;
	}
}

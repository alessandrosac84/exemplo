package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeProcessoView;
import br.gov.caixa.api.result.BasicResult;

public class EspecialidadeProcessoViewResult extends BasicResult {
	private List<EspecialidadeProcessoView> list;
	private EspecialidadeProcessoView especialidadeProcessoView;

	public List<EspecialidadeProcessoView> getList() {
		return list;
	}

	public void setList(List<EspecialidadeProcessoView> list) {
		this.list = list;
	}

	public EspecialidadeProcessoView getEspecialidadeProcessoView() {
		return especialidadeProcessoView;
	}

	public void setEspecialidadeProcessoView(EspecialidadeProcessoView especialidadeProcessoView) {
		this.especialidadeProcessoView = especialidadeProcessoView;
	}
}
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ProjectPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ProjectPK_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Project_;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de acesso ao banco de dados da entidade Parameter.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class ProjectRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Metodo responsavel pela consulta paginada de projetos no banco de dados
	 * 
	 * @param projeto
	 * @return Project
	 */
	public Project findById(ProjectPK id) {
		return entityManager.find(Project.class, id);
	}

	/**
	 * Lista projetos por paginacao
	 * 
	 * @param offset
	 * @param limit
	 * @param search
	 * @param sort
	 * @param order
	 * @return Todos os projetos por paginacao
	 */
	public List<Project> findAll(String carteira, int offset, int limit, String search, String sort, AscDesc order) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Project> query = builder.createQuery(Project.class);
		Root<Project> from = query.from(Project.class);

		Predicate predicate = builder.like(builder.lower(from.get(Project_.id).get(ProjectPK_.id)), "%" + search.toLowerCase() + "%");
		predicate = builder.or(predicate, builder.like(builder.lower(from.get(Project_.name)), "%" + search.toLowerCase() + "%"));
		predicate = builder.and(predicate, builder.equal(from.get(Project_.id).get(ProjectPK_.wallet), carteira));

		Order ascDesc = builder.asc(from.get(Project_.id).get(sort));
		if (order != AscDesc.ASC) {
			ascDesc = builder.desc(from.get(Project_.id).get(sort));
		}

		return entityManager.createQuery(query.select(from).where(predicate).orderBy(ascDesc)).setFirstResult(offset)
				.setMaxResults(limit).getResultList();
	}

	/**
	 * Obtem o total de projetos
	 * @param search 
	 * @return Total de projetos
	 */
	public Long countAll(String carteira, String search) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);
		
		Root<Project> from = query.from(Project.class);

		Predicate predicate = builder.like(builder.lower(from.get(Project_.id).get(ProjectPK_.id)), "%" + search.toLowerCase() + "%");
		predicate = builder.or(predicate, builder.like(builder.lower(from.get(Project_.name)), "%" + search.toLowerCase() + "%"));
		predicate = builder.and(predicate, builder.equal(from.get(Project_.id).get(ProjectPK_.wallet), carteira));

		return entityManager.createQuery(query.select(builder.count(from)).where(predicate)).getSingleResult();
	}

	/**
	 * Salva projeto
	 * 
	 * @param project
	 * @return project
	 */
	public Project save(Project project) {
		entityManager.persist(project);
		return project;
	}
}

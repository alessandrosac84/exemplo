package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Path;

/**
 * Classe de acesso ao banco de dados da entidade Path.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class PathRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Salva Path
	 * 
	 * @param Path
	 * @return Path
	 */
	public Path save(Path path) {
		entityManager.persist(path);
		return path;
	}
}

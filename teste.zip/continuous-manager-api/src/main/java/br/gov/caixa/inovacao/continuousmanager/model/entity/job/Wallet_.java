package br.gov.caixa.inovacao.continuousmanager.model.entity.job;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity_;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-15T10:32:47.596-0300")
@StaticMetamodel(Wallet.class)
public class Wallet_ extends AuditedEntity_ {
	public static volatile SingularAttribute<Wallet, String> id;
	public static volatile SingularAttribute<Wallet, String> name;
	public static volatile SetAttribute<Wallet, Project> projects;
}

package br.gov.caixa.api.model.views;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.gov.caixa.api.dto.views.FuncionarioParticipanteDto;
import br.gov.caixa.api.model.StatusParticipante;

@Entity
@Table(name = "funcionario_participante")
public class FuncionarioParticipante {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "NOME", nullable = false)
	private String nome;
	
	@Column(name = "EMAIL")
	private String email;

	@Column(name = "MATRICULA", nullable = false)
	private String matricula;

	@Column(name = "CARGO", nullable = true)
	private String cargo;
	
	@Column(name = "PARTICIPANTE_ID")
	private Long participanteId;
	
	@Column(name = "PARTICIPACAO")
	private Boolean participacao;

	@Column(name = "TURMA_ID")
	private Long turmaId;
	
	@Column(name = "STATUS_PARTICIPANTE")
	private StatusParticipante statusParticipante;
		
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}	
	
	public Long getParticipanteId() {
		return participanteId;
	}

	public void setParticipanteId(Long participanteId) {
		this.participanteId = participanteId;
	}

	public Boolean getParticipacao() {
		return participacao;
	}

	public void setParticipacao(Boolean participacao) {
		this.participacao = participacao;
	}

	public Long getTurmaId() {
		return turmaId;
	}

	public void setTurmaId(Long turmaId) {
		this.turmaId = turmaId;
	}

	public StatusParticipante getStatusParticipante() {
		return statusParticipante;
	}

	public void setStatusParticipante(StatusParticipante statusParticipante) {
		this.statusParticipante = statusParticipante;
	}

	public static FuncionarioParticipante fromDtoToFuncionarioParticipante(FuncionarioParticipanteDto funcionarioParticipanteDto) {
		
		FuncionarioParticipante funcionarioParticipante = new FuncionarioParticipante();
		
		funcionarioParticipante.setUid(funcionarioParticipanteDto.getUid());
		funcionarioParticipante.setNome(funcionarioParticipanteDto.getNome());
		funcionarioParticipante.setEmail(funcionarioParticipanteDto.getEmail());
		funcionarioParticipante.setMatricula(funcionarioParticipanteDto.getMatricula());
		funcionarioParticipante.setCargo(funcionarioParticipanteDto.getCargo());				
		funcionarioParticipante.setTurmaId(funcionarioParticipanteDto.getTurmaId());
		funcionarioParticipante.setParticipacao(funcionarioParticipanteDto.getParticipacao());
		funcionarioParticipante.setParticipanteId(funcionarioParticipanteDto.getParticipanteId());
		funcionarioParticipante.setStatusParticipante(funcionarioParticipanteDto.getStatusParticipante());
		
		return funcionarioParticipante;
	}

	public static List<FuncionarioParticipante> fromDtoToListFuncionarioParticipante(List<FuncionarioParticipanteDto> funcionariosParticipantesDto) {
		 List<FuncionarioParticipante> result = new ArrayList<FuncionarioParticipante>();
		 
		 for (Iterator<FuncionarioParticipanteDto> iterator = funcionariosParticipantesDto.iterator(); iterator.hasNext();) {
			FuncionarioParticipanteDto dto = (FuncionarioParticipanteDto) iterator.next();
			result.add(fromDtoToFuncionarioParticipante(dto));
		}
		 
		return result;
	}
}
package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;


/**
 * The persistent class for the sonar database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name="sonar")
@NamedQuery(name="Sonar.findAll", query="SELECT s FROM Sonar s")
public class Sonar implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SonarPK id;

	@Column(nullable=false)
	private Integer bugs;

	@Column(name="code_smells", nullable=false)
	private Integer codeSmells;

	@Column(nullable=false, precision=4, scale=1)
	private BigDecimal coverages;

	@Column(nullable=false)
	private Integer debts;

	@Column(nullable=false, precision=4, scale=1)
	private BigDecimal duplications;

	@Column(nullable=false, length=100)
	private String key;

	@Column(nullable=false)
	private Integer lines;

	@Enumerated(EnumType.STRING)
	@Column(name="quality_gate", nullable=false, length=3)
	private QualityGate qualityGate;

	@Column(name="unit_tests", nullable=false)
	private Integer unitTests;

	@Column(nullable=false)
	private Integer vulnerabilities;

	@JsonIgnore
	//bi-directional one-to-one association to Project
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="project", referencedColumnName="id", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private Project project;

	public Sonar() {
		/* class constructor intentionally left blank */
	}

	public SonarPK getId() {
		return this.id;
	}

	public void setId(SonarPK id) {
		this.id = id;
	}

	public Integer getBugs() {
		return this.bugs;
	}

	public void setBugs(Integer bugs) {
		this.bugs = bugs;
	}

	public Integer getCodeSmells() {
		return this.codeSmells;
	}

	public void setCodeSmells(Integer codeSmells) {
		this.codeSmells = codeSmells;
	}

	public BigDecimal getCoverages() {
		return this.coverages;
	}

	public void setCoverages(BigDecimal coverages) {
		this.coverages = coverages;
	}

	public Integer getDebts() {
		return this.debts;
	}

	public void setDebts(Integer debts) {
		this.debts = debts;
	}

	public BigDecimal getDuplications() {
		return this.duplications;
	}

	public void setDuplications(BigDecimal duplications) {
		this.duplications = duplications;
	}

	public String getKey() {
		return this.key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Integer getLines() {
		return this.lines;
	}

	public void setLines(Integer lines) {
		this.lines = lines;
	}

	public QualityGate getQualityGate() {
		return this.qualityGate;
	}

	public void setQualityGate(QualityGate qualityGate) {
		this.qualityGate = qualityGate;
	}

	public Integer getUnitTests() {
		return this.unitTests;
	}

	public void setUnitTests(Integer unitTests) {
		this.unitTests = unitTests;
	}

	public Integer getVulnerabilities() {
		return this.vulnerabilities;
	}

	public void setVulnerabilities(Integer vulnerabilities) {
		this.vulnerabilities = vulnerabilities;
	}

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

}
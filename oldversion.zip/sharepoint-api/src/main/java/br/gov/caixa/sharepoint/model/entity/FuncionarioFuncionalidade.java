package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the funcionario_funcionalidade database table.
 * 
 */
@Entity
@Table(name="funcionario_funcionalidade")
@NamedQueries ({
	@NamedQuery(name="FuncionarioFuncionalidade.findAll", query="SELECT f FROM FuncionarioFuncionalidade f"),
	@NamedQuery(name="FuncionarioFuncionalidade.findFuncionariosByFuncionalidade", query="SELECT a FROM FuncionarioFuncionalidade a WHERE a.id.funcionalidade = :id")
})
public class FuncionarioFuncionalidade extends AuditedEntity implements Serializable, IEntity<FuncionarioFuncionalidadePK> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private FuncionarioFuncionalidadePK id;
	
	@JsonIgnore
	//bi-directional many-to-one association to Funcionario
	@ManyToOne
	@JoinColumn(name="funcionario", nullable=false, insertable=false, updatable=false)
	private Funcionario funcionario;

	@JsonIgnore
	//bi-directional many-to-one association to Funcionalidade
	@ManyToOne
	@JoinColumn(name="funcionalidade", nullable=false, insertable=false, updatable=false)
	private Funcionalidade funcionalidade;

	public FuncionarioFuncionalidade() {
	}

	public FuncionarioFuncionalidadePK getId() {
		return this.id;
	}

	public void setId(FuncionarioFuncionalidadePK id) {
		this.id = id;
	}
	
	public Funcionario getFuncionario() {
		return this.funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public Funcionalidade getFuncionalidade() {
		return this.funcionalidade;
	}

	public void setFuncionalidade(Funcionalidade funcionalidade) {
		this.funcionalidade = funcionalidade;
	}

	@Override
	public boolean isTheSameObject(IEntity<FuncionarioFuncionalidadePK> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		FuncionarioFuncionalidade other = (FuncionarioFuncionalidade) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
package br.gov.caixa.inovacao.continuousmanager.model.entity;

/**
 * @author Fabio Iwakoshi
 *
 */
public enum Action {
	INCLUIR, ALTERAR, EXCLUIR
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cm-builds',
  templateUrl: './builds.component.html',
  styles: []
})
export class BuildsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

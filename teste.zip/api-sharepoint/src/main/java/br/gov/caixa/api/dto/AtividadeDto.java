package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.Atividade;

public class AtividadeDto {

	private Long uid;
	private String nome;
	private DisciplinaDto disciplina;
	private Boolean ativo;
	private ComplementoDto complementoDto;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

	public DisciplinaDto getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(DisciplinaDto disciplina) {
		this.disciplina = disciplina;
	}

	public ComplementoDto getComplementoDto() {
		return complementoDto;
	}

	public void setComplementoDto(ComplementoDto complementoDto) {
		this.complementoDto = complementoDto;
	}

	public static AtividadeDto fromAtividadeToDto(Atividade atividade) {
		AtividadeDto dto = new AtividadeDto();
		dto.setUid(atividade.getUid());
		dto.setNome(atividade.getNome());
		dto.setAtivo(atividade.getAtivo());
		dto.setDisciplina(DisciplinaDto.fromDisciplinaToDto(atividade.getDisciplina()));
		
		if(atividade.getComplemento() != null)
			dto.setComplementoDto(ComplementoDto.fromComplementoToDto(atividade.getComplemento()));
		
		return dto;
	}

	public static List<AtividadeDto> fromAtividadeToListDto(List<Atividade> atividades) {

		List<AtividadeDto> returnList = new ArrayList<AtividadeDto>();			
		
		for (Atividade atividade : atividades) {
			
			AtividadeDto dto = new AtividadeDto();
			
			dto.setUid(atividade.getUid());
			dto.setNome(atividade.getNome());
			dto.setAtivo(atividade.getAtivo());
			dto.setDisciplina(DisciplinaDto.fromDisciplinaToDto(atividade.getDisciplina()));
			
			if (atividade.getComplemento() != null)
				dto.setComplementoDto(ComplementoDto.fromComplementoToDto(atividade.getComplemento()));
			
			returnList.add(dto);
			
		}
		
		return returnList;
	}

}

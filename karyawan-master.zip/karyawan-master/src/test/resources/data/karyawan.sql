DELETE FROM karyawan;
INSERT INTO karyawan (id, nama, keterangan) VALUES
('1', 'Monkey.D Luffy', 'Kapten bajak laut topi jerami'),
('2', 'Roronoa Zorro', 'Pengguna Pedang No.1 didunia'),
('3', 'Ussop', 'Penembak jitu'),
('4', 'Nami', 'Navigator kapal'),
('5', 'Tony tony Chopper', 'Dokter'),
('6', 'Robin', 'Arkeolog'),
('7', 'Sanji', 'Juru masak / koki'),
('8', 'Broook', 'Manusia Tengkorak'),
('9', 'Franky', 'Tukang Kapal');
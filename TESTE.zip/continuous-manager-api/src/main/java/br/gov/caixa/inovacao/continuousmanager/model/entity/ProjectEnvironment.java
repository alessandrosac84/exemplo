package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;


/**
 * The persistent class for the project_environment database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name="project_environment")
@NamedQuery(name="ProjectEnvironment.findAll", query="SELECT p FROM ProjectEnvironment p")
public class ProjectEnvironment extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonView(ViewJson.ProjectEnvironmentVO.class)
	@EmbeddedId
	private ProjectEnvironmentPK id;

	//bi-directional many-to-one association to Build
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="build", referencedColumnName="id", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="job", referencedColumnName="job", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="project", referencedColumnName="project", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	
	
	private Build build;

	public ProjectEnvironment() {
		/* class constructor intentionally left blank */
	}

	public ProjectEnvironmentPK getId() {
		return this.id;
	}

	public void setId(ProjectEnvironmentPK id) {
		this.id = id;
	}

	public Build getBuild() {
		return this.build;
	}

	public void setBuild(Build build) {
		this.build = build;
	}

}
package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Job;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.ProjectPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Wallet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildLogPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab.CommitGitLabVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BuildJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.JobJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.PayloadNotificationJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ProjectJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.WalletJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.Comparator;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.ConditionVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.HistorySonarVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.InfoSonarVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.MeasureHistorySonarVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.MeasuresSonarVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.QualityGateVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.TaskVO;
import br.gov.caixa.inovacao.continuousmanager.service.BuildLogService;
import br.gov.caixa.inovacao.continuousmanager.service.BuildService;
import br.gov.caixa.inovacao.continuousmanager.service.ChangeSetService;
import br.gov.caixa.inovacao.continuousmanager.service.CommitService;
import br.gov.caixa.inovacao.continuousmanager.service.JobService;
import br.gov.caixa.inovacao.continuousmanager.service.MeasuresService;
import br.gov.caixa.inovacao.continuousmanager.service.PathService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectEnvironmentService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectService;
import br.gov.caixa.inovacao.continuousmanager.service.QualityGateService;
import br.gov.caixa.inovacao.continuousmanager.service.WalletService;
import javassist.NotFoundException;

/**
 * Classe de testes do SonarWebhookService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class WebhookServiceTest {

	@Mock
	private JenkinsService jenkinsService;

	@Mock
	private WalletService walletService;

	@Mock
	private ProjectService projectService;

	@Mock
	private JobService jobService;

	@Mock
	private BuildService buildService;

	@Mock
	private BuildLogService buildLogService;

	@Mock
	private CommitService commitService;

	@Mock
	private PathService pathService;

	@Mock
	private ChangeSetService changeSetService;

	@Mock
	private MeasuresService measuresService;

	@Mock
	private SonarService sonarService;

	@Mock
	private QualityGateService qualityGateService;

	@Mock
	private ProjectEnvironmentService projectEnvironmentService;

	@Mock
	private GitLabService gitLabService;

	@InjectMocks
	private WebhookService webhookService;

	private List<WalletJenkinsVO> wallets;
	private List<ProjectJenkinsVO> projects;
	private List<JobJenkinsVO> jobs;
	private List<BuildJenkinsVO> builds;
	private QualityGateVO qualityGateVO;

	@Before
	public void before() {
		wallets = JenkinsBuilder.createWallets();
		projects = JenkinsBuilder.createProjects();
		jobs = JenkinsBuilder.createJobs();
		builds = JenkinsBuilder.createBuilds();
		UtilReflection.setField(webhookService, "log", Logger.getLogger(WebhookService.class.getName()));
		
		qualityGateVO = new QualityGateVO();
		qualityGateVO.setConditions(new ArrayList<>());
		qualityGateVO.setId(1);
		qualityGateVO.setName("Sonarway");
		ConditionVO condition = new ConditionVO();
		condition.setError("1");
		condition.setId(1);
		condition.setMetric("metric");
		condition.setOp(Comparator.GT);
		condition.setPeriod(1);
		qualityGateVO.getConditions().add(condition);
	}

	@Test
	public void testCheckAll() throws InterruptedException {
		// Arrange
		Mockito.when(walletService.save(Mockito.<Wallet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(projectService.findById(Mockito.<ProjectPK>any())).thenReturn(null,
				EntityBuilder.createProjects().get(0));
		Mockito.when(projectService.save(Mockito.<Project>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jobService.save(Mockito.<Job>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(buildService.save(Mockito.<Build>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(sonarService.getQualityGates()).thenReturn(qualityGateVO);

		Mockito.when(jenkinsService.listWallets()).thenReturn(wallets);
		Mockito.when(jenkinsService.listProjects(wallets.get(0).getName())).thenReturn(projects);
		Mockito.when(jenkinsService.listJobs(Mockito.anyString(), Mockito.anyString())).thenReturn(jobs);
		Mockito.when(jenkinsService.listBuilds(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(builds);
		Mockito.when(
				jenkinsService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn("ERROR: Pipeline abortado por falha no Quality Gate: ERROR");

		// Act
		webhookService.add();
	}

	@Test
	public void testCheckByWallet() throws InterruptedException {
		// Arrange
		Mockito.when(walletService.save(Mockito.<Wallet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(projectService.findById(Mockito.<ProjectPK>any())).thenReturn(null,
				EntityBuilder.createProjects().get(0));
		Mockito.when(projectService.save(Mockito.<Project>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jobService.save(Mockito.<Job>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(buildService.save(Mockito.<Build>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(sonarService.getQualityGates()).thenReturn(qualityGateVO);

		Mockito.when(jenkinsService.listWallets()).thenReturn(wallets);
		Mockito.when(jenkinsService.listProjects(wallets.get(0).getName())).thenReturn(projects);
		Mockito.when(jenkinsService.listJobs(Mockito.anyString(), Mockito.anyString())).thenReturn(jobs);
		Mockito.when(jenkinsService.listBuilds(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(builds);
		Mockito.when(
				jenkinsService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn("ERROR: Pipeline abortado por falha no Quality Gate: ERROR");

		// Act
		webhookService.add("inovacao");
	}

	@Test
	public void testCheckByWalletProject() throws InterruptedException {
		// Arrange
		Mockito.when(walletService.save(Mockito.<Wallet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(projectService.findById(Mockito.<ProjectPK>any())).thenReturn(null,
				EntityBuilder.createProjects().get(0));
		Mockito.when(projectService.save(Mockito.<Project>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jobService.save(Mockito.<Job>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(buildService.save(Mockito.<Build>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(sonarService.getQualityGates()).thenReturn(qualityGateVO);

		Mockito.when(jenkinsService.listWallets()).thenReturn(wallets);
		Mockito.when(jenkinsService.listProjects(wallets.get(0).getName())).thenReturn(projects);
		Mockito.when(jenkinsService.listJobs(Mockito.anyString(), Mockito.anyString())).thenReturn(jobs);
		Mockito.when(jenkinsService.listBuilds(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(builds);
		Mockito.when(
				jenkinsService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn("ERROR: Pipeline abortado por falha no Quality Gate: ERROR");

		// Act
		webhookService.add("inovacao", "continuous-manager-web");
	}

	@Test
	public void testCheckByWalletProjectJob() throws InterruptedException {
		// Arrange
		Mockito.when(walletService.save(Mockito.<Wallet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(projectService.findById(Mockito.<ProjectPK>any())).thenReturn(null,
				EntityBuilder.createProjects().get(0));
		Mockito.when(projectService.save(Mockito.<Project>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jobService.save(Mockito.<Job>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(buildService.save(Mockito.<Build>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(sonarService.getQualityGates()).thenReturn(qualityGateVO);

		Mockito.when(jenkinsService.listWallets()).thenReturn(wallets);
		Mockito.when(jenkinsService.listProjects(wallets.get(0).getName())).thenReturn(projects);
		Mockito.when(jenkinsService.listJobs(Mockito.anyString(), Mockito.anyString())).thenReturn(jobs);
		Mockito.when(jenkinsService.listBuilds(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(builds);
		Mockito.when(
				jenkinsService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn("ERROR: Pipeline abortado por falha no Quality Gate: ERROR");

		// Act
		webhookService.add("inovacao", "continuous-manager-web", "continuous-manager-web-ci-dev");
	}

	@Test
	public void testCheckByWalletProjectJobBuild() throws InterruptedException {
		// Arrange
		Mockito.when(walletService.save(Mockito.<Wallet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(projectService.findById(Mockito.<ProjectPK>any())).thenReturn(null,
				EntityBuilder.createProjects().get(0));
		Mockito.when(projectService.save(Mockito.<Project>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jobService.save(Mockito.<Job>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(buildService.save(Mockito.<Build>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(sonarService.getQualityGates()).thenReturn(qualityGateVO);

		Mockito.when(jenkinsService.listWallets()).thenReturn(wallets);
		Mockito.when(jenkinsService.listProjects(wallets.get(0).getName())).thenReturn(projects);
		Mockito.when(jenkinsService.listJobs(Mockito.anyString(), Mockito.anyString())).thenReturn(jobs);
		Mockito.when(jenkinsService.listBuilds(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(builds);
		Mockito.when(
				jenkinsService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn("ERROR: Pipeline abortado por falha no Quality Gate: ERROR");

		// Act
		webhookService.add("inovacao", "continuous-manager-web", "continuous-manager-web-ci-dev", "65");
	}

	@Test
	public void testUpdate() throws InterruptedException, JsonParseException, JsonMappingException, IOException, NotFoundException {
		// Arrange
		InfoSonarVO infoSonarVO = new InfoSonarVO();
		infoSonarVO.setTask(new TaskVO());
		infoSonarVO.getTask().setAnalysisId("askkjsakdjaklçsdjnkjas");
		infoSonarVO.getTask().setComponentId("asdas5das4d4as6d");
		infoSonarVO.getTask().setComponentKey("br.gov.br.inovacao:continuous-manager");
		
		MeasureHistorySonarVO measureVO = new MeasureHistorySonarVO();
		measureVO.setMeasures(new ArrayList<>());

		measureVO.getMeasures().add(createMeasure("complexity"));
		measureVO.getMeasures().add(createMeasure("lines"));
		measureVO.getMeasures().add(createMeasure("bugs"));
		measureVO.getMeasures().add(createMeasure("vulnerabilities"));
		measureVO.getMeasures().add(createMeasure("code_smells"));
		measureVO.getMeasures().add(createMeasure("coverage"));
		measureVO.getMeasures().add(createMeasure("tests"));
		measureVO.getMeasures().add(createMeasure("duplicated_lines"));
		measureVO.getMeasures().add(createMeasure("duplicated_lines_density"));
		measureVO.getMeasures().add(createMeasure("comment_lines"));
		measureVO.getMeasures().add(createMeasure("comment_lines_density"));
		measureVO.getMeasures().add(createMeasure("violations"));
		measureVO.getMeasures().add(createMeasure("sqale_rating"));
		measureVO.getMeasures().add(createMeasure("security_rating"));
		measureVO.getMeasures().add(createMeasure("reliability_rating"));
		measureVO.getMeasures().add(createMeasure("files"));
		measureVO.getMeasures().add(createMeasure("new_files"));
		measureVO.getMeasures().add(createMeasure("new_code_smells"));
		measureVO.getMeasures().add(createMeasure("new_coverage"));
		measureVO.getMeasures().add(createMeasure("new_lines"));
		measureVO.getMeasures().add(createMeasure("new_vulnerabilities"));
		measureVO.getMeasures().add(createMeasure("new_bugs"));
		measureVO.getMeasures().add(createMeasure("new_duplicated_lines"));
		measureVO.getMeasures().add(createMeasure("new_duplicated_lines_density"));
		measureVO.getMeasures().add(createMeasure("new_violations"));
		measureVO.getMeasures().add(createMeasure("new_maintainability_rating"));
		measureVO.getMeasures().add(createMeasure("new_security_rating"));
		measureVO.getMeasures().add(createMeasure("new_reliability_rating"));
		
		Mockito.when(projectService.findById(Mockito.<ProjectPK>any()))
				.thenReturn(EntityBuilder.createProjects().get(1));
		Mockito.when(buildService.findById(Mockito.<BuildPK>any())).thenReturn(EntityBuilder.createBuilds().get(1));
		Mockito.when(buildLogService.findById(Mockito.<BuildLogPK>any()))
				.thenReturn(EntityBuilder.createBuildLogs(EntityBuilder.createBuilds().get(1)).get(0));
		
		Mockito.when(measuresService.findById(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
		.thenReturn(null);

		Mockito.when(sonarService.getInfoSonar(Mockito.anyString())).thenReturn(infoSonarVO);
		Mockito.when(sonarService.getMeasuresHistory(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(measureVO);
		
		Mockito.when(commitService.save(Mockito.<Commit>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jenkinsService.listBuilds(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(builds);
		Mockito.when(
				jenkinsService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(EntityBuilder.createBuildLogs(EntityBuilder.createBuilds().get(0)).get(0).getLog());

		PayloadNotificationJenkinsVO payload = new ObjectMapper().readValue(
				"{\"name\":\"continuous-manager-web-ci-dev\","
						+ "\"display_name\":\"Continuous Manager WEB - CI DEV\",\"url\":\"job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/\","
						+ "\"build\":{\"full_url\":\"https://jenkins.caixa/job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/2/\","
						+ "\"number\":2,\"queue_id\":49,\"timestamp\":1524778793601,\"phase\":\"COMPLETED\",\"status\":\"SUCCESS\","
						+ "\"url\":\"job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/2/\",\"scm\":{},"
						+ "\"parameters\":{\"commit\":\"b9257a9a145d753f90bed0e2ead0fe9272272391\"},\"log\":\"\",\"artifacts\":{}}}",
				PayloadNotificationJenkinsVO.class);

		// Act
		webhookService.update(payload);
	}

	private MeasuresSonarVO createMeasure(String metric) {
		MeasuresSonarVO item1 = new MeasuresSonarVO();
		item1.setMetric(metric);
		item1.setHistory(new ArrayList<>());
		item1.getHistory().add(new HistorySonarVO());
		item1.getHistory().get(0).setDate(Calendar.getInstance());
		item1.getHistory().get(0).setValue("1");
		return item1;
	}

	@Test
	public void testAddOnStart() throws InterruptedException, JsonParseException, JsonMappingException, IOException {
		// Arrange
		Mockito.when(walletService.save(Mockito.<Wallet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(projectService.findById(Mockito.<ProjectPK>any())).thenReturn(null,
				EntityBuilder.createProjects().get(0));
		Mockito.when(projectService.save(Mockito.<Project>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jobService.save(Mockito.<Job>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(buildService.save(Mockito.<Build>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(sonarService.getQualityGates()).thenReturn(qualityGateVO);

		Mockito.when(jenkinsService.listWallets()).thenReturn(wallets);
		Mockito.when(jenkinsService.listProjects(wallets.get(0).getName())).thenReturn(projects);
		Mockito.when(jenkinsService.listJobs(Mockito.anyString(), Mockito.anyString())).thenReturn(jobs);
		Mockito.when(jenkinsService.listBuilds(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(builds);
		Mockito.when(
				jenkinsService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn("ERROR: Pipeline abortado por falha no Quality Gate: ERROR");
		Mockito.when(gitLabService.getCommit(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(new CommitGitLabVO());

		builds.forEach(b -> {
			b.getChangeSets().clear();
		});

		PayloadNotificationJenkinsVO payload = new ObjectMapper().readValue(
				"{\"name\":\"continuous-manager-web-ci-dev\","
						+ "\"display_name\":\"Continuous Manager WEB - CI DEV\",\"url\":\"job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/\","
						+ "\"build\":{\"full_url\":\"https://jenkins.caixa/job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/2/\","
						+ "\"number\":2,\"queue_id\":49,\"timestamp\":1524778793601,\"phase\":\"STARTED\",\"status\":\"SUCCESS\","
						+ "\"url\":\"job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/2/\",\"scm\":{},"
						+ "\"parameters\":{\"commit\":\"b9257a9a145d753f90bed0e2ead0fe9272272391\"},\"log\":\"\",\"artifacts\":{}}}",
				PayloadNotificationJenkinsVO.class);

		// Act
		webhookService.add(payload);
	}

	@Test
	public void testAddOnStartCommitNull() throws InterruptedException, JsonParseException, JsonMappingException, IOException {
		// Arrange
		Mockito.when(walletService.save(Mockito.<Wallet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(projectService.findById(Mockito.<ProjectPK>any())).thenReturn(null,
				EntityBuilder.createProjects().get(0));
		Mockito.when(projectService.save(Mockito.<Project>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jobService.save(Mockito.<Job>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(buildService.save(Mockito.<Build>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(sonarService.getQualityGates()).thenReturn(qualityGateVO);

		Mockito.when(jenkinsService.listWallets()).thenReturn(wallets);
		Mockito.when(jenkinsService.listProjects(wallets.get(0).getName())).thenReturn(projects);
		Mockito.when(jenkinsService.listJobs(Mockito.anyString(), Mockito.anyString())).thenReturn(jobs);
		Mockito.when(jenkinsService.listBuilds(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(builds);
		Mockito.when(
				jenkinsService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn("ERROR: Pipeline abortado por falha no Quality Gate: ERROR");

		builds.forEach(b -> {
			b.getChangeSets().clear();
		});

		PayloadNotificationJenkinsVO payload = new ObjectMapper().readValue(
				"{\"name\":\"continuous-manager-web-ci-dev\","
						+ "\"display_name\":\"Continuous Manager WEB - CI DEV\",\"url\":\"job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/\","
						+ "\"build\":{\"full_url\":\"https://jenkins.caixa/job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/2/\","
						+ "\"number\":2,\"queue_id\":49,\"timestamp\":1524778793601,\"phase\":\"STARTED\",\"status\":\"SUCCESS\","
						+ "\"url\":\"job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/2/\",\"scm\":{},"
						+ "\"parameters\":{\"commit\":\"b9257a9a145d753f90bed0e2ead0fe9272272391\"},\"log\":\"\",\"artifacts\":{}}}",
				PayloadNotificationJenkinsVO.class);

		// Act
		webhookService.add(payload);
	}

	@Test
	public void testAddOnStartLastBuiltRevisionNull() throws InterruptedException, JsonParseException, JsonMappingException, IOException {
		// Arrange
		Mockito.when(walletService.save(Mockito.<Wallet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(projectService.findById(Mockito.<ProjectPK>any())).thenReturn(null,
				EntityBuilder.createProjects().get(0));
		Mockito.when(projectService.save(Mockito.<Project>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jobService.save(Mockito.<Job>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(buildService.save(Mockito.<Build>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(sonarService.getQualityGates()).thenReturn(qualityGateVO);
		Mockito.when(commitService.save(Mockito.<Commit>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());

		Mockito.when(jenkinsService.listWallets()).thenReturn(wallets);
		Mockito.when(jenkinsService.listProjects(wallets.get(0).getName())).thenReturn(projects);
		Mockito.when(jenkinsService.listJobs(Mockito.anyString(), Mockito.anyString())).thenReturn(jobs);
		Mockito.when(jenkinsService.listBuilds(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(builds);
		Mockito.when(
				jenkinsService.getLog(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn("ERROR: Pipeline abortado por falha no Quality Gate: ERROR");

		builds.forEach(b -> {
			b.getChangeSets().clear();
		});

		PayloadNotificationJenkinsVO payload = new ObjectMapper().readValue(
				"{\"name\":\"continuous-manager-web-ci-dev\","
						+ "\"display_name\":\"Continuous Manager WEB - CI DEV\",\"url\":\"job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/\","
						+ "\"build\":{\"full_url\":\"https://jenkins.caixa/job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/2/\","
						+ "\"number\":2,\"queue_id\":49,\"timestamp\":1524778793601,\"phase\":\"STARTED\",\"status\":\"SUCCESS\","
						+ "\"url\":\"job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-tqs/2/\",\"scm\":{},"
						+ "\"parameters\":{\"commit\":\"b9257a9a145d753f90bed0e2ead0fe9272272391\"},\"log\":\"\",\"artifacts\":{}}}",
				PayloadNotificationJenkinsVO.class);

		// Act
		webhookService.add(payload);
	}
}

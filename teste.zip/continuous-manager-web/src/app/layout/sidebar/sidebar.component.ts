import { Component, OnInit, DoCheck, Input } from '@angular/core';

import { AuthService } from '../../shared/service/auth/auth.service';

@Component({
  selector: 'jmw-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit, DoCheck {

  @Input() opened: boolean;
  logged = false;

  constructor(private _authService: AuthService) { }

  ngOnInit() { }

  ngDoCheck() {
    this.logged = this._authService.isAuthenticated();
  }
}

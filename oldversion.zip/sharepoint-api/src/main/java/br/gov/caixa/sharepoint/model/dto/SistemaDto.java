/**
 * 
 */
package br.gov.caixa.sharepoint.model.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Fabio Iwakoshi
 *
 */
@XmlRootElement(name="sistema")
public class SistemaDto {
	
	private Integer id;
	
	private String sigla;
	
	private String alias;
	
	private String apelido;
	
	private boolean indicadorPCN;
	
	private String observacao;
	
	private Integer quantidadeImplantacao;
	
	private List<ArtefatoDto> artefatos;

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	@XmlElementWrapper(name="artefatos")
	@XmlElement(name="artefato")
	public List<ArtefatoDto> getArtefatos() {
		return artefatos;
	}

	public void setArtefatos(List<ArtefatoDto> artefatos) {
		this.artefatos = artefatos;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the indicadorPCN
	 */
	public boolean isIndicadorPCN() {
		return indicadorPCN;
	}

	/**
	 * @param indicadorPCN the indicadorPCN to set
	 */
	public void setIndicadorPCN(boolean indicadorPCN) {
		this.indicadorPCN = indicadorPCN;
	}

	/**
	 * @return the observacao
	 */
	public String getObservacao() {
		return observacao;
	}

	/**
	 * @param observacao the observacao to set
	 */
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	/**
	 * @return the quantidadeImplantacao
	 */
	public Integer getQuantidadeImplantacao() {
		return quantidadeImplantacao;
	}

	/**
	 * @param quantidadeImplantacao the quantidadeImplantacao to set
	 */
	public void setQuantidadeImplantacao(Integer quantidadeImplantacao) {
		this.quantidadeImplantacao = quantidadeImplantacao;
	}

}

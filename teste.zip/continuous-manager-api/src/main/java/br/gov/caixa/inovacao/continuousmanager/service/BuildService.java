/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.NoResultException;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.BuildRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de servicos de Build.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class BuildService {

	@Inject
	private Logger log;

	@Inject
	private BuildRepository buildRepository;

	public List<Build> findAll(String wallet, String project, String job, int offset, int limit, String search, String sort, AscDesc order) { //NOSONAR
		log.log(Level.FINE,
				"Listando Builds : offset :: {0} :: limit :: {1} :: search :: {2} :: sort :: {3} :: order :: {4}",
				new Object[] { offset, limit, search, sort, order });
		return buildRepository.findAll(wallet, project, job, offset, limit, search, sort, order);
	}

	public Long countAll(String wallet, String project, String job, String search) {
		log.log(Level.FINE, "Contando Builds: Carteira :: {0} :: Projeto {1} :: Job {2} :: Search :: {3}", new Object[] { wallet, project, job, search });
		return buildRepository.countAll(wallet, project, job, search);
	}

	public Build save(@Valid Build build) {
		log.log(Level.FINE, "Salvando Build :: {0}", build.getId());
		return buildRepository.save(build);
	}

	public Build findById(BuildPK id) {
		log.fine("Obtendo Build");
		try {
			return buildRepository.findById(id);
		} catch (NoResultException e) {
			log.log(Level.SEVERE, "Não foram encontrada informações da Build {0}!", id.getId());
			return null;
		} 
	}

	public Build findById(String wallet, String project, String job, Integer build) {
		log.fine("Obtendo Build IDs");
		BuildPK id = new BuildPK();
		id.setWallet(wallet);
		id.setProject(project);
		id.setJob(job);
		id.setId(build);
		
		return findById(id);
	}

	public Build update(Build build) {
		log.log(Level.FINE, "Atualizando Build :: {0}", build.getId());
		return buildRepository.update(build);
	}
}

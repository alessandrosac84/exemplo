package br.gov.caixa.inovacao.continuousmanager.config.threadlocal;

/**
 * @author Fabio Iwakoshi
 *
 */
public class HelperThreadLocal {
	
	private HelperThreadLocal() {}

	public static final ThreadLocal<String> IP = new ThreadLocal<>();
}

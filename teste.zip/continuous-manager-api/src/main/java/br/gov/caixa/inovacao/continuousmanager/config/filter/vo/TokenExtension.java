package br.gov.caixa.inovacao.continuousmanager.config.filter.vo;

import java.util.List;

public class TokenExtension {

	private List<Integer> ativos;
	
	private boolean admin;

	/**
	 * @return the ativos
	 */
	public List<Integer> getAtivos() {
		return ativos;
	}

	/**
	 * @param ativos the ativos to set
	 */
	public void setAtivos(List<Integer> ativos) {
		this.ativos = ativos;
	}

	/**
	 * @return the admin
	 */
	public boolean isAdmin() {
		return admin;
	}

	/**
	 * @param admin the admin to set
	 */
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	
	
}

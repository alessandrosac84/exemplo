package br.gov.caixa.api.controller.views;

import java.util.List;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.result.views.EspecialidadeFuncionarioFerramentaViewResult;
import br.gov.caixa.api.services.views.EspecialidadeFuncionarioFerramentaViewService;

@RestController
public class EspecialidadeFuncionarioFerramentaViewController {

	@Inject
	EspecialidadeFuncionarioFerramentaViewService service;

	@RequestMapping(value = "/api/especialidadeFuncionarioFuncionarioFerramentaView/all", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)	
	public EspecialidadeFuncionarioFerramentaViewResult listAll() {
		return service.listAll();
	}

//	@RequestMapping(value="/api/especialidadeFuncionarioFerramentaView/obterEspecialidadeFuncionarioFerramentaViewPorIdFerramenta/{idFerramenta}", method=RequestMethod.GET, produces = "application/json")
//	@ResponseStatus(HttpStatus.OK)
//	public EspecialidadeFuncionarioFerramentaViewResult obterAtivoPorIdFerramenta(@PathVariable Long idFerramenta) {
//		
//		return service.listEspecialidadeFuncionarioFerramentaViewsByIdFerramenta(idFerramenta);
//	}
//	                                                    
//	@RequestMapping(value="/api/especialidadeFuncionarioFerramentaView/obterEspecialidadeFuncionarioFerramentaViewPorIdsFerramenta", 
//			method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
//	
//	@ResponseStatus(HttpStatus.OK)
//	public EspecialidadeFuncionarioFerramentaViewResult obterAtivoPorIdsFerramenta(@RequestBody List<Long> idsFerramenta) {
//		
//		return service.listEspecialidadeFuncionarioFerramentasViewByIdsFerramenta(idsFerramenta);
//	}
	                                                                   
	@RequestMapping(value="/api/especialidadeFuncionarioFerramentaView/obterEspecialidadeFuncionarioFerramentaViewPorIdsFerramentaAndEspecialidade/{idEspecialidade}", 
			method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeFuncionarioFerramentaViewResult obterEspecialidadeFuncionarioFerramentaViewPorIdsFerramentaAndEspecialidade(
			@RequestBody List<Long> idsFerramenta, @PathVariable Long idEspecialidade) {
		
		return service.listEspecialidadeFuncionarioFerramentasViewByIdsFerramentaAndEspecialidadeId(idsFerramenta, idEspecialidade);
	}
	
	@RequestMapping(value="/api/especialidadeFuncionarioFerramentaView/obterEspecialidadeFuncionarioFerramentaViewPorEspecialidade/{idEspecialidade}", 
			method=RequestMethod.GET, produces = "application/json")
	
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeFuncionarioFerramentaViewResult obterEspecialidadeFuncionarioFerramentaViewPorEspecialidade(@PathVariable Long idEspecialidade) {
		
		return service.listEspecialidadeFuncionarioFerramentasViewByEspecialidadeId(idEspecialidade);
	}
	

}

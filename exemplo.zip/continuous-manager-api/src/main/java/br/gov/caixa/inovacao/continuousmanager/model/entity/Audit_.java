package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.util.Calendar;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-01-31T14:17:12.936-0200")
@StaticMetamodel(Audit.class)
public class Audit_ {
	public static volatile SingularAttribute<Audit, Long> id;
	public static volatile SingularAttribute<Audit, String> functionality;
	public static volatile SingularAttribute<Audit, String> ipEvent;
	public static volatile SingularAttribute<Audit, Calendar> timestampEvent;
	public static volatile SingularAttribute<Audit, String> userEvent;
	public static volatile SingularAttribute<Audit, Action> action;
	public static volatile SingularAttribute<Audit, String> entity;
}

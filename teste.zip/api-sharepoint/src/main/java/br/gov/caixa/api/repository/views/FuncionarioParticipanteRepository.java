package br.gov.caixa.api.repository.views;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.views.FuncionarioParticipante;

public interface FuncionarioParticipanteRepository extends JpaRepository<FuncionarioParticipante, Long> {

	@Query("select f from FuncionarioParticipante f where (f.turmaId is null or f.turmaId = ?1)")
	public List<FuncionarioParticipante> findByTurmaAndNulls(Long turmaId);

}




// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

// Add here your keycloak setup infos
const keycloakConfig = {
  url: 'https://login.des.caixa/auth',
  realm: 'intranet',
  clientId: 'cli-web-dep-guardiao',
  credentials: { secret: 'd019330d-b5e5-4da4-be02-db32598371c9'}
};

export const environment = {
  production: false,
  apis: { continuous: 'continuous-manager-api', sharepoint: 'sharepoint-api' },
  keycloak: keycloakConfig,
  hmr: false
};

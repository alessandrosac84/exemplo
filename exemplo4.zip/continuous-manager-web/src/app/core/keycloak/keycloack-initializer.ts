import { KeycloakService } from './keycloak.service';
import { EventStackService } from './event-stack.service';

export function keycloackInitializer(keycloakService: KeycloakService, eventStackService: EventStackService) {
  return () => {
    keycloakService.keycloakEvents$.subscribe(event => {
      eventStackService.triggerEvent(event);
    });
    keycloakService.init({ onLoad: 'check-sso' });
  };
}

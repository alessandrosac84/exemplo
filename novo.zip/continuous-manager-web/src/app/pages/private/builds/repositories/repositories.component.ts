import { Component, OnInit, Input } from '@angular/core';
import { Repository } from '../../../../shared/model/entity/repository.model';
import { Router } from '@angular/router';

@Component({
  selector: 'cm-repositories',
  templateUrl: './repositories.component.html',
  styles: []
})
export class RepositoryComponent implements OnInit {

  @Input() repository: Repository;

  constructor() { }

  ngOnInit() {
  }

  getClassSideDiv() {
    switch (this.repository.lastBuild.result) {
      case 'SUCCESS':
        return 'passed';
      case 'FAILURE':
        return 'not-passed';
      default:
        return 'not-compiled';
    }
  }

}

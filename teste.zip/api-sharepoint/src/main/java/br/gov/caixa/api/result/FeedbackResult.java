package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.FeedbackDto;

public class FeedbackResult extends BasicResult {

	private List<FeedbackDto> list;
	private FeedbackDto feedback;

	public List<FeedbackDto> getList() {
		return list;
	}

	public void setList(List<FeedbackDto> list) {
		this.list = list;
	}

	public FeedbackDto getFeedback() {
		return feedback;
	}

	public void setFeedback(FeedbackDto feedback) {
		this.feedback = feedback;
	}

}
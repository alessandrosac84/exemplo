package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-01-30T16:53:57.800-0200")
@StaticMetamodel(GitRepoPK.class)
public class GitRepoPK_ {
	public static volatile SingularAttribute<GitRepoPK, String> commit;
	public static volatile SingularAttribute<GitRepoPK, String> project;
	public static volatile SingularAttribute<GitRepoPK, String> wallet;
}

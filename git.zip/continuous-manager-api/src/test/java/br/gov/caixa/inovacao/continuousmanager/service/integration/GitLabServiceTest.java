package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.util.Calendar;
import java.util.logging.Logger;

import javax.ws.rs.NotFoundException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.ssl.SSLContexts;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab.CommitGitLabVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.gitlab.UserGitLabVO;
import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;

/**
 * Classe de testes do JenkinsService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ SSLContexts.class, ClientBuilder.class })
@PowerMockIgnore("javax.net.ssl.*")
public class GitLabServiceTest {
	
	@Rule
	public MockitoRule mrule = MockitoJUnit.rule();
	
	@Mock
	private ParameterService parameterService;
	
	@Mock
	private Response response;
	
	@Mock
	private ClientBuilder clientBuilder;
	
	@Mock
	private Client client;

	@Mock
	private WebTarget target;
	
	@Mock 
	private Invocation.Builder builder;
	
	@InjectMocks
	private GitLabService gitLabService;
	
	private Parameter parameter;
	
	@Before
	public void before() {
		parameter = new Parameter();
		parameter.setId(new ParameterPK());
		parameter.getId().setEnvironment(Environment.DES);
		parameter.getId().setServerType(ServerType.GITLAB);
		parameter.setCredential("");
		parameter.setHost("https://gitlab.caixa");
		parameter.setPrincipal("GitLab");
		UtilReflection.setField(gitLabService, "log", Logger.getLogger(GitLabService.class.getName()));
	}

	@Test(expected=NotFoundException.class)
	public void testNullParameters() {		
		// Act
		gitLabService.getUserByMatricula("f771274");
	}

	@Test
	public void testGetCommit() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class)).thenReturn("{\"id\": \"d43fc877c248ba45e2a61f4d5de485c228423286\","
				+ "\"short_id\": \"d43fc877\",\"title\": \"Merge remote-tracking branch 'origin/master'\","
				+ "\"created_at\": \"2017-11-22T11:15:21.000-02:00\",\"parent_ids\": [\"d49c4756276fa867bdcda467dfac3bb8fa536d12\","
				+ "\"10065fe03c89d9aa7e58f76105ee5da5baef2723\"],\"message\": \"Merge remote-tracking branch 'origin/master'\","
				+ "\"author_name\": \"Fabio Iwakoshi\",\"author_email\": \"fabio.iwakoshi@gmail.com\","
				+ "\"authored_date\": \"2017-11-22T11:15:21.000-02:00\",\"committer_name\": \"Fabio Iwakoshi\","
				+ "\"committer_email\": \"fabio.iwakoshi@gmail.com\",\"committed_date\": \"2017-11-22T11:15:21.000-02:00\"}");
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		CommitGitLabVO commit = gitLabService.getCommit("inovacao", "continuous-manager-web", "16a5s4da54s36re46a5sd");
		// Then
		Assert.assertEquals("fabio.iwakoshi@gmail.com", commit.getAuthorEmail());
		Assert.assertEquals("Fabio Iwakoshi", commit.getAuthorName());
		Assert.assertEquals("fabio.iwakoshi@gmail.com", commit.getCommitterEmail());
		Assert.assertEquals("Fabio Iwakoshi", commit.getCommitterName());
		Assert.assertTrue(commit.getCreatedAt().before(Calendar.getInstance()));
		Assert.assertEquals("d43fc877c248ba45e2a61f4d5de485c228423286", commit.getId());
		Assert.assertEquals("Merge remote-tracking branch 'origin/master'", commit.getMessage());
		Assert.assertEquals("Merge remote-tracking branch 'origin/master'", commit.getTitle());
		Assert.assertTrue(commit.getAuthoredDate().before(Calendar.getInstance()));
		Assert.assertTrue(commit.getCommittedDate().before(Calendar.getInstance()));
		Assert.assertEquals(2, commit.getParentIds().length);
		Assert.assertNull(commit.getStats());
		Assert.assertNull(commit.getStatus());
	}

	@Test
	public void testGetCommits() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class)).thenReturn("[{\"id\": \"d43fc877c248ba45e2a61f4d5de485c228423286\","
				+ "\"short_id\": \"d43fc877\",\"title\": \"Merge remote-tracking branch 'origin/master'\","
				+ "\"created_at\": \"2017-11-22T11:15:21.000-02:00\",\"parent_ids\": [\"d49c4756276fa867bdcda467dfac3bb8fa536d12\","
				+ "\"10065fe03c89d9aa7e58f76105ee5da5baef2723\"],\"message\": \"Merge remote-tracking branch 'origin/master'\","
				+ "\"author_name\": \"Fabio Iwakoshi\",\"author_email\": \"fabio.iwakoshi@gmail.com\","
				+ "\"authored_date\": \"2017-11-22T11:15:21.000-02:00\",\"committer_name\": \"Fabio Iwakoshi\","
				+ "\"committer_email\": \"fabio.iwakoshi@gmail.com\",\"committed_date\": \"2017-11-22T11:15:21.000-02:00\"}]");
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		gitLabService.getCommits("inovacao", "continuous-manager-web");
	}

	@Test
	public void testGetUserByMatricula() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
		
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
	    
	    Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class)).thenReturn("{\"name\": \"Continuous Manager\","
				+ "\"username\": \"continuous-manager-usr\",\"id\": 159,"
				+ "\"state\": \"active\",\"avatar_url\": null,\"web_url\": \"http://10.116.98.23/continuous-manager-usr\","
				+ "\"created_at\": \"2018-03-29T12:17:40.707Z\",\"is_admin\": false,\"bio\": null,\"location\": null,"
				+ "\"skype\": \"\",\"linkedin\": \"\",\"twitter\": \"\",\"website_url\": \"\",\"organization\": null,"
				+ "\"last_sign_in_at\": \"2018-04-13T10:25:32.590Z\",\"confirmed_at\": \"2018-03-29T12:17:40.597Z\","
				+ "\"last_activity_on\": \"2018-03-29\",\"email\": \"continuous-manager@example.com\",\"color_scheme_id\": 1,"
				+ "\"projects_limit\": 0,\"current_sign_in_at\": \"2018-04-13T10:26:23.202Z\",\"identities\": [],"
				+ "\"can_create_group\": false,\"can_create_project\": false,\"two_factor_enabled\": false,\"external\": false}");
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		UserGitLabVO gitLabVO = gitLabService.getUserByMatricula("f771274");
		// Then
		Assert.assertEquals(null, gitLabVO.getAvatarUrl());
		Assert.assertNotNull(gitLabVO.getIdentities());
		Assert.assertEquals(null, gitLabVO.getBio());
		Assert.assertEquals(1, gitLabVO.getColorSchemeId().intValue());
		Assert.assertTrue(gitLabVO.getConfirmedAt().before(Calendar.getInstance()));
		Assert.assertTrue(gitLabVO.getCreatedAt().before(Calendar.getInstance()));
		Assert.assertTrue(gitLabVO.getCurrentSignInAt().before(Calendar.getInstance()));
		Assert.assertEquals("continuous-manager@example.com", gitLabVO.getEmail());
		Assert.assertEquals(159, gitLabVO.getId().intValue());
		Assert.assertTrue(gitLabVO.getLastActivityOn().before(Calendar.getInstance()));
		Assert.assertTrue(gitLabVO.getLastSignInAt().before(Calendar.getInstance()));
		Assert.assertEquals("", gitLabVO.getLinkedin());
		Assert.assertEquals(null, gitLabVO.getLocation());
		Assert.assertEquals("Continuous Manager", gitLabVO.getName());
		Assert.assertEquals(null, gitLabVO.getOrganization());
		Assert.assertEquals(0, gitLabVO.getProjectsLimit().intValue());
		Assert.assertEquals("", gitLabVO.getSkype());
		Assert.assertEquals("active", gitLabVO.getState());
		Assert.assertEquals("", gitLabVO.getTwitter());
		Assert.assertEquals("continuous-manager-usr", gitLabVO.getUsername());
		Assert.assertEquals("", gitLabVO.getWebsiteUrl());
		Assert.assertEquals("http://10.116.98.23/continuous-manager-usr", gitLabVO.getWebUrl());
	}
}

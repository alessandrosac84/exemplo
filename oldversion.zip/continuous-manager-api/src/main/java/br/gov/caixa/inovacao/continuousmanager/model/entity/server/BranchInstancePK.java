package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the branch_instance database table.
 * 
 */
@Embeddable
public class BranchInstancePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String wallet;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String project;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=100)
	private String branch;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=15)
	private String server;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=50)
	private String instance;

	public BranchInstancePK() {
		/* class constructor intentionally left blank */
	}
	public String getWallet() {
		return this.wallet;
	}
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}
	public String getProject() {
		return this.project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getBranch() {
		return this.branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getServer() {
		return this.server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public String getInstance() {
		return this.instance;
	}
	public void setInstance(String instance) {
		this.instance = instance;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof BranchInstancePK)) {
			return false;
		}
		BranchInstancePK castOther = (BranchInstancePK)other;
		return 
			this.wallet.equals(castOther.wallet)
			&& this.project.equals(castOther.project)
			&& this.branch.equals(castOther.branch)
			&& this.server.equals(castOther.server)
			&& this.instance.equals(castOther.instance);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.wallet.hashCode();
		hash = hash * prime + this.project.hashCode();
		hash = hash * prime + this.branch.hashCode();
		hash = hash * prime + this.server.hashCode();
		hash = hash * prime + this.instance.hashCode();
		
		return hash;
	}
}
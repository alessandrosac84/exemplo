package br.gov.caixa.api.result;

public interface IResult {
	public String getMessage();
	public void setMessage(String message);		
}

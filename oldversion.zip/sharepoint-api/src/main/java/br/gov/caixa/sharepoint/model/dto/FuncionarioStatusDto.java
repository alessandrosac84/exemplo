/**
 * 
 */
package br.gov.caixa.sharepoint.model.dto;

import java.util.Calendar;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import br.gov.caixa.sharepoint.model.entity.StatusFuncionario;

/**
 * @author Fabio Iwakoshi
 *
 */
public class FuncionarioStatusDto {
	
	@NotNull
	@Past
	private Calendar statusDate;	
	
	@NotEmpty
	@Size(min=5, max=255)
	private String statusDetail;
	
	@NotNull
	private StatusFuncionario status;

	public Calendar getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(Calendar statusDate) {
		this.statusDate = statusDate;
	}	

	public StatusFuncionario getStatus() {
		return status;
	}

	public void setStatus(StatusFuncionario status) {
		this.status = status;
	}

	public String getStatusDetail() {
		return statusDetail;
	}

	public void setStatusDetail(String statusDetail) {
		this.statusDetail = statusDetail;
	}
	
	
	
}

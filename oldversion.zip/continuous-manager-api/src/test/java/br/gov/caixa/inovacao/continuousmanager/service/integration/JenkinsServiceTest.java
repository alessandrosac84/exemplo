package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.util.logging.Logger;

import javax.ws.rs.NotFoundException;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.ssl.SSLContexts;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;
import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;

/**
 * Classe de testes do JenkinsService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ SSLContexts.class, ClientBuilder.class })
@PowerMockIgnore("javax.net.ssl.*")
public class JenkinsServiceTest {
	
	@Rule
	public MockitoRule mrule = MockitoJUnit.rule();
	
	@Mock
	private ParameterService parameterService;
	
	@Mock
	private Response response;
	
	@Mock
	private ClientBuilder clientBuilder;
	
	@Mock
	private Client client;

	@Mock
	private WebTarget target;
	
	@Mock 
	private Invocation.Builder builder;
	
	@InjectMocks
	private JenkinsService jenkinsService;
	
	private Parameter parameter;
	
	@Before
	public void before() {
		parameter = new Parameter();
		parameter.setId(new ParameterPK());
		parameter.getId().setEnvironment(Environment.DES);
		parameter.getId().setServerType(ServerType.JENKINS);
		parameter.setCredential("");
		parameter.setHost("https://jenkins.caixa");
		parameter.setPrincipal("jenkins");
		UtilReflection.setField(jenkinsService, "log", Logger.getLogger(JenkinsService.class.getName()));
	}

	@Test(expected=NotFoundException.class)
	public void testNullParameters() {		
		// Act
		jenkinsService.listWallets();
	}

	@Test(expected=NotFoundException.class)
	public void testNotFoundException() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(builder.post(Mockito.any())).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(false);
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.listWallets();
	}

	@Test(expected=ServiceUnavailableException.class)
	public void testIOException() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(builder.post(Mockito.any())).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class)).thenReturn("{\"_class\":\"com.c}");
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.listWallets();
	}

	@Test
	public void testListWallets() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class)).thenReturn("{\"_class\":\"com.cloudbees.hudson.plugins.folder.Folder\","
				+ "\"jobs\":[{\"_class\":\"com.cloudbees.hudson.plugins.folder.Folder\",\"displayName\":\"Continuous Manager API\","
				+ "\"name\":\"continuous-manager-api\"},{\"_class\":\"com.cloudbees.hudson.plugins.folder.Folder\","
				+ "\"displayName\":\"Continuous Manager WEB\",\"name\":\"continuous-manager-web\"},"
				+ "{\"_class\":\"com.cloudbees.hudson.plugins.folder.Folder\",\"displayName\":\"Gestão Conhecimento API\","
				+ "\"name\":\"gestao-conhecimento-api\"},{\"_class\":\"com.cloudbees.hudson.plugins.folder.Folder\","
				+ "\"displayName\":\"Portal Inovação API\",\"name\":\"portal-inovacao-api\"},{\"_class\":\"com.cloudbees.hudson.plugins.folder.Folder\","
				+ "\"displayName\":\"Portal Inovação WEB\",\"name\":\"portal-inovacao-web\"},{\"_class\":\"com.cloudbees.hudson.plugins.folder.Folder\","
				+ "\"displayName\":\"Sharepoint API\",\"name\":\"sharepoint-api\"}]}");
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.listWallets();
	}

	@Test(expected=Exception.class)
	public void testListProjects() {
		// Arrange
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.listProjects("inovacao");
	}

	@Test(expected=Exception.class)
	public void testListJobs() {
		// Arrange
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.listJobs("inovacao", "portal-inovacao");
	}

	@Test(expected=Exception.class)
	public void testListBuilds() {
		// Arrange
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.listBuilds("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev");
	}

	@Test(expected=Exception.class)
	public void testCreateVersion() {
		// Arrange
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.createVersion("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", "7892387a6df85dsfdas", "2.0.0");
	}

	@Test
	public void testCreateDeploy() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(builder.post(Mockito.any())).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true, false);
		Mockito.when(response.readEntity(String.class)).thenReturn("{\"_class\":\"hudson.security.csrf.DefaultCrumbIssuer\",\"crumb\":\"d6e95394b96fa0f28018f5701f80b25c\",\"crumbRequestField\":\"Jenkins-Crumb\"}");
		Mockito.when(response.getStatus()).thenReturn(200, 201);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.createDeploy("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", "2.0.0");
	}

	@Test(expected=Exception.class)
	public void testCreateBuild() {
		// Arrange
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.createBuild("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", "7892387a6df85dsfdas", "2.0.0");
	}

	@Test
	public void testGetLog() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.path(Mockito.anyString())).thenReturn(target); 
	    Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
	    Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class)).thenReturn("{\"_class\":\"hudson.security.csrf.DefaultCrumbIssuer\",\"crumb\":\"d6e95394b96fa0f28018f5701f80b25c\",\"crumbRequestField\":\"Jenkins-Crumb\"}");
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);
		
		// Act
		jenkinsService.getLog("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 1);
	}

}

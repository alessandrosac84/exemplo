package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.ComplementoDto;
import br.gov.caixa.api.model.Complemento;
import br.gov.caixa.api.repository.ComplementoRepository;
import br.gov.caixa.api.result.ComplementoResult;

@Named
public class ComplementoService {

	@Inject
	ComplementoRepository repository;
	
	public ComplementoResult listAll() {
		List<Complemento> lista = (repository.findAll());
		ComplementoResult result = new ComplementoResult();
		
		result.setList(ComplementoDto.fromComplementoToListDto(lista));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}
	
	public ComplementoResult delete(ComplementoDto complementoDto) {
		
		Complemento complemento = new  Complemento();
		complemento.setUid(complementoDto.getUid());
		
		repository.delete(complemento);
		
		ComplementoResult result = new ComplementoResult();
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public ComplementoResult save(ComplementoDto complementoDto) {
		
		Complemento complemento = Complemento.fromDtoToComplemento(complementoDto);
		
		repository.save(complemento);
		
		ComplementoResult result = new ComplementoResult();
		result.setMessage("Executado com sucesso.");
		return result;
	}
}

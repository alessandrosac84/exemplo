package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;
import java.math.BigDecimal;

public class ConditionsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7155679762811447521L;
	
	/**
	 * 
	 */
	private String status;
	
	/**
	 * 
	 */
	private String metricKey;
	
	/**
	 * 
	 */
	private String comparator;
	
	/**
	 * 
	 */
	private Integer periodIndex;
	
	/**
	 * 
	 */
	private Integer errorThreshold;
	
	/**
	 * 
	 */
	private BigDecimal actualValue;

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the metricKey
	 */
	public String getMetricKey() {
		return metricKey;
	}

	/**
	 * @param metricKey the metricKey to set
	 */
	public void setMetricKey(String metricKey) {
		this.metricKey = metricKey;
	}

	/**
	 * @return the comparator
	 */
	public String getComparator() {
		return comparator;
	}

	/**
	 * @param comparator the comparator to set
	 */
	public void setComparator(String comparator) {
		this.comparator = comparator;
	}

	/**
	 * @return the periodIndex
	 */
	public Integer getPeriodIndex() {
		return periodIndex;
	}

	/**
	 * @param periodIndex the periodIndex to set
	 */
	public void setPeriodIndex(Integer periodIndex) {
		this.periodIndex = periodIndex;
	}

	/**
	 * @return the errorThreshold
	 */
	public Integer getErrorThreshold() {
		return errorThreshold;
	}

	/**
	 * @param errorThreshold the errorThreshold to set
	 */
	public void setErrorThreshold(Integer errorThreshold) {
		this.errorThreshold = errorThreshold;
	}

	/**
	 * @return the actualValue
	 */
	public BigDecimal getActualValue() {
		return actualValue;
	}

	/**
	 * @param actualValue the actualValue to set
	 */
	public void setActualValue(BigDecimal actualValue) {
		this.actualValue = actualValue;
	}

}

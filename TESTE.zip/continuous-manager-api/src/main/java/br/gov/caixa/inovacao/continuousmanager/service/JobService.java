/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Job;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JobPK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.JobRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de servicos de Job.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class JobService {

	@Inject
	private Logger log;

	@Inject
	private JobRepository jobRepository;

	public List<Job> findAll(String carteira, String projeto, int offset, int limit, String search, String sort, AscDesc order) {
		log.log(Level.FINE,
				"Listando Jobs : offset :: {0} :: limit :: {1} :: search :: {2} :: sort :: {3} :: order :: {4}",
				new Object[] { offset, limit, search, sort, order });
		return jobRepository.findAll(carteira, projeto, offset, limit, search, sort, order);
	}

	public Long countAll(String carteira, String projeto, String search) {
		log.log(Level.FINE, "Contando Jobs: Carteira :: {0} :: Projeto {1} :: Search :: {2}", new Object[] { carteira, projeto, search });
		return jobRepository.countAll(carteira, projeto, search);
	}

	public Job save(@Valid Job job) {
		log.log(Level.FINE, "Salvando Job :: {0}", job.getId());
		return jobRepository.save(job);
	}

	public Job findById(JobPK id) {
		log.fine("Obtendo Job");
		return jobRepository.findById(id);
	}

	public Job findById(String wallet, String project, String job) {
		JobPK id = new JobPK();
		id.setWallet(wallet);
		id.setProject(project);
		id.setId(job);
		return findById(id);
	}
}

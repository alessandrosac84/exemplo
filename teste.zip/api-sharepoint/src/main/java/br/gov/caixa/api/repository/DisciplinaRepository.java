package br.gov.caixa.api.repository;

import java.util.List;

import javax.persistence.OrderBy;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.Disciplina;
import br.gov.caixa.api.model.Metodologia;

public interface DisciplinaRepository extends JpaRepository<Disciplina, Long> {

	@OrderBy("uid") 
	public List<Disciplina> findByMetodologia(Metodologia metodologia);
	
	@Query("select d from Disciplina d where d.metodologia = ?1 order by d.nome")
	public List<Disciplina> findByMetodologiaOrderByNome(Metodologia metodologia);
	
	@Query("select d from Disciplina d where d.metodologia != 4 and d.metodologia != 3 ")
	public List<Disciplina> findExcecao();
}

package br.gov.caixa.api.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the busca_funcionario_coordencao database table.
 * 
 */
@Entity
@Table(name="busca_funcionario_coordenacao")
@NamedQuery(name="BuscaFuncionarioCoordenacao.findAll", query="SELECT b FROM BuscaFuncionarioCoordenacao b")
public class BuscaFuncionarioCoordenacao implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BuscaFuncionarioCoordencaoId buscaFuncionarioCoordencaoId;
	
	@Column(name="coordenacao_id", nullable=false, insertable=false, updatable=false)
	private Long coordenacaoId;

	@Column(name="funcionario_id", nullable=false, insertable=false, updatable=false)
	private Long funcionarioId;

	private String funcionario;
	
	private String matricula;
	
	private String nome;
	
	private String cargo;

	public BuscaFuncionarioCoordenacao() {
	}
	
	public BuscaFuncionarioCoordencaoId getBuscaFuncionarioCoordencaoId() {
		return buscaFuncionarioCoordencaoId;
	}

	public void setBuscaFuncionarioCoordencaoId(BuscaFuncionarioCoordencaoId buscaFuncionarioCoordencaoId) {
		this.buscaFuncionarioCoordencaoId = buscaFuncionarioCoordencaoId;
	}

	public Long getCoordenacaoId() {
		return this.coordenacaoId;
	}

	public void setCoordenacaoId(Long coordenacaoId) {
		this.coordenacaoId = coordenacaoId;
	}

	public Long getFuncionarioId() {
		return this.funcionarioId;
	}

	public void setFuncionarioId(Long funcionarioId) {
		this.funcionarioId = funcionarioId;
	}
	
	public String getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(String funcionario) {
		this.funcionario = funcionario;
	}
	
	public String getMatricula() {
		return this.matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

}
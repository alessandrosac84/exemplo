package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * The persistent class for the project database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name = "project")
@NamedQuery(name = "Project.findAll", query = "SELECT p FROM Project p")
public class Project extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonView(ViewJson.ProjectView.class)
	private ProjectPK id;

	@Column(name = "git_repo", length = 150)
	private String gitRepo;

	@JsonView({ ViewJson.ProjectView.class, ViewJson.SonarView.class })
	@Column(nullable = false, length = 50)
	private String name;
	
	@Column(name = "ativo_sharepoint")
	private Integer ativoSharepoint;

	// bi-directional many-to-one association to Commit
	@OneToMany(mappedBy = "project")
	private Set<Commit> commits;

	// bi-directional many-to-one association to Job
	@OneToMany(mappedBy = "project")
	private Set<Job> jobs;

	// bi-directional many-to-one association to Wallet
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "wallet", nullable = false, insertable = false, updatable = false)
	private Wallet wallet;

	public Project() {
		/* class constructor intentionally left blank */
	}

	public ProjectPK getId() {
		return this.id;
	}

	public void setId(ProjectPK id) {
		this.id = id;
	}

	public String getGitRepo() {
		return this.gitRepo;
	}

	public void setGitRepo(String gitRepo) {
		this.gitRepo = gitRepo;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Commit> getCommits() {
		return this.commits;
	}

	public void setCommits(Set<Commit> commits) {
		this.commits = commits;
	}

	public Commit addCommit(Commit commit) {
		getCommits().add(commit);
		commit.setProject(this);

		return commit;
	}

	public Commit removeCommit(Commit commit) {
		getCommits().remove(commit);
		commit.setProject(null);

		return commit;
	}

	public Set<Job> getJobs() {
		return this.jobs;
	}

	public void setJobs(Set<Job> jobs) {
		this.jobs = jobs;
	}

	public Job addJob(Job job) {
		getJobs().add(job);
		job.setProject(this);

		return job;
	}

	public Job removeJob(Job job) {
		getJobs().remove(job);
		job.setProject(null);

		return job;
	}

	public Wallet getWallet() {
		return this.wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	/**
	 * @return the ativoSharepoint
	 */
	public Integer getAtivoSharepoint() {
		return ativoSharepoint;
	}

	/**
	 * @param ativoSharepoint the ativoSharepoint to set
	 */
	public void setAtivoSharepoint(Integer ativoSharepoint) {
		this.ativoSharepoint = ativoSharepoint;
	}
}
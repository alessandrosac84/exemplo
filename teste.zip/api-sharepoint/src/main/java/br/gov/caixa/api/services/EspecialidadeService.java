package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.EspecialidadeDto;
import br.gov.caixa.api.model.Especialidade;
import br.gov.caixa.api.repository.EspecialidadeRepository;
import br.gov.caixa.api.result.EspecialidadeResult;

@Named
public class EspecialidadeService {
	
	@Inject
	EspecialidadeRepository repository;

	public EspecialidadeResult listAll() {
		List <Especialidade> especialidades = repository.findAll();
		
		EspecialidadeResult result = new EspecialidadeResult();
		
		result.setMessage("Executado com sucesso.");
		
		List<EspecialidadeDto> especialidadeDto = EspecialidadeDto.fromEspecialidadeToListDto(especialidades);
		result.setList(especialidadeDto);
		
		return result;
	}

	public EspecialidadeResult save(EspecialidadeDto dto) {
		Especialidade especialidade = Especialidade.fromDtoToEspecialidade(dto);
		
		repository.save(especialidade);
		
		EspecialidadeResult result = new EspecialidadeResult();
		result.setMessage("Executado com sucesso.");
		return result;
	}

	public EspecialidadeResult delete(EspecialidadeDto dto) {
		
		Especialidade especialidade = Especialidade.fromDtoToEspecialidade(dto);		
		EspecialidadeResult result;
		
		try {
			repository.delete(especialidade);
		
			result = new EspecialidadeResult();
			result.setMessage("Executado com sucesso.");
			
		} catch (Exception e) { 
			result = new EspecialidadeResult();
			
			result.setIsError(true);
			result.setMessage("Exclus�o n�o permitida H� Disciplinas, Recursos ou Processos Associados.");
			
			e.printStackTrace();
		}
		
		return result;
	}
	
}

package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.NoResultException;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.Measures;
import br.gov.caixa.inovacao.continuousmanager.model.repository.MeasuresRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de servicos do Sonar.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class MeasuresService {

	@Inject
	private Logger log;
	
	@Inject
	private MeasuresRepository measuresRepository;
	
	public List<Measures> findAll(int offset, int limit, String search, String sort, AscDesc order) {
		log.log(Level.FINE,
				"Listando Dashboards : offset :: {0} :: limit :: {1} :: search :: {2} :: sort :: {3} :: order :: {4}",
				new Object[] { offset, limit, search, sort, order });
		return measuresRepository.findAll(offset, limit, search, sort, order);
	}
	
	public Long countAll(String search) {
		log.log(Level.FINE, "Contando Dashboards:: search :: {0}", search);
		return measuresRepository.countAll(search);
	}
	
	public Measures findById(String wallet, String projeto, String commit) {
		log.fine("Obtendo detail item measure");
		try {
			return measuresRepository.findById(wallet, projeto, commit);
		} catch (NoResultException e) {
			log.log(Level.SEVERE, "Não foram encontrada informações de Measures!");
			return null;
		}
	}
	
	public Measures save (Measures measures) {
		log.fine("Salvando metricas do sonar");
		return measuresRepository.save(measures);
	}
}
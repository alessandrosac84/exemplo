package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;

/**
 * 
 * @author Alessandro Carvalho
 * 
 */
public class QualityGateVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6229430707520052115L;
	
	/**
	 * 
	 */
	private ProjectStatusVO projectStatus;

	/**
	 * @return the projectStatus
	 */
	public ProjectStatusVO getProjectStatus() {
		return projectStatus;
	}

	/**
	 * @param projectStatus the projectStatus to set
	 */
	public void setProjectStatus(ProjectStatusVO projectStatus) {
		this.projectStatus = projectStatus;
	}

}

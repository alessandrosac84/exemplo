package br.gov.caixa.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.gov.caixa.api.model.Questionario;

public interface QuestionarioRepository  extends JpaRepository<Questionario, Long> {
	
//	Questionario findByFuncionario(Funcionario funcionario);
//
//	Questionario findByFuncionarioMatricula(String matricula);		
}
	
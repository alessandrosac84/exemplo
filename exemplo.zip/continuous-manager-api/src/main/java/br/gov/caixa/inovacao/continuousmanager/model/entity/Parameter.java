package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the parameter database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Table(name="parameter")
@NamedQuery(name="Parameter.findAll", query="SELECT p FROM Parameter p")
public class Parameter implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ParameterPK id;

	@Column(length=200)
	private String credential;

	@Column(nullable=false, length=100)
	private String host;

	@Column(nullable=false, length=200)
	private String principal;

	public Parameter() {
		/* class constructor intentionally left blank */
	}

	public ParameterPK getId() {
		return this.id;
	}

	public void setId(ParameterPK id) {
		this.id = id;
	}

	public String getCredential() {
		return this.credential;
	}

	public void setCredential(String credential) {
		this.credential = credential;
	}

	public String getHost() {
		return this.host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPrincipal() {
		return this.principal;
	}

	public void setPrincipal(String principal) {
		this.principal = principal;
	}

}
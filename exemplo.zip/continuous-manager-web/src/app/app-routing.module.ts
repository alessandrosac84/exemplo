import { DevComponent } from './pages/dev/dev.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', loadChildren: 'app/pages/dashboard/dashboard.module#DashboardModule' },
  { path: 'log', loadChildren: 'app/pages/log/log.module#LogModule' },
  { path: 'dev', loadChildren: 'app/pages/dev/dev.module#DevModule' },
  { path: 'release', loadChildren: 'app/pages/release/release.module#ReleaseModule' },
  { path: 'sonar', loadChildren: 'app/pages/sonar/sonar.module#SonarModule' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

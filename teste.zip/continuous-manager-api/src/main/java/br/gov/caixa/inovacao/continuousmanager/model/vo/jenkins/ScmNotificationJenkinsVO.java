package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;

/**
 * Classe de representação do Scm de Notificacao do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class ScmNotificationJenkinsVO implements Serializable {

	private static final long serialVersionUID = -5077842626188514211L;
	
}

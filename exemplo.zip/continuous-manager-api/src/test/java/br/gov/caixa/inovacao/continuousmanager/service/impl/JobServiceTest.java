///**
// * 
// */
//package br.gov.caixa.inovacao.continuousmanager.service.impl;
//
//import java.util.List;
//import java.util.logging.Logger;
//
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.junit.MockitoJUnitRunner;
//
//import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
//import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsBuilder;
//import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.JobJenkinsVO;
//import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.SistemaJenkinsVO;
//import br.gov.caixa.inovacao.continuousmanager.service.JenkinsService;
//import br.gov.caixa.inovacao.continuousmanager.service.JobService;
//import br.gov.caixa.inovacao.continuousmanager.service.WalletService;
//
///**
// * Classe de testes do JobService.
// * 
// * @author Fabio Iwakoshi
// *
// */
//@RunWith(MockitoJUnitRunner.class)
//public class JobServiceTest {
//
//	@InjectMocks
//	private JobService jobService;
//
//	@Mock
//	private JenkinsService jenkinsService;
//	
//	private List<SistemaJenkinsVO> folders;
//
//	@Before
//	public void before() {
//		folders = JenkinsBuilder.createSistemas();
//		UtilReflection.setField(jobService, "log", Logger.getLogger(WalletService.class.getName()));
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.JobService#getJobs(int, int, java.lang.String)}.
//	 */
//	@Test
//	public void testFindAll() {
//		// Arrange
//		String nomeSistema = "sharepoint";
//		Mockito.when(jenkinsService.listJobs("sharepoint")).thenReturn(folders.get(0).getJobs());
//
//		// Act
//		List<JobJenkinsVO> folderList = jobService.listJobs(nomeSistema, 0, 0, "", "");
//
//		// Then
//		Assert.assertEquals(2, folderList.size());
//		Assert.assertNotNull(folderList.get(0).getName());
//		
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.JobService#countAllJobs(java.lang.String)}.
//	 */
//	@Test
//	public void testCountAll() {
//		// Arrange
//		Mockito.when(jenkinsService.countAllJobs("sharepoint")).thenReturn((long)folders.get(0).getJobs().size());
//
//		// Act
//		long count = jobService.countAll("sharepoint", "");
//
//		// Then
//		Assert.assertEquals(2, count);
//	}
//}

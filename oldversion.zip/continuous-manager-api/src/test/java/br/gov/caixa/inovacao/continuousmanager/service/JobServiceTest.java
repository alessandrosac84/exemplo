/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Job;
import br.gov.caixa.inovacao.continuousmanager.model.repository.JobRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes do JobService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class JobServiceTest {
	
	@Mock
	private JobRepository jobRepository;

	@InjectMocks
	private JobService jobService;

	private List<Job> jobs;
	
	@Before
	public void before() {
		jobs = EntityBuilder.createJobs();
		UtilReflection.setField(jobService, "log", Logger.getLogger(JobService.class.getName()));
	}
	
	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(jobRepository.findById(jobs.get(0).getId())).thenReturn(jobs.get(0));
		
		// Act
		Job job = jobService.findById(jobs.get(0).getId());

		// Then
		Assert.assertEquals("portal-inovacao-api-ci-dev", job.getId().getId());
		Assert.assertEquals("portal-inovacao", job.getId().getProject());
		Assert.assertEquals("inovacao", job.getId().getWallet());
		//Assert.assertNotNull(job.getBuilds());
		Assert.assertNotNull(job.getCreatedAt());
		Assert.assertEquals("Portal Inovacao - CI Dev", job.getName());
		//Assert.assertNull(job.getProject());
		Assert.assertNotNull(job.getUpdatedAt());
		Assert.assertEquals("f771274", job.getUserInsert());
		Assert.assertEquals("f771274", job.getUserUpdate());
	}
	
	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(jobRepository.findAll("inovacao", "portal-inovacao", 0, 30, "", "id", AscDesc.ASC)).thenReturn(jobs);
		
		// Act
		List<Job> listJobs = jobService.findAll("inovacao", "portal-inovacao", 0, 30, "", "id", AscDesc.ASC);

		// Then
		Assert.assertEquals(2, listJobs.size());
	}
	
	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(jobRepository.countAll("inovacao", "portal-inovacao", "")).thenReturn((long) jobs.size());
		
		// Act
		Long contJobs = jobService.countAll("inovacao", "portal-inovacao", "");

		// Then
		Assert.assertEquals(2, contJobs.longValue());
	}
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(jobRepository.save(jobs.get(0))).thenReturn(jobs.get(0));
		
		// Act
		Job job = jobService.save(jobs.get(0));

		// Then
		Assert.assertEquals(jobs.get(0).getId(), job.getId());
	}
}

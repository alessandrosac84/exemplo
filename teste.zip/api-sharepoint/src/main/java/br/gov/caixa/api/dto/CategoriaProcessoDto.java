package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.CategoriaProcesso;

public class CategoriaProcessoDto {

	private Long uid;
	private String nome;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public static CategoriaProcessoDto fromCategoriaProcessoToDto(CategoriaProcesso categoriaProcesso){
		CategoriaProcessoDto dto = new CategoriaProcessoDto();
		dto.setUid(categoriaProcesso.getUid());
		dto.setNome(categoriaProcesso.getNome());
		return dto;
	}

	public static List<CategoriaProcessoDto> fromCategoriaProcessoToListDto(List<CategoriaProcesso> lista) {
		List<CategoriaProcessoDto> list = new ArrayList<CategoriaProcessoDto>();
		for (CategoriaProcesso categoriaProcesso : lista) {
			CategoriaProcessoDto dto = new CategoriaProcessoDto();
			dto.setUid(categoriaProcesso.getUid());
			dto.setNome(categoriaProcesso.getNome());
			list.add(dto);
		}
		return list;
	}
}

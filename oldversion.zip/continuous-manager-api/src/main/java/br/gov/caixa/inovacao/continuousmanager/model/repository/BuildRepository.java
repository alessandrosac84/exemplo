package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.BuildPK_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSet_;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.model.vo.ResultVO;

/**
 * Classe de acesso ao banco de dados da entidade Build.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class BuildRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Metodo responsavel pela consulta paginada de Builds no banco de dados
	 * 
	 * @param Build
	 * @return Build
	 */
	public Build findById(BuildPK id) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Build> query = builder.createQuery(Build.class);
		Root<Build> from = query.from(Build.class);
		from.fetch(Build_.changeSets, JoinType.LEFT).fetch(ChangeSet_.commit, JoinType.LEFT);

		Predicate predicate = builder.equal(from.get(Build_.id), id);

		return entityManager.createQuery(query.select(from).where(predicate)).getSingleResult();
	}

	/**
	 * Lista Builds por paginacao
	 * 
	 * @param offset
	 * @param limit
	 * @param search
	 * @param sort
	 * @param order
	 * @return Todos os Builds por paginacao
	 */
	public List<Build> findAll(String carteira, String projeto, String job, int offset, int limit,
			String sort, AscDesc order) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Build> query = builder.createQuery(Build.class);
		Root<Build> from = query.from(Build.class);
		from.fetch(Build_.changeSets, JoinType.LEFT).fetch(ChangeSet_.commit, JoinType.LEFT);

		Predicate predicate = builder.equal(from.get(Build_.id).get(BuildPK_.wallet), carteira);
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.project), projeto));
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.job), job));

		Order ascDesc = builder.asc(from.get(Build_.id).get(sort));
		if (order != AscDesc.ASC) {
			ascDesc = builder.desc(from.get(Build_.id).get(sort));
		}

		return entityManager.createQuery(query.select(from).distinct(true).where(predicate).orderBy(ascDesc))
				.setFirstResult(offset).setMaxResults(limit).getResultList();
	}

	/**
	 * Obtem o total de projetos
	 * 
	 * @param search
	 * @return Total de projetos
	 */
	public Long countAll(String carteira, String projeto, String job) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> query = builder.createQuery(Long.class);

		Root<Build> from = query.from(Build.class);

		Predicate predicate = builder.equal(from.get(Build_.id).get(BuildPK_.wallet), carteira);
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.project), projeto));
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.job), job));

		return entityManager.createQuery(query.select(builder.count(from)).where(predicate)).getSingleResult();
	}

	/**
	 * Lista de Builds elegíveis a release para TQS
	 * 
	 * @param wallet
	 * @param project
	 * @param result
	 * @param offset
	 * @param limit
	 * @param sort
	 * @param order
	 * @return Builds to Release
	 */
	public List<Build> findAllToRelease(String wallet, String project, JenkinsResult result, int offset, int limit) {
		
		return entityManager.createQuery("SELECT b FROM Build b JOIN FETCH b.changeSets cs JOIN FETCH cs.commit c " + 
				"WHERE b.id.wallet = :wallet AND b.id.project = :project AND b.result = :result AND b.id.job  = :job " +
				"AND c.committedDate = (SELECT MAX(cx.committedDate) FROM Build bx " + 
				"			 JOIN bx.changeSets csx JOIN csx.commit cx " +
				"            WHERE bx.id.wallet = b.id.wallet AND bx.id.project = b.id.project AND bx.result = b.result AND bx.id.job = b.id.job AND bx.id.id = b.id.id " + 
				"			 GROUP BY bx.id.id) " +
				"AND b.id.id = (SELECT MIN(bx.id.id) FROM Build bx " + 
				"			 JOIN bx.changeSets csx JOIN csx.commit cx " +
				"            WHERE bx.id.wallet = b.id.wallet AND bx.id.project = b.id.project AND bx.result = b.result AND bx.id.job = b.id.job AND cx.id.commit = c.id.commit " + 
				"			 GROUP BY cx.id.commit) " +
				"ORDER BY c.committedDate DESC", Build.class)
				.setFirstResult(offset).setMaxResults(limit)
				.setParameter("wallet", wallet).setParameter("project", project).setParameter("job", project + "-ci-dev").setParameter("result", result)
				.getResultList();
	}

	public Long countToReleaseAll(String wallet, String project, JenkinsResult result) {
		return (long) findAllToRelease(wallet, project, result, 0, Integer.MAX_VALUE).size();
	}

	/**
	 * Metodo responsavel pela consulta paginada de Folders no banco de dados
	 * 
	 * @param environment
	 * @return Parameter
	 */
	public List<ResultVO> findBuildsById(String wallet, String project) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ResultVO> query = builder.createQuery(ResultVO.class);
		Root<Build> from = query.from(Build.class);

		Predicate predicate = builder.equal(from.get(Build_.id).get(BuildPK_.wallet), wallet);
		predicate = builder.and(predicate, builder.equal(from.get(Build_.id).get(BuildPK_.project), project));

		return entityManager.createQuery(query.multiselect(from.get(Build_.result), builder.count(from))
				.where(predicate).groupBy(from.get(Build_.result))).getResultList();
	}

	/**
	 * Salva Build
	 * 
	 * @param Build
	 * @return Build
	 */
	public Build save(Build build) {
		entityManager.persist(build);
		return build;
	}

	/**
	 * Atualiza Build
	 * 
	 * @param build
	 * @return build
	 */
	public Build update(Build build) {
		return entityManager.merge(build);
	}
}

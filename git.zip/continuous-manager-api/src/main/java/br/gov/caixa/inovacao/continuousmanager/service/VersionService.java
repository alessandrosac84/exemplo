package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.Calendar;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.BadRequestException;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;

/**
 * Classe de servicos de Version.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class VersionService {

	@Inject
	private Logger log;

	@Inject
	private JenkinsService jenkinsService;

	@Inject
	private CommitService commitService;

	/**
	 * Gera uma nova versão do projeto para TQS
	 * 
	 * @param wallet
	 * @param project
	 * @param job
	 * @param commit
	 * @param version
	 */
	public void version(String wallet, String project, @Valid Commit commit) {
		log.fine("Iniciando Versionamento");
		
		List<Commit> commitVersion = commitService.findByVersionOrCommit(wallet, project, commit);
		
		if (commitVersion == null || (commitVersion.size() == 1 && commitVersion.get(0).getVersion() == null)) {
			jenkinsService.createVersion(wallet, project, project + "-ci-tqs", commit.getId().getCommit(),
					commit.getVersion());
			CommitPK id = new CommitPK();
			id.setWallet(wallet);
			id.setProject(project);
			id.setCommit(commit.getId().getCommit());
			Commit current = commitService.findById(id);
			current.setVersion(commit.getVersion());
			current.setVersionerUser(HelperThreadLocal.USER.get());
			current.setVersionedAt(Calendar.getInstance());
			return;
		}
		throw new BadRequestException(
				"Versão já existente! Realize as alterações na branch correspondente ou gere uma nova versão.");
	}
}
package br.gov.caixa.sharepoint.config.security.token;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;

import org.jose4j.lang.JoseException;

import br.gov.caixa.sharepoint.config.security.subject.Principal;
import br.gov.caixa.sharepoint.config.security.subject.PrincipalThreadLocal;

@Provider
public class JWTResponseFilter implements ContainerResponseFilter {

	private Logger log;

	@Override
	public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext)
			throws IOException {
		log = Logger.getLogger(JWTResponseFilter.class.getName());
		log.fine("Executando Response Filter... ");

		responseContext.getHeaders().add("Access-Control-Allow-Origin", "*");
		responseContext.getHeaders().add("Access-Control-Allow-Headers", "origin, content-type, accept, Authorization2, If-Modified-Since, Cache-Control, Pragma, Expires");
		responseContext.getHeaders().add("Access-Control-Expose-Headers", "origin, content-type, accept, Authorization2, cache, jwt, Content-Range");
		responseContext.getHeaders().add("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");
		responseContext.getHeaders().add("Access-Control-Max-Age", "0"); //
		responseContext.getHeaders().add("Cache-Control", "no-cache, no-store, must-revalidate"); 
		responseContext.getHeaders().add("Pragma", "no-cache"); 
		responseContext.getHeaders().add("Expires", "0"); 

		Principal principal = PrincipalThreadLocal.USER.get();
		PrincipalThreadLocal.USER.remove();

		if (requestContext.getProperty("auth-failed") != null) {
			Boolean failed = (Boolean) requestContext.getProperty("auth-failed");
			if (failed) {
				log.warning("Erro na autenticacao JWT token.");
				return;
			}
		}
		
		if (requestContext.getMethod().equalsIgnoreCase("OPTIONS")) {
			responseContext.setStatus(200);
			return;
		}

		if (principal == null) {
			return;
		}

		List<Object> jwt = new ArrayList<>();

		try {
			jwt.add(TokenUtility.buildJWT(principal));
		} catch (JoseException e) {
			log.log(Level.SEVERE, null, e);
			log.warning("Erro na Criação JWT token.");
			return;
		}
		responseContext.getHeaders().put("jwt", jwt);

		log.fine("Adicionado o JWT para o Response header 'jwt'");
	}
}

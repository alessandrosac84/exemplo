package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;


/**
 * The persistent class for the branch_parameter database table.
 * 
 */
@Entity
@Table(name="branch_parameter")
@NamedQuery(name="BranchParameter.findAll", query="SELECT b FROM BranchParameter b")
public class BranchParameter extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonView(ViewJson.JenkisfileView.class)
	private BranchParameterPK id;

	@JsonView(ViewJson.JenkisfileView.class)
	@Column(nullable=false, length=50)
	private String value;

	//bi-directional many-to-one association to ProjectBranch
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="branch", referencedColumnName="branch", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="project", referencedColumnName="project", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private ProjectBranch projectBranch;

	public BranchParameter() {
		/* class constructor intentionally left blank */
	}

	public BranchParameterPK getId() {
		return this.id;
	}

	public void setId(BranchParameterPK id) {
		this.id = id;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public ProjectBranch getProjectBranch() {
		return this.projectBranch;
	}

	public void setProjectBranch(ProjectBranch projectBranch) {
		this.projectBranch = projectBranch;
	}

}
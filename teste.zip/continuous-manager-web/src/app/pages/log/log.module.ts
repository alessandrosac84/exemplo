/* Angular Imports */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxPaginationModule } from 'ngx-pagination';

/* App Imports */
import { LogComponent } from './log.component';
import { JenkinsComponent } from './jenkins/jenkins.component';
import { SonarComponent } from './sonar/sonar.component';

/* Routing Module */
import { LogRoutingModule } from './log-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    LogRoutingModule,
    NgxPaginationModule,
    NgbModule.forRoot()
  ],
  declarations: [
    LogComponent,
    JenkinsComponent,
    SonarComponent
  ]
})
export class LogModule { }

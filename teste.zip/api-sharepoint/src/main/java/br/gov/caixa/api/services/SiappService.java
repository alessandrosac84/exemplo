package br.gov.caixa.api.services;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.axis.AxisFault;

import SIAPP_WS_DistinctItemPortfolio.OutputMapping5GetListValues;
import SIAPP_WS_DistinctItemPortfolio.PortSoapBindingStub;
import SIAPP_WS_DistinctItemPortfolio.SIAPP_WS_DistinctItemPortfolioServiceLocator;
import br.gov.caixa.api.dto.SiappDto;
import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.Siapp;
import br.gov.caixa.api.model.Timeline;
import br.gov.caixa.api.model.TipoTimeline;
import br.gov.caixa.api.repository.SiappRepository;
import br.gov.caixa.api.repository.TimelineRepository;
import br.gov.caixa.api.result.GenericResult;
import br.gov.caixa.api.result.SiappResult;

@Named
public class SiappService {
	@Inject
	SiappRepository repository;
	
	@Inject
	TimelineRepository TimelineRepositoryrepository;
	
	@Inject
	EntityManager entityManager;
		
	public SiappResult delete(SiappDto siappDto) {
				
		Siapp siapp = new Siapp().fromDtoToSiapp(siappDto);
		
		repository.delete(siapp);
		
		SiappResult result = new SiappResult();
		result.setMessage("Executado com sucesso.");
		
		return result;
	}	

	
	public SiappResult salvarSistema(SiappDto siappDto) {

		SiappResult result = new SiappResult();
		
		try
		{
			Siapp siapp = new Siapp().fromDtoToSiapp(siappDto);		
			repository.save(siapp);	
		
			result.setMessage("Executado com sucesso.");
		}
		catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		
		return result;
	}		
	
	public SiappResult salvarSistemas(List<SiappDto> siappDto) {
				
		repository.setEstadoNulo("DESCONHECIDO");
	
		for (SiappDto dto : siappDto) {
		
			try {
				
				if(dto.getSistema().equals("SIGIB") || dto.getSistema().equals("SIAGC"))
					System.out.println(dto.getSistema() + " Break");
				
				
				if (!dto.getOrigem().equalsIgnoreCase("CEDESSP") || dto.getCoordenacaoProjeto().equals(""))
					continue;
							
				Siapp siapp = repository.findByCodigo(dto.getCodigo());
									
				if (siapp == null)
				{	
					siapp = repository.findBySistemaAndAlias(dto.getSistema(), dto.getAlias() );
				}				
				
				if (siapp == null)
				{					
					List<Siapp> siapps = repository.findBySistema(dto.getSistema());
					
					//Sistema n�o encontrado por c�digo, nome + alias e nem pelo nome
					if(siapps.isEmpty() && dto.getEstado().equalsIgnoreCase("ATIVO") ) {										
						
						Siapp siappNew = new Siapp().fromDtoToSiapp(dto);			
						repository.save(siappNew);
						
					}
					//Encontrado um Sistema pelo NOME, se ativo atualiza
					else if(siapps.size() == 1 && dto.getEstado().equalsIgnoreCase("ATIVO") ) {
						siapp = siapps.get(0);
					}
					//Encontrado mais de um Sistema pelo NOME ou o Est� suspenso Nada a Fazer
					else {
						System.out.println(dto.getSistema() + " Encontrado mais de um Sistema pelo NOME ou o Est� suspenso Nada a Fazer");
						continue;
					}					 
				}
				
				
				if (siapp != null)
				{				
					//Sistema n�o est� mais ativo
					if( ! dto.getEstado().equalsIgnoreCase("ATIVO")  )
					{					
						Set<Funcionario> funcionarios = siapp.getFuncionarios();
						
						//Exclui funcion�rios respons�veis (se existir)
						for (Funcionario funcionario : funcionarios ) {
							if(funcionario.getCoordenacao().getNome() != "") {
								
								Timeline timeline = new Timeline();
								Funcionario funcionarioTimeLine = new Funcionario();
								funcionarioTimeLine.setUid(funcionario.getUid());
															
								timeline.setFuncionario(funcionarioTimeLine);
								timeline.setData(new Date());
								timeline.setTitulo("Exclu�do Como Respons�vel do Sistema: " + siapp.getSistema() + " - Sistema N�o esta ATIVO");
								timeline.setDetalhe("Mensagem Autom�tica de Atribui��o � Coordena��es. Respons�vel: SISTEMA (Atualiza��o SIAPP)");
								timeline.setTipoTimeline(TipoTimeline.DOIS);
								
								timeline = TimelineRepositoryrepository.save(timeline);														 							
							}						
						}
						
						siapp.getFuncionarios().clear();					
						siapp.getFerramentas().clear();
						
						//Excluir Sistema
						repository.delete(siapp);
						continue;
						
					}
					//Sistema trocou de coordena��o
					else if( !dto.getCoordenacaoProjeto().equals(siapp.getCoordenacaoProjeto()) )
					{					
						Set<Funcionario> funcionarios = siapp.getFuncionarios();
						
						//Exclui funcion�rios respons�veis (se existir)
						for (Funcionario funcionario : funcionarios ) {
							if(funcionario.getCoordenacao().getNome() != "") {
								
								Timeline timeline = new Timeline();
								Funcionario funcionarioTimeLine = new Funcionario();
								funcionarioTimeLine.setUid(funcionario.getUid());
															
								timeline.setFuncionario(funcionarioTimeLine);
								timeline.setData(new Date());
								timeline.setTitulo("Exclu�do da Coordena��o " + funcionario.getCoordenacao().getNome());
								timeline.setDetalhe("Mensagem Autom�tica de Atribui��o � Coordena��es. Respons�vel: SISTEMA (Atualiza��o SIAPP)");
								timeline.setTipoTimeline(TipoTimeline.DOIS);
								
								timeline = TimelineRepositoryrepository.save(timeline);														 							
							}						
						}
						
						siapp.getFuncionarios().clear();					
						siapp.getFerramentas().clear();
					}
					
					//Apenas atualiza informa��es
					siapp.setCarteira(dto.getCarteira());
					siapp.setAlias(dto.getAlias());
					siapp.setOrigem(dto.getOrigem());
					siapp.setTipo(dto.getTipo());
					siapp.setEstado(dto.getEstado());
					siapp.setCoordenacaoProjeto(dto.getCoordenacaoProjeto());
					siapp.setCoordenacaoTi(dto.getCoordenacaoTi());
					siapp.setDescricao(dto.getDescricao());
					siapp.setSistema(dto.getSistema());
					
					repository.save(siapp);			
				}
				
			}
			catch (Exception e) {				 
				e.printStackTrace();
				
			}
				
		}
		
		SiappResult result = new SiappResult();
		result.setMessage("Executado com sucesso.");
		
		return result;
	}
	
	public SiappResult salvarSistemasOld(List<SiappDto> siappDto) {

		
		for (SiappDto dto : siappDto) {
			
			if (!dto.getOrigem().equalsIgnoreCase("CEDESSP") || dto.getCoordenacaoProjeto().equals(""))
				continue;
						
			Siapp siapp = repository.findByCodigo(dto.getCodigo());
								
			if (siapp == null)
			{	
				siapp = repository.findBySistemaAndAlias(dto.getSistema(), dto.getAlias() );
				
				if (siapp != null)
					System.out.println("Testei");
			
				if (siapp == null)
				{					
					 List<Siapp> siapps = repository.findBySistema(dto.getSistema());
					 
					 if(siapps.isEmpty() && dto.getEstado().equalsIgnoreCase("ATIVO") ) {										
						 Siapp siappNew = new Siapp().fromDtoToSiapp(dto);			
						 repository.save(siappNew);
					 }
					 else if(siapps.size() == 1 && dto.getEstado().equalsIgnoreCase("ATIVO") ) {
						 siapp = siapps.get(0);
					 }
					 else {
						 System.out.println("Testei");
						 continue;
					 }
					 
				}
			}
			
			if (siapp != null)
			{				
				if( ! dto.getEstado().equalsIgnoreCase("ATIVO")  )
				{					
					Set<Funcionario> funcionarios = siapp.getFuncionarios();
					
					for (Funcionario funcionario : funcionarios ) {
						if(funcionario.getCoordenacao().getNome() != "") {
							
							Timeline timeline = new Timeline();
							Funcionario funcionarioTimeLine = new Funcionario();
							funcionarioTimeLine.setUid(funcionario.getUid());
														
							timeline.setFuncionario(funcionarioTimeLine);
							timeline.setData(new Date());
							timeline.setTitulo("Exclu�do Como Respons�vel do Sistema: " + siapp.getSistema() + " Sistema Suspenso");
							timeline.setDetalhe("Mensagem Autom�tica de Atribui��o � Coordena��es. Respons�vel: SISTEMA (Atualiza��o SIAPP)");
							timeline.setTipoTimeline(TipoTimeline.DOIS);
							
							timeline = TimelineRepositoryrepository.save(timeline);														 							
						}						
					}
					
					siapp.getFuncionarios().clear();					
					siapp.getFerramentas().clear();
					
					repository.delete(siapp);
					continue;
					
				}				
				else if( !dto.getCoordenacaoProjeto().equals(siapp.getCoordenacaoProjeto()) )
				{					
					Set<Funcionario> funcionarios = siapp.getFuncionarios();
					
					for (Funcionario funcionario : funcionarios ) {
						if(funcionario.getCoordenacao().getNome() != "") {
							
							Timeline timeline = new Timeline();
							Funcionario funcionarioTimeLine = new Funcionario();
							funcionarioTimeLine.setUid(funcionario.getUid());
														
							timeline.setFuncionario(funcionarioTimeLine);
							timeline.setData(new Date());
							timeline.setTitulo("Exclu�do da Coordena��o " + funcionario.getCoordenacao().getNome());
							timeline.setDetalhe("Mensagem Autom�tica de Atribui��o � Coordena��es. Respons�vel: SISTEMA (Atualiza��o SIAPP)");
							timeline.setTipoTimeline(TipoTimeline.DOIS);
							
							timeline = TimelineRepositoryrepository.save(timeline);														 							
						}						
					}
					
					siapp.getFuncionarios().clear();					
					siapp.getFerramentas().clear();
				}
				
				siapp.setCarteira(dto.getCarteira());
				siapp.setAlias(dto.getAlias());
				siapp.setOrigem(dto.getOrigem());
				siapp.setTipo(dto.getTipo());
				siapp.setEstado(dto.getEstado());
				siapp.setCoordenacaoProjeto(dto.getCoordenacaoProjeto());
				siapp.setCoordenacaoTi(dto.getCoordenacaoTi());
				siapp.setDescricao(dto.getDescricao());
				siapp.setSistema(dto.getSistema());
				
				repository.save(siapp);			
			}		

		}
		
		SiappResult result = new SiappResult();
		result.setMessage("Executado com sucesso.");
		
		return result;
	}
	
	
	public SiappResult listSistemasPorNomeCoordenacao(String nomeCoordenacao)
	{
 		SiappResult result = new SiappResult();	
				
			try {
				List<Siapp> lista = repository.findByCoordenacaoProjetoAndEstadoNot(nomeCoordenacao, "DESCONHECIDO" );				
				
				if (lista != null) {
									
					result.setList(SiappDto.fromSiappToListDto(lista));					
					result.setMessage("Executado com sucesso.");
				}
				else {
					result.setIsError(true);
					result.setMessage("Nenhum Sistema para a Coordena��o.");
				}
			} catch (Exception e) {				 
				result.setIsError(true);
				result.setMessage(e.getMessage());
			}				
		
		return result;
	}
	
	
	@SuppressWarnings("unchecked")	
	public GenericResult listCoordenacaoSistemas() {
		Query query = entityManager.createQuery("Select s.coordenacaoTi, s.coordenacaoProjeto, s.sistema, s.descricao from Siapp s order by s.coordenacaoTi");
		
		List<Object> listaSistemas = new ArrayList<Object>();
		
		listaSistemas = query.getResultList();

		GenericResult result = new GenericResult();
		
		result.setList(listaSistemas);
		result.setMessage("Executado com sucesso.");
		
		return result;
	}


	public SiappResult listAll() {
		List<Siapp> lista = (repository.findAll());
		SiappResult result = new SiappResult();
		
		result.setList(SiappDto.fromSiappToListDto(lista));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}


	public SiappResult getInfoSigla(String sigla) {
		SiappResult result = new SiappResult();
		try {
			SIAPP_WS_DistinctItemPortfolioServiceLocator wsservice = new SIAPP_WS_DistinctItemPortfolioServiceLocator();
			PortSoapBindingStub stub = new PortSoapBindingStub(new URL(wsservice.getPortSoapAddress()), wsservice);
			OutputMapping5GetListValues[] retorno = stub.getList("NO_SIGLA = \"" + sigla + "\"", "0", "0");
	
			SiappDto dto = new SiappDto();
									
			dto.setCarteira(retorno[0].getDE_CARTEIRA());
			dto.setSistema(retorno[0].getNO_SIGLA());
			dto.setObjetivo(retorno[0].getDE_OBJETIVO());
			dto.setCenario(retorno[0].getDE_CENARIO());
			dto.setPlataforma(retorno[0].getNO_PLATAFORMA());
			dto.setRede(retorno[0].getNO_REDE());
			dto.setIntegracoes(retorno[0].getNO_INTEGRACAO());
			
			result.setSiapp(dto);
		} catch (AxisFault e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		} catch (MalformedURLException e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		} catch (RemoteException e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}
	
	public SiappResult getInfoSiglaAlias(String sistema, String alias) {
		
		SiappResult result = new SiappResult();
		
		try {			
			SIAPP_WS_DistinctItemPortfolioServiceLocator wsservice = new SIAPP_WS_DistinctItemPortfolioServiceLocator();
			PortSoapBindingStub stub = new PortSoapBindingStub(new URL(wsservice.getPortSoapAddress()), wsservice);
			OutputMapping5GetListValues[] retorno = stub.getList("DE_ALIAS = \"" + alias + "\"", "0", "0");
	
			Siapp siapp = repository.findBySistemaAndAlias(sistema, alias);
			
			SiappDto dto = SiappDto.fromSiappToDto(siapp);
			
			dto.setCarteira(retorno[0].getDE_CARTEIRA());
			dto.setSistema(retorno[0].getNO_SIGLA());
			dto.setObjetivo(retorno[0].getDE_OBJETIVO());
			dto.setCenario(retorno[0].getDE_CENARIO());
			dto.setPlataforma(retorno[0].getNO_PLATAFORMA());
			dto.setRede(retorno[0].getNO_REDE());
			dto.setIntegracoes(retorno[0].getNO_INTEGRACAO());
			
			result.setSiapp(dto);
		} catch (AxisFault e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		} catch (MalformedURLException e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		} catch (RemoteException e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}
}

package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;
import java.util.List;

/**
 * Classe de representação de projeto no Sonar
 * 
 * @author Alessandro Carvalho
 *
 */

public class ComponentVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4001457837877031094L;
	
	/**
	 * 
	 */
	private String id;
	
	/**
	 * 
	 */
	private String key;
	
	/**
	 * 
	 */
	private String name;
	
	/**
	 * 
	 */
	private String qualifier;
	
	/**
	 * 
	 */
	private List<MeasureVO> measures;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the qualifier
	 */
	public String getQualifier() {
		return qualifier;
	}

	/**
	 * @param qualifier the qualifier to set
	 */
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}

	/**
	 * @return the measures
	 */
	public List<MeasureVO> getMeasures() {
		return measures;
	}

	/**
	 * @param measures the measures to set
	 */
	public void setMeasures(List<MeasureVO> measures) {
		this.measures = measures;
	}

}

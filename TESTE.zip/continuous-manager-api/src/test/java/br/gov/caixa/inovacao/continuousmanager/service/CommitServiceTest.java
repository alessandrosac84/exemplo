/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.repository.CommitRepository;

/**
 * Classe de testes do CommitService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CommitServiceTest {
	
	@Mock
	private CommitRepository commitRepository;

	@InjectMocks
	private CommitService commitService;

	private Commit commit;
	
	@Before
	public void before() {
		commit = null; // EntityBuilder.createProjects().get(0).getCommits().stream().findFirst().get();
		UtilReflection.setField(commitService, "log", Logger.getLogger(AuditService.class.getName()));
	}
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(commitRepository.save(Mockito.<Commit>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		
		// Act
		Commit savedCommit = commitService.save(commit);

		// Then
		Assert.assertNotNull(savedCommit);
	}
}

package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;

/**
 * Classe de acesso ao banco de dados da entidade Parameter.
 * 
 * @author Fabio Iwakoshi
 *
 */
@ApplicationScoped
public class ParameterRepository {

	@Inject
	private EntityManager entityManager;

	/**
	 * Metodo responsavel pela consulta paginada de Folders no banco de
	 * dados
	 * 
	 * @param environment
	 * @return Parameter
	 */
	public Parameter findById(ParameterPK id) {
		return entityManager.find(Parameter.class, id);
	}
}

package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import br.gov.caixa.api.model.Ferramenta;
import br.gov.caixa.api.model.Funcionario;
import br.gov.caixa.api.model.Siapp;

public class SiappDto {
	
	private Long uid;
	private String origem;
	private String sistema;
	private String carteira;
	private String descricao;
	private String alias;
	private String tipo;	
	private String estado;
	private String cenario;
	private String beneficio;
	private String objetivo;
	private String rede;
	private String plataforma;
	private String integracoes;
	
	private Long codigo;
	private String coordenacaoProjeto;
	private String coordenacaoTi;	

	private List<FuncionarioDto> funcionarios = new ArrayList<FuncionarioDto>();	
	private List<FerramentaDto> ferramentasDto = new ArrayList<FerramentaDto>();
	
	public Long getUid() {
		return uid;
	}
	
	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}
	
	public String getSistema() {
		return sistema;
	}
	
	public void setSistema(String sistema) {
		this.sistema = sistema;
	}
	
	public String getCarteira() {
		return carteira;
	}
	
	public void setCarteira(String carteira) {
		this.carteira = carteira;
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}
	
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	
	public String getCenario() {
		return cenario;
	}

	public void setCenario(String cenario) {
		this.cenario = cenario;
	}

	public String getBeneficio() {
		return beneficio;
	}

	public void setBeneficio(String beneficio) {
		this.beneficio = beneficio;
	}

	public String getObjetivo() {
		return objetivo;
	}

	public void setObjetivo(String objetivo) {
		this.objetivo = objetivo;
	}

	public String getRede() {
		return rede;
	}

	public void setRede(String rede) {
		this.rede = rede;
	}

	public String getPlataforma() {
		return plataforma;
	}

	public void setPlataforma(String plataforma) {
		this.plataforma = plataforma;
	}

	public String getIntegracoes() {
		return integracoes;
	}

	public void setIntegracoes(String integracoes) {
		this.integracoes = integracoes;
	}
	
	public String getCoordenacaoProjeto() {
		return coordenacaoProjeto;
	}
	
	public void setCoordenacaoProjeto(String coordenacaoProjeto) {
		this.coordenacaoProjeto = coordenacaoProjeto;
	}
	
	public String getCoordenacaoTi() {
		return coordenacaoTi;
	}

	public void setCoordenacaoTi(String coordenacaoTi) {
		this.coordenacaoTi = coordenacaoTi;
	}

	public List<FuncionarioDto> getFuncionarios() {
		return funcionarios;
	}

	public void setFuncionarios(List<FuncionarioDto> funcionarios) {
		this.funcionarios = funcionarios;
	}

	public List<FerramentaDto> getFerramentasDto() {
		return ferramentasDto;
	}

	public void setFerramentasDto(List<FerramentaDto> ferramentasDto) {
		this.ferramentasDto = ferramentasDto;
	}

	public static SiappDto fromSiappToDto(Siapp siapp) {
		
		SiappDto dto = new SiappDto();
		
		dto.setUid(siapp.getUid());
		dto.setOrigem(siapp.getOrigem());
		dto.setSistema(siapp.getSistema());
		dto.setCarteira(siapp.getCarteira());
		dto.setDescricao(siapp.getDescricao());
		dto.setAlias(siapp.getAlias());
		dto.setTipo(siapp.getTipo());
		dto.setEstado(siapp.getEstado());
		dto.setCodigo(siapp.getCodigo());
		dto.setCoordenacaoProjeto(siapp.getCoordenacaoProjeto());
		dto.setCoordenacaoTi(siapp.getCoordenacaoTi());
		
		if(siapp.getFuncionarios() != null){
			
			List<FuncionarioDto> funcionarios = new ArrayList<FuncionarioDto>();
			
			Iterator<Funcionario> itr = siapp.getFuncionarios().iterator();				
			while (itr.hasNext()) {
				FuncionarioDto funcionarioDto = FuncionarioDto.fromFuncionarioToDto(itr.next());					
				funcionarios.add(funcionarioDto);
			}
			
			dto.setFuncionarios(funcionarios);
		}
		
		if(siapp.getFerramentas() != null) {
			
			List<FerramentaDto> ferramentas = new ArrayList<FerramentaDto>();
						
			Iterator<Ferramenta> itr = siapp.getFerramentas().iterator();				
			while (itr.hasNext()) {
				FerramentaDto ferramentaDto = FerramentaDto.fromFerramentaToDto(itr.next());					
				ferramentas.add(ferramentaDto);
			}
			
			dto.setFerramentasDto(ferramentas);
		}
		
		return dto;
	}
	
	public static List<SiappDto> fromSiappToListDto(List<Siapp> list) {
		
		List<SiappDto> returnList = new ArrayList<SiappDto>();
		
		for (Siapp siapp   : list) {	
			returnList.add(fromSiappToDto(siapp));		
		}
		
		return returnList;
	}
	
}

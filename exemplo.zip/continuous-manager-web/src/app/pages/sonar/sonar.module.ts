import { FormsModule } from '@angular/forms';
import { SonarComponent } from './sonar.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { SonarRoutingModule } from './sonar-routing.module';

@NgModule({
  imports: [
    CommonModule,
    SonarRoutingModule,
    FormsModule,
    NgbModule.forRoot()
  ],
  declarations: [
    SonarComponent
  ]
})
export class SonarModule { }

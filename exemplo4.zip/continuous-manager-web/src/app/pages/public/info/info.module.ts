import { NgModule } from '@angular/core';

import { InfoRoutingModule } from './info-routing.module';
import { SharedModule } from '../../../shared/shared.module';

import { InfoComponent } from './info.component';
import { NewsComponent } from './news/news.component';

@NgModule({
  imports: [
    SharedModule,
    InfoRoutingModule,
  ],
  declarations: [
    InfoComponent,
    NewsComponent
  ],
  entryComponents: [
    NewsComponent
  ]
})
export class InfoModule { }

﻿/*
Created: 26/01/2018
Modified: 07/02/2018
Model: Continuous Manager
Database: PostgreSQL 9.4
*/


-- Create roles section -------------------------------------------------

CREATE ROLE "sistema"
;

-- Create tables section -------------------------------------------------

-- Table parameter

CREATE TABLE "parameter"(
 "environment" Character(3) NOT NULL
        CONSTRAINT "environment" CHECK ("environment" IN ('DES', 'TQS', 'HMP', 'PRD')),
 "server_type" Character varying(7) NOT NULL
        CONSTRAINT "server_type" CHECK ("server_type" IN ('JENKINS', 'SONAR', 'GITLAB') ),
 "host" Character varying(100) NOT NULL,
 "principal" Character varying(200) NOT NULL,
 "credential" Character varying(200)
)
;

-- Add keys for table parameter

ALTER TABLE "parameter" ADD CONSTRAINT "Key1" PRIMARY KEY ("environment","server_type")
;

-- Table wallet

CREATE TABLE "wallet"(
 "id" Character varying(30) NOT NULL
        CONSTRAINT "lowercase" CHECK ("id" ~ '[a-z\-]*'),
 "name" Character varying(50) NOT NULL,
 "user_insert" Character(7) NOT NULL,
 "created_at" Timestamp NOT NULL,
 "user_update" Character(7),
 "updated_at" Timestamp
)
;

-- Add keys for table wallet

ALTER TABLE "wallet" ADD CONSTRAINT "Key2" PRIMARY KEY ("id")
;

-- Table project

CREATE TABLE "project"(
 "id" Character varying(30) NOT NULL
        CONSTRAINT "lowercase" CHECK ("id" ~ '[a-z\-]*'),
 "wallet" Character varying(30) NOT NULL,
 "name" Character varying(50) NOT NULL,
 "git_repo" Character varying(150),
 "user_insert" Character(7) NOT NULL,
 "created_at" Timestamp NOT NULL,
 "user_update" Character(7),
 "updated_at" Timestamp
)
;

-- Create indexes for table project

CREATE INDEX "ix_project_wallet" ON "project" ("wallet")
;

-- Add keys for table project

ALTER TABLE "project" ADD CONSTRAINT "Key3" PRIMARY KEY ("id","wallet")
;

-- Table git_repo

CREATE TABLE "git_repo"(
 "wallet" Character varying(30) NOT NULL,
 "project" Character varying(30) NOT NULL,
 "commit" Character(40) NOT NULL,
 "version" Character varying(20),
 "versioner_user" Character(7),
 "versioned_at" Timestamp,
 "author_name" Character varying(100) NOT NULL,
 "author_email" Character varying(70) NOT NULL,
 "authored_date" Timestamp NOT NULL,
 "committer_name" Character varying(100) NOT NULL,
 "committer_email" Character varying(70) NOT NULL,
 "committed_date" Timestamp NOT NULL,
 "title" Character varying(72) NOT NULL,
 "message" Text
)
;

-- Add keys for table git_repo

ALTER TABLE "git_repo" ADD CONSTRAINT "Key4" PRIMARY KEY ("commit","project","wallet")
;

-- Table sonar

CREATE TABLE "sonar"(
 "project" Character varying(30) NOT NULL,
 "wallet" Character varying(30) NOT NULL,
 "key" Character varying(100) NOT NULL,
 "quality_gate" Character varying(3) NOT NULL
        CONSTRAINT "quality_gate" CHECK ("quality_gate" IN ('OK', 'NOK')),
 "lines" Integer NOT NULL,
 "bugs" Integer NOT NULL,
 "vulnerabilities" Integer NOT NULL,
 "debts" Integer NOT NULL,
 "code_smells" Integer NOT NULL,
 "coverages" Numeric(4,1) NOT NULL,
 "unit_tests" Integer NOT NULL,
 "duplications" Numeric(4,1) NOT NULL
)
;

-- Add keys for table sonar

ALTER TABLE "sonar" ADD CONSTRAINT "Key5" PRIMARY KEY ("project","wallet")
;

ALTER TABLE "sonar" ADD CONSTRAINT "key" UNIQUE ("key")
;

-- Table job

CREATE TABLE "job"(
 "id" Character varying(50) NOT NULL
        CONSTRAINT "lowercase" CHECK ("id" ~ '[a-z\-]*'),
 "project" Character varying(30) NOT NULL,
 "wallet" Character varying(30) NOT NULL,
 "name" Character varying(50) NOT NULL,
 "user_insert" Character(7) NOT NULL,
 "created_at" Timestamp NOT NULL,
 "user_update" Character(7),
 "updated_at" Timestamp
)
;

-- Add keys for table job

ALTER TABLE "job" ADD CONSTRAINT "Key6" PRIMARY KEY ("project","wallet","id")
;

-- Table build

CREATE TABLE "build"(
 "id" Integer NOT NULL,
 "project" Character varying(30) NOT NULL,
 "wallet" Character varying(30) NOT NULL,
 "job" Character varying(50) NOT NULL,
 "description" Character varying(200),
 "duration" Time NOT NULL,
 "estimate_duration" Time NOT NULL,
 "local_error" character varying(10),
 "result" Character(9) NOT NULL
        CONSTRAINT "result_jenkins" CHECK ("result" IN ('SUCCESS', 'UNSTABLE', 'FAILURE', 'ABORTED', 'NOT_BUILT')),
 "phase" Character(9) NOT NULL
        CONSTRAINT "phase_jenkins" CHECK ("phase" IN ('QUEUED', 'STARTED', 'COMPLETED', 'FINALIZED', 'FAILED')),
 "created_at" Timestamp without time zone NOT NULL
)
;

-- Add keys for table build

ALTER TABLE "build" ADD CONSTRAINT "Key7" PRIMARY KEY ("id","project","wallet","job")
;

-- Table change_sets

CREATE TABLE "change_sets"(
 "project" Character varying(30) NOT NULL,
 "wallet" Character varying(30) NOT NULL,
 "job" Character varying(50) NOT NULL,
 "build" Integer NOT NULL,
 "commit" Character(40) NOT NULL
)
;

-- Add keys for table change_sets

ALTER TABLE "change_sets" ADD CONSTRAINT "Key8" PRIMARY KEY ("build","project","wallet","job","commit")
;

-- Table project_environment

CREATE TABLE "project_environment"(
 "project" Character varying(30) NOT NULL,
 "wallet" Character varying(30) NOT NULL,
 "job" Character varying(50) NOT NULL,
 "build" Integer NOT NULL,
 "environment" Character(3) NOT NULL
        CONSTRAINT "environment" CHECK ("environment" IN ('DES', 'TQS', 'HMP', 'PRD')),
 "user_insert" Character(7) NOT NULL,
 "created_at" Timestamp NOT NULL,
 "user_update" Character(7),
 "updated_at" Timestamp
)
;

-- Add keys for table project_environment

ALTER TABLE "project_environment" ADD CONSTRAINT "Key9" PRIMARY KEY ("environment","build","project","wallet","job")
;

-- Table audit

CREATE TABLE "audit"(
 "id" BigSerial NOT NULL,
 "action" Character varying(7) NOT NULL
        CONSTRAINT "acao" CHECK ("action" IN ('INCLUIR', 'ALTERAR', 'EXCLUIR')),
 "entity" Text NOT NULL,
 "timestamp_event" Timestamp NOT NULL,
 "user_event" Character(7) NOT NULL,
 "functionality" Character varying(100) NOT NULL,
 "ip_event" Character varying(30) NOT NULL
)
;

-- Add keys for table audit

ALTER TABLE "audit" ADD CONSTRAINT "Key10" PRIMARY KEY ("id")
;

-- Table path

CREATE TABLE "path"(
 "commit" Character(40) NOT NULL,
 "project" Character varying(30) NOT NULL,
 "wallet" Character varying(30) NOT NULL,
 "file" Character varying(500) NOT NULL,
 "editType" Character varying(6) NOT NULL
        CONSTRAINT "editType" CHECK ("editType" IN ('ADD', 'EDIT', 'DELETE'))
)
;

-- Add keys for table path

ALTER TABLE "path" ADD CONSTRAINT "Key11" PRIMARY KEY ("commit","project","wallet","file")
;
-- Create foreign keys (relationships) section ------------------------------------------------- 

ALTER TABLE "project" ADD CONSTRAINT "wallet_project" FOREIGN KEY ("wallet") REFERENCES "wallet" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION
;

ALTER TABLE "git_repo" ADD CONSTRAINT "fk_project_git_repo" FOREIGN KEY ("project", "wallet") REFERENCES "project" ("id", "wallet") ON DELETE NO ACTION ON UPDATE NO ACTION
;

ALTER TABLE "sonar" ADD CONSTRAINT "Relationship3" FOREIGN KEY ("project", "wallet") REFERENCES "project" ("id", "wallet") ON DELETE NO ACTION ON UPDATE NO ACTION
;

ALTER TABLE "job" ADD CONSTRAINT "Relationship4" FOREIGN KEY ("project", "wallet") REFERENCES "project" ("id", "wallet") ON DELETE NO ACTION ON UPDATE NO ACTION
;

ALTER TABLE "build" ADD CONSTRAINT "Relationship5" FOREIGN KEY ("project", "wallet", "job") REFERENCES "job" ("project", "wallet", "id") ON DELETE NO ACTION ON UPDATE NO ACTION
;

ALTER TABLE "change_sets" ADD CONSTRAINT "change_sets_build" FOREIGN KEY ("build", "project", "wallet", "job") REFERENCES "build" ("id", "project", "wallet", "job") ON DELETE NO ACTION ON UPDATE NO ACTION
;

ALTER TABLE "change_sets" ADD CONSTRAINT "change_sets_git_repo" FOREIGN KEY ("commit", "project", "wallet") REFERENCES "git_repo" ("commit", "project", "wallet") ON DELETE NO ACTION ON UPDATE NO ACTION
;

ALTER TABLE "project_environment" ADD CONSTRAINT "build_project_environment" FOREIGN KEY ("build", "project", "wallet", "job") REFERENCES "build" ("id", "project", "wallet", "job") ON DELETE NO ACTION ON UPDATE NO ACTION
;

ALTER TABLE "path" ADD CONSTRAINT "Relationship6" FOREIGN KEY ("commit", "project", "wallet") REFERENCES "git_repo" ("commit", "project", "wallet") ON DELETE NO ACTION ON UPDATE NO ACTION
;



-- Grant permissions section -------------------------------------------------



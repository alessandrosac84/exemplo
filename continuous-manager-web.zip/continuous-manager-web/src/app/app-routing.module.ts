import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppAuthGuard } from './app.auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/projects', pathMatch: 'full' },
  { path: 'projects', loadChildren: './pages/public/projects/projects.module#ProjectsModule', data: { preload: true } },
  { path: 'dashboard', loadChildren: './pages/public/dashboard/dashboard.module#DashboardModule' },
  { path: 'info', loadChildren: './pages/public/info/info.module#InfoModule' },
  { path: 'builds', loadChildren: './pages/private/builds/builds.module#BuildsModule', canActivate: [AppAuthGuard] },
  { path: 'stage', loadChildren: './pages/private/stage/stage.module#StageModule', canActivate: [AppAuthGuard] },
  { path: 'settings', loadChildren: './pages/private/settings/settings.module#SettingsModule', canActivate: [AppAuthGuard] },
  { path: '**', redirectTo: '/projects' }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

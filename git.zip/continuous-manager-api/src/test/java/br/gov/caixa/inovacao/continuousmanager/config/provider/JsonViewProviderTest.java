/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.provider;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

/**
 * Classe de teste de JsonViewProvider
 * 
 * @author Fabio Iwakoshi
 *
 */
public class JsonViewProviderTest {
	
	@Test
	public void entityProviderTest() {
		assertNotNull(new JsonViewProvider().getContext(JsonViewProviderTest.class));
	}

}

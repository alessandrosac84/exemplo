package br.gov.caixa.api.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.gov.caixa.api.dto.FerramentaDto;

@Entity
@Table(name = "ferramenta")
public class Ferramenta {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "nome")
	private String nome;
	
	@Column(name = "ATIVO", columnDefinition = "boolean default true")
	private Boolean ativo;
	
	@ManyToOne
	@JoinColumn(name = "CATEGORIA_TECNOLOGICA_ID")
	private CategoriaTecnologica categoriaTecnologica;
	
	@OneToMany(mappedBy="ferramenta", cascade=CascadeType.REMOVE, orphanRemoval=true )
    private Set<RatingFerramenta> ratingFerramentas = new HashSet<RatingFerramenta>();

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

	public CategoriaTecnologica getCategoriaTecnologica() {
		return categoriaTecnologica;
	}

	public void setCategoriaTecnologica(CategoriaTecnologica categoriaTecnologica) {
		this.categoriaTecnologica = categoriaTecnologica;
	}
	
	public static Ferramenta fromDtoToFerramenta(FerramentaDto dto){
		Ferramenta ferramenta = new Ferramenta();
		ferramenta.setUid(dto.getUid());
		ferramenta.setNome(dto.getNome());
		ferramenta.setAtivo(dto.getAtivo());
		
		if(dto.getCategoriaTecnologica() != null){
			ferramenta.setCategoriaTecnologica(CategoriaTecnologica.fromDtoToCategoriaTecnologica(dto.getCategoriaTecnologica()));
		}
		return ferramenta;
	}
}

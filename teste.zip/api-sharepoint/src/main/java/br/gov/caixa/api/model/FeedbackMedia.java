package br.gov.caixa.api.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import br.gov.caixa.api.dto.FeedbackMediaDto;

@Entity
@Table(name = "feedback_medias")
public class FeedbackMedia {
	
	@Id	
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "QUALIDADE_INFO_MATERIAL")
	private Double qualidadeInfoMaterial;

	@Column(name = "DURACAO")
	private Double duracao;

	@Column(name = "DESEMPENHO_CONHECIMENTO_INSTRUTOR")
	private Double desempenhoConhecimentoInstrautor;

	@Column(name = "SATISFACAO_GERAL")
	private Double satisfacaoGeral;
	
	@Column(name = "TURMA_ID")
	private Long turmaId;	
	
	public Double getQualidadeInfoMaterial() {
		return qualidadeInfoMaterial;
	}

	public void setQualidadeInfoMaterial(Double qualidadeInfoMaterial) {
		this.qualidadeInfoMaterial = qualidadeInfoMaterial;
	}

	public Double getDuracao() {
		return duracao;
	}

	public void setDuracao(Double duracao) {
		this.duracao = duracao;
	}

	public Double getDesempenhoConhecimentoInstrautor() {
		return desempenhoConhecimentoInstrautor;
	}

	public void setDesempenhoConhecimentoInstrautor(
			Double desempenhoConhecimentoInstrautor) {
		this.desempenhoConhecimentoInstrautor = desempenhoConhecimentoInstrautor;
	}

	public Double getSatisfacaoGeral() {
		return satisfacaoGeral;
	}

	public void setSatisfacaoGeral(Double satisfacaoGeral) {
		this.satisfacaoGeral = satisfacaoGeral;
	}
	
	public Long getTurmaId() {
		return turmaId;
	}

	public void setTurmaId(Long turmaId) {
		this.turmaId = turmaId;
	}

	public static FeedbackMedia fromDtoToFeedbackMedia(FeedbackMediaDto dto){
		FeedbackMedia feedbackMedia = new FeedbackMedia();
		
		feedbackMedia.setQualidadeInfoMaterial(dto.getQualidadeInfoMaterial());
		feedbackMedia.setDuracao(dto.getDuracao());
		feedbackMedia.setDesempenhoConhecimentoInstrautor(dto.getDesempenhoConhecimentoInstrautor());
		feedbackMedia.setSatisfacaoGeral(dto.getSatisfacaoGeral());
		feedbackMedia.setTurmaId(dto.getTurmaId());
		
		return feedbackMedia;
	}
	
}
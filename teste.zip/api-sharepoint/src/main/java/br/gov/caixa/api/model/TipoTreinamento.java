package br.gov.caixa.api.model;

public enum TipoTreinamento {
	NENHUM(0),
	DISCIPLINA(1), 
	REC_TECNOLOGICO(2),
	PROCESSO(3),
	PALESTRA(4),
	OUTROS(5);
	
	private final int codigo;
	
	TipoTreinamento(int codigo) { this.codigo = codigo; }
	
	int codigo() { return codigo; }
	
	public static TipoTreinamento porCodigo(int codigo) {
        for (TipoTreinamento tipoTreinamento: TipoTreinamento.values()) {
            if (codigo == tipoTreinamento.codigo()) return tipoTreinamento;
        }
        throw new IllegalArgumentException("tipo invalido");
    }
}

import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl } from '@angular/forms';

import { ProjectService } from '../../../../../shared/service/project.service';
import { Repository } from '../../../../../shared/model/entity/repository.model';
import { Branch } from '../../../../../shared/model/entity/branch.model';
import { Build } from '../../../../../shared/model/entity/build.model';

@Component({
  selector: 'cm-detail',
  templateUrl: './detail.component.html',
})
export class DetailComponent implements OnInit {

  repository: Repository;
  branch: Branch;
  build: Build;
  selectedTab = new FormControl(0);

  constructor(
    private _projectService: ProjectService,
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit() {
    const project = +localStorage.getItem('project');
    const repository = this._activatedRoute.snapshot.params['repository'];
    const branch = this._activatedRoute.snapshot.params['branch'];
    const build = this._activatedRoute.snapshot.params['build'];

    if (project != null) {
      if (repository != null) {
        this._projectService.getRepository(project, repository).subscribe(data => this.repository = data);
        if (this._activatedRoute.snapshot.routeConfig.path.includes('/branches')) {
          this.selectedTab.setValue(1);
          if (branch != null) {
            this._projectService.getBranch(repository, repository, branch).subscribe(data => {
              this.loadBuildHistoryTab(data);
            });
            if (build != null) {
              this._projectService.getBuild(repository, repository, build).subscribe(data => {
                this.loadBuildTab(data);
              });
            }
          }
        }
      } else {
        this._projectService
          .getRepositories(project).subscribe(data => {
            if (data.length > 0) {
              this._router.navigateByUrl('/builds/' + data[0].id.id);
            }
          });
      }
    } else {
      this._router.navigateByUrl('/projects');
    }
  }

  loadBuildHistoryTab(branch: Branch) {
    this.branch = branch;
    this.selectedTab.setValue(2);
    if (this.selectedTab.value === 2 && this._activatedRoute.snapshot.params['branch'] !== encodeURIComponent(branch.id.id)) {
      this._router.navigate([this._activatedRoute.snapshot.params['branch'] ? '../' : '.', encodeURIComponent(branch.id.id)],
        { relativeTo: this._activatedRoute });
    }
  }

  loadBuildTab(build: Build) {
    this.build = build;
    this.selectedTab.setValue(3);
    if (this.selectedTab.value === 3 && this._activatedRoute.snapshot.params['build'] !== build.id.id) {
      this._router.navigate([this._activatedRoute.snapshot.params['build'] ? '../' : '.', build.id.id],
        { relativeTo: this._activatedRoute });
    }
  }

  checkBranch() {
    if (this.selectedTab.value === 1 && !this._activatedRoute.snapshot.routeConfig.path.includes('/branches')) {
      this._router.navigate(['branches'], { relativeTo: this._activatedRoute });
    }
  }
}

/**
 * 
 */
package br.gov.caixa.sharepoint.model.dto;

import java.util.Calendar;

/**
 * @author Fabio Iwakoshi
 *
 */
public class ArquivoDto {
	private String nome;
	
	private String situacao;
	
	private Calendar atualizacao;
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getSituacao() {
		return situacao;
	}
	
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	
	public Calendar getAtualizacao() {
		return atualizacao;
	}
	
	public void setAtualizacao(Calendar atualizacao) {
		this.atualizacao = atualizacao;
	}
}

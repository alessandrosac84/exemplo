package br.gov.caixa.api.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.gov.caixa.api.dto.AtividadeDto;

@Entity
@Table(name = "atividade")
public class Atividade {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "NOME")
	private String nome;
	
	@Column(name = "ATIVO", columnDefinition = "boolean default true")
	private Boolean ativo;

	@ManyToOne
	@JoinColumn(name = "DISCIPLINA_ID")
	private Disciplina disciplina;
	
	@OneToMany(mappedBy="atividade", cascade=CascadeType.REMOVE, orphanRemoval=true )
    private Set<RatingAtividade> ratingAtividades = new HashSet<RatingAtividade>();
	
	@ManyToOne
	@JoinColumn(name = "COMPLEMENTO_ID", nullable = true)
	private Complemento complemento;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

	public Disciplina getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}
	
	public Complemento getComplemento() {
		return complemento;
	}

	public void setComplemento(Complemento complemento) {
		this.complemento = complemento;
	}
	
	public static Atividade fromDtoToAtividade(AtividadeDto atividadeDto) {
		Atividade atividade = new Atividade();
		
		atividade.setUid(atividadeDto.getUid());
		atividade.setNome(atividadeDto.getNome());
		atividade.setAtivo(atividadeDto.getAtivo());
		
		if(atividadeDto.getComplementoDto() != null){
			atividade.setComplemento(Complemento.fromDtoToComplemento(atividadeDto.getComplementoDto()));
		}
		
		if(atividadeDto.getDisciplina() != null){
			atividade.setDisciplina(Disciplina.fromDtoToDisciplina(atividadeDto.getDisciplina()));
		}
		
		return atividade;
	}
}

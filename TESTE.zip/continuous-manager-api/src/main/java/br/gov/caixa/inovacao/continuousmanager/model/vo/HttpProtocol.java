package br.gov.caixa.inovacao.continuousmanager.model.vo;

public enum HttpProtocol {
	HTTP, HTTPS
}

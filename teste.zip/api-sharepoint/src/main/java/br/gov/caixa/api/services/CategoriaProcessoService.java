package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.CategoriaProcessoDto;
import br.gov.caixa.api.model.CategoriaProcesso;
import br.gov.caixa.api.repository.CategoriaProcessoRepository;
import br.gov.caixa.api.result.CategoriaProcessoResult;

@Named
public class CategoriaProcessoService {
	
	@Inject
	CategoriaProcessoRepository repository;
	
	public CategoriaProcessoResult listAll() {

		CategoriaProcessoResult result = new CategoriaProcessoResult();
		try {
			List<CategoriaProcesso> lista = repository.findAll();

			if (lista != null) {
				result.setList(CategoriaProcessoDto.fromCategoriaProcessoToListDto(lista));
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma CategoriaProcesso.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}

	public CategoriaProcessoResult save(CategoriaProcessoDto dto) {
		CategoriaProcesso categoriaProcesso = CategoriaProcesso.fromDtoToCategoriaProcesso(dto);
		repository.save(categoriaProcesso);
		CategoriaProcessoResult result = new CategoriaProcessoResult();
		result.setMessage("Executado com sucesso.");
		return result;
	}

	public CategoriaProcessoResult delete(CategoriaProcessoDto dto) {
		CategoriaProcesso categoriaProcesso = CategoriaProcesso.fromDtoToCategoriaProcesso(dto);
		CategoriaProcessoResult result;
		try {
			repository.delete(categoriaProcesso);
			
			result = new CategoriaProcessoResult();
			result.setMessage("Executado com sucesso.");
			
		} catch (Exception e) {
			result = new CategoriaProcessoResult();
			
			result.setIsError(true);
			result.setMessage("Existe(m) Rating(s) Associados a esta categoria processo.");
			
			e.printStackTrace();
		}		
		return result;
	}

}

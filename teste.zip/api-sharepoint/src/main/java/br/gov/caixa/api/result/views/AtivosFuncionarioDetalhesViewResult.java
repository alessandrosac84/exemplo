package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.AtivosFuncionarioDetalhesView;
import br.gov.caixa.api.result.BasicResult;

public class AtivosFuncionarioDetalhesViewResult extends BasicResult {
	private List<AtivosFuncionarioDetalhesView> list;
	private AtivosFuncionarioDetalhesView ativosFuncionarioDetalhesView;

	public List<AtivosFuncionarioDetalhesView> getList() {
		return list;
	}

	public void setList(List<AtivosFuncionarioDetalhesView> list) {
		this.list = list;
	}

	public AtivosFuncionarioDetalhesView ativosFuncionarioDetalhesView() {
		return ativosFuncionarioDetalhesView;
	}

	public void setAtivosFuncionarioDetalhesView(AtivosFuncionarioDetalhesView ativosFuncionarioDetalhesView) {
		this.ativosFuncionarioDetalhesView = ativosFuncionarioDetalhesView;
	}
}
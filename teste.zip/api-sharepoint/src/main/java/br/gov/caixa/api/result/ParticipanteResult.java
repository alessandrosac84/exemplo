package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.ParticipanteDto;

public class ParticipanteResult extends BasicResult {

	private List<ParticipanteDto> list;
	private ParticipanteDto participante;
	private Integer vaga;

	public List<ParticipanteDto> getList() {
		return list;
	}

	public void setList(List<ParticipanteDto> list) {
		this.list = list;
	}

	public ParticipanteDto getParticipante() {
		return participante;
	}

	public void setParticipante(ParticipanteDto participante) {
		this.participante = participante;
	}

	public Integer getVaga() {
		return vaga;
	}

	public void setVaga(Integer vaga) {
		this.vaga = vaga;
	}
	
	
}

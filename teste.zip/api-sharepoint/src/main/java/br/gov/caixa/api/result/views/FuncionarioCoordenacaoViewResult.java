package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.FuncionarioCoordenacaoView;
import br.gov.caixa.api.result.BasicResult;

public class FuncionarioCoordenacaoViewResult extends BasicResult {
	private List<FuncionarioCoordenacaoView> list;
	private FuncionarioCoordenacaoView funcionarioCoordenacaoView;
		
	public List<FuncionarioCoordenacaoView> getList() {
		return list;
	}
	
	public void setList(List<FuncionarioCoordenacaoView> list) {
		this.list = list;
	}
	
	public FuncionarioCoordenacaoView getFuncionarioCoordenacaoView() {
		return funcionarioCoordenacaoView;
	}
	
	public void setFuncionarioCoordenacaoView(FuncionarioCoordenacaoView funcionarioCoordenacaoView) {
		this.funcionarioCoordenacaoView = funcionarioCoordenacaoView;
	}
	
}
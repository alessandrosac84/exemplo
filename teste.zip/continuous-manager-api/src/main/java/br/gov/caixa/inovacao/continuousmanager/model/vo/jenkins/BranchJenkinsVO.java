package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe de representação do Last Built Revision do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class BranchJenkinsVO implements Serializable {

	private static final long serialVersionUID = 8472438626182237977L;
	
	@JsonProperty("SHA1")
	private String sha1;
	
	private String name;

	/**
	 * @return the sha1
	 */
	public String getSha1() {
		return sha1;
	}

	/**
	 * @param sha1 the sha1 to set
	 */
	public void setSha1(String sha1) {
		this.sha1 = sha1;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

}

package br.gov.caixa.api.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.gov.caixa.api.dto.FeedbackDto;

@Entity
@Table(name = "feedback")
public class Feedback {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@ManyToOne
	@JoinColumn(name = "PARTICIPANTE_ID")
	private Participante participante;

	@Column(name = "MAIS_GOSTOU")
	private String maisGostou;

	@Column(name = "MENOS_GOSTOU")
	private String menosGostou;

	@Column(name = "SUGESTAO")
	private String sugestao;

	@Column(name = "QUALIDADE_INFO_MATERIAL")
	private Integer qualidadeInfoMaterial;

	@Column(name = "DURACAO")
	private Integer duracao;

	@Column(name = "DESEMPENHO_CONHECIMENTO_INSTRUTOR")
	private Integer desempenhoConhecimentoInstrautor;

	@Column(name = "SATISFACAO_GERAL")
	private Integer satisfacaoGeral;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public String getMaisGostou() {
		return maisGostou;
	}

	public void setMaisGostou(String maisGostou) {
		this.maisGostou = maisGostou;
	}

	public String getMenosGostou() {
		return menosGostou;
	}

	public void setMenosGostou(String menosGostou) {
		this.menosGostou = menosGostou;
	}

	public String getSugestao() {
		return sugestao;
	}

	public void setSugestao(String sugestao) {
		this.sugestao = sugestao;
	}

	public Integer getQualidadeInfoMaterial() {
		return qualidadeInfoMaterial;
	}

	public void setQualidadeInfoMaterial(Integer qualidadeInfoMaterial) {
		this.qualidadeInfoMaterial = qualidadeInfoMaterial;
	}

	public Integer getDuracao() {
		return duracao;
	}

	public void setDuracao(Integer duracao) {
		this.duracao = duracao;
	}

	public Integer getDesempenhoConhecimentoInstrautor() {
		return desempenhoConhecimentoInstrautor;
	}

	public void setDesempenhoConhecimentoInstrautor(
			Integer desempenhoConhecimentoInstrautor) {
		this.desempenhoConhecimentoInstrautor = desempenhoConhecimentoInstrautor;
	}

	public Integer getSatisfacaoGeral() {
		return satisfacaoGeral;
	}

	public void setSatisfacaoGeral(Integer satisfacaoGeral) {
		this.satisfacaoGeral = satisfacaoGeral;
	}
	
	public static Feedback froDtoToFeedback(FeedbackDto dto){
		Feedback feedback = new Feedback();
		feedback.setUid(dto.getUid());
		feedback.setParticipante(Participante.fromDtoToParticipante(dto.getParticipanteDto()));
		feedback.setMaisGostou(dto.getMaisGostou());
		feedback.setMenosGostou(dto.getMenosGostou());
		feedback.setQualidadeInfoMaterial(dto.getQualidadeInfoMaterial());
		feedback.setDuracao(dto.getDuracao());
		feedback.setDesempenhoConhecimentoInstrautor(dto.getDesempenhoConhecimentoInstrautor());
		feedback.setSatisfacaoGeral(dto.getSatisfacaoGeral());
		return feedback;
	}
}
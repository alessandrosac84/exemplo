<!--
Para uma correção mais rápida, providencie as seguintes informações.
Issues com informações importantes faltando podem ser fechadas sem grandes investigações.
-->

### Bug

## Comportamento Atual
<!-- Descreva como o erro se manifesta. -->


## Comportamento Esperado
<!-- Descreva qual conportamento deveria ser o esperado. -->


## Instruções mínimas para reprodução do problema
<!-- Providencie um passo a passo para reprodução do erro. -->

## Qual o motivo/caso de uso da alteração do comportamento?
<!-- Descreva a motivação do real caso de uso -->


## Ambiente
<pre><code>
Browser:
- [ ] Chrome (desktop) version XX
- [ ] Chrome (Android) version XX
- [ ] Chrome (iOS) version XX
- [ ] Firefox version XX
- [ ] Safari (desktop) version XX
- [ ] Safari (iOS) version XX
- [ ] IE version XX
- [ ] Edge version XX

- Platform:  <!-- Mac, Linux, Windows -->

Others:
<!-- Alguma outra coisa relevante?  Versão do sistema operacional... -->
</code></pre>
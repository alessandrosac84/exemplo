/* Angular Imports */
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/* App Imports */
import { LogComponent } from './log.component';
import { SonarComponent } from './sonar/sonar.component';
import { JenkinsComponent } from './jenkins/jenkins.component';

const routes: Routes = [
  { path: '', component: LogComponent },
  { path: 'jenkins/:wallet/:project/:job/:build', component: JenkinsComponent },
  { path: 'sonar/:wallet/:project/:job/:build', component: SonarComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LogRoutingModule { }

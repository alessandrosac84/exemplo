/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.gov.caixa.inovacao.continuousmanager.config.interceptor.AuditInterceptor;

/**
 * @author Fabio Iwakoshi
 *
 */
@MappedSuperclass
@EntityListeners(AuditInterceptor.class)
public abstract class AuditedEntity implements Serializable {
	/** * */
	private static final long serialVersionUID = -9210299262782006525L;

	@Column(name="user_insert", nullable=false, updatable=false, length=7)
	private String userInsert;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_at", nullable=false, updatable=false)
	private Calendar createdAt;

	@Column(name="user_update", length=7)
	private String userUpdate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_at")
	private Calendar updatedAt;

	public Calendar getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Calendar updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Calendar getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Calendar createdAt) {
		this.createdAt = createdAt;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}
}

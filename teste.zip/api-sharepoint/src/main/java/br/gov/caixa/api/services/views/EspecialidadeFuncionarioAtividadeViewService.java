package br.gov.caixa.api.services.views;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.model.views.EspecialidadeFuncionarioAtividadeView;
import br.gov.caixa.api.repository.views.EspecialidadeFuncionarioAtividadeViewRepository;
import br.gov.caixa.api.result.views.EspecialidadeFuncionarioAtividadeViewResult;

@Named
public class EspecialidadeFuncionarioAtividadeViewService {
	
	@Inject
	EspecialidadeFuncionarioAtividadeViewRepository repository;
	
	public EspecialidadeFuncionarioAtividadeViewResult listAll() {

		EspecialidadeFuncionarioAtividadeViewResult result = new EspecialidadeFuncionarioAtividadeViewResult();
		try {
			List<EspecialidadeFuncionarioAtividadeView> lista = repository.findAll();

			if (lista != null) {
				result.setList(lista);
				result.setMessage("Executado com sucesso.");
			} else {
				result.setIsError(true);
				result.setMessage("Nenhuma especialidadeAtividadeView.");
			}
		} catch (Exception e) {
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}
		return result;
	}

	public EspecialidadeFuncionarioAtividadeViewResult listEspecialidadeFuncionarioAtividadeViewsByIdAtividade(Long idAtividade) {
		EspecialidadeFuncionarioAtividadeViewResult result = new EspecialidadeFuncionarioAtividadeViewResult();
		try {
						
			List<EspecialidadeFuncionarioAtividadeView> lista = repository.findByAtividadeId(idAtividade);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Atividade para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}
	
	public EspecialidadeFuncionarioAtividadeViewResult listEspecialidadeFuncionarioAtividadesViewByIdsAtividade(List<Long> idsAtividade) {
		
		EspecialidadeFuncionarioAtividadeViewResult result = new EspecialidadeFuncionarioAtividadeViewResult();
		try {
						
			List<EspecialidadeFuncionarioAtividadeView> lista = repository.findByAtividadeIdIn(idsAtividade);				
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Atividade para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}

	public EspecialidadeFuncionarioAtividadeViewResult listEspecialidadeFuncionarioAtividadesViewByIdsAtividadeAndEspecialidadeId(List<Long> idsAtividade, Long especialidadeId) {
		
		EspecialidadeFuncionarioAtividadeViewResult result = new EspecialidadeFuncionarioAtividadeViewResult();
		try {
						
			//List<EspecialidadeFuncionarioAtividadeView> lista = repository.findByEspecialidadeIdAndAtividadeIdIn(especialidadeId,  idsAtividade);				
			
			List<EspecialidadeFuncionarioAtividadeView> lista = repository.findByEspecialidadeId(especialidadeId);
			
			if (lista != null) {
				result.setList(lista);					
				result.setMessage("Executado com sucesso.");
			}
			else {
				result.setIsError(true);
				result.setMessage("Nenhuma Atividade para a categoria tecnologica.");
			}
		} catch (Exception e) {				 
			result.setIsError(true);
			result.setMessage(e.getMessage());
		}				
	
		return result;
	}


}

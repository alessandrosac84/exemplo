/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import org.junit.Assert;
import org.junit.Test;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Job;
import br.gov.caixa.inovacao.continuousmanager.util.Util;

/**
 * Classe de Testes de Util
 * 
 * @author Fabio Iwakoshi
 *
 */
public class UtilTest {

	@Test
	public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InstantiationException,
			IllegalArgumentException, InvocationTargetException {
		// Arrange
		Constructor<Util> constructor = Util.class.getDeclaredConstructor();
		constructor.setAccessible(true);
		
		// Act
		constructor.newInstance();
		
		// Then
		Assert.assertTrue(Modifier.isPrivate(constructor.getModifiers()));
	}

	@Test
	public void testFixEntity() throws IllegalAccessException {
		// Act
		Util.fixEntity(new Job());
	}

}

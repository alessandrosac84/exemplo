package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * The primary key class for the project database table.
 * 
 * @author Fabio Iwakoshi
 */
@Embeddable
public class ProjectPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@JsonView(ViewJson.ProjectView.class)
	@Column(unique=true, nullable=false, length=30)
	private String id;

	@JsonView(ViewJson.ProjectView.class)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String wallet;

	public ProjectPK() {
		/* class constructor intentionally left blank */
	}
	public String getId() {
		return this.id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getWallet() {
		return this.wallet;
	}
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ProjectPK)) {
			return false;
		}
		ProjectPK castOther = (ProjectPK)other;
		return 
			this.id.equals(castOther.id)
			&& this.wallet.equals(castOther.wallet);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.id.hashCode();
		hash = hash * prime + this.wallet.hashCode();
		
		return hash;
	}
}
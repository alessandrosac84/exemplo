package br.gov.caixa.api.repository.views;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.views.EspecialidadeAtividadeView;

public interface EspecialidadeAtividadeViewRepository extends JpaRepository<EspecialidadeAtividadeView, Long> {

		
	@Query("select a from EspecialidadeAtividadeView a where (a.especialidadeId = ?1 or a.especialidadeId is null)")
	List<EspecialidadeAtividadeView> findByEspecialidadeId(Long especialidadeId);

}

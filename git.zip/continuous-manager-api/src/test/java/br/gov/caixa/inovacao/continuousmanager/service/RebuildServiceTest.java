package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sharepoint.FuncionarioSharepointVO;
import br.gov.caixa.inovacao.continuousmanager.service.integration.JenkinsService;
import br.gov.caixa.inovacao.continuousmanager.service.integration.SharepointService;

/**
 * Classe de testes do RebuildService.
 * 
 * @author Alessandro Carvalho
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class RebuildServiceTest {
	
	@InjectMocks
	private RebuildService rebuildService;
	
	@Mock
	private JenkinsService jenkinsService;
	
	@Mock
	private SharepointService sharepointService;
	
	private FuncionarioSharepointVO func = new FuncionarioSharepointVO();
	
	@Before
	public void before() {
		func.setMatricula("f777884");
		func.setNome("José");
		UtilReflection.setField(rebuildService, "log", Logger.getLogger(AuditService.class.getName()));
	}
	
	@Test
	public void rebuild() {
		//Arrange
		HelperThreadLocal.USER.set(func.getMatricula());
		Mockito.when(sharepointService.getFuncionario(Mockito.anyString())).thenReturn(func);
		
		// Act
		rebuildService.rebuild("inovacao", "continuous-manager-web", "portal-inovacao-api-ci-dev", "sdasadasdasd");
	}

}

import { NgModule } from '@angular/core';

import { ProjectsManagementRoutingModule } from './projects-management-routing.module';
import { SharedModule } from '../../../../shared/shared.module';
import { MatPaginator, MatPaginatorModule, MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { AddMemberComponent } from './add-project/add-member/add-member.component';
import { AddBranchComponent } from './add-project/add-branch/add-branch.component';
import { AddParametersComponent } from './add-project/add-branch/add-parameters/add-parameters.component';
import { AddServersComponent } from './add-project/add-branch/add-servers/add-servers.component';
import { AddRepositoryComponent } from './add-project/add-repository/add-repository.component';
import { AddProjectComponent } from './add-project/add-project.component';
import { ProjectsManagementComponent } from './projects-management.component';

@NgModule({
  imports: [
    SharedModule,
    ProjectsManagementRoutingModule,
  ],
  declarations: [ProjectsManagementComponent, AddProjectComponent, AddRepositoryComponent,
    AddMemberComponent, AddBranchComponent, AddParametersComponent, AddServersComponent, AddMemberComponent],
  entryComponents: [
    AddProjectComponent, AddRepositoryComponent, AddBranchComponent, AddParametersComponent, AddServersComponent, AddMemberComponent
  ],
  providers: [{
    provide: MatDialogRef,
    useValue: {}
  }, {
    provide: MAT_DIALOG_DATA,
    useValue: {}
  }]
})
export class ProjectsManagementModule { }

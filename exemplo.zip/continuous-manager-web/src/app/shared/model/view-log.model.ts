export class ViewLog {
    public number_build: number;
    public result_build: string;
    public timestamp_build: Date;
    public short_id_commit: string;
    public title_commit: string;
    public author_name_commit: string;
}

package br.gov.caixa.api.controller;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.dto.EspecialidadeProcessoDto;
import br.gov.caixa.api.result.EspecialidadeProcessoResult;
import br.gov.caixa.api.services.EspecialidadeProcessoService;

@RestController
public class EspecialidadeProcessoController {

	@Inject
	EspecialidadeProcessoService service;

	@RequestMapping(value = "/api/especialidadeProcesso/all", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeProcessoResult listAll() {
		return service.listAll();
	}

	@RequestMapping(value="/api/especialidadeProcesso/save", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeProcessoResult save(@RequestBody EspecialidadeProcessoDto especialidadeProcessoDto) {
		
		return service.save(especialidadeProcessoDto);
	}
	
	@RequestMapping(value="/api/especialidadeProcesso/delete", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeProcessoResult delete(@RequestBody EspecialidadeProcessoDto especialidadeProcessoDto) {
		
		return service.delete(especialidadeProcessoDto);
	}
	
	@RequestMapping(value="/api/especialidadeProcesso/obterEspecialidadeProcessoPorIdEspecialidade/{idEspecialidade}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeProcessoResult obterAtivoPorIdCategoria(@PathVariable Long idEspecialidade) {
		
		return service.listEspecialidadeProcessosByIdProcesso(idEspecialidade);
	}


}

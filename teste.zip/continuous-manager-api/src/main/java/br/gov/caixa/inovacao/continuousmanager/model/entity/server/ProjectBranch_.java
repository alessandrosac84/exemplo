package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity_;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Project;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-15T10:48:02.779-0300")
@StaticMetamodel(ProjectBranch.class)
public class ProjectBranch_ extends AuditedEntity_ {
	public static volatile SingularAttribute<ProjectBranch, ProjectBranchPK> id;
	public static volatile SetAttribute<ProjectBranch, BranchInstance> branchInstances;
	public static volatile SetAttribute<ProjectBranch, BranchParameter> branchParameters;
	public static volatile SingularAttribute<ProjectBranch, Project> project;
}

package br.gov.caixa.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.gov.caixa.api.model.Especialidade;
import br.gov.caixa.api.model.EspecialidadeAtividade;

public interface EspecialidadeAtividadeRepository extends JpaRepository<EspecialidadeAtividade, Long> {

	List<EspecialidadeAtividade> findByEspecialidade(Especialidade especialidade);
	
	@Query("select a from EspecialidadeAtividade a where a.especialidade.uid = ?1 order by a.uid")
	List<EspecialidadeAtividade> findByEspecialidadeId(Long especialidadeId);

}

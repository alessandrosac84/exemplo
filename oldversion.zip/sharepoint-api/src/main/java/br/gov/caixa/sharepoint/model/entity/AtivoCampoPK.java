package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.Size;

/**
 * The primary key class for the ativo_campo database table.
 * 
 */
@Embeddable
public class AtivoCampoPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private Integer ativo;

	@Size(min=3, max=20)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=20)
	private String campo;
	
	@Column(name="tipo_ativo", updatable=false, unique=true, nullable=false)
	private Integer tipoAtivo;

	public AtivoCampoPK() {
	}
	public Integer getAtivo() {
		return this.ativo;
	}
	public void setAtivo(Integer ativo) {
		this.ativo = ativo;
	}
	public String getCampo() {
		return this.campo;
	}
	public void setCampo(String campo) {
		this.campo = campo;
	}
	public Integer getTipoAtivo() {
		return tipoAtivo;
	}
	public void setTipoAtivo(Integer tipoAtivo) {
		this.tipoAtivo = tipoAtivo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AtivoCampoPK)) {
			return false;
		}
		AtivoCampoPK castOther = (AtivoCampoPK)other;
		return 
			this.ativo.equals(castOther.ativo)
			&& this.campo.equals(castOther.campo)
			&& this.tipoAtivo.equals(castOther.tipoAtivo);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((ativo == null) ? 0 : ativo.hashCode());
		hash = hash * prime + ((campo == null) ? 0 : campo.hashCode());
		hash = hash * prime + ((tipoAtivo == null) ? 0 : tipoAtivo.hashCode());
		
		return hash;
	}
}
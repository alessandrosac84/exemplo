import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cm-news',
  templateUrl: './news.component.html',
  styles: []
})
export class NewsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

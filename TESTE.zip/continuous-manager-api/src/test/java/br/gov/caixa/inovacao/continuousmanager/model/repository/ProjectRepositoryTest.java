/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ProjectPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Project_;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes de ProjectRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ProjectRepositoryTest {
	
	@Mock
	private EntityManager em;
	
	@Mock
	private CriteriaBuilder builder;
	
	@Mock
	private CriteriaQuery<Project> query;
	
	@Mock
	private CriteriaQuery<Long> queryCount;
	
	@Mock
	private Root<Project> from;
	
	@Mock
	private Expression<Long> expressionCount;
	
	@Mock
	private TypedQuery<Project> typedQuery;
	
	@Mock
	private TypedQuery<Long> typedQueryCount;
	
	@Mock
	private Path<ProjectPK> path;

	@InjectMocks
	private ProjectRepository projectRepository;
	
	private List<Project> projects;

	@Before
	public void before() {
		projects = EntityBuilder.createProjects();
	}

	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(em.find(Project.class, projects.get(0).getId())).thenReturn(projects.get(0));
		
		// Act
		Project retorno = projectRepository.findById(projects.get(0).getId());
		
		// Then
		Assert.assertNotNull(retorno.getId());
	}

	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Project>>any())).thenReturn(typedQuery);
		
		Mockito.when(builder.createQuery(Project.class)).thenReturn(query);
		
		
		
		Mockito.when(query.from(Project.class)).thenReturn(from);
		Mockito.when(from.get(Project_.id)).thenReturn(path);
		Mockito.when(query.select(from)).thenReturn(query);
		Mockito.when(query.where(Mockito.<Expression<Boolean>>any())).thenReturn(query);
		
		Mockito.when(typedQuery.setFirstResult(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setMaxResults(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(projects);
		
		// Act
		List<Project> retorno = projectRepository.findAll("inovacao", 0, 30, "", "id", AscDesc.ASC);
		
		// Then
		Assert.assertEquals(2, retorno.size());
	}

	@Test
	public void testFindAllDesc() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Project>>any())).thenReturn(typedQuery);
		
		Mockito.when(builder.createQuery(Project.class)).thenReturn(query);
		
		
		
		Mockito.when(query.from(Project.class)).thenReturn(from);
		Mockito.when(from.get(Project_.id)).thenReturn(path);
		Mockito.when(query.select(from)).thenReturn(query);
		Mockito.when(query.where(Mockito.<Expression<Boolean>>any())).thenReturn(query);
		
		Mockito.when(typedQuery.setFirstResult(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setMaxResults(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(projects);
		
		// Act
		List<Project> retorno = projectRepository.findAll("inovacao", 0, 30, "", "id", AscDesc.DESC);
		
		// Then
		Assert.assertEquals(2, retorno.size());
	}

	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Long>>any())).thenReturn(typedQueryCount);
		
		Mockito.when(builder.createQuery(Long.class)).thenReturn(queryCount);
		Mockito.when(builder.count(from)).thenReturn(expressionCount);
		
		Mockito.when(queryCount.from(Project.class)).thenReturn(from);
		Mockito.when(from.get(Project_.id)).thenReturn(path);
		Mockito.when(queryCount.select(expressionCount)).thenReturn(queryCount);
		Mockito.when(queryCount.where(Mockito.<Expression<Boolean>>any())).thenReturn(queryCount);
		
		Mockito.when(typedQueryCount.getSingleResult()).thenReturn((long) projects.size());
		
		// Act
		Long retorno = projectRepository.countAll("inovacao", "");
		
		// Then
		Assert.assertEquals(2, retorno.longValue());
	}
	
	@Test
	public void testSave() {
		// Act
		Project save = projectRepository.save(projects.get(0));
		// Then
		Assert.assertEquals(projects.get(0).getId(), save.getId());
	}

}

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Job;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JobPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.Job_;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes de JobRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class JobRepositoryTest {
	
	@Mock
	private EntityManager em;
	
	@Mock
	private CriteriaBuilder builder;
	
	@Mock
	private CriteriaQuery<Job> query;
	
	@Mock
	private CriteriaQuery<Long> queryCount;
	
	@Mock
	private Root<Job> from;
	
	@Mock
	private Expression<Long> expressionCount;
	
	@Mock
	private TypedQuery<Job> typedQuery;
	
	@Mock
	private TypedQuery<Long> typedQueryCount;
	
	@Mock
	private Path<JobPK> path;

	@InjectMocks
	private JobRepository jobRepository;
	
	private List<Job> jobs;

	@Before
	public void before() {
		jobs = EntityBuilder.createJobs();
	}

	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(em.find(Job.class, jobs.get(0).getId())).thenReturn(jobs.get(0));
		
		// Act
		Job retorno = jobRepository.findById(jobs.get(0).getId());
		
		// Then
		Assert.assertNotNull(retorno.getId());
	}

	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Job>>any())).thenReturn(typedQuery);
		
		Mockito.when(builder.createQuery(Job.class)).thenReturn(query);
		
		
		
		Mockito.when(query.from(Job.class)).thenReturn(from);
		Mockito.when(from.get(Job_.id)).thenReturn(path);
		Mockito.when(query.select(from)).thenReturn(query);
		Mockito.when(query.where(Mockito.<Expression<Boolean>>any())).thenReturn(query);
		
		Mockito.when(typedQuery.setFirstResult(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setMaxResults(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(jobs);
		
		// Act
		List<Job> retorno = jobRepository.findAll("inovacao", "portal-inovacao", 0, 30, "", "id", AscDesc.ASC);
		
		// Then
		Assert.assertEquals(2, retorno.size());
	}

	@Test
	public void testFindAllDesc() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Job>>any())).thenReturn(typedQuery);
		
		Mockito.when(builder.createQuery(Job.class)).thenReturn(query);
		
		
		
		Mockito.when(query.from(Job.class)).thenReturn(from);
		Mockito.when(from.get(Job_.id)).thenReturn(path);
		Mockito.when(query.select(from)).thenReturn(query);
		Mockito.when(query.where(Mockito.<Expression<Boolean>>any())).thenReturn(query);
		
		Mockito.when(typedQuery.setFirstResult(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setMaxResults(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(jobs);
		
		// Act
		List<Job> retorno = jobRepository.findAll("inovacao", "portal-inovacao", 0, 30, "", "id", AscDesc.DESC);
		
		// Then
		Assert.assertEquals(2, retorno.size());
	}

	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Long>>any())).thenReturn(typedQueryCount);
		
		Mockito.when(builder.createQuery(Long.class)).thenReturn(queryCount);
		Mockito.when(builder.count(from)).thenReturn(expressionCount);
		
		Mockito.when(queryCount.from(Job.class)).thenReturn(from);
		Mockito.when(from.get(Job_.id)).thenReturn(path);
		Mockito.when(queryCount.select(expressionCount)).thenReturn(queryCount);
		Mockito.when(queryCount.where(Mockito.<Expression<Boolean>>any())).thenReturn(queryCount);
		
		Mockito.when(typedQueryCount.getSingleResult()).thenReturn((long) jobs.size());
		
		// Act
		Long retorno = jobRepository.countAll("inovacao", "portal-inovacao", "");
		
		// Then
		Assert.assertEquals(2, retorno.longValue());
	}
	
	@Test
	public void testSave() {
		// Act
		Job save = jobRepository.save(jobs.get(0));
		// Then
		Assert.assertEquals(jobs.get(0).getId(), save.getId());
	}

}

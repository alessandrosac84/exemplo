package br.com.opussolutions.model.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.com.opussolutions.model.entity.Cliente;


@ApplicationScoped
public class OpusRepository {
	
	@Inject
	private EntityManager entityManager;

	/**
	 * Metodo responsavel pela consulta paginada de Folders no banco de dados
	 * 
	 * @param environment
	 * @return Parameter
	 */
	public br.com.opussolutions.model.entity.Cliente findById(String cliente) {
		return entityManager.find(Cliente.class, cliente);
	}

}

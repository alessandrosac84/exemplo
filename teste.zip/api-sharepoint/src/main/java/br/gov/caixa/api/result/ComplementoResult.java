package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.ComplementoDto;

public class ComplementoResult extends BasicResult {

	private List<ComplementoDto> list;

	public List<ComplementoDto> getList() {
		return list;
	}

	public void setList(List<ComplementoDto> list) {
		this.list = list;
	}	
}
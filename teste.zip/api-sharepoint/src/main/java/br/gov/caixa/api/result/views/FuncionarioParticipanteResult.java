package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.dto.views.FuncionarioParticipanteDto;
import br.gov.caixa.api.result.BasicResult;

public class FuncionarioParticipanteResult extends BasicResult  {
	private List<FuncionarioParticipanteDto> list;
	private FuncionarioParticipanteDto funcionarioParticipante;	

	public List<FuncionarioParticipanteDto> getList() {
		return list;
	}

	public void setList(List<FuncionarioParticipanteDto> list) {
		this.list = list;
	}

	public FuncionarioParticipanteDto getFuncionarioParticipante() {
		return funcionarioParticipante;
	}

	public void setFuncionarioQuestionante(FuncionarioParticipanteDto funcionarioParticipante) {
		this.funcionarioParticipante = funcionarioParticipante;
	}	
}

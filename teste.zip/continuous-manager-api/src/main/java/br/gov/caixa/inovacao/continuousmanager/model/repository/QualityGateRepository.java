package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGate;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGatePK;

/**
 * Classe de acesso ao banco de dados da entidade Parameter.
 * 
 * @author Alessandro Carvalho
 *
 */
@ApplicationScoped
public class QualityGateRepository {
	
	@Inject
	private EntityManager entityManager;
	
	/**
	 * Salva Quality Gate
	 * 
	 * @param QualityGate
	 * @return QualityGate
	 */
	public QualityGate save(QualityGate qualityGate) {
		entityManager.persist(qualityGate);
		return qualityGate;
	}

	public QualityGate findById(QualityGatePK id) {
		return entityManager.find(QualityGate.class, id);
	}
}

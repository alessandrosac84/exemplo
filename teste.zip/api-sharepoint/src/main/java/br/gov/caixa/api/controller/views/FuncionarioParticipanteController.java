package br.gov.caixa.api.controller.views;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.result.views.FuncionarioParticipanteResult;
import br.gov.caixa.api.services.views.FuncionarioParticipanteService;

@RestController
public class FuncionarioParticipanteController {
	
	@Inject
	FuncionarioParticipanteService service;
		          
	@RequestMapping(value="/api/funcionarioParticipante/listFuncionariosParticipantesByTurmaId/{turmaId}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public FuncionarioParticipanteResult listFuncionariosParticipantesByTurmaId(@PathVariable Long turmaId) {
		
		return service.listFuncionariosParticipantesByTurmaId(turmaId);
	}
	
	
}

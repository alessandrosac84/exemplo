package br.gov.caixa.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import br.gov.caixa.api.model.CategoriaTecnologica;
import br.gov.caixa.api.model.Ferramenta;

public interface FerramentaRepository extends JpaRepository<Ferramenta, Long>  {

	List<Ferramenta> findByCategoriaTecnologica(CategoriaTecnologica categoriaTecnologica);	
	
	@Query("select a from Ferramenta a where a.categoriaTecnologica = ?1 order by a.uid")
	public List<Ferramenta> findByCategoriaTecnologicaOrder(CategoriaTecnologica categoriaTecnologica);
	
	@Modifying
	@Transactional
	@Query("update Ferramenta f set f.ativo = ?1 where f.uid = ?2")
	int setAtivo(Boolean ativo, Long uid);
		
	@Query("select a from Ferramenta a where a.ativo = true order by a.uid")
	public List<Ferramenta> findAllAtivas();
	
	public Ferramenta findByNome(String nome);

	@Query("select a from Ferramenta a where a.ativo = true order by a.nome")
	List<Ferramenta> findAllOrderByNome();
 
}

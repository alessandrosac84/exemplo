/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.repository.BuildRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes do BuildService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BuildServiceTest {
	
	@Mock
	private BuildRepository buildRepository;

	@InjectMocks
	private BuildService buildService;

	private List<Build> builds;
	
	@Before
	public void before() {
		builds = EntityBuilder.createBuilds();
		UtilReflection.setField(buildService, "log", Logger.getLogger(BuildService.class.getName()));
	}
	
	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(buildRepository.findById(builds.get(0).getId())).thenReturn(builds.get(0));
		
		// Act
		Build build = buildService.findById(builds.get(0).getId());

		// Then
		Assert.assertEquals(1, build.getId().getId().intValue());
		Assert.assertEquals("portal-inovacao-api-ci-dev", build.getId().getJob());
		Assert.assertEquals("portal-inovacao", build.getId().getProject());
		Assert.assertEquals("inovacao", build.getId().getWallet());
		Assert.assertNotNull(build.getChangeSets());
		Assert.assertNotNull(build.getCreatedAt());
		Assert.assertEquals("description", build.getDescription());
		Assert.assertNotNull(build.getDuration());
		Assert.assertNotNull(build.getEstimateDuration());
		//Assert.assertNull(build.getJob());
		//Assert.assertTrue(build.getLog().length() > 100);
		//Assert.assertNotNull(build.getProjectEnvironments());
		Assert.assertEquals(JenkinsResult.SUCCESS, build.getResult());
	}
	
	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(buildRepository.findAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 0, 30, "", "id", AscDesc.ASC)).thenReturn(builds);
		
		// Act
		List<Build> listBuilds = buildService.findAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 0, 30, "", "id", AscDesc.ASC);

		// Then
		Assert.assertEquals(2, listBuilds.size());
	}
	
	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(buildRepository.countAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", "")).thenReturn((long) builds.size());
		
		// Act
		Long contBuilds = buildService.countAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", "");

		// Then
		Assert.assertEquals(2, contBuilds.longValue());
	}
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(buildRepository.save(builds.get(0))).thenReturn(builds.get(0));
		
		// Act
		Build build = buildService.save(builds.get(0));

		// Then
		Assert.assertEquals(builds.get(0).getId(), build.getId());
	}
	
//	@Test
//	public void testGetLog() {
//		// Arrange
//		Mockito.when(buildRepository.findById(builds.get(0).getId())).thenReturn(builds.get(0));
//		
//		// Act
//		String log = buildService.getLog("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 1);
//
//		// Then
//		Assert.assertTrue(log.length() > 100);
//	}
//	
//	@Test
//	public void testGetLogStages() {
//		// Arrange
//		Mockito.when(buildRepository.findById(builds.get(0).getId())).thenReturn(builds.get(0));
//		
//		// Act
//		List<Stage> stages = buildService.getLogStages("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 1);
//
//		// Then
//		Assert.assertEquals(3, stages.size());
//		Assert.assertEquals(1, stages.get(0).getSteps().size());
//		Assert.assertEquals(1693, stages.get(0).getSteps().get(0).getLines().length());
//	}
}

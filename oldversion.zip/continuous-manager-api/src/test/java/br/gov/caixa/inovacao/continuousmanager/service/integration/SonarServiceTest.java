package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.util.logging.Logger;

import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.ssl.SSLContexts;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.server.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.Comparator;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.InfoSonarVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.MeasureHistorySonarVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.sonar.QualityGateVO;
import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;

/**
 * Classe de testes do SonarService.
 * 
 * @author Alessandro Carvalho
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ SSLContexts.class, ClientBuilder.class })
@PowerMockIgnore("javax.net.ssl.*")
public class SonarServiceTest {

	@Rule
	public MockitoRule mrule = MockitoJUnit.rule();

	@Mock
	private ParameterService parameterService;

	@InjectMocks
	private SonarService sonarService;

	@Mock
	private Response response;

	@Mock
	private ClientBuilder clientBuilder;

	@Mock
	private Client client;

	@Mock
	private WebTarget target;

	@Mock
	private Invocation.Builder builder;

	private Parameter parameter;

	@Before
	public void before() {
		parameter = new Parameter();
		parameter.setId(new ParameterPK());
		parameter.getId().setEnvironment(Environment.DES);
		parameter.getId().setServerType(ServerType.SONAR);
		parameter.setCredential("");
		parameter.setHost("https://sonar.caixa");
		parameter.setPrincipal("Sonar");
		UtilReflection.setField(sonarService, "log", Logger.getLogger(SonarService.class.getName()));
	}

	@Test
	public void testGetMeasures() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
		Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class))
				.thenReturn("{\"paging\":{\"pageIndex\":1,\"pageSize\":100,\"total\":1},"
						+ "\"measures\":[{\"metric\":\"branch_coverage\",\"history\":[{\"date\":\"2018-05-30T17:49:56-0300\",\"value\":\"61.0\"}]},"
						+ "{\"metric\":\"it_coverage\",\"history\":[]},{\"metric\":\"it_lines_to_cover\",\"history\":[]}]}");

		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);

		// Act
		MeasureHistorySonarVO sonarMeasureVO = sonarService.getMeasuresHistory("hdahuidahiuda",
				"2018-05-30T17:49:45-0300", "2018-05-30T17:50:27-0300");
		// Then
		Assert.assertNotNull(sonarMeasureVO.getMeasures());
	}

	@Test
	public void testGetMeasuresHistoryException() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
		Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);

		// Act
		MeasureHistorySonarVO sonarMeasureVO = sonarService.getMeasuresHistory("hdahuidahiuda",
				"2018-05-30T17:49:45-0300", "2018-05-30T17:50:27-0300");
		// Then
		Assert.assertNull(sonarMeasureVO);
	}

	@Test
	public void testGetInfoSonar() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
		Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class))
				.thenReturn("{\"task\": {\"organization\": \"default-organization\","
						+ "\"id\": \"AWMsbkrTorV0KED3ChF8\",\"type\": \"REPORT\",\"componentId\": \"AV6V_YPUWyFlvteRPM6e\","
						+ "\"componentKey\": \"br.gov.caixa.inovacao:continuous-manager-api\",\"componentName\": \"Continuous Manager API\","
						+ "\"componentQualifier\": \"TRK\",\"analysisId\": \"AWMsbk5MnXONwxOWgwl2\",\"status\": \"SUCCESS\","
						+ "\"submittedAt\": \"2018-05-04T15:33:35-0300\",\"submitterLogin\": \"sonarqube\",\"startedAt\": \"2018-05-04T15:33:35-0300\","
						+ "\"executedAt\": \"2018-05-04T15:33:53-0300\",\"executionTimeMs\": 17616,\"logs\": false,\"hasScannerContext\": true}}");

		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);

		// Act
		InfoSonarVO infoSonarVO = sonarService.getInfoSonar("hdahuidahiuda");
		// Then
		Assert.assertEquals("default-organization", infoSonarVO.getTask().getOrganization());
		Assert.assertEquals("AWMsbkrTorV0KED3ChF8", infoSonarVO.getTask().getId());
		Assert.assertEquals("REPORT", infoSonarVO.getTask().getType());
		Assert.assertEquals("AV6V_YPUWyFlvteRPM6e", infoSonarVO.getTask().getComponentId());
		Assert.assertEquals("br.gov.caixa.inovacao:continuous-manager-api", infoSonarVO.getTask().getComponentKey());
		Assert.assertEquals("Continuous Manager API", infoSonarVO.getTask().getComponentName());
		Assert.assertEquals("TRK", infoSonarVO.getTask().getComponentQualifier());
		Assert.assertEquals("AWMsbk5MnXONwxOWgwl2", infoSonarVO.getTask().getAnalysisId());
		Assert.assertEquals("SUCCESS", infoSonarVO.getTask().getStatus());
		Assert.assertNotNull(infoSonarVO.getTask().getSubmittedAt());
		Assert.assertEquals("sonarqube", infoSonarVO.getTask().getSubmitterLogin());
		Assert.assertNotNull(infoSonarVO.getTask().getStartedAt());
		Assert.assertNotNull(infoSonarVO.getTask().getExecutedAt());
		Assert.assertEquals(17616L, infoSonarVO.getTask().getExecutionTimeMs().longValue());
		Assert.assertEquals(false, infoSonarVO.getTask().getLogs());
		Assert.assertEquals(true, infoSonarVO.getTask().getHasScannerContext());
	}

	@Test(expected=ServiceUnavailableException.class)
	public void testGetInfoSonarException() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
		Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);

		// Act
		InfoSonarVO infoSonarVO = sonarService.getInfoSonar("hdahuidahiuda");
		// Then
		Assert.assertEquals("default-organization", infoSonarVO.getTask().getOrganization());
		Assert.assertEquals("AWMsbkrTorV0KED3ChF8", infoSonarVO.getTask().getId());
		Assert.assertEquals("REPORT", infoSonarVO.getTask().getType());
		Assert.assertEquals("AV6V_YPUWyFlvteRPM6e", infoSonarVO.getTask().getComponentId());
		Assert.assertEquals("br.gov.caixa.inovacao:continuous-manager-api", infoSonarVO.getTask().getComponentKey());
		Assert.assertEquals("Continuous Manager API", infoSonarVO.getTask().getComponentName());
		Assert.assertEquals("TRK", infoSonarVO.getTask().getComponentQualifier());
		Assert.assertEquals("AWMsbk5MnXONwxOWgwl2", infoSonarVO.getTask().getAnalysisId());
		Assert.assertEquals("SUCCESS", infoSonarVO.getTask().getStatus());
		Assert.assertNotNull(infoSonarVO.getTask().getSubmittedAt());
		Assert.assertEquals("sonarqube", infoSonarVO.getTask().getSubmitterLogin());
		Assert.assertNotNull(infoSonarVO.getTask().getStartedAt());
		Assert.assertNotNull(infoSonarVO.getTask().getExecutedAt());
		Assert.assertEquals(17616L, infoSonarVO.getTask().getExecutionTimeMs().longValue());
		Assert.assertEquals(false, infoSonarVO.getTask().getLogs());
		Assert.assertEquals(true, infoSonarVO.getTask().getHasScannerContext());
	}

	@Test
	public void testGetQualityGate() {
		// Arrange
		PowerMockito.mockStatic(ClientBuilder.class);
		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.hostnameVerifier(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.sslContext(Mockito.any())).thenReturn(clientBuilder);
		Mockito.when(clientBuilder.build()).thenReturn(client);
		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
		Mockito.when(builder.header(Mockito.anyString(), Mockito.anyString())).thenReturn(builder);
		Mockito.when(builder.get()).thenReturn(response);
		Mockito.when(response.hasEntity()).thenReturn(true);
		Mockito.when(response.readEntity(String.class))
				.thenReturn("{\"id\":1,\"name\":\"SonarQubeway\",\"conditions\":[{\"id\":1,\"metric\":\"new_security_rating\",\"op\":\"GT\","
						+ "\"error\":\"1\",\"period\":1},{\"id\":2,\"metric\":\"new_reliability_rating\",\"op\":\"GT\",\"error\":\"1\",\"period\":1},"
						+ "{\"id\":3,\"metric\":\"new_maintainability_rating\",\"op\":\"GT\",\"error\":\"1\",\"period\":1},"
						+ "{\"id\":4,\"metric\":\"new_coverage\",\"op\":\"LT\",\"error\":\"80\",\"period\":1}]}");

		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(parameterService.findById(parameter.getId())).thenReturn(parameter);

		// Act
		QualityGateVO qualityGateVO = sonarService.getQualityGates();
		// Then
		Assert.assertEquals("new_security_rating", qualityGateVO.getConditions().get(0).getMetric());
		Assert.assertEquals(Comparator.GT, qualityGateVO.getConditions().get(0).getOp());
		Assert.assertEquals("1", qualityGateVO.getConditions().get(0).getError());
	}
}

package br.gov.caixa.portalinovacao.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.portalinovacao.model.vo.TransacaoVO;
import br.gov.caixa.portalinovacao.service.geraws.SUDPOMSGPort;
import br.gov.caixa.portalinovacao.service.geraws.SUDPOMSGService;
import br.gov.caixa.portalinovacao.service.geraws.request.ProgramInterface;
import br.gov.caixa.portalinovacao.service.geraws.response.ProgramInterface.WebSudwsmsg;

@RunWith(MockitoJUnitRunner.class)
public class TransacaoServiceTest {
	
	@InjectMocks
	private TransacaoService transacaoService;
	
	@Mock
	private SUDPOMSGService service1;
	
	@Mock
	private SUDPOMSGPort port1;
	
	@Mock
	private WebSudwsmsg webSudwsmsg;

	@Test
	public void testSend() {
		TransacaoVO transacao = new TransacaoVO();

		transacao.setPrograma("AAAA1234");
		transacao.setUri("teste");
		transacao.setSistemaId("CAIXA");
		transacao.setFlag("1");
		transacao.setBookEntrada("AAAA1234");
		transacao.setBookSaida("BBBB1234");
		transacao.setDiretorioEntrada("testeEntrada");
		transacao.setDiretorioSaida("testeSaida");

		Mockito.when(service1.getSUDPOMSGPort()).thenReturn(port1);
		Mockito.when(port1.geraws(Mockito.any())).thenReturn(webSudwsmsg);
		Mockito.when(webSudwsmsg.getWebMsgRetorno()).thenReturn("xxx");
		
		String send = transacaoService.send(transacao);
				
		ProgramInterface request = new ProgramInterface();
		request.setWebSudwsmsg(new ProgramInterface.WebSudwsmsg());
		request.getWebSudwsmsg().getWebUsuarioTmpdirUsuserv();
		request.getWebSudwsmsg().getWebPdslibBook();
		request.getWebSudwsmsg().getWebReqmemBookEntrada();
		request.getWebSudwsmsg().getWebResquestNamespace();
		request.getWebSudwsmsg().getWebResponseNamespace();
		request.getWebSudwsmsg().getWebLang();
		request.getWebSudwsmsg().getWebPgmname();
		request.getWebSudwsmsg().getWebUri();
		request.getWebSudwsmsg().getWebPgmintContainerCommarea();
		request.getWebSudwsmsg().getWebWsbind();
		request.getWebSudwsmsg().getWebWsdl();
		request.getWebSudwsmsg().getWebWsdlNamespaceHttp();
		request.getWebSudwsmsg().getWebOperationName();
		request.getWebSudwsmsg().getWebUserid();
		request.getWebSudwsmsg().getWebTransaction();
		request.getWebSudwsmsg().getWebMsgRetorno();
		request.getWebSudwsmsg().getWebSequenciaControle();
		request.getWebSudwsmsg().getWebSubmitStatus();
		request.getWebSudwsmsg().getWebRespmemBookSaida();
				
		br.gov.caixa.portalinovacao.service.geraws.response.ProgramInterface.WebSudwsmsg webSudwsmsg = new WebSudwsmsg();
		webSudwsmsg.getWebUsuarioTmpdirUsuserv();
		webSudwsmsg.setWebUsuarioTmpdirUsuserv("");
		webSudwsmsg.getWebPdslibBook();
		webSudwsmsg.setWebPdslibBook("");
		webSudwsmsg.getWebReqmemBookEntrada();
		webSudwsmsg.setWebReqmemBookEntrada("");
		webSudwsmsg.getWebResquestNamespace();
		webSudwsmsg.setWebResquestNamespace("");
		webSudwsmsg.getWebRespmemBookSaida();
		webSudwsmsg.setWebRespmemBookSaida("");
		webSudwsmsg.getWebResponseNamespace();
		webSudwsmsg.setWebResponseNamespace("");
		webSudwsmsg.getWebLang();
		webSudwsmsg.setWebLang("");
		webSudwsmsg.getWebPgmname();
		webSudwsmsg.setWebPgmname("");
		webSudwsmsg.getWebUri();
		webSudwsmsg.setWebUri("");
		webSudwsmsg.getWebPgmintContainerCommarea();
		webSudwsmsg.setWebPgmintContainerCommarea("");
		webSudwsmsg.getWebWsbind();
		webSudwsmsg.setWebWsbind("");
		webSudwsmsg.getWebWsdl();
		webSudwsmsg.setWebWsdl("");
		webSudwsmsg.getWebWsdlNamespaceHttp();
		webSudwsmsg.setWebWsdlNamespaceHttp("");
		webSudwsmsg.getWebOperationName();
		webSudwsmsg.setWebOperationName("");
		webSudwsmsg.getWebUserid();
		webSudwsmsg.setWebUserid("");
		webSudwsmsg.getWebTransaction();
		webSudwsmsg.setWebTransaction("");
		webSudwsmsg.getWebMsgRetorno();
		webSudwsmsg.setWebMsgRetorno("");
		webSudwsmsg.getWebSequenciaControle();
		webSudwsmsg.setWebSequenciaControle(0L);
		webSudwsmsg.getWebSubmitStatus();
		webSudwsmsg.setWebSubmitStatus("");
		
		Assert.assertEquals("xxx", send);
	}

}

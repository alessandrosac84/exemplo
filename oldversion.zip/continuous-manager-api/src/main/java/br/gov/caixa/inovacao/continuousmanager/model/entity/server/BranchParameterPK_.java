package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-15T10:43:47.547-0300")
@StaticMetamodel(BranchParameterPK.class)
public class BranchParameterPK_ {
	public static volatile SingularAttribute<BranchParameterPK, String> wallet;
	public static volatile SingularAttribute<BranchParameterPK, String> project;
	public static volatile SingularAttribute<BranchParameterPK, String> branch;
	public static volatile SingularAttribute<BranchParameterPK, String> parameter;
}

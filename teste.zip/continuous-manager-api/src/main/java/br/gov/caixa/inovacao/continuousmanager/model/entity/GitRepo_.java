package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.util.Calendar;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-04-17T16:24:09.075-0300")
@StaticMetamodel(GitRepo.class)
public class GitRepo_ {
	public static volatile SingularAttribute<GitRepo, GitRepoPK> id;
	public static volatile SingularAttribute<GitRepo, String> authorEmail;
	public static volatile SingularAttribute<GitRepo, String> authorName;
	public static volatile SingularAttribute<GitRepo, Integer> sequential;
	public static volatile SingularAttribute<GitRepo, Calendar> authoredDate;
	public static volatile SingularAttribute<GitRepo, Calendar> committedDate;
	public static volatile SingularAttribute<GitRepo, String> committerEmail;
	public static volatile SingularAttribute<GitRepo, String> committerName;
	public static volatile SingularAttribute<GitRepo, String> message;
	public static volatile SingularAttribute<GitRepo, String> title;
	public static volatile SingularAttribute<GitRepo, String> version;
	public static volatile SingularAttribute<GitRepo, Calendar> versionedAt;
	public static volatile SingularAttribute<GitRepo, String> versionerUser;
}

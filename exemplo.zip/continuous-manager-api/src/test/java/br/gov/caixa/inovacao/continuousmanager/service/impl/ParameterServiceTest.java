///**
// * 
// */
//package br.gov.caixa.inovacao.continuousmanager.service.impl;
//
//import java.util.logging.Logger;
//
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.junit.MockitoJUnitRunner;
//
//import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
//import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
//import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
//import br.gov.caixa.inovacao.continuousmanager.model.repository.ParameterRepository;
//import br.gov.caixa.inovacao.continuousmanager.service.JenkinsService;
//import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;
//import br.gov.caixa.inovacao.continuousmanager.service.WalletService;
//
///**
// * Classe de testes do WalletService.
// * 
// * @author Fabio Iwakoshi
// *
// */
//@RunWith(MockitoJUnitRunner.class)
//public class ParameterServiceTest {
//
//	@Mock
//	private JenkinsService jenkinsService;
//	
//	@Mock
//	private ParameterRepository parameterRepository;
//
//	@InjectMocks
//	private ParameterService parameterService;
//
//	@Before
//	public void before() {
//		Parameter parameter = new Parameter();
//		parameter.setEnvironment(Environment.DESENVOLVIMENTO);
//		parameter.setJenkinsHost("https://10.1.32.242:8443/");
//		parameter.setJenkinsAuthorization("sdfij342hj3b43k23k42jk3n4k2bn34k");
//		UtilReflection.setField(parameterService, "log", Logger.getLogger(WalletService.class.getName()));
//		Mockito.when(parameterRepository.findById(Environment.DESENVOLVIMENTO)).thenReturn(parameter);
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.ParameterService#findById(Environment)}.
//	 */
//	@Test
//	public void testFindById() {
//		// Act
//		Parameter parameter = parameterService.findById(Environment.DESENVOLVIMENTO);
//
//		// Then
//		Assert.assertEquals(Environment.DESENVOLVIMENTO, parameter.getEnvironment());
//		Assert.assertEquals("DES", parameter.getEnvironment().getDescription());
//	}
//
//}

package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.EspecialidadeFerramenta;

public class EspecialidadeFerramentaDto {

	private Long uid;
	private Integer rating;	
	private EspecialidadeDto especialidadeDto;
	private FerramentaDto ferramentaDto;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public EspecialidadeDto getEspecialidadeDto() {
		return especialidadeDto;
	}

	public void setEspecialidadeDto(EspecialidadeDto especialidadeDto) {
		this.especialidadeDto = especialidadeDto;
	}

	public FerramentaDto getFerramentaDto() {
		return ferramentaDto;
	}

	public void setFerramentaDto(FerramentaDto ferramentaDto) {
		this.ferramentaDto = ferramentaDto;
	}


	public static EspecialidadeFerramentaDto fromEspecialidadeFerramentaDto(EspecialidadeFerramenta especialidadeFerramenta) {
		EspecialidadeFerramentaDto dto = new EspecialidadeFerramentaDto();
		
		dto.setUid(especialidadeFerramenta.getUid());
		dto.setRating(especialidadeFerramenta.getRating());
		dto.setEspecialidadeDto(EspecialidadeDto.fromEspecialidadeToDto(especialidadeFerramenta.getEspecialidade()));
		dto.setFerramentaDto(FerramentaDto.fromFerramentaToDto(especialidadeFerramenta.getFerramenta()));	
		
		return dto;
	}
	
	public static List<EspecialidadeFerramentaDto> fromEspecialidadeFerramentaToListDto(List<EspecialidadeFerramenta> especialidadeFerramentas) {
		List<EspecialidadeFerramentaDto> returnList = new ArrayList<EspecialidadeFerramentaDto>();
		
		for (EspecialidadeFerramenta especialidadeFerramenta : especialidadeFerramentas) {
			
			returnList.add(fromEspecialidadeFerramentaDto(especialidadeFerramenta) );
		}
		return returnList;
	}	

}

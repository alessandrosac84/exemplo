package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeTreinamentoView;
import br.gov.caixa.api.result.BasicResult;

public class EspecialidadeTreinamentoViewResult extends BasicResult {
	private List<EspecialidadeTreinamentoView> list;
	private EspecialidadeTreinamentoView especialidadeTreinamentoView;

	public List<EspecialidadeTreinamentoView> getList() {
		return list;
	}

	public void setList(List<EspecialidadeTreinamentoView> list) {
		this.list = list;
	}

	public EspecialidadeTreinamentoView getEspecialidadeTreinamentoView() {
		return especialidadeTreinamentoView;
	}

	public void setEspecialidadeTreinamentoView(EspecialidadeTreinamentoView especialidadeTreinamentoView) {
		this.especialidadeTreinamentoView = especialidadeTreinamentoView;
	}
}
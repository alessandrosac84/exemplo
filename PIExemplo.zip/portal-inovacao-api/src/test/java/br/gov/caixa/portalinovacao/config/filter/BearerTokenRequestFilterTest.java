package br.gov.caixa.portalinovacao.config.filter;

import java.io.IOException;

import javax.ws.rs.container.ContainerRequestContext;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class BearerTokenRequestFilterTest {

	@Mock
	private ContainerRequestContext containerRequestContext;

	@InjectMocks
	private BearerTokenRequestFilter bearerTokenRequestFilter;
	/**
	 * Test method for {@link br.gov.caixa.portalinovacao.config.filter.BearerTokenRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)}.
	 * @throws IOException 
	 */
	@Test
	public void testFilter() throws IOException {
		bearerTokenRequestFilter.filter(containerRequestContext);
	}
}

package br.gov.caixa.inovacao.continuousmanager.model.entity;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity_;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-01-31T14:12:28.556-0200")
@StaticMetamodel(ProjectEnvironment.class)
public class ProjectEnvironment_ extends AuditedEntity_ {
	public static volatile SingularAttribute<ProjectEnvironment, ProjectEnvironmentPK> id;
	public static volatile SingularAttribute<ProjectEnvironment, Build> build;
}

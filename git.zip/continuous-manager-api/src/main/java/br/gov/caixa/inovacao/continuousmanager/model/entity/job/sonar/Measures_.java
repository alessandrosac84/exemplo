package br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar;

import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;
import java.math.BigDecimal;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-15T10:35:00.365-0300")
@StaticMetamodel(Measures.class)
public class Measures_ {
	public static volatile SingularAttribute<Measures, MeasuresPK> id;
	public static volatile SingularAttribute<Measures, Integer> complexity;
	public static volatile SingularAttribute<Measures, Integer> lines;
	public static volatile SingularAttribute<Measures, Integer> bugs;
	public static volatile SingularAttribute<Measures, Integer> vulnerabilities;
	public static volatile SingularAttribute<Measures, Integer> codeSmells;
	public static volatile SingularAttribute<Measures, BigDecimal> coverage;
	public static volatile SingularAttribute<Measures, Integer> unitTests;
	public static volatile SingularAttribute<Measures, Integer> duplicatedLines;
	public static volatile SingularAttribute<Measures, Integer> newCodeSmells;
	public static volatile SingularAttribute<Measures, BigDecimal> newCoverage;
	public static volatile SingularAttribute<Measures, Integer> newLines;
	public static volatile SingularAttribute<Measures, Integer> newVulnerabilities;
	public static volatile SingularAttribute<Measures, Integer> newBugs;
	public static volatile SingularAttribute<Measures, Integer> commentLines;
	public static volatile SingularAttribute<Measures, BigDecimal> commentLinesPercent;
	public static volatile SingularAttribute<Measures, BigDecimal> duplicatedLinesPercent;
	public static volatile SingularAttribute<Measures, Integer> newDuplicatedLines;
	public static volatile SingularAttribute<Measures, BigDecimal> newDuplicatedLinesPercent;
	public static volatile SingularAttribute<Measures, Integer> violations;
	public static volatile SingularAttribute<Measures, Integer> newViolations;
	public static volatile SingularAttribute<Measures, BigDecimal> sqaleRating;
	public static volatile SingularAttribute<Measures, BigDecimal> newMaintainabilityRating;
	public static volatile SingularAttribute<Measures, BigDecimal> securityRating;
	public static volatile SingularAttribute<Measures, BigDecimal> newSecurityRating;
	public static volatile SingularAttribute<Measures, BigDecimal> reliabilityRating;
	public static volatile SingularAttribute<Measures, BigDecimal> newReliabilityRating;
	public static volatile SingularAttribute<Measures, Integer> files;
	public static volatile SingularAttribute<Measures, Commit> commit;
}

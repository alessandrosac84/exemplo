const keycloakConfig = {
  url: 'https://login.prd.caixa/auth',
  realm: 'intranet',
  clientId: 'cli-web-dep-guardiao',
  credentials: { secret: 'd019330d-b5e5-4da4-be02-db32598371c9'}
};

export const environment = {
  production: true,
  apis: { continuous: 'continuous-manager-api', sharepoint: 'sharepoint-api' },
  keycloak: keycloakConfig,
  hmr: false
};

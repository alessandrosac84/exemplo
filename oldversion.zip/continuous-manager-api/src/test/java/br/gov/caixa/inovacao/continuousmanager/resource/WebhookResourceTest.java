package br.gov.caixa.inovacao.continuousmanager.resource;

import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.service.integration.WebhookService;

/**
 * Classe de testes do WalletResource.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class WebhookResourceTest {

	@Mock
	private WebhookService webhookService;

	@InjectMocks
	private WebhookResource webhookResource;

	@Before
	public void before() {
		UtilReflection.setField(webhookResource, "log", Logger.getLogger(WebhookResource.class.getName()));
	}
	
	/**
	 * Listar todas as Wallets.
	 * @throws InterruptedException 
	 */
	@Test
	public void testListAllWalletsDefault() throws InterruptedException {
		String payload = "{\"name\":\"continuous-manager-web-ci-dev\",\"display_name\":\"Continuous Manager WEB - CI DEV\","
				+ "\"url\":\"job/inovacao/job/continuous-manager-web/job/continuous-manager-web-ci-dev/\","
				+ "\"build\":{\"url\":\"backoffice/sipgt/sipgt-ci-dev\"}}";
		
		// Act
		webhookResource.createJobResource(payload);
	}
}

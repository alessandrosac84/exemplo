import { ChangeSet } from './changeset.model';

export class Commit {
  public id: { project: string, wallet: string, id: string };
  public title: string;
  public createdAt: string;
  public message: string;
  public authorName: string;
  public authorEmail: string;
  public authoredDate: string;
  public committerName: string;
  public committerEmail: string;
  public committedDate: string;
  public version: string;
  public versionedAt: Date;
  public versionerUser: string;
  public changeSets: ChangeSet[];
}

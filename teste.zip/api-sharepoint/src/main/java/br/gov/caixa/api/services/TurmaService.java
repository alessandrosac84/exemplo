package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.TurmaDto;
import br.gov.caixa.api.model.Treinamento;
import br.gov.caixa.api.model.Turma;
import br.gov.caixa.api.repository.TurmaRepository;
import br.gov.caixa.api.result.TurmaResult;

@Named
public class TurmaService {
	
	@Inject
	private TurmaRepository repository;
	
	public TurmaResult save(TurmaDto dto) {
		
		Turma turma = Turma.fromDtoToTurma(dto);
		if(dto.getInscritos() == null)
			dto.setInscritos(0);
		
		repository.save(turma);
		TurmaResult result = new TurmaResult();
		result.setMessage("Executado com sucesso.");
		return result;
	}
		
	public TurmaResult delete(Long id){
				
		repository.delete(id);
		TurmaResult result = new TurmaResult();
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public TurmaResult get(Long id){
		TurmaResult result = new TurmaResult();
		Turma turma = repository.findOne(id);
		TurmaDto dto = TurmaDto.fromTurmaToDto(turma);
		
		result.setTurma(dto);
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public TurmaResult getTurmaByTreinamento(Long idTreinamento){
		TurmaResult result = new TurmaResult();
		Treinamento treinamento = new Treinamento();
		treinamento.setUid(idTreinamento);
		
		List<Turma> listaTurma = repository.findByTreinamento(treinamento);
		
		result.setList(TurmaDto.fromTurmaToListaDto(listaTurma));
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	public TurmaResult getTurmaByTreinamentoNaoEncerradas(Long idTreinamento){
		TurmaResult result = new TurmaResult();
		Treinamento treinamento = new Treinamento();
		treinamento.setUid(idTreinamento);
		
		List<Turma> listaTurma = repository.findByTreinamentoAndEncerradoFalse(treinamento);
		
		result.setList(TurmaDto.fromTurmaToListaDto(listaTurma));
		result.setMessage("Executado com sucesso.");
		return result;
	}
}

package br.gov.caixa.api.services;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.QuestionarioDto;
import br.gov.caixa.api.model.Questionario;
import br.gov.caixa.api.repository.QuestionarioRepository;
import br.gov.caixa.api.result.QuestionarioResult;

@Named
public class QuestionarioService {

	@Inject
	QuestionarioRepository repository;
	
	public QuestionarioResult save(QuestionarioDto dto) {
		
		Questionario questionario = Questionario.fromDtoToQuestionario(dto);
		questionario.setDataQuestionario(new Date());		
		
		questionario = repository.save(questionario);
				
		dto.setUid(questionario.getUid());
		
		QuestionarioResult result = new QuestionarioResult();		
		result.setQuestionario(dto);		
		result.setMessage("Questionario Gravado com Sucesso.");
		
		return result;
	}

	public QuestionarioResult listOne(Long uid) {
		Questionario questionario = (repository.findOne(uid));
		QuestionarioResult result = new QuestionarioResult();
		
		result.setQuestionario(QuestionarioDto.fromQuestionarioToDto(questionario));
		result.setMessage("Executado com sucesso.");
		
		return result;
	}
	
	public QuestionarioResult delete(Long id) {
		QuestionarioResult result = new QuestionarioResult();
		
		try {
			repository.delete(id);			
			result.setMessage("Executado com sucesso.");
		}
		catch(Exception ex)
		{
			result.setIsError(true);
			result.setMessage("OPs! N�o foi Poss�vel Excluir o Questionario. Detalhes: " + ex.toString());
		}
		return result;
	}
	
//	public QuestionarioResult listQuestionarioPorIdFuncionario(Long uid) {
//		
//		Funcionario funcionario = new Funcionario();
//		funcionario.setUid(uid);
//		
//		Questionario questionario = repository.findByFuncionario(funcionario);
//		
//		QuestionarioResult result = new QuestionarioResult();
//		
//		if(questionario == null) {
//			result.setIsError(true);
//			result.setMessage("Perfil Inexistente.");
//		}		
//		else {					
//		
//			result.setQuestionario(QuestionarioDto.fromQuestionarioToDto(questionario));
//			result.setMessage("Executado com sucesso.");
//		}
//		
//		return result;	
//	}

	public QuestionarioResult getAll() {
		List<Questionario> listaQuestionario = repository.findAll();
		QuestionarioResult result = new QuestionarioResult();
		result.setList(QuestionarioDto.fromQuestionarioToListDto(listaQuestionario));
		result.setMessage("Executado com sucesso.");
		return result;
	}
	
	
}

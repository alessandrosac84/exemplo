import { Component, OnInit } from '@angular/core';
import {
  trigger,
  transition,
  query,
  animate,
  stagger,
  style
} from '@angular/animations';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Build } from '../../../shared/model/entity/build.model';
import { WalletService } from '../../../shared/service/wallet.service';

@Component({
  selector: 'cm-builds',
  templateUrl: './builds.component.html',
  styleUrls: ['./builds.component.scss'],
  animations: [
    trigger('listStagger', [
      transition('* => *', [ // each time the binding value changes
        query(':enter', [
          style({ opacity: 0 }),
          stagger(200, [animate('0.5s', style({ opacity: 1 }))])
        ], { optional: true }),
        query(':leave', [
          stagger(200, [animate('0.5s', style({ opacity: 0 }))])
        ], { optional: true })
      ])
    ]),
  ]
})
export class BuildsComponent implements OnInit {
  builds$: Observable<Build[]>;
  buildsLength: number;

  constructor(private _walletService: WalletService) {}

  ngOnInit() {
    this.builds$ = this._walletService
      .getBuilds(localStorage.getItem('project'), 1)
      .pipe(
        map(data => {
          this.buildsLength = data.length;
          return data;
        })
      );
  }
}

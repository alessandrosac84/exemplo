/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;

/**
 * Classe de testes de ParameterRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ParameterRepositoryTest {
	
	@Mock
	private EntityManager em;

	@InjectMocks
	private ParameterRepository parameterRepository;

	/**
	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.model.repository.ParameterRepository#findById(br.gov.caixa.inovacao.continuousmanager.model.entity.Environment)}.
	 */
	@Test
	public void testFindById() {
		// Arrange
		Parameter parameter = new Parameter();
		parameter.setId(new ParameterPK());
		parameter.getId().setEnvironment(Environment.DES);
		parameter.setHost("http://jenkins.caixa");
		parameter.setPrincipal("jhcAIYEFLKASULi");
		Mockito.when(em.find(Parameter.class, parameter.getId())).thenReturn(parameter);
		
		// Act
		Parameter retorno = parameterRepository.findById(parameter.getId());
		
		// Then
		Assert.assertNotNull(retorno.getHost());
		Assert.assertEquals(Environment.DES, retorno.getId().getEnvironment());
	}

}

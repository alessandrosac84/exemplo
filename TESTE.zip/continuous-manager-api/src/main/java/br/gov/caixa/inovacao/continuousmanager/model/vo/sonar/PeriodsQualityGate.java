package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;
import java.util.Date;

public class PeriodsQualityGate implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1204980834717195473L;

	/**
	 * 
	 */
	private Integer index;
	
	/**
	 * 
	 */
	private String mode;
	
	/**
	 * 
	 */
	private Date date;
	
	/**
	 * 
	 */
	private String parameter;

	/**
	 * @return the index
	 */
	public Integer getIndex() {
		return index;
	}

	/**
	 * @param index the index to set
	 */
	public void setIndex(Integer index) {
		this.index = index;
	}

	/**
	 * @return the mode
	 */
	public String getMode() {
		return mode;
	}

	/**
	 * @param mode the mode to set
	 */
	public void setMode(String mode) {
		this.mode = mode;
	}

	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return the parameter
	 */
	public String getParameter() {
		return parameter;
	}

	/**
	 * @param parameter the parameter to set
	 */
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
}

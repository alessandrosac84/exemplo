## sample crud appkaryawan [![pipeline status](https://gitlab.com/dihardmg/karyawan/badges/master/pipeline.svg)](https://gitlab.com/dihardmg/karyawan/commits/master)|[![coverage report](https://gitlab.com/dihardmg/karyawan/badges/master/coverage.svg)](https://gitlab.com/dihardmg/karyawan/commits/master)

- DEMO

       https://karyawan-app.herokuapp.com/login
       Username: admin
       password: 123

        
![Screenshot](img/screenshoot.gif "Screenshot")
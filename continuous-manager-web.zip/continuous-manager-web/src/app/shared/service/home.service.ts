import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';

import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { Wallet } from '../model/entity/wallet.model';
import { Project } from '../model/entity/project.model';
import { Job } from '../model/entity/job.model';
import { Build } from '../model/entity/build.model';
import { Stage } from '../model/vo/stage.model';
import { CedesBuilds } from '../model/vo/cedesBuilds.model';
import { ProjectsBuildsStatus } from '../model/vo/projectsBuildsStatus';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

    constructor(private http: HttpClient) { }

    getCedesBuilds(): Observable<CedesBuilds[]> {
        return this.http.get<CedesBuilds[]>('../../../assets/file/cedes.json');
      }

    getProjectsBuildsStatus(): Observable<ProjectsBuildsStatus[]> {
        return this.http.get<ProjectsBuildsStatus[]>('../../../assets/file/projectsBuildsStatus.json');
      }
}



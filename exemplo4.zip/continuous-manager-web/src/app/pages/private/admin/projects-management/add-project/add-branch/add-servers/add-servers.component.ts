import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material';
import { Server } from '../../../../../../../shared/model/entity/server.model';
import { Flavor } from '../../../../../../../shared/model/entity/flavor.model';
import { EnvironmentEnum } from '../../../../../../../shared/enum/environment.enum';
import { TypeServerEnum } from '../../../../../../../shared/enum/typeServer.enum';
import { BranchInstance } from '../../../../../../../shared/model/entity/branch-instance.model';
import { Branch } from '../../../../../../../shared/model/entity/branch.model';
import { ProjectManagementService } from '../../../../../../../shared/service/project-management.service';

@Component({
  selector: 'cm-add-servers',
  templateUrl: './add-servers.component.html',
  styleUrls: ['./add-servers.component.scss']
})
export class AddServersComponent implements OnInit {

  firstFormGroup: FormGroup;
  listComboServer: Server[];

  ambiente = new FormControl;
  tipoServer = new FormControl;
  server = new FormControl;
  instancia = new FormControl;
  deploy = new FormControl;
  serverData: BranchInstance;

  /*Slider Deploy*/
  color = 'primary';
  checked = false;

  listEnvironment: string[] = Object.values(EnvironmentEnum);
  listTypeServer: string[] = Object.values(TypeServerEnum);

  constructor(private _formBuilder: FormBuilder, private _projectManagerService: ProjectManagementService,
    public dialogRef: MatDialogRef<AddServersComponent>) { }

  ngOnInit() {
    this.serverData = new BranchInstance();
    this.serverData.branch = new Branch;
    this.serverData.server = new Server;
    this.serverData.server.flavor = new Flavor;

    this._projectManagerService.getServers().subscribe(data => this.listComboServer = data);

    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
  }

  addServer() {
    this.serverData.server.environment = this.ambiente.value;
    this.serverData.server.flavor.typeServer = this.tipoServer.value;
    this.serverData.server.ip = this.server.value;
    this.serverData.instance = this.instancia.value;
    this.serverData.automaticDeploy = this.deploy.value;

    this.dialogRef.close(this.serverData);
  }

}

import { Branch } from './branch.model';
import { Server } from './server.model';


export class BranchInstance {
  id: { id: string };
  branch: Branch;
  server: Server;
  instance: string;
  automaticDeploy: Boolean;
}

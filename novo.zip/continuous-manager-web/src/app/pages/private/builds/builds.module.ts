import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';

import { MaterialModule } from '../../../core/material/material.module';

import { BuildsRoutingModule } from './builds-routing.module';
import { BuildsComponent } from './builds.component';
import { RepositoryComponent } from './repositories/repositories.component';
import { DetailComponent } from './repositories/detail/detail.component';
import { BranchComponent } from './repositories/detail/branch/branch.component';
import { BuildComponent } from './repositories/detail/build/build.component';
import { BuildLogComponent } from './repositories/detail/build/build-log/build-log.component';
import { RouterModule } from '@angular/router';
import { BuildListComponent } from './repositories/detail/build-list/build-list.component';

@NgModule({
  imports: [
    CommonModule,
    BuildsRoutingModule,
    MaterialModule,
    FlexLayoutModule,
    RouterModule
  ],
  declarations: [
    BuildsComponent,
    RepositoryComponent,
    BranchComponent,
    BuildComponent,
    BuildLogComponent,
    DetailComponent,
    BuildListComponent
  ]
})
export class BuildsModule { }

/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Project;
import br.gov.caixa.inovacao.continuousmanager.model.repository.ProjectRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes do ProjectService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ProjectServiceTest {
	
	@Mock
	private ProjectRepository projectRepository;

	@InjectMocks
	private ProjectService projectService;

	private List<Project> projects;
	
	@Before
	public void before() {
		projects = EntityBuilder.createProjects();
		UtilReflection.setField(projectService, "log", Logger.getLogger(ProjectService.class.getName()));
	}
	
	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(projectRepository.findById(projects.get(0).getId())).thenReturn(projects.get(0));
		
		// Act
		Project project = projectService.findById(projects.get(0).getId());

		// Then
		Assert.assertEquals("portal-inovacao", project.getId().getId());
		Assert.assertEquals("inovacao", project.getId().getWallet());
		Assert.assertNotNull(project.getCreatedAt());
		Assert.assertEquals("http://gitlab.gov.caixa/inovacao/portal-inovacao.git", project.getGitRepo());
		//Assert.assertNotNull(project.getCommits());
		//Assert.assertNotNull(project.getJobs());
		Assert.assertEquals("Portal Inovação", project.getName());
		//Assert.assertNotNull(project.getSonars());
		Assert.assertNotNull(project.getUpdatedAt());
		Assert.assertEquals("f771274", project.getUserInsert());
		Assert.assertEquals("f771274", project.getUserUpdate());
		//Assert.assertNull(project.getWallet());
	}
	
	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(projectRepository.findAll("inovacao", 0, 30, "", "id", AscDesc.ASC)).thenReturn(projects);
		
		// Act
		List<Project> listProjects = projectService.findAll("inovacao", 0, 30, "", "id", AscDesc.ASC);

		// Then
		Assert.assertEquals(2, listProjects.size());
	}
	
	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(projectRepository.countAll("inovacao", "")).thenReturn((long) projects.size());
		
		// Act
		Long contProjects = projectService.countAll("inovacao", "");

		// Then
		Assert.assertEquals(2, contProjects.longValue());
	}
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(projectRepository.save(projects.get(0))).thenReturn(projects.get(0));
		
		// Act
		Project project = projectService.save(projects.get(0));

		// Then
		Assert.assertEquals(projects.get(0).getId(), project.getId());
	}
}

package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author Alessandro Carvalho
 *
 */
public class ProjectStatusVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1305927553548613370L;
	
	/**
	 * 
	 */
	private String status;
	
	/**
	 * 
	 */
	private List<ConditionsVO> conditions;
	
	/**
	 * 
	 */
	private List<PeriodsQualityGate> periods;

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the conditions
	 */
	public List<ConditionsVO> getConditions() {
		return conditions;
	}

	/**
	 * @param conditions the conditions to set
	 */
	public void setConditions(List<ConditionsVO> conditions) {
		this.conditions = conditions;
	}

	/**
	 * @return the periods
	 */
	public List<PeriodsQualityGate> getPeriods() {
		return periods;
	}

	/**
	 * @param periods the periods to set
	 */
	public void setPeriods(List<PeriodsQualityGate> periods) {
		this.periods = periods;
	}
	

}

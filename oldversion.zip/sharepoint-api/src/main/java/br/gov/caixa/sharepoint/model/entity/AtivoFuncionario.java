package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the ativo_funcionario database table.
 * 
 */
@Entity
@Table(name="ativo_funcionario")
@NamedQueries({	
	@NamedQuery(name="AtivoFuncionario.findAll", query="SELECT a FROM AtivoFuncionario a"),
	@NamedQuery(name="AtivoFuncionario.findByAtivo", query="SELECT a FROM AtivoFuncionario a INNER JOIN FETCH a.funcionario WHERE a.id.ativo = :ativo")
})
public class AtivoFuncionario extends AuditedEntity implements Serializable, IEntity<AtivoFuncionarioPK> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AtivoFuncionarioPK id;

	//bi-directional many-to-one association to Ativo
	@ManyToOne
	@JoinColumn(name="ativo", nullable=false, insertable=false, updatable=false)
	private Ativo ativo;

	//bi-directional many-to-one association to Funcionario
	@ManyToOne
	@JoinColumn(name="funcionario", nullable=false, insertable=false, updatable=false)
	private Funcionario funcionario;

	public AtivoFuncionario() {
	}

	public AtivoFuncionarioPK getId() {
		return this.id;
	}

	public void setId(AtivoFuncionarioPK id) {
		this.id = id;
	}

	public Ativo getAtivo() {
		return this.ativo;
	}

	public void setAtivo(Ativo ativo) {
		this.ativo = ativo;
	}

	public Funcionario getFuncionario() {
		return this.funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	@Override
	public boolean isTheSameObject(IEntity<AtivoFuncionarioPK> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		AtivoFuncionario other = (AtivoFuncionario) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof AtivoFuncionario))
			return false;
		AtivoFuncionario other = (AtivoFuncionario) obj;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
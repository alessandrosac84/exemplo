package br.gov.caixa.api.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.gov.caixa.api.model.Participante;
import br.gov.caixa.api.model.StatusParticipante;
import br.gov.caixa.api.model.views.FuncionarioView;


public class ParticipanteDto {

	private Long uid;
	private FuncionarioView funcionario;
	private TurmaDto turma;
	private boolean presenca;
	private byte autorizacao;
	private Date data;
	
	private Integer index; 
	
	private StatusParticipante statusParticipante;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public FuncionarioView getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(FuncionarioView funcionario) {
		this.funcionario = funcionario;
	}

	public boolean isPresenca() {
		return presenca;
	}

	public void setPresenca(boolean presenca) {
		this.presenca = presenca;
	}

	public TurmaDto getTurma() {
		return turma;
	}

	public void setTurma(TurmaDto turma) {
		this.turma = turma;
	}
	
	public byte getAutorizacao() {
		return autorizacao;
	}

	public void setAutorizacao(byte autorizacao) {
		this.autorizacao = autorizacao;
	}	

	public StatusParticipante getStatusParticipante() {
		return statusParticipante;
	}

	public void setStatusParticipante(StatusParticipante statusParticipante) {
		this.statusParticipante = statusParticipante;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public static ParticipanteDto fromParticipanteToDto(Participante participante) {
		ParticipanteDto dto = new ParticipanteDto();
		dto.setUid(participante.getUid());
		dto.setAutorizacao(participante.getAutorizacao());
		dto.setFuncionario(participante.getFuncionario());
		dto.setTurma(TurmaDto.fromTurmaToDto(participante.getTurma()));
		dto.setStatusParticipante(participante.getStatusParticipante());
		dto.setPresenca(participante.isPresenca());
		return dto;
	}

	public static List<ParticipanteDto> fromParticipanteToListDto(List<Participante> participantes) {		
		List<ParticipanteDto> result = new ArrayList<ParticipanteDto>();		
		for (Participante participante : participantes) {						
			result.add(fromParticipanteToDto(participante));
		}
		return result;
	}
}

///**
// * 
// */
//package br.gov.caixa.inovacao.continuousmanager.service.impl;
//
//import java.util.List;
//import java.util.logging.Logger;
//
//import javax.net.ssl.HostnameVerifier;
//import javax.net.ssl.SSLContext;
//import javax.ws.rs.client.Client;
//import javax.ws.rs.client.ClientBuilder;
//import javax.ws.rs.client.Invocation;
//import javax.ws.rs.client.WebTarget;
//import javax.ws.rs.core.MediaType;
//import javax.ws.rs.core.Response;
//import javax.ws.rs.core.Response.ResponseBuilder;
//
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.powermock.api.mockito.PowerMockito;
//import org.powermock.core.classloader.annotations.PowerMockIgnore;
//import org.powermock.core.classloader.annotations.PrepareForTest;
//import org.powermock.modules.junit4.PowerMockRunner;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
//import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
//import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsBuilder;
//import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
//import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BuildJenkinsVO;
//import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.JobJenkinsVO;
//import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.SistemaJenkinsVO;
//import br.gov.caixa.inovacao.continuousmanager.service.JenkinsService;
//import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;
//import br.gov.caixa.inovacao.continuousmanager.service.WalletService;
//
///**
// * Classe de testes do JenkinsService.
// * 
// * @author Fabio Iwakoshi
// *
// */
//@RunWith(PowerMockRunner.class)
//@PrepareForTest({ ClientBuilder.class, Response.class })
//@PowerMockIgnore("javax.net.ssl.*")
//public class JenkinsServiceTest {
//
//	@InjectMocks
//	private JenkinsService jenkinsService;
//
//	@Mock
//	private ParameterService parameterService;
//
//	@Mock
//	private Invocation.Builder builder;
//
//	@Mock
//	private Client client;
//
//	@Mock
//	private WebTarget target;
//	
//	@Mock
//	private ClientBuilder clientBuilder;
//	
//	@Mock
//	private ResponseBuilder responseBuilder;
//	
//	@Mock
//	private Response response;
//
//	@Before
//	public void before() {
//		UtilReflection.setField(jenkinsService, "log", Logger.getLogger(WalletService.class.getName()));
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.JenkinsService#listFolders(int, int, java.lang.String, java.lang.String)}.
//	 * @throws JsonProcessingException 
//	 */
//	@Test
//	public void testListFolders() throws JsonProcessingException {
//		// Arrange
//		Parameter parameter = new Parameter();
//		parameter.setEnvironment(Environment.DESENVOLVIMENTO);
//		parameter.setJenkinsHost("https://10.1.32.242:8443/");
//		parameter.setJenkinsAuthorization("sdfij342hj3b43k23k42jk3n4k2bn34k");
//
//		PowerMockito.mockStatic(ClientBuilder.class);
//		PowerMockito.mockStatic(Response.class);
//		
//		PowerMockito.when(Response.ok(JenkinsBuilder.createSistemas())).thenReturn(responseBuilder);
//		Mockito.when(responseBuilder.build()).thenReturn(response);
//		
//		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.hostnameVerifier(Mockito.<HostnameVerifier>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.sslContext(Mockito.<SSLContext>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.build()).thenReturn(client);
//		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
//		Mockito.when(builder.header(Mockito.anyString(), Mockito.<Parameter>any())).thenReturn(builder);
//		Mockito.when(builder.get()).thenReturn(response);
//		Mockito.when(response.readEntity(String.class)).thenReturn("{\"_class\":\"br.gov.caixa.Teste\",\"exec\":" + new ObjectMapper().writeValueAsString(JenkinsBuilder.createSistemas()) + "}");
//		Mockito.when(response.hasEntity()).thenReturn(true);
//		Mockito.when(parameterService.findById(Environment.DESENVOLVIMENTO)).thenReturn(parameter);
//
//		// Act
//		List<SistemaJenkinsVO> sistemas = jenkinsService.listSistemas();
//
//		// Then
//		Assert.assertEquals(2, sistemas.size());
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.JenkinsService#getJobs(int, int, java.lang.String, java.lang.String)}.
//	 * @throws JsonProcessingException 
//	 */
//	@Test
//	public void testListJobs() throws JsonProcessingException {
//		// Arrange
//		Parameter parameter = new Parameter();
//		parameter.setEnvironment(Environment.DESENVOLVIMENTO);
//		parameter.setJenkinsHost("https://10.1.32.242:8443/");
//		parameter.setJenkinsAuthorization("sdfij342hj3b43k23k42jk3n4k2bn34k");
//		String nomeSistema = "sharepoint";
//		
//		PowerMockito.mockStatic(ClientBuilder.class);
//		PowerMockito.mockStatic(Response.class);
//		
//		PowerMockito.when(Response.ok(JenkinsBuilder.createSistemas())).thenReturn(responseBuilder);
//		Mockito.when(responseBuilder.build()).thenReturn(response);
//		
//		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.hostnameVerifier(Mockito.<HostnameVerifier>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.sslContext(Mockito.<SSLContext>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.build()).thenReturn(client);
//		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
//		Mockito.when(builder.header(Mockito.anyString(), Mockito.<Parameter>any())).thenReturn(builder);
//		Mockito.when(builder.get()).thenReturn(response);
//		Mockito.when(response.readEntity(String.class)).thenReturn("{\"_class\":\"br.gov.caixa.Teste\",\"exec\":" + new ObjectMapper().writeValueAsString(JenkinsBuilder.createSistemas().get(0).getJobs()) + "}");
//		Mockito.when(response.hasEntity()).thenReturn(true);
//		Mockito.when(parameterService.findById(Environment.DESENVOLVIMENTO)).thenReturn(parameter);
//
//		// Act
//		List<JobJenkinsVO> jobs = jenkinsService.listJobs(nomeSistema);
//
//		// Then
//		Assert.assertEquals(2, jobs.size());
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.JenkinsService#getJobs(int, int, java.lang.String, java.lang.String)}.
//	 * @throws JsonProcessingException 
//	 */
//	@Test
//	public void testListBuilds() throws JsonProcessingException {
//		// Arrange
//		Parameter parameter = new Parameter();
//		parameter.setEnvironment(Environment.DESENVOLVIMENTO);
//		parameter.setJenkinsHost("https://10.1.32.242:8443/");
//		parameter.setJenkinsAuthorization("sdfij342hj3b43k23k42jk3n4k2bn34k");
//		String nomeSistema = "sharepoint";
//		String nomeJob = "sharepoint-api-cd-tqs";
//		
//		PowerMockito.mockStatic(ClientBuilder.class);
//		PowerMockito.mockStatic(Response.class);
//		
//		PowerMockito.when(Response.ok(JenkinsBuilder.createSistemas())).thenReturn(responseBuilder);
//		Mockito.when(responseBuilder.build()).thenReturn(response);
//		
//		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.hostnameVerifier(Mockito.<HostnameVerifier>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.sslContext(Mockito.<SSLContext>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.build()).thenReturn(client);
//		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
//		Mockito.when(builder.header(Mockito.anyString(), Mockito.<Parameter>any())).thenReturn(builder);
//		Mockito.when(builder.get()).thenReturn(response);
//		Mockito.when(response.readEntity(String.class)).thenReturn("{\"_class\":\"br.gov.caixa.Teste\",\"exec\":" + new ObjectMapper().writeValueAsString(JenkinsBuilder.createSistemas().get(0).getJobs().get(0).getBuilds()) + "}");
//		Mockito.when(response.hasEntity()).thenReturn(true);
//		Mockito.when(parameterService.findById(Environment.DESENVOLVIMENTO)).thenReturn(parameter);
//
//		// Act
//		List<BuildJenkinsVO> jobs = jenkinsService.listBuilds(nomeSistema, nomeJob);
//
//		// Then
//		Assert.assertEquals(12, jobs.size());
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.JenkinsService#countAllSistemas(java.lang.String)}.
//	 * @throws JsonProcessingException 
//	 */
//	@Test
//	public void testCountAllSistema() throws JsonProcessingException {
//		// Arrange
//		Parameter parameter = new Parameter();
//		parameter.setEnvironment(Environment.DESENVOLVIMENTO);
//		parameter.setJenkinsHost("https://10.1.32.242:8443/");
//		parameter.setJenkinsAuthorization("sdfij342hj3b43k23k42jk3n4k2bn34k");
//		
//		PowerMockito.mockStatic(ClientBuilder.class);
//		PowerMockito.mockStatic(Response.class);
//		
//		PowerMockito.when(Response.ok(JenkinsBuilder.createSistemas())).thenReturn(responseBuilder);
//		Mockito.when(responseBuilder.build()).thenReturn(response);
//		
//		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.hostnameVerifier(Mockito.<HostnameVerifier>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.sslContext(Mockito.<SSLContext>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.build()).thenReturn(client);
//		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
//		Mockito.when(builder.header(Mockito.anyString(), Mockito.<Parameter>any())).thenReturn(builder);
//		Mockito.when(builder.get()).thenReturn(response);
//		Mockito.when(response.readEntity(String.class)).thenReturn("{\"_class\":\"br.gov.caixa.Teste\",\"exec\":" + new ObjectMapper().writeValueAsString(JenkinsBuilder.createSistemas()) + "}");
//		Mockito.when(response.hasEntity()).thenReturn(true);
//		Mockito.when(parameterService.findById(Environment.DESENVOLVIMENTO)).thenReturn(parameter);
//
//		// Act
//		long count = jenkinsService.countAllSistemas();
//
//		// Then
//		Assert.assertEquals(2, count);
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.JenkinsService#countAllJobs(java.lang.String)}.
//	 * @throws JsonProcessingException 
//	 */
//	@Test
//	public void testCountAllJobs() throws JsonProcessingException {
//		// Arrange
//		Parameter parameter = new Parameter();
//		parameter.setEnvironment(Environment.DESENVOLVIMENTO);
//		parameter.setJenkinsHost("https://10.1.32.242:8443/");
//		parameter.setJenkinsAuthorization("sdfij342hj3b43k23k42jk3n4k2bn34k");
//
//		String nomeSistema = "sharepoint";
//		
//		PowerMockito.mockStatic(ClientBuilder.class);
//		PowerMockito.mockStatic(Response.class);
//		
//		PowerMockito.when(Response.ok(JenkinsBuilder.createSistemas())).thenReturn(responseBuilder);
//		Mockito.when(responseBuilder.build()).thenReturn(response);
//		
//		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.hostnameVerifier(Mockito.<HostnameVerifier>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.sslContext(Mockito.<SSLContext>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.build()).thenReturn(client);
//		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
//		Mockito.when(builder.header(Mockito.anyString(), Mockito.<Parameter>any())).thenReturn(builder);
//		Mockito.when(builder.get()).thenReturn(response);
//		Mockito.when(response.readEntity(String.class)).thenReturn("{\"_class\":\"br.gov.caixa.Teste\",\"exec\":" + new ObjectMapper().writeValueAsString(JenkinsBuilder.createSistemas().get(0).getJobs()) + "}");
//		Mockito.when(response.hasEntity()).thenReturn(true);
//		Mockito.when(parameterService.findById(Environment.DESENVOLVIMENTO)).thenReturn(parameter);
//
//		// Act
//		long count = jenkinsService.countAllJobs(nomeSistema);
//
//		// Then
//		Assert.assertEquals(2, count);
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.JenkinsService#countAllBuilds(java.lang.String)}.
//	 * @throws JsonProcessingException 
//	 */
//	@Test
//	public void testCountAllBuilds() throws JsonProcessingException {
//		// Arrange
//		Parameter parameter = new Parameter();
//		parameter.setEnvironment(Environment.DESENVOLVIMENTO);
//		parameter.setJenkinsHost("https://10.1.32.242:8443/");
//		parameter.setJenkinsAuthorization("sdfij342hj3b43k23k42jk3n4k2bn34k");
//
//		String nomeSistema = "sharepoint";
//		String nomeJob = "sharepoint-api-cd-tqs";
//		
//		PowerMockito.mockStatic(ClientBuilder.class);
//		PowerMockito.mockStatic(Response.class);
//		
//		PowerMockito.when(Response.ok(JenkinsBuilder.createSistemas())).thenReturn(responseBuilder);
//		Mockito.when(responseBuilder.build()).thenReturn(response);
//		
//		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.hostnameVerifier(Mockito.<HostnameVerifier>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.sslContext(Mockito.<SSLContext>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.build()).thenReturn(client);
//		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
//		Mockito.when(builder.header(Mockito.anyString(), Mockito.<Parameter>any())).thenReturn(builder);
//		Mockito.when(builder.get()).thenReturn(response);
//		Mockito.when(response.readEntity(String.class)).thenReturn("{\"_class\":\"br.gov.caixa.Teste\",\"exec\":" + new ObjectMapper().writeValueAsString(JenkinsBuilder.createSistemas().get(0).getJobs().get(0).getBuilds()) + "}");
//		Mockito.when(response.hasEntity()).thenReturn(true);
//		Mockito.when(parameterService.findById(Environment.DESENVOLVIMENTO)).thenReturn(parameter);
//
//		// Act
//		long count = jenkinsService.countAllBuilds(nomeSistema, nomeJob);
//
//		// Then
//		Assert.assertEquals(12, count);
//	}
//
//	/**
//	 * Test method for
//	 * {@link br.gov.caixa.inovacao.continuousmanager.service.JenkinsService#getLog(java.lang.String, java.lang.String, int)}.
//	 */
//	@Test
//	public void testGetLog() {
//		// Arrange
//		String folderName = "sharepoint";
//		String jobName = "sharepoint-api-cd-tqs";
//		int build = 2;
//		Parameter parameter = new Parameter();
//		parameter.setEnvironment(Environment.DESENVOLVIMENTO);
//		parameter.setJenkinsHost("https://10.1.32.242:8443/");
//		parameter.setJenkinsAuthorization("sdfij342hj3b43k23k42jk3n4k2bn34k");
//		
//		PowerMockito.mockStatic(ClientBuilder.class);
//		PowerMockito.mockStatic(Response.class);
//		
//		PowerMockito.when(Response.ok(JenkinsBuilder.createSistemas())).thenReturn(responseBuilder);
//		Mockito.when(responseBuilder.build()).thenReturn(response);
//		
//		PowerMockito.when(ClientBuilder.newBuilder()).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.hostnameVerifier(Mockito.<HostnameVerifier>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.sslContext(Mockito.<SSLContext>any())).thenReturn(clientBuilder);
//		Mockito.when(clientBuilder.build()).thenReturn(client);
//		Mockito.when(client.target(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.path(Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.queryParam(Mockito.anyString(), Mockito.anyString())).thenReturn(target);
//		Mockito.when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
//		Mockito.when(builder.header(Mockito.anyString(), Mockito.<Parameter>any())).thenReturn(builder);
//		Mockito.when(builder.get()).thenReturn(response);
//		Mockito.when(response.readEntity(String.class)).thenReturn("Log do Jenkins");
//		Mockito.when(response.hasEntity()).thenReturn(true);
//		Mockito.when(parameterService.findById(Environment.DESENVOLVIMENTO)).thenReturn(parameter);
//		
//		// Act
//		String log = jenkinsService.getLog(folderName, jobName, build);
//		
//		// Then
//		Assert.assertEquals("Log do Jenkins", log);
//	}
//	
//}

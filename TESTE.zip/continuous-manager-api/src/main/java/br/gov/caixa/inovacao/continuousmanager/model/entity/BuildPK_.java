package br.gov.caixa.inovacao.continuousmanager.model.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-04-16T14:14:37.227-0300")
@StaticMetamodel(BuildPK.class)
public class BuildPK_ {
	public static volatile SingularAttribute<BuildPK, Integer> id;
	public static volatile SingularAttribute<BuildPK, String> project;
	public static volatile SingularAttribute<BuildPK, String> wallet;
	public static volatile SingularAttribute<BuildPK, String> job;
}

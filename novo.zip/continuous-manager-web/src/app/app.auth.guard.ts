import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from '@angular/router';
import { Observable } from 'rxjs';
import { KeycloakService } from './core/keycloak/keycloak.service';

@Injectable()
export class AppAuthGuard implements CanActivate {
  constructor(private _keyCloakService: KeycloakService) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    if (!this._keyCloakService.isLoggedIn()) {
      this._keyCloakService.login();
      return;
    } else {
      return true;
    }
  }
}

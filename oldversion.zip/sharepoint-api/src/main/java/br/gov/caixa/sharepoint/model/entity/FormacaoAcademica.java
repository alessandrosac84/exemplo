package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the formacao_academica database table.
 * 
 */
@Entity
@Table(name="formacao_academica")
@NamedQueries({
	@NamedQuery(name = "FormacaoAcademica.findAll", query = "SELECT f FROM FormacaoAcademica f"),
	@NamedQuery(name = "FormacaoAcademica.findByAKs", query = "SELECT f FROM FormacaoAcademica f WHERE f.id <> :id AND (f.instituicao = :instituicao OR f.curso = :curso OR f.anoInicio = :anoInicio OR f.anoConclusao = :anoConclusao)"),
	@NamedQuery(name="FormacaoAcademica.findAllByFuncionario", query="SELECT f FROM FormacaoAcademica f WHERE f.funcionario.matricula = :matricula"),
})
public class FormacaoAcademica extends AuditedEntity implements Serializable, IEntity<Integer> {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Max(value=2050)
	@Min(value=1950)
	@NotNull
	@Column(name="ano_conclusao", nullable=false, precision=4)
	private Integer anoConclusao;
	
	@Max(value=2050)
	@Min(value=1950)
	@NotNull
	@Column(name="ano_inicio", nullable=false, precision=4)
	private Integer anoInicio;

	@NotEmpty
	@Size(min=3)
	@Column(nullable=false, length=70)
	private String curso;

	@NotEmpty
	@Size(min=2)
	@Column(nullable=false, length=70)
	private String instituicao;
	
	@JsonIgnore
	//bi-directional many-to-one association to Funcionario
	@ManyToOne
	@JoinColumn(name="funcionario", nullable=false)
	private Funcionario funcionario;

	public FormacaoAcademica() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAnoConclusao() {
		return this.anoConclusao;
	}

	public void setAnoConclusao(Integer anoConclusao) {
		this.anoConclusao = anoConclusao;
	}

	public Integer getAnoInicio() {
		return this.anoInicio;
	}

	public void setAnoInicio(Integer anoInicio) {
		this.anoInicio = anoInicio;
	}

	public String getCurso() {
		return this.curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public String getInstituicao() {
		return this.instituicao;
	}

	public void setInstituicao(String instituicao) {
		this.instituicao = instituicao;
	}

	public Funcionario getFuncionario() {
		return this.funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((anoConclusao == null) ? 0 : anoConclusao.hashCode());
		result = prime * result + ((anoInicio == null) ? 0 : anoInicio.hashCode());
		result = prime * result + ((curso == null) ? 0 : curso.hashCode());
		result = prime * result + ((funcionario == null) ? 0 : funcionario.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((instituicao == null) ? 0 : instituicao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FormacaoAcademica other = (FormacaoAcademica) obj;
		if (anoConclusao == null) {
			if (other.anoConclusao != null)
				return false;
		} else if (!anoConclusao.equals(other.anoConclusao))
			return false;
		if (anoInicio == null) {
			if (other.anoInicio != null)
				return false;
		} else if (!anoInicio.equals(other.anoInicio))
			return false;
		if (curso == null) {
			if (other.curso != null)
				return false;
		} else if (!curso.equals(other.curso))
			return false;
		if (funcionario == null) {
			if (other.funcionario != null)
				return false;
		} else if (!funcionario.equals(other.funcionario))
			return false;
		if (id == null) {
			return false;
		} else if (!id.equals(other.id))
			return false;
		if (instituicao == null) {
			if (other.instituicao != null)
				return false;
		} else if (!instituicao.equals(other.instituicao))
			return false;
		return true;
	}

	@Override
	public boolean isTheSameObject(IEntity<Integer> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		FormacaoAcademica other = (FormacaoAcademica) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
package br.gov.caixa.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.gov.caixa.api.model.FeedbackMedia;

public interface FeedbackMediaRepository extends JpaRepository<FeedbackMedia, Long>  {		
	public FeedbackMedia findByTurmaId(Long turmaId);
}

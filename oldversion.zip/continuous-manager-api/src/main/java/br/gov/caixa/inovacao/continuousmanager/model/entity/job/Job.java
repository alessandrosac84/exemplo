package br.gov.caixa.inovacao.continuousmanager.model.entity.job;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Build;


/**
 * The persistent class for the job database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name="job")
@NamedQuery(name="Job.findAll", query="SELECT j FROM Job j")
public class Job extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonView(ViewJson.JobView.class)
	private JobPK id;

	@JsonView(ViewJson.JobView.class)
	@Column(nullable=false, length=50)
	private String name;

	//bi-directional many-to-one association to Build
	@JsonIgnore
	@OneToMany(mappedBy="job", fetch = FetchType.LAZY)
	private Set<Build> builds;

	//bi-directional many-to-one association to Project
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="project", referencedColumnName="id", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private Project project;

	public Job() {
		/* class constructor intentionally left blank */
	}

	public JobPK getId() {
		return this.id;
	}

	public void setId(JobPK id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Build> getBuilds() {
		return this.builds;
	}

	public void setBuilds(Set<Build> builds) {
		this.builds = builds;
	}

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

}
/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.persistence.NoResultException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.repository.ChangeSetRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes do ChangeSetService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ChangeSetServiceTest {
	
	@Mock
	private ChangeSetRepository changeSetRepository;

	@InjectMocks
	private ChangeSetService changeSetService;

	private ChangeSet changeSet;
	
	private List<ChangeSet> listChangeSet = new ArrayList<>();
	
	@Before
	public void before() {
		changeSet = EntityBuilder.createBuilds().get(0).getChangeSets().stream().findFirst().get();
		UtilReflection.setField(changeSetService, "log", Logger.getLogger(AuditService.class.getName()));
	}
	
	@Test
	public void testSave() {
		// Arrange
		Mockito.when(changeSetRepository.update(Mockito.<ChangeSet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		
		// Act
		ChangeSet savedChangeSet = changeSetService.update(changeSet);

		// Then
		Assert.assertNotNull(savedChangeSet);
	}
	
	@Test
	public void testFindById() {
		// Arrange
		Mockito.when(changeSetRepository.findById(changeSet.getId())).thenReturn(changeSet);
		
		// Act
		ChangeSet cs = changeSetService.findById(changeSet.getId());

		// Then
		Assert.assertNotNull(cs);
	}
	
	@Test
	public void testFindByIdException() {
		// Arrange
		Mockito.when(changeSetRepository.findById(changeSet.getId())).thenThrow(NoResultException.class);
		
		// Act
		ChangeSet retorno = changeSetService.findById(changeSet.getId());
		
		Assert.assertNull(retorno);
	}
	
	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(changeSetRepository.findAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 0, 30, "", "id", AscDesc.ASC)).thenReturn(new ArrayList<ChangeSet>());
		
		// Act
		List<ChangeSet> listCs = changeSetService.findAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 0, 30, "", "id", AscDesc.ASC);

		// Then
		Assert.assertEquals(0, listCs.size());
	}
	
	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(changeSetRepository.countAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", "")).thenReturn((long) listChangeSet.size());
		
		// Act
		Long contChangeSet = changeSetService.countAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", "");

		// Then
		Assert.assertEquals(0, contChangeSet.longValue());
	}
}

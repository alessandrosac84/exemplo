package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;
import java.util.List;

/**
 * Classe de representação de histórico de Measures do Sonar
 * 
 * @author Fabio Iwakoshi
 * 
 */
public class MeasureHistorySonarVO implements Serializable {

	private static final long serialVersionUID = 7159838731812255315L;

	private transient Object paging;
	
	private List<MeasuresSonarVO> measures;

	/**
	 * @return the paging
	 */
	public Object getPaging() {
		return paging;
	}

	/**
	 * @param paging the paging to set
	 */
	public void setPaging(Object paging) {
		this.paging = paging;
	}

	/**
	 * @return the measures
	 */
	public List<MeasuresSonarVO> getMeasures() {
		return measures;
	}

	/**
	 * @param measures the measures to set
	 */
	public void setMeasures(List<MeasuresSonarVO> measures) {
		this.measures = measures;
	}
	
}

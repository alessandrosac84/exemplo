import { DashBoardService } from './../../shared/service/dashboard.service';
import { Dashboard } from './../../shared/model/dashboard.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jmw-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  pageTitle = 'Dashboard';

  listaDashboard: Dashboard[] = [];

  constructor(private dashBoardService: DashBoardService) { }

  ngOnInit() {
    this.dashBoardService.getProjects().subscribe(data => {
      this.listaDashboard = data;

      this.listaDashboard.forEach(item => {
        if (item.lines <= 5000) {
          item.sizeProject = 'S';
        } else if (item.lines > 5000 && item.lines <= 10000) {
          item.sizeProject = 'M';
        } else {
          item.sizeProject = 'L';
        }

        switch (item.securityRating) {
          case 1:
            item.security = 'A';
            break;
          case 2:
            item.security = 'B';
            break;
          case 3:
            item.security = 'C';
            break;
          case 4:
            item.security = 'D';
            break;
          case 5:
            item.security = 'E';
            break;
        }

        switch (item.sqaleRating) {
          case 1:
            item.quality = 'A';
            break;
          case 2:
            item.quality = 'B';
            break;
          case 3:
            item.quality = 'C';
            break;
          case 4:
            item.quality = 'D';
            break;
          case 5:
            item.quality = 'E';
            break;
        }
      });
    });
  }
}

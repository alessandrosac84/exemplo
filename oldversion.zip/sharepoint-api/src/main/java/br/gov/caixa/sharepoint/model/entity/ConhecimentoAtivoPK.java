package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the conhecimento_ativo database table.
 * 
 */
@Embeddable
public class ConhecimentoAtivoPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private Integer ativo;

	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private Integer atividade;

	public ConhecimentoAtivoPK() {
	}
	public Integer getAtivo() {
		return this.ativo;
	}
	public void setAtivo(Integer ativo) {
		this.ativo = ativo;
	}
	public Integer getAtividade() {
		return this.atividade;
	}
	public void setAtividade(Integer atividade) {
		this.atividade = atividade;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ConhecimentoAtivoPK)) {
			return false;
		}
		ConhecimentoAtivoPK castOther = (ConhecimentoAtivoPK)other;
		return 
			this.ativo.equals(castOther.ativo)
			&& this.atividade.equals(castOther.atividade);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.ativo.hashCode();
		hash = hash * prime + this.atividade.hashCode();
		
		return hash;
	}
}
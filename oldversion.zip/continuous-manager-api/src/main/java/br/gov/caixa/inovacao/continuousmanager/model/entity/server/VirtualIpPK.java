package br.gov.caixa.inovacao.continuousmanager.model.entity.server;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the virtual_ip database table.
 * 
 */
@Embeddable
public class VirtualIpPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=15)
	private String server;

	@Column(unique=true, nullable=false, length=15)
	private String ip;

	public VirtualIpPK() {
		/* class constructor intentionally left blank */
	}
	public String getServer() {
		return this.server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public String getIp() {
		return this.ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof VirtualIpPK)) {
			return false;
		}
		VirtualIpPK castOther = (VirtualIpPK)other;
		return 
			this.server.equals(castOther.server)
			&& this.ip.equals(castOther.ip);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.server.hashCode();
		hash = hash * prime + this.ip.hashCode();
		
		return hash;
	}
}
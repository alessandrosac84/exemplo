package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.NotificacaoDto;

public class NotificacaoResult extends BasicResult {

	private List<NotificacaoDto> list;
	private NotificacaoDto notificacaoDto;

	public List<NotificacaoDto> getList() {
		return list;
	}

	public void setList(List<NotificacaoDto> list) {
		this.list = list;
	}

	public NotificacaoDto getNotificacaoDto() {
		return notificacaoDto;
	}

	public void setNotificacaoDto(NotificacaoDto notificacaoDto) {
		this.notificacaoDto = notificacaoDto;
	}
}

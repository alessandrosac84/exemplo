import { Component, OnInit, DoCheck, Output, EventEmitter } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';

import { AuthService } from '../../shared/service/auth/auth.service';

import { filter } from 'rxjs/operators';

@Component({
  selector: 'jmw-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, DoCheck {

  @Output() navToggled = new EventEmitter();
  navOpen = false;
  logged = false;

  constructor(private router: Router, private _authService: AuthService) { }

  ngOnInit() {
    // Fechar o menu se navegar para outra pagina
    this.router.events.pipe(
      filter(event => event instanceof NavigationStart && this.navOpen))
      .subscribe(event => this.openCloseMenu());
  }

  ngDoCheck() {
    this.logged = this._authService.isAuthenticated();
  }

  openCloseMenu() {
    this.navOpen = !this.navOpen;
    this.navToggled.emit(this.navOpen);
  }

  login() {
    if (!this._authService.isAuthenticated()) {
      this.router.navigate(['/login']);
    }
  }

  logout() {
    if (!this._authService.logout()) {
      this.router.navigate(['/log']);
    }
  }
}

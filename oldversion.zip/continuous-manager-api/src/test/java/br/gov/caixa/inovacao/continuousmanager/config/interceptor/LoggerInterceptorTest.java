/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.config.interceptor;

import java.security.Principal;
import java.util.logging.Logger;

import javax.ejb.SessionContext;
import javax.interceptor.InvocationContext;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.service.WalletService;

/**
 * Classe de testes do LoggerInterceptor.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class LoggerInterceptorTest {
	
	@Mock
	private Principal principal;

	/**
	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.config.log.LoggerInterceptor#intercept(javax.interceptor.InvocationContext)}.
	 * @throws Exception 
	 */
	@Test
	public void testIntercept() throws Exception {
		InvocationContext invocationContext = Mockito.mock(InvocationContext.class);
		LoggerInterceptor loggerInterceptor = new LoggerInterceptor();
		
		SessionContext context = Mockito.mock(SessionContext.class);
		UtilReflection.setField(loggerInterceptor, "context", context);

		Mockito.when(invocationContext.getTarget()).thenReturn(LoggerInterceptorTest.class);
		Mockito.when(invocationContext.getMethod()).thenReturn(LoggerInterceptorTest.class.getMethods()[0]);
		Mockito.when(context.getCallerPrincipal()).thenReturn(principal);
		Mockito.when(principal.getName()).thenReturn("f771274");

		UtilReflection.setField(loggerInterceptor, "log", Logger.getLogger(WalletService.class.getName()));
		
		loggerInterceptor.intercept(invocationContext);
	}
	
	@Rule
	public ExpectedException expectedEx = ExpectedException.none();
	
	/**
	 * Test method for {@link br.gov.caixa.inovacao.continuousmanager.config.log.LoggerInterceptor#intercept(javax.interceptor.InvocationContext)}.
	 * @throws Exception 
	 */
	@Test
	public void testInterceptException() throws Exception {
		// Expected
		expectedEx.expect(Exception.class);
		
		InvocationContext invocationContext = Mockito.mock(InvocationContext.class);
		LoggerInterceptor loggerInterceptor = new LoggerInterceptor();
		loggerInterceptor.intercept(invocationContext);
	}

}

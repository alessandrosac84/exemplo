package br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-12T11:21:59.345-0300")
@StaticMetamodel(QualityGatePK.class)
public class QualityGatePK_ {
	public static volatile SingularAttribute<QualityGatePK, String> project;
	public static volatile SingularAttribute<QualityGatePK, String> wallet;
	public static volatile SingularAttribute<QualityGatePK, String> metricKey;
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cm-add-server-dialog',
  templateUrl: './add-server-dialog.component.html',
  styles: []
})
export class AddServerDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

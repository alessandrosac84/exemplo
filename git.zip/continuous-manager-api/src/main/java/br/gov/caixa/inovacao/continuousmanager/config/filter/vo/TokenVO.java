package br.gov.caixa.inovacao.continuousmanager.config.filter.vo;

import java.util.Calendar;
import java.util.List;

public class TokenVO {

	private Calendar exp;
	
	private String sub;
	
	private String jti;
	
	private Calendar iat;
	
	private String email;
	
	private List<String> roles;
	
	private String others;

	/**
	 * @return the exp
	 */
	public Calendar getExp() {
		return exp;
	}

	/**
	 * @param exp the exp to set
	 */
	public void setExp(Calendar exp) {
		this.exp = exp;
	}

	/**
	 * @return the sub
	 */
	public String getSub() {
		return sub;
	}

	/**
	 * @param sub the sub to set
	 */
	public void setSub(String sub) {
		this.sub = sub;
	}

	/**
	 * @return the jti
	 */
	public String getJti() {
		return jti;
	}

	/**
	 * @param jti the jti to set
	 */
	public void setJti(String jti) {
		this.jti = jti;
	}

	/**
	 * @return the iat
	 */
	public Calendar getIat() {
		return iat;
	}

	/**
	 * @param iat the iat to set
	 */
	public void setIat(Calendar iat) {
		this.iat = iat;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the roles
	 */
	public List<String> getRoles() {
		return roles;
	}

	/**
	 * @param roles the roles to set
	 */
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	/**
	 * @return the others
	 */
	public String getOthers() {
		return others;
	}

	/**
	 * @param others the others to set
	 */
	public void setOthers(String others) {
		this.others = others;
	}		
}

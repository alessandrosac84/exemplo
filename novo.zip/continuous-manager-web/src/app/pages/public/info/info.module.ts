import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';

import { InfoRoutingModule } from './info-routing.module';
import { MaterialModule } from '../../../core/material/material.module';
import { InfoComponent } from './info.component';
import { NewsComponent } from './news/news.component';
import { PipeModule } from '../../../shared/pipe/pipe.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    FormsModule,
    InfoRoutingModule,
    PipeModule
  ],
  declarations: [InfoComponent, NewsComponent],
  entryComponents: [
    NewsComponent
  ]
})
export class InfoModule { }

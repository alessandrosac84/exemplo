package br.gov.caixa.api.services;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.MailContentDto;
import br.gov.caixa.api.dto.MailDto;
import br.gov.caixa.api.model.StatusParticipante;
import br.gov.caixa.api.result.NotificacaoResult;

@Named
public class MailService {
	
	@Inject
	SendMailService sendMailService;

	private String message ="<html>" +
	        "<head><meta http-equiv='Content-type' content='text/html; charset=utf-8'></head>" +
		    "<body style='font-family:arial;text-align:center'>" +
		        "<div style='width:50%;'>" +
		            "<img border='0' src={3}>" +
		            "<h2 class='color: navy'>AVISO</h2>" +
		            "<span>Portal de Gest�o de Pessoas Informa:</span> <strong>{0}</strong> no Evento: {1}: " +
		            "<hr>" +
		            "<p><b>{2}</b></p>" +		            
		            "{4}" +
		            "<p><a href='http://unidades/sites/CEDESSP/EQUIPES/SitePages/profile.aspx' target='_blank'>PerfilDeEmpregados</a></p>" +
		        "</div>" +
		    "</body>" +
		    "<html>";
	
	private String message2 ="<html>" +
	        "<head><meta http-equiv='Content-type' content='text/html; charset=utf-8'></head>" +
		    "<body style='font-family:arial;text-align:center'>" +
		        "<div style='width:50%;'>" +
		            "<img border='0' src='http://unidades/sites/CEDESSP/PublishingImages/cedes.png'>" +
		            "<h2 class='color: navy'>A CEDESP/SP</h2>" +
		            "Atrav�s da Comiss�o PTDES - PESSOAS tem o prazer de agradecer a todos que direta ou indiretamente "
		            + " contribu�ram para a realiza��o do I Simp�sio Inova CEDES/SP ocorrido entre 06 e 09 de Novembro."
		            + "<br>"
		            + "<span style:'font-color:navy'>350 Participantes !!!!!!!!!</span>"
		            + "<hr>"		            	            
		            + " <p>Aos funcion�rios da CEDESSP/SP presentes em nossas palestras, eis sua oportunidade de fazer uma "
		            + "<a href='http://unidades/sites/CEDESSP/EQUIPES/SitePages/profile.aspx' target='_blank'>breve avalia��o</a> e deixar sua opini�o.</p>"
		            + "<p>Aos que n�o puderam comparecer esperamos sua participa��o em nossos pr�ximos eventos e aos visitantes presentes "
		            + "um agradecimento especial e esperamos rev�-los em uma pr�xima oportunidade.<p>" +
		            "<hr>" +
		            "<p><b>{0}</b></p>" +
		            "<br>" +		            
		            "<p><a href='http://unidades/sites/CEDESSP/EQUIPES/SitePages/index.aspx' target='_blank'>Gest�o de Pessoas PTDES</a></p>" +
		        "</div>" +
		    "</body>" +
		    "<html>";
	
	private String messageEnquete ="<html>" +
	        "<head><meta http-equiv='Content-type' content='text/html; charset=utf-8'></head>" +
		    "<body style='font-family:arial;text-align:center'>" +
		        "<div style='width:50%;'>" +
		            "<img border='0' src={0}>" +
		            "<h2 class='color: navy'>AVISO</h2>" +
		            "<span>Portal de Gest�o de Pessoas Informa:</span> <strong>{1}</strong> na Enquete: " +
		            "<hr>" +
		            "<p><b>{2}</b></p>" +
		            "<hr>" +
		            "{3}" +
		            "<p><a href='http://unidades/sites/CEDESSP/EQUIPES/SitePages/profile.aspx' target='_blank'>PerfilDeEmpregados</a></p>" +
		        "</div>" +
		    "</body>" +
		    "<html>";
	
	private static final String subject = "INFORMA��O - PTDES - [CEDESSP]";
		
	private static final String from = "cedessp004@caixa.gov.br";

	
	public NotificacaoResult sendMail(MailContentDto mailContentDto) {
				
		NotificacaoResult result = new NotificacaoResult();
		
		MailDto mail = new MailDto();
		mail.setSubject(subject);		
		mail.setFrom(from);		
		
		List<String> toList = mailContentDto.getMail();						
		mail.setTo(toList);
		mail.setCc( Arrays.asList("cedessp004@caixa.gov.br") );		
		
		SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");
		
		String data;		
		String content;
		
		if(mailContentDto.getStatus() == StatusParticipante.ENQUETE) {
						
			content = "<i> " + mailContentDto.getNomeTreinamento() +				 
				"</i><br><br> Inicia em: " + fmt.format(mailContentDto.getTurma().getData()) + 
				"<br> Termina em: " + fmt.format(mailContentDto.getTurma().getData2());			
		}
		else { 
			data = fmt.format(mailContentDto.getTurma().getData());
		
			content = mailContentDto.getNomeTreinamento() + 
				"<br> Turma: " + mailContentDto.getTurma().getNome() + 
				"<br> Data/Hora: " + data + " �s " + mailContentDto.getTurma().getHoraEntrada() +
				"<hr> Local: " + mailContentDto.getTurma().getLocal();				
		}
		
		String status = mailContentDto.getStatus().toString();
		String detalhe = "" ;
		
		if(mailContentDto.getStatus() == StatusParticipante.INSCRITO)
		{
			status = "Voc� foi " +  StatusParticipante.INSCRITO;
			detalhe = "Aguarde a CONFIRMA��O da sua participa��o, Acesse o link Abaixo, v� em notifica��es no canto superior direito da p�gina para maiores informa��es.";
		}
		else if(mailContentDto.getStatus() == StatusParticipante.CONVIDADO)
		{
			status = "Voc� est� recebendo um CONVITE para participa��o ";
			
			if(mailContentDto.getTurma().isAutoInscricao())
				
				detalhe = "Acesse o link, v� em notifica��es no canto superior direito da p�gina e fa�a a sua <a href='http://unidades/sites/CEDESSP/EQUIPES/SitePages/profile.aspx' target='_blank'>INSCRI��O</a> no evento.";
			else
				detalhe = "Acesse o link, v� em notifica��es no canto superior direito da p�gina para maiores informa��es";
		}
		else if(mailContentDto.getStatus() == StatusParticipante.CONFIRMADO)
		{
			status = "Voc� foi " +  StatusParticipante.CONFIRMADO;
			detalhe = "Acesse o link Abaixo, v� em notifica��es no canto superior direito da p�gina para maiores informa��es.";
		}
		else if(mailContentDto.getStatus() == StatusParticipante.ESPERA)
		{
			status = "Voc� foi Adicionado(a) � Fila de Espera";
			detalhe = "Se houver disponibiliza��o de Vagas voc� ser� avisado, Acesse o link Abaixo, v� em notifica��es no canto superior direito da p�gina para maiores informa��es.";			
		}
		else if(mailContentDto.getStatus() == StatusParticipante.RECUSADO || mailContentDto.getStatus() == StatusParticipante.REMOVIDO)
		{
			status = "N�o foi possivel EFETIVAR sua participa��o";
			detalhe = "Acesse o link Abaixo, v� em notifica��es no canto superior direito da p�gina para maiores informa��es.";			
		}
		else if(mailContentDto.getStatus() == StatusParticipante.CANCELADO)
		{
			status = "Voc� CANCELOU sua participa��o, ou SAIU da fila de espera";
			detalhe = "Para INSCREVER-SE novamente acesse o link Abaixo, v� em notifica��es no canto superior direito da p�gina para maiores informa��es.";			
		}
		else if(mailContentDto.getStatus() == StatusParticipante.PRESENTE)
		{
			status = "Voc� CONFIRMOU sua participa��o";
			detalhe = "Acesse o link Abaixo, v� em notifica��es no canto superior direito da p�gina para maiores informa��es.";			
		}		
		else if(mailContentDto.getStatus() == StatusParticipante.ENQUETE)
		{
			status = "Voc� est� recebendo um CONVITE para participa��o ";			
			detalhe = "Acesse o link, v� em notifica��es no canto superior direito da p�gina e <a href='http://unidades/sites/CEDESSP/EQUIPES/SitePages/profile.aspx' target='_blank'>PARTICIPE</a>.";
		}
		
		String msg = "";
		if(	mailContentDto.getStatus() == StatusParticipante.PRESENTIN 
//			mailContentDto.getStatus() == StatusParticipante.PRESENTIN || 
//			mailContentDto.getStatus() == StatusParticipante.PRESENTOUT ||
//			mailContentDto.getStatus() == StatusParticipante.AUSENTE ||
//			mailContentDto.getStatus() == StatusParticipante.INCONFIRMADO ||
//			mailContentDto.getStatus() == StatusParticipante.ININSCRITO
			) {
						 
			mail.setSubject("INFORMA��O - PTDES - Evento: " + mailContentDto.getNomeTreinamento().toUpperCase());		
//			if(mailContentDto.getStatus() == StatusParticipante.PRESENTIN)
				detalhe = "Para deixar sua opini�o sobre o evento: [ " + mailContentDto.getNomeTreinamento().toUpperCase() +  " ], acesse qualquer p�gina do Portal de Gest�o PTDES, v� em notifica��es no canto superior direito da p�gina e selecione FEEDBACK.";
//			else 
//				detalhe = "";						
			msg = MessageFormat.format(message2, detalhe);
		}
		else if(mailContentDto.getStatus() == StatusParticipante.ENQUETE) {
			
			msg = MessageFormat.format(messageEnquete, "http://unidades/sites/CEDESSP/PublishingImages/cedes.png", status, content, detalhe);
		} 
		else 
			msg = MessageFormat.format(message, status, mailContentDto.getTipoTreinamento(), content, "http://unidades/sites/CEDESSP/PublishingImages/cedes.png", detalhe);
				
		mail.setMessage(msg);

		sendMailService.send(mail);
		result.setMessage("Email(s) Enviado(s)");
		
		return result;		
	}

}

package br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.Commit;

/**
 * The persistent class for the measures database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name="measures")
@NamedQuery(name="Measures.findAll", query="SELECT s FROM Measures s")
public class Measures implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonView(ViewJson.SonarView.class)
	@EmbeddedId
	private MeasuresPK id;
	
	@JsonView(ViewJson.SonarView.class)
	@Column
	private Integer complexity;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(nullable=false)
	private Integer lines;
	
	@JsonView(ViewJson.SonarView.class)
	@Column
	private Integer bugs;
	
	@JsonView(ViewJson.SonarView.class)
	@Column
	private Integer vulnerabilities;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="code_smells")
	private Integer codeSmells;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(precision=4, scale=1)
	private BigDecimal coverage;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="unit_tests")
	private Integer unitTests;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="duplicated_lines")
	private Integer duplicatedLines;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_code_smells")
	private Integer newCodeSmells;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_coverage", precision=4, scale=1)
	private BigDecimal newCoverage;

	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_lines")
	private Integer newLines;

	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_vulnerabilities")
	private Integer newVulnerabilities;

	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_bugs")
	private Integer newBugs;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="comment_lines")
	private Integer commentLines;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="comment_lines_density", precision=4, scale=1)
	private BigDecimal commentLinesPercent;

	@JsonView(ViewJson.SonarView.class)
	@Column(name="duplicated_lines_density", precision=4, scale=1)
	private BigDecimal duplicatedLinesPercent;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_duplicated_lines")
	private Integer newDuplicatedLines;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_duplicated_lines_density", precision=4, scale=1)
	private BigDecimal newDuplicatedLinesPercent;
	
	@JsonView(ViewJson.SonarView.class)
	@Column
	private Integer violations;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_violations")
	private Integer newViolations;

	@JsonView(ViewJson.SonarView.class)
	@Column(name="sqale_rating", precision=4, scale=1)
	private BigDecimal sqaleRating;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_maintainability_rating", precision=4, scale=1)
	private BigDecimal newMaintainabilityRating;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="security_rating", precision=4, scale=1)
	private BigDecimal securityRating;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_security_rating", precision=4, scale=1)
	private BigDecimal newSecurityRating;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="reliability_rating", precision=4, scale=1)
	private BigDecimal reliabilityRating;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(name="new_reliability_rating", precision=4, scale=1)
	private BigDecimal newReliabilityRating;

	@JsonView(ViewJson.SonarView.class)
	@Column
	private Integer files;
	
	//bi-directional one-to-one association to Project
	@JsonView(ViewJson.SonarView.class)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="project", referencedColumnName="project", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="commit", referencedColumnName="commit", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private Commit commit;

	public Measures() {
		/* class constructor intentionally left blank */
	}

	public MeasuresPK getId() {
		return this.id;
	}

	public void setId(MeasuresPK id) {
		this.id = id;
	}

	public Integer getBugs() {
		return this.bugs;
	}

	public void setBugs(Integer bugs) {
		this.bugs = bugs;
	}

	public Integer getCodeSmells() {
		return this.codeSmells;
	}

	public void setCodeSmells(Integer codeSmells) {
		this.codeSmells = codeSmells;
	}

	public Integer getLines() {
		return this.lines;
	}

	public void setLines(Integer lines) {
		this.lines = lines;
	}

	public Integer getUnitTests() {
		return this.unitTests;
	}

	public void setUnitTests(Integer unitTests) {
		this.unitTests = unitTests;
	}

	public Integer getVulnerabilities() {
		return this.vulnerabilities;
	}

	public void setVulnerabilities(Integer vulnerabilities) {
		this.vulnerabilities = vulnerabilities;
	}

	public Commit getCommit() {
		return this.commit;
	}

	public void setCommit(Commit commit) {
		this.commit = commit;
	}

	/**
	 * @return the coverage
	 */
	public BigDecimal getCoverage() {
		return coverage;
	}

	/**
	 * @param coverage the coverage to set
	 */
	public void setCoverage(BigDecimal coverage) {
		this.coverage = coverage;
	}

	/**
	 * @return the duplicatedLines
	 */
	public Integer getDuplicatedLines() {
		return duplicatedLines;
	}

	/**
	 * @param duplicatedLines the duplicatedLines to set
	 */
	public void setDuplicatedLines(Integer duplicatedLines) {
		this.duplicatedLines = duplicatedLines;
	}

	/**
	 * @return the newCodeSmells
	 */
	public Integer getNewCodeSmells() {
		return newCodeSmells;
	}

	/**
	 * @param newCodeSmells the newCodeSmells to set
	 */
	public void setNewCodeSmells(Integer newCodeSmells) {
		this.newCodeSmells = newCodeSmells;
	}

	/**
	 * @return the newCoverage
	 */
	public BigDecimal getNewCoverage() {
		return newCoverage;
	}

	/**
	 * @param newCoverage the newCoverage to set
	 */
	public void setNewCoverage(BigDecimal newCoverage) {
		this.newCoverage = newCoverage;
	}

	/**
	 * @return the newLines
	 */
	public Integer getNewLines() {
		return newLines;
	}

	/**
	 * @param newLines the newLines to set
	 */
	public void setNewLines(Integer newLines) {
		this.newLines = newLines;
	}

	/**
	 * @return the newVulnerabilities
	 */
	public Integer getNewVulnerabilities() {
		return newVulnerabilities;
	}

	/**
	 * @param newVulnerabilities the newVulnerabilities to set
	 */
	public void setNewVulnerabilities(Integer newVulnerabilities) {
		this.newVulnerabilities = newVulnerabilities;
	}

	/**
	 * @return the newBugs
	 */
	public Integer getNewBugs() {
		return newBugs;
	}

	/**
	 * @param newBugs the newBugs to set
	 */
	public void setNewBugs(Integer newBugs) {
		this.newBugs = newBugs;
	}

	/**
	 * @return the commentLines
	 */
	public Integer getCommentLines() {
		return commentLines;
	}

	/**
	 * @param commentLines the commentLines to set
	 */
	public void setCommentLines(Integer commentLines) {
		this.commentLines = commentLines;
	}

	/**
	 * @return the commentLinesPercent
	 */
	public BigDecimal getCommentLinesPercent() {
		return commentLinesPercent;
	}

	/**
	 * @param commentLinesPercent the commentLinesPercent to set
	 */
	public void setCommentLinesPercent(BigDecimal commentLinesPercent) {
		this.commentLinesPercent = commentLinesPercent;
	}

	/**
	 * @return the duplicatedLinesPercent
	 */
	public BigDecimal getDuplicatedLinesPercent() {
		return duplicatedLinesPercent;
	}

	/**
	 * @param duplicatedLinesPercent the duplicatedLinesPercent to set
	 */
	public void setDuplicatedLinesPercent(BigDecimal duplicatedLinesPercent) {
		this.duplicatedLinesPercent = duplicatedLinesPercent;
	}

	/**
	 * @return the newDuplicatedLines
	 */
	public Integer getNewDuplicatedLines() {
		return newDuplicatedLines;
	}

	/**
	 * @param newDuplicatedLines the newDuplicatedLines to set
	 */
	public void setNewDuplicatedLines(Integer newDuplicatedLines) {
		this.newDuplicatedLines = newDuplicatedLines;
	}

	/**
	 * @return the newDuplicatedLinesPercent
	 */
	public BigDecimal getNewDuplicatedLinesPercent() {
		return newDuplicatedLinesPercent;
	}

	/**
	 * @param newDuplicatedLinesPercent the newDuplicatedLinesPercent to set
	 */
	public void setNewDuplicatedLinesPercent(BigDecimal newDuplicatedLinesPercent) {
		this.newDuplicatedLinesPercent = newDuplicatedLinesPercent;
	}

	/**
	 * @return the violations
	 */
	public Integer getViolations() {
		return violations;
	}

	/**
	 * @param violations the violations to set
	 */
	public void setViolations(Integer violations) {
		this.violations = violations;
	}

	/**
	 * @return the newViolations
	 */
	public Integer getNewViolations() {
		return newViolations;
	}

	/**
	 * @param newViolations the newViolations to set
	 */
	public void setNewViolations(Integer newViolations) {
		this.newViolations = newViolations;
	}

	/**
	 * @return the sqaleRating
	 */
	public BigDecimal getSqaleRating() {
		return sqaleRating;
	}

	/**
	 * @param sqaleRating the sqaleRating to set
	 */
	public void setSqaleRating(BigDecimal sqaleRating) {
		this.sqaleRating = sqaleRating;
	}

	/**
	 * @return the newMaintainabilityRating
	 */
	public BigDecimal getNewMaintainabilityRating() {
		return newMaintainabilityRating;
	}

	/**
	 * @param newMaintainabilityRating the newMaintainabilityRating to set
	 */
	public void setNewMaintainabilityRating(BigDecimal newMaintainabilityRating) {
		this.newMaintainabilityRating = newMaintainabilityRating;
	}

	/**
	 * @return the securityRating
	 */
	public BigDecimal getSecurityRating() {
		return securityRating;
	}

	/**
	 * @param securityRating the securityRating to set
	 */
	public void setSecurityRating(BigDecimal securityRating) {
		this.securityRating = securityRating;
	}

	/**
	 * @return the newSecurityRating
	 */
	public BigDecimal getNewSecurityRating() {
		return newSecurityRating;
	}

	/**
	 * @param newSecurityRating the newSecurityRating to set
	 */
	public void setNewSecurityRating(BigDecimal newSecurityRating) {
		this.newSecurityRating = newSecurityRating;
	}

	/**
	 * @return the reliabilityRating
	 */
	public BigDecimal getReliabilityRating() {
		return reliabilityRating;
	}

	/**
	 * @param reliabilityRating the reliabilityRating to set
	 */
	public void setReliabilityRating(BigDecimal reliabilityRating) {
		this.reliabilityRating = reliabilityRating;
	}

	/**
	 * @return the newReliabilityRating
	 */
	public BigDecimal getNewReliabilityRating() {
		return newReliabilityRating;
	}

	/**
	 * @param newReliabilityRating the newReliabilityRating to set
	 */
	public void setNewReliabilityRating(BigDecimal newReliabilityRating) {
		this.newReliabilityRating = newReliabilityRating;
	}

	/**
	 * @return the files
	 */
	public Integer getFiles() {
		return files;
	}

	/**
	 * @param files the files to set
	 */
	public void setFiles(Integer files) {
		this.files = files;
	}

	/**
	 * @return the complexity
	 */
	public Integer getComplexity() {
		return complexity;
	}

	/**
	 * @param complexity the complexity to set
	 */
	public void setComplexity(Integer complexity) {
		this.complexity = complexity;
	}
}
package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the cursos database table.
 * 
 */
@Entity
@Table(name="cursos")
@NamedQueries({
	@NamedQuery(name = "Curso.findAll", query="SELECT c FROM Curso c"),
	@NamedQuery(name = "Curso.findByAKs", query = "SELECT c FROM Curso c WHERE c.id <> :id AND (c.instituicao = :instituicao OR c.curso = :curso OR c.cargaHoraria = :cargaHoraria OR c.ano = :ano)"),
	@NamedQuery(name="Curso.findAllByFuncionario", query="SELECT c FROM Curso c WHERE c.funcionario.matricula = :matricula"),
})
public class Curso extends AuditedEntity implements Serializable, IEntity<Integer> {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;
	
	@Max(value=2050)
	@Min(value=1950)
	@NotNull
	@Column(nullable=false, precision=4)
	private Integer ano;

	@NotNull
	@Column(name="carga_horaria", nullable=false, precision=7)
	private Integer cargaHoraria;

	@NotEmpty
	@Size(min=3)
	@Column(nullable=false, length=70)
	private String curso;

	@NotEmpty
	@Size(min=3)
	@Column(nullable=false, length=70)
	private String instituicao;

	@JsonIgnore
	//bi-directional many-to-one association to Funcionario
	@ManyToOne
	@JoinColumn(name="funcionario", nullable=false)
	private Funcionario funcionario;

	public Curso() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAno() {
		return this.ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public Integer getCargaHoraria() {
		return this.cargaHoraria;
	}

	public void setCargaHoraria(Integer cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}

	public String getCurso() {
		return this.curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public String getInstituicao() {
		return this.instituicao;
	}

	public void setInstituicao(String instituicao) {
		this.instituicao = instituicao;
	}

	public Funcionario getFuncionario() {
		return this.funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}
	
	@Override
	public boolean isTheSameObject(IEntity<Integer> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		Curso other = (Curso) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
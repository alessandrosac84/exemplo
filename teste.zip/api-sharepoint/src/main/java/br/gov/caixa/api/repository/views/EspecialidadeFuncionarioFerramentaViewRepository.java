package br.gov.caixa.api.repository.views;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.gov.caixa.api.model.views.EspecialidadeFuncionarioFerramentaView;

public interface EspecialidadeFuncionarioFerramentaViewRepository extends JpaRepository<EspecialidadeFuncionarioFerramentaView, Long> {
		
	//@Query("select a from EspecialidadeFuncionarioFerramentaView a where a.ferramentaId = ?1)")
//	List<EspecialidadeFuncionarioFerramentaView> findByFerramentaId(Long ferramentaId);
	
//	List<EspecialidadeFuncionarioFerramentaView> findByFerramentaIdIn(List<Long> ferramentaId);
//	
//	List<EspecialidadeFuncionarioFerramentaView> findByEspecialidadeIdAndFerramentaIdIn(Long especialidadeId, List<Long> ferramentaId);
	
	List<EspecialidadeFuncionarioFerramentaView> findByEspecialidadeId(Long especialidadeId);

}

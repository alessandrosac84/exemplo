import { ChangeSet } from './changeset.model';

export class Build {
  public id: { id: number, project: string, wallet: string, job: string };
  public createdAt: Date;
  public description: string;
  public duration: Date;
  public estimateDuration: Date;
  public localError: string;
  public result: string;
  public changeSets: ChangeSet[];
}

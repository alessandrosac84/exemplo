import { Router } from '@angular/router';
import { Component, OnInit, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { Login } from '../../shared/model/login.model';
import { AuthService } from '../../shared/service/auth/auth.service';

@Component({
  selector: 'jmw-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnChanges {

  login: Login;
  loginForm: FormGroup;

  constructor(private _fb: FormBuilder,
    private _authService: AuthService,
    private _router: Router) {
    this.createForm();
  }

  ngOnInit() {
  }

  createForm() {
    this.loginForm = this._fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      rememberMe: false,
    });
    this.ngOnChanges();
  }

  ngOnChanges() {
    // Obter usuario do cookie
    this.loginForm.reset({
      username: ''// this.hero.name
    });
  }

  onSubmit() {
    this.login = this.prepareLogin();
    this._authService.login(this.login).subscribe(
      data => {
        this._router.navigate(['/dashboard']);
      }
    );
  }

  prepareLogin(): Login {
    const formModel = this.loginForm.value;
    // return new `Login` object containing a combination of original login value(s)
    // and deep copies of changed form model values
    const saveLogin: Login = {
      username: formModel.username,
      password: formModel.password,
      rememberMe: formModel.rememberMe || false,
    };
    return saveLogin;
  }

}

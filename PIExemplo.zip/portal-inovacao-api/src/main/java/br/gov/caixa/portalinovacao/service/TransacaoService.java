package br.gov.caixa.portalinovacao.service;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.portalinovacao.model.vo.TransacaoVO;
import br.gov.caixa.portalinovacao.service.geraws.SUDPOMSGPort;
import br.gov.caixa.portalinovacao.service.geraws.SUDPOMSGService;
import br.gov.caixa.portalinovacao.service.geraws.request.ProgramInterface;
import br.gov.caixa.portalinovacao.service.geraws.request.ProgramInterface.WebSudwsmsg;


@Stateless
public class TransacaoService {
	@Inject
	private SUDPOMSGService service1;

	public String send(TransacaoVO servico) {
		ProgramInterface request = new ProgramInterface();
		request.setWebSudwsmsg(new WebSudwsmsg());
		br.gov.caixa.portalinovacao.service.geraws.response.ProgramInterface response = new br.gov.caixa.portalinovacao.service.geraws.response.ProgramInterface(); 
		
		request.getWebSudwsmsg().setWebPgmname(servico.getPrograma());
		request.getWebSudwsmsg().setWebUri(servico.getUri());
		request.getWebSudwsmsg().setWebTransaction(servico.getSistemaId());
		request.getWebSudwsmsg().setWebPgmintContainerCommarea(servico.getFlag());
		request.getWebSudwsmsg().setWebReqmemBookEntrada(servico.getBookEntrada());
		request.getWebSudwsmsg().setWebRespmemBookSaida(servico.getBookSaida());
		request.getWebSudwsmsg().setWebPdslibBook(servico.getDiretorioEntrada());
		
		request.getWebSudwsmsg().setWebUsuarioTmpdirUsuserv("SSUDS01D");
		request.getWebSudwsmsg().setWebResquestNamespace("/tokensmst");
		request.getWebSudwsmsg().setWebResponseNamespace("tokensms");
		request.getWebSudwsmsg().setWebLang("COBOL");
		request.getWebSudwsmsg().setWebWsbind("tokensmst.wsbind");
		request.getWebSudwsmsg().setWebWsdl("tokensmst.wsdl");
		request.getWebSudwsmsg().setWebWsdlNamespaceHttp("tokensms");
		request.getWebSudwsmsg().setWebOperationName("getToken");
		request.getWebSudwsmsg().setWebUserid("SMBSSUDD");
		request.getWebSudwsmsg().setWebMsgRetorno("");
		request.getWebSudwsmsg().setWebSequenciaControle(163733);
		request.getWebSudwsmsg().setWebSubmitStatus("S");
		
        SUDPOMSGPort port1 = service1.getSUDPOMSGPort();
        response.setWebSudwsmsg(port1.geraws(request.getWebSudwsmsg()));
        
        return response.getWebSudwsmsg().getWebMsgRetorno();

    }

}

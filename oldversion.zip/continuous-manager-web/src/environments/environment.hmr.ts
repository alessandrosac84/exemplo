export const environment = {
  production: false,
  apiBaseUrl: 'https://localhost:8443/continuous-manager-api/',
  hmr: true
};

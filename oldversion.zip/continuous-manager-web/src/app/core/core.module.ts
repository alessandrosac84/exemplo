/* Angular Imports */
import { CommonModule } from '@angular/common';
import { ModuleWithProviders, NgModule, Optional, SkipSelf } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

/* Third Party Angular */
import { ToastrModule } from 'ngx-toastr';

/* App Imports */
import { HeaderComponent } from '../layout/header/header.component';
import { FooterComponent } from '../layout/footer/footer.component';
import { SidebarComponent } from '../layout/sidebar/sidebar.component';
import { LoginComponent } from '../pages/login/login.component';

/* Service Imports */
import { AuthService } from './../shared/service/auth/auth.service';
import { WalletService } from './../shared/service/wallet.service';
import { DashBoardService } from './../shared/service/dashboard.service';
import { httpInterceptorProviders } from './interceptors';

/* Guard Imports */
import { AuthGuard } from './../guards/auth.guard';

@NgModule({
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: 'toast-bottom-right',
    }),
    RouterModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  declarations: [
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    LoginComponent
  ],
  providers: [
    Title,
    WalletService,
    AuthService,
    DashBoardService,
    httpInterceptorProviders,
    AuthGuard
  ],
  exports: [
    BrowserAnimationsModule,
    RouterModule,
    ReactiveFormsModule,
    HttpClientModule,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
  ]
})
export class CoreModule {
  constructor( @Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only');
    }
  }

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CoreModule,
      providers: [
        Title,
        WalletService,
        AuthService,
        DashBoardService
      ]
    };
  }
}

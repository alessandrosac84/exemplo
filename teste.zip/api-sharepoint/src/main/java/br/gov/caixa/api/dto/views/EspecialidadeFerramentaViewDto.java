package br.gov.caixa.api.dto.views;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeFerramentaView;

public class EspecialidadeFerramentaViewDto {

	private Long uid;	
	private String ferramenta;
	private Long especialidadeId;
	private String especialidade;
	private Integer rating;
	private Long especialidadeFerramentaId;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public String getFerramenta() {
		return ferramenta;
	}

	public void setFerramenta(String ferramenta) {
		this.ferramenta = ferramenta;
	}

	public Long getEspecialidadeId() {
		return especialidadeId;
	}

	public void setEspecialidadeId(Long especialidadeId) {
		this.especialidadeId = especialidadeId;
	}

	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}


	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}
	
	public Long getEspecialidadeFerramentaId() {
		return especialidadeFerramentaId;
	}

	public void setEspecialidadeFerramentaId(Long especialidadeFerramentaId) {
		this.especialidadeFerramentaId = especialidadeFerramentaId;
	}

	public static EspecialidadeFerramentaViewDto fromEspecialidadeFerramentaViewToDto(EspecialidadeFerramentaView especialidadeFerramentaView) {
		EspecialidadeFerramentaViewDto dto = new EspecialidadeFerramentaViewDto();
		
		dto.setUid(especialidadeFerramentaView.getUid());
		dto.setFerramenta(especialidadeFerramentaView.getFerramenta());
		dto.setEspecialidade(especialidadeFerramentaView.getEspecialidade());
		dto.setEspecialidadeId(especialidadeFerramentaView.getEspecialidadeId());
		dto.setEspecialidadeFerramentaId(especialidadeFerramentaView.getEspecialidadeFerramentaId());
		dto.setRating(especialidadeFerramentaView.getRating());
		
		return dto;
	}
	
	public static List<EspecialidadeFerramentaViewDto> fromEspecialidadeFerramentaViewToListDto(List<EspecialidadeFerramentaView> especialidadeFerramentaViews) {
		List<EspecialidadeFerramentaViewDto> returnList = new ArrayList<EspecialidadeFerramentaViewDto>();
		
		for (EspecialidadeFerramentaView especialidadeFerramentaView : especialidadeFerramentaViews) {
			
			returnList.add(fromEspecialidadeFerramentaViewToDto(especialidadeFerramentaView) );
		}
		return returnList;
	}
}

/* Angular Imports */
import { CommonModule } from '@angular/common';
import { ModuleWithProviders, NgModule, Optional, SkipSelf } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

/* Routing Module */
import { CoreRoutingModule } from './core-routing.module';

/* App Imports */
import { HeaderComponent } from '../layout/header/header.component';
import { FooterComponent } from '../layout/footer/footer.component';
import { SidebarComponent } from '../layout/sidebar/sidebar.component';
import { LoginComponent } from './auth/login/login.component';

/* Service Imports */
import { AuthService } from './auth/auth.service';
import { JenkinsService } from './../shared/service/jenkins.service';

@NgModule({
  imports: [
    CommonModule,
    CoreRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  declarations: [
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    LoginComponent
  ],
  providers: [
    Title,
    JenkinsService,
    AuthService
  ],
  exports: [
    BrowserAnimationsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
  ]
})
export class CoreModule {
  constructor( @Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only');
    }
  }

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CoreModule,
      providers: [
        Title,
        JenkinsService,
        AuthService
      ]
    };
  }
}

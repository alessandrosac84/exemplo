package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author Alessandro Carvalho
 * 
 */
public class QualityGateVO implements Serializable{

	private static final long serialVersionUID = -6229430707520052115L;
	
	private Integer id;
	
	private String name;
	
	private List<ConditionVO> conditions;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the conditions
	 */
	public List<ConditionVO> getConditions() {
		return conditions;
	}

	/**
	 * @param conditions the conditions to set
	 */
	public void setConditions(List<ConditionVO> conditions) {
		this.conditions = conditions;
	}
}

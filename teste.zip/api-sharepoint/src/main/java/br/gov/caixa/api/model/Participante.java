package br.gov.caixa.api.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.gov.caixa.api.dto.ParticipanteDto;
import br.gov.caixa.api.model.views.FuncionarioView;

@Entity
@Table(name = "participante")
public class Participante {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@ManyToOne
	@JoinColumn(name = "FUNCIONARIO_ID")
	private FuncionarioView funcionario;
	
	@ManyToOne
	@JoinColumn(name = "TURMA_ID")
	private Turma turma;
	
	@Column(name = "PRESENSCA", columnDefinition = "boolean default false")
	private boolean presenca;
	
	@Column(name = "AUTORIZACAO", columnDefinition = "int default 0")
	private byte autorizacao;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	@Column(name = "STATUS_PARTICIPANTE", columnDefinition = "int default 0")
	private StatusParticipante statusParticipante;	
	
	@Column(name = "DATA")
	private Date data;

	@Enumerated(EnumType.ORDINAL) 
	private StatusParticipante StatusParticipante() { 
	    return statusParticipante; 
	}	
	
	public StatusParticipante getStatusParticipante() {
		return statusParticipante;
	}

	public void setStatusParticipante(StatusParticipante statusParticipante) {
		this.statusParticipante = statusParticipante;
	}
	
	public FuncionarioView getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(FuncionarioView funcionario) {
		this.funcionario = funcionario;
	}
	
	public byte getAutorizacao() {
		return autorizacao;
	}

	public void setAutorizacao(byte autorizacao) {
		this.autorizacao = autorizacao;
	}	
	
	public boolean isPresenca() {
		return presenca;
	}

	public void setPresenca(boolean presenca) {
		this.presenca = presenca;
	}

	public Turma getTurma() {
		return turma;
	}

	public void setTurma(Turma turma) {
		this.turma = turma;
	}
	
	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public static Participante fromDtoToParticipante(ParticipanteDto dto) {
		Participante participante = new Participante();
		participante.setUid(dto.getUid());
		participante.setFuncionario(dto.getFuncionario());
		participante.setAutorizacao(dto.getAutorizacao());
		participante.setTurma(Turma.fromDtoToTurma(dto.getTurma()));
		participante.setStatusParticipante(dto.getStatusParticipante());
		participante.setPresenca(dto.isPresenca());
		return participante;
	}

	public static List<Participante> fromDtoToListParticipante(List<ParticipanteDto> participantes) {
		List<Participante> result = new ArrayList<Participante>();
		
		for (ParticipanteDto dto : participantes) {
			result.add(fromDtoToParticipante(dto));
		}
		
		return result;
	}
}

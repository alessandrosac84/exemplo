import { Environment } from './../../../shared/model/environment.model';
import { Commit } from './../../../shared/model/commit.model';
import { Project } from './../../../shared/model/project.model';
import { Measure } from './../../../shared/model/measure.model';
import { HttpResponse } from '@angular/common/http';
import { WalletService } from './../../../shared/service/wallet.service';
import { Build } from './../../../shared/model/build.model';
import { DashBoardService } from './../../../shared/service/dashboard.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Dashboard } from './../../../shared/model/dashboard.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jmw-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {
  pageTitle = 'Detalhe';
  walletSelected: string;
  projectSelected: string;
  commitSelected: string;
  itemDetailProject: Measure;
  listaBuilds: Build[];
  listResults: any[];
  listEnviroments: Environment[];
  percentSuccess = 0;
  percentAborted = 0;
  percentFailed = 0;
  percentUnstable = 0;
  percentNotBuilt = 0;
  totalListaBuilds = 0;
  dev_version;
  tqs_version;
  prd_version;

  /*apagar esta lista: FAKE*/
  listaDashboard: Dashboard[] = [];
  /**/

  constructor(private route: ActivatedRoute,
    private _router: Router, private _dashBoardService: DashBoardService, private _walletService: WalletService) { }

  ngOnInit() {
    this.itemDetailProject = new Measure();
    this.itemDetailProject.id = { wallet: null, project: null, commit: null };
    this.itemDetailProject.commit = { project: { name: null } };


    this.projectSelected = this.route.snapshot.paramMap.get('project');
    this.walletSelected = this.route.snapshot.paramMap.get('wallet');
    this.commitSelected = this.route.snapshot.paramMap.get('commit');

    this._dashBoardService.getDetailProject(this.walletSelected, this.projectSelected, this.commitSelected).subscribe(data => {
      this.itemDetailProject = data;

      if (this.itemDetailProject.lines <= 5000) {
        this.itemDetailProject.sizeProject = 'S';
      } else if (this.itemDetailProject.lines > 5000 && this.itemDetailProject.lines <= 10000) {
        this.itemDetailProject.sizeProject = 'M';
      } else {
        this.itemDetailProject.sizeProject = 'L';
      }

      switch (this.itemDetailProject.securityRating) {
        case 1:
          this.itemDetailProject.security = 'A';
          break;
        case 2:
          this.itemDetailProject.security = 'B';
          break;
        case 3:
          this.itemDetailProject.security = 'C';
          break;
        case 4:
          this.itemDetailProject.security = 'D';
          break;
        case 5:
          this.itemDetailProject.security = 'E';
          break;
      }

      switch (this.itemDetailProject.sqaleRating) {
        case 1:
          this.itemDetailProject.quality = 'A';
          break;
        case 2:
          this.itemDetailProject.quality = 'B';
          break;
        case 3:
          this.itemDetailProject.quality = 'C';
          break;
        case 4:
          this.itemDetailProject.quality = 'D';
          break;
        case 5:
          this.itemDetailProject.quality = 'E';
          break;
      }
    });

    this.getBuilds();
    this.getVersions();

  }

  getVersions() {
    this._dashBoardService.getVersions(this.walletSelected, this.projectSelected).subscribe(data => {
      this.listEnviroments = data;

      this.listEnviroments.forEach(env => {
        if (env.ambiente === 'DES') {
          this.dev_version = env.version;
        } else if (env.ambiente === 'TQS') {
          this.tqs_version = env.version;
        } else if (env.ambiente === 'PRD') {
          this.prd_version = env.version;
        }
      });
    });
  }

  getBuilds() {
    this._dashBoardService.getProjectBuildsById(this.walletSelected, this.projectSelected).subscribe(data => {
      this.listResults = data;

      this.listResults.forEach(item => {
        if (item.result === 'FAILURE') {
          this.percentFailed = item.quantidade;
        } else if (item.result === 'ABORTED') {
          this.percentAborted = item.quantidade;
        } else if (item.result === 'SUCCESS') {
          this.percentSuccess = item.quantidade;
        } else if (item.result === 'UNSTABLE') {
          this.percentUnstable = item.quantidade;
        } else if (item.result === 'NOT_BUILT') {
          this.percentNotBuilt = item.quantidade;
        }

        this.totalListaBuilds += item.quantidade;
      });
      this.percentSuccess = ((this.percentSuccess * 100) / this.totalListaBuilds);
      this.percentAborted = ((this.percentAborted * 100) / this.totalListaBuilds);
      this.percentFailed = ((this.percentFailed * 100) / this.totalListaBuilds);
      this.percentUnstable = ((this.percentUnstable * 100) / this.totalListaBuilds);
      this.percentNotBuilt = ((this.percentNotBuilt * 100) / this.totalListaBuilds);
    });
  }
}

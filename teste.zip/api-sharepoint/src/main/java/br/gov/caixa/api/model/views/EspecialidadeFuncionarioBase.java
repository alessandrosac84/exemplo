package br.gov.caixa.api.model.views;

public abstract class EspecialidadeFuncionarioBase{
	
	public Long uid;	
	public String nome;	
	public Integer rating;	
	public Long tipoId;	
	public String tipoNome;	
	public Boolean ativo;
	public Integer ratingEspecialidade;	
	public Long especialidadeId;
	public String tipo;
	
}

package br.gov.caixa.inovacao.continuousmanager.config.filter.response;

import java.io.IOException;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.core.MultivaluedMap;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * Classe de Teste de CacheControlFilter
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CacheControlResponseFilterTest {

	@InjectMocks
	private CacheControlResponseFilter cacheControlResponseFilter;
	
	@Mock
	private ContainerRequestContext containerRequestContext;
	
	@Mock
	private ContainerResponseContext containerResponseContext;
	
	@Mock
	private MultivaluedMap<String, Object> headers;
	
	@Test
	public void testFilterGet() throws IOException {
		// Arrange
		Mockito.when(containerRequestContext.getMethod()).thenReturn("GET");
		Mockito.when(containerResponseContext.getHeaders()).thenReturn(headers);
		
		// Act
		cacheControlResponseFilter.filter(containerRequestContext, containerResponseContext);
		
		// Then
		Assert.assertEquals("GET", containerRequestContext.getMethod());
	}
	
	@Test
	public void testFilterPost() throws IOException {
		// Arrange
		Mockito.when(containerRequestContext.getMethod()).thenReturn("POST");
		Mockito.when(containerResponseContext.getHeaders()).thenReturn(headers);
		
		// Act
		cacheControlResponseFilter.filter(containerRequestContext, containerResponseContext);
		
		// Then
		Assert.assertEquals("POST", containerRequestContext.getMethod());
	}

}

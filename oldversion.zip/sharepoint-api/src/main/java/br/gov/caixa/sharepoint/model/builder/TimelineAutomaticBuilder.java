/**
 * 
 */
package br.gov.caixa.sharepoint.model.builder;

import java.util.Calendar;

import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;

import br.gov.caixa.sharepoint.model.entity.Funcionario;
import br.gov.caixa.sharepoint.model.entity.Timeline;
import br.gov.caixa.sharepoint.model.entity.TipoTimeline;

/**
 * @author Fabio Iwakoshi
 *
 */
public class TimelineAutomaticBuilder {

	private TimelineAutomaticBuilder() {}
	
	public static IDataEvento funcionario(Funcionario funcionario) {
        return new TimelineAutomaticBuilder.Builder(funcionario);
    }
	
	public interface IDataEvento {
        ITitulo dataEvento(@Past Calendar dataEvento);
    }
	
	public interface ITitulo {
		IDetalhe titulo(@NotEmpty String titulo);
    }
	
	public interface IDetalhe {
        IBuild detalhe(@NotEmpty String detalhe);
    }

    public interface IBuild {
    	Timeline build();
    }
	
	
	private static class Builder implements IDataEvento, ITitulo, IDetalhe, IBuild {
		private Timeline instance = new Timeline();
		
		public Builder(Funcionario funcionario) {
			TipoTimeline tipoTimeline = new TipoTimeline();
			tipoTimeline.setId(1);
			instance.setTipoTimeline(tipoTimeline);
            instance.setFuncionario(funcionario);
        }

		@Override
		public ITitulo dataEvento(@Past Calendar dataEvento) {
			instance.setDataEvento(dataEvento);
            return this;
		}

		@Override
		public IDetalhe titulo(@NotEmpty String titulo) {
			instance.setTitulo(titulo);
            return this;
		}

		@Override
		public IBuild detalhe(@NotEmpty String detalhe) {
			instance.setDetalhe(detalhe);
            return this;
		}

		@Override
		public Timeline build() {
			return instance;
		}
	}
}

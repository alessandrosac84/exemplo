/**
 * 
 */
package br.gov.caixa.sharepoint.config.exception;

import java.util.Iterator;
import java.util.List;

import javax.ejb.EJBException;
import javax.validation.ConstraintDeclarationException;
import javax.validation.ConstraintDefinitionException;
import javax.validation.GroupDefinitionException;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.NotSupportedException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.jboss.resteasy.api.validation.ResteasyViolationException;
import org.jboss.resteasy.api.validation.Validation;
import org.jboss.resteasy.api.validation.ViolationReport;

/**
 * @author Fabio Iwakoshi
 *
 */
@Provider
public class ValidationExceptionMapper implements ExceptionMapper<Exception> {

	@Override
    public Response toResponse(Exception exception) {
		//exception.printStackTrace();
        if (exception instanceof ConstraintDefinitionException) {
            return buildResponse(unwrapException(exception), MediaType.TEXT_PLAIN, Status.SERVICE_UNAVAILABLE);
        }
        if (exception instanceof ConstraintDeclarationException) {
            return buildResponse(unwrapException(exception), MediaType.TEXT_PLAIN, Status.SERVICE_UNAVAILABLE);
        }
        if (exception instanceof GroupDefinitionException) {
            return buildResponse(unwrapException(exception), MediaType.TEXT_PLAIN, Status.SERVICE_UNAVAILABLE);
        }
        if (exception instanceof ResteasyViolationException) {
            ResteasyViolationException resteasyViolationException = ResteasyViolationException.class.cast(exception);
            Exception e = resteasyViolationException.getException();
            if (e != null) {
                return buildResponse(unwrapException(e), MediaType.TEXT_PLAIN, Status.SERVICE_UNAVAILABLE);
            } else if (resteasyViolationException.getReturnValueViolations().size() == 0) {
                return buildViolationReportResponse(resteasyViolationException, Status.BAD_REQUEST);
            } else {
                return buildViolationReportResponse(resteasyViolationException, Status.SERVICE_UNAVAILABLE);
            }
        }
        if (exception instanceof ClientErrorException) {
        	ClientErrorException clientErrorException = ClientErrorException.class.cast(exception);
        	return buildViolationReportResponse(clientErrorException);
        }
        if (exception instanceof EJBException) {
        	if(exception.getMessage().lastIndexOf("Exception:") > -1) {        		
        		return buildResponse("{\"message\":\"" + exception.getMessage().substring(exception.getMessage().lastIndexOf("Exception:")+10) + "\"}", MediaType.APPLICATION_JSON, Status.BAD_REQUEST);
        	} else {
        		return buildResponse("{\"message\":\"" + exception.getMessage() + "\"}", MediaType.APPLICATION_JSON, Status.BAD_REQUEST);
        	}
        }
        return buildResponse("{\"message\":\"" + unwrapException(exception) + "\"}", MediaType.APPLICATION_JSON, Status.SERVICE_UNAVAILABLE);
    }

    protected Response buildResponse(Object entity, String mediaType, Status status) {
        ResponseBuilder builder = Response.status(status).entity(entity);
        builder.type(mediaType);
        builder.header(Validation.VALIDATION_HEADER, "true");
        return builder.build();
    }
    
    protected Response buildViolationReportResponse(ClientErrorException exception) {
    	Status status = Status.SERVICE_UNAVAILABLE;
    	if (exception instanceof NotAuthorizedException) {
    		status = Status.UNAUTHORIZED;
    	} else if (exception instanceof NotSupportedException) {
    		status = Status.UNSUPPORTED_MEDIA_TYPE;
    	}
    	
    	return buildResponse("{\"message\":\"" + exception.getMessage() + "\"}", MediaType.APPLICATION_JSON, status);
    }

    protected Response buildViolationReportResponse(ResteasyViolationException exception, Status status) {
        ResponseBuilder builder = Response.status(status);
        builder.header(Validation.VALIDATION_HEADER, "true");

        // Check standard media types.
        MediaType mediaType = getAcceptMediaType(exception.getAccept());
        if (mediaType != null) {
            builder.type(mediaType);
            builder.entity(new ViolationReport(exception));
            return builder.build();
        }

        // Default media type.
        builder.type(MediaType.TEXT_PLAIN);
        builder.entity(exception.toString());
        return builder.build();
    }

    protected String unwrapException(Throwable t) {
        StringBuffer sb = new StringBuffer();
        doUnwrapException(sb, t);
        return sb.toString();
    }

    private void doUnwrapException(StringBuffer sb, Throwable t) {
        if (t == null) {
            return;
        }
        sb.append(t.toString());
        if (t.getCause() != null && t != t.getCause()) {
            sb.append('[');
            doUnwrapException(sb, t.getCause());
            sb.append(']');
        }
    }

    private MediaType getAcceptMediaType(List<MediaType> accept) {
        Iterator<MediaType> it = accept.iterator();
        while (it.hasNext()) {
            MediaType mt = it.next();
            if (MediaType.APPLICATION_JSON_TYPE.getType().equals(mt.getType())
                    && MediaType.APPLICATION_JSON_TYPE.getSubtype().equals(mt.getSubtype())) {
                return MediaType.APPLICATION_JSON_TYPE;
            }
            /*
             * application/xml media type causes an exception:
             * org.jboss.resteasy.core.NoMessageBodyWriterFoundFailure: Could not find MessageBodyWriter for response
             * object of type: org.jboss.resteasy.api.validation.ViolationReport of media type: application/xml
             */
            if (MediaType.APPLICATION_XML_TYPE.getType().equals(mt.getType())
                    && MediaType.APPLICATION_XML_TYPE.getSubtype().equals(mt.getSubtype())) {
                return MediaType.APPLICATION_XML_TYPE;
            }
        }
        return null;
}
}

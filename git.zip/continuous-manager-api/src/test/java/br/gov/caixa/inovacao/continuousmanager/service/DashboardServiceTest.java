package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.JenkinsResult;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.Measures;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;
import br.gov.caixa.inovacao.continuousmanager.model.vo.ResultVO;

/**
 * Classe de testes do DashboardService.
 * 
 * @author Alessandro Carvalho
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DashboardServiceTest {
	
	@InjectMocks
	private DashboardService dashboardService;
	
	@Mock
	private MeasuresService measureService;
	
	@Mock
	private BuildService buildService;
	
	private List<ResultVO> resultsVO = new ArrayList<ResultVO>();
	
	@Before
	public void before() {
		ResultVO item = new ResultVO(JenkinsResult.SUCCESS, 1L);
		resultsVO.add(item);
		UtilReflection.setField(dashboardService, "log", Logger.getLogger(AuditService.class.getName()));
	}
	
	@Test
	public void testFindById() {
		//Arrange
		Mockito.when(measureService.findById(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(new Measures());
		
		// Act
		Measures ms = dashboardService.findById("inovacao", "continuous-manager-web", "sdasadasdasd");

		// Then
		Assert.assertNotNull(ms);
	}
	
	@Test
	public void testFindAll() {
		
		// Act
		List<Measures> listCs = dashboardService.findAll(0, Integer.MAX_VALUE, "", "id", AscDesc.ASC);

		// Then
		Assert.assertEquals(0, listCs.size());
	}
	
	@Test
	public void testCountAll() {
		// Arrange
		
		// Act
		Long contChangeSet = dashboardService.countAll("");

		// Then
		Assert.assertEquals(0, contChangeSet.longValue());
	}
	
	@Test
	public void testFindBuildsById() {
		//Arrange
		Mockito.when(buildService.findBuildsById(Mockito.anyString(), Mockito.anyString())).thenReturn(resultsVO);
		
		// Act
		List<ResultVO> result = dashboardService.findBuildsById("inovacao", "continuous-manager-web");

		// Then
		Assert.assertNotNull(result);
	}
}

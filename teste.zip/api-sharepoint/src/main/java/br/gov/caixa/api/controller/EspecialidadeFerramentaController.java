package br.gov.caixa.api.controller;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.api.dto.EspecialidadeFerramentaDto;
import br.gov.caixa.api.result.EspecialidadeFerramentaResult;
import br.gov.caixa.api.services.EspecialidadeFerramentaService;

@RestController
public class EspecialidadeFerramentaController {

	@Inject
	EspecialidadeFerramentaService service;

	@RequestMapping(value = "/api/especialidadeFerramenta/all", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeFerramentaResult listAll() {
		return service.listAll();
	}

	@RequestMapping(value="/api/especialidadeFerramenta/save", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeFerramentaResult save(@RequestBody EspecialidadeFerramentaDto especialidadeFerramentaDto) {
		
		return service.save(especialidadeFerramentaDto);
	}
	
	@RequestMapping(value="/api/especialidadeFerramenta/delete", method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeFerramentaResult delete(@RequestBody EspecialidadeFerramentaDto especialidadeFerramentaDto) {
		
		return service.delete(especialidadeFerramentaDto);
	}
	
	@RequestMapping(value="/api/especialidadeFerramenta/obterEspecialidadeFerramentaPorIdEspecialidade/{idEspecialidade}", method=RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public EspecialidadeFerramentaResult obterAtivoPorIdCategoria(@PathVariable Long idEspecialidade) {
		
		return service.listEspecialidadeFerramentasByIdFerramenta(idEspecialidade);
	}


}

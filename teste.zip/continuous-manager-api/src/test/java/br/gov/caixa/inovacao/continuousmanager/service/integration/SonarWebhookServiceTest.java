package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.UtilReflection;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Build;
import br.gov.caixa.inovacao.continuousmanager.model.entity.BuildLog;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.GitRepo;
import br.gov.caixa.inovacao.continuousmanager.model.entity.JenkinsBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Job;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Path;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Project;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Wallet;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BuildJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.JobJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ProjectJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.WalletJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.service.BuildLogService;
import br.gov.caixa.inovacao.continuousmanager.service.BuildService;
import br.gov.caixa.inovacao.continuousmanager.service.ChangeSetService;
import br.gov.caixa.inovacao.continuousmanager.service.GitRepoService;
import br.gov.caixa.inovacao.continuousmanager.service.JobService;
import br.gov.caixa.inovacao.continuousmanager.service.PathService;
import br.gov.caixa.inovacao.continuousmanager.service.ProjectService;
import br.gov.caixa.inovacao.continuousmanager.service.WalletService;

/**
 * Classe de testes do SonarWebhookService.
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class SonarWebhookServiceTest {
	
	@Mock
	private JenkinsService jenkinsService;
	
	@Mock
	private WalletService walletService;
	
	@Mock
	private ProjectService projectService;
	
	@Mock
	private JobService jobService;
	
	@Mock
	private BuildService buildService;
	
	@Mock
	private BuildLogService buildLogService;
	
	@Mock
	private GitRepoService gitRepoService;
	
	@Mock
	private PathService pathService;
	
	@Mock
	private ChangeSetService changeSetService;
	
	@InjectMocks
	private SonarWebhookService sonarWebhookService;

	private List<WalletJenkinsVO> wallets;
	private List<ProjectJenkinsVO> projects;
	private List<JobJenkinsVO> jobs;
	private List<BuildJenkinsVO> builds;

	@Before
	public void before() {
		wallets = JenkinsBuilder.createWallets();
		projects = JenkinsBuilder.createProjects();
		jobs = JenkinsBuilder.createJobs();
		builds = JenkinsBuilder.createBuilds();
		UtilReflection.setField(sonarWebhookService, "log", Logger.getLogger(SonarWebhookService.class.getName()));
	}
	
	@Test
	public void testCheckNews() throws InterruptedException {
		// Act
		//sonarWebhookService.add();
	}
	
	@Test
	public void testCheckNewsWallet() throws InterruptedException {
		// Arrange
		Mockito.when(jenkinsService.listWallets()).thenReturn(wallets);
		Mockito.when(walletService.save(Mockito.<Wallet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jenkinsService.listProjects(wallets.get(0).getName())).thenReturn(projects);
		Mockito.when(projectService.save(Mockito.<Project>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jenkinsService.listJobs(wallets.get(0).getName(), projects.get(0).getName())).thenReturn(jobs);
		Mockito.when(jobService.save(Mockito.<Job>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(jenkinsService.listBuilds(wallets.get(0).getName(), projects.get(0).getName(), jobs.get(0).getName())).thenReturn(builds);
		Mockito.when(buildService.save(Mockito.<Build>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(buildLogService.save(Mockito.<BuildLog>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(gitRepoService.save(Mockito.<GitRepo>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(pathService.save(Mockito.<Path>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		Mockito.when(changeSetService.save(Mockito.<ChangeSet>any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
		
		// Act
		//sonarWebhookService.add();
		
	}
}

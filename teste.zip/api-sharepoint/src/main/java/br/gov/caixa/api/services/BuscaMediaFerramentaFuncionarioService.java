package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.BuscaMediaFerramentaFuncionarioDto;
import br.gov.caixa.api.model.BuscaMediaFerramentaFuncionario;
import br.gov.caixa.api.repository.BuscaMediaFerramentaFuncionarioRepository;
import br.gov.caixa.api.result.BuscaMediaFerramentaFuncionarioResult;

@Named
public class BuscaMediaFerramentaFuncionarioService {
	
	@Inject
	private BuscaMediaFerramentaFuncionarioRepository repository;
	
	public BuscaMediaFerramentaFuncionarioResult findAll(){
		
		List<BuscaMediaFerramentaFuncionario> lista = repository.findAll();
		
		BuscaMediaFerramentaFuncionarioResult result = new BuscaMediaFerramentaFuncionarioResult();
		
		result.setList(BuscaMediaFerramentaFuncionarioDto.fromBuscaMediaFerramentaFuncionarioToListDto(lista));
		result.setMessage("Executado com sucesso.");
		return result;
	}

}

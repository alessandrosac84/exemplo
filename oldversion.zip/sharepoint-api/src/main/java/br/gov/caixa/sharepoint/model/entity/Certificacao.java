package br.gov.caixa.sharepoint.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.caixa.sharepoint.model.AuditedEntity;
import br.gov.caixa.sharepoint.model.IEntity;


/**
 * The persistent class for the certificacao database table.
 * 
 */
@Entity
@Table(name="certificacao")
@NamedQueries({	
	@NamedQuery(name = "Certificacao.findAll", query="SELECT c FROM Certificacao c"),
	@NamedQuery(name = "Certificacao.findByAKs", query = "SELECT c FROM Certificacao c WHERE c.id <> :id AND (c.certificacao = :certificacao OR c.ano = :ano OR c.mes = :mes)"),
	@NamedQuery(name="Certificacao.findAllByFuncionario", query="SELECT c FROM Certificacao c WHERE c.funcionario.matricula = :matricula"),
})
public class Certificacao extends AuditedEntity implements Serializable, IEntity<Integer> {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Max(value=2050)
	@Min(value=1950)
	@NotNull
	@Column(nullable=false, precision=4)
	private Integer ano;

	@NotEmpty
	@Size(min=3)
	@Column(nullable=false, length=70)
	private String certificacao;

	@Min(value=1)
	@Max(value=12)
	@NotNull
	@Column(nullable=false, precision=2)
	private Integer mes;

	@JsonIgnore
	//bi-directional many-to-one association to Funcionario
	@ManyToOne
	@JoinColumn(name="funcionario", nullable=false)
	private Funcionario funcionario;

	public Certificacao() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAno() {
		return this.ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public String getCertificacao() {
		return this.certificacao;
	}

	public void setCertificacao(String certificacao) {
		this.certificacao = certificacao;
	}

	public Integer getMes() {
		return this.mes;
	}

	public void setMes(Integer mes) {
		this.mes = mes;
	}

	public Funcionario getFuncionario() {
		return this.funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}
	
	@Override
	public boolean isTheSameObject(IEntity<Integer> object) {
		if (this == object)
			return true;
		if (object == null)
			return false;
		if (getClass() != object.getClass())
			return false;
		Certificacao other = (Certificacao) object;
		if (id == null) {
			
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;

/**
 * The primary key class for the Measures database table.
 * 
 * @author Fabio Iwakoshi
 */
@Embeddable
public class MeasuresPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@JsonView(ViewJson.SonarView.class)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String project;

	@JsonView(ViewJson.SonarView.class)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=30)
	private String wallet;
	
	@JsonView(ViewJson.SonarView.class)
	@Column(insertable=false, updatable=false, unique=true, nullable=false, length=40)
	private String commit;
	

	public MeasuresPK() {
		/* class constructor intentionally left blank */
	}
	public String getProject() {
		return this.project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getWallet() {
		return this.wallet;
	}
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof MeasuresPK)) {
			return false;
		}
		MeasuresPK castOther = (MeasuresPK)other;
		return 
			this.project.equals(castOther.project)
			&& this.wallet.equals(castOther.wallet)
			&& this.commit.equals(castOther.commit);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.project.hashCode();
		hash = hash * prime + this.wallet.hashCode();
		hash = hash * prime + this.commit.hashCode();
		
		return hash;
	}
	/**
	 * @return the commit
	 */
	public String getCommit() {
		return commit;
	}
	/**
	 * @param commit the commit to set
	 */
	public void setCommit(String commit) {
		this.commit = commit;
	}
}
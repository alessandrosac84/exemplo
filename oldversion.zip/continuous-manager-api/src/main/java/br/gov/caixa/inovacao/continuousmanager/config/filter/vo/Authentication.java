package br.gov.caixa.inovacao.continuousmanager.config.filter.vo;

import javax.validation.constraints.NotNull;

/**
 * Classe de autenticacao.
 * 
 * @author Fabio Iwakoshi
 *
 */
public class Authentication {

	@NotNull
	private String username;

	@NotNull
	private String password;
	
	@NotNull
	private Boolean rememberMe;
	
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @param username the username to set
	 * @return the Authentication
	 */
	public Authentication username(String username) {
		this.username = username;
		return this;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @param password the password to set
	 * @return the Authentication
	 */
	public Authentication password(String password) {
		this.password = password;
		return this;
	}
	public Boolean getRememberMe() {
		return rememberMe;
	}
	public void setRememberMe(Boolean rememberMe) {
		this.rememberMe = rememberMe;
	}
}
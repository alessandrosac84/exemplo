package br.gov.caixa.api.services;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import br.gov.caixa.api.dto.BuscaFuncionarioCoordenacaoDto;
import br.gov.caixa.api.model.BuscaFuncionarioCoordenacao;
import br.gov.caixa.api.repository.BuscaFuncionarioCoodernacaoRepository;
import br.gov.caixa.api.result.BuscaFuncionarioCoordenacaoResult;


@Named
public class BuscaFuncionarioCoordenacaoService {
	
	@Inject
	private BuscaFuncionarioCoodernacaoRepository repository;
	
	public BuscaFuncionarioCoordenacaoResult findAll(){
		List<BuscaFuncionarioCoordenacao> lista = repository.findAll();
		BuscaFuncionarioCoordenacaoResult result = new BuscaFuncionarioCoordenacaoResult();
		result.setList(BuscaFuncionarioCoordenacaoDto.fromBuscaFuncionarioCoordenacaoToListDto(lista));
		result.setMessage("Executado com sucesso.");
		return result;
	}

}

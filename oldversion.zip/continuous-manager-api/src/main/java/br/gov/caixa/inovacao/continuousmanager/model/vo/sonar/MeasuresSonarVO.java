package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author Alessandro Carvalho
 * 
 */
public class MeasuresSonarVO implements Serializable {

	private static final long serialVersionUID = -3375621878821093047L;
	
	private String metric;

	private List<HistorySonarVO> history;

	/**
	 * @return the metric
	 */
	public String getMetric() {
		return metric;
	}

	/**
	 * @param metric the metric to set
	 */
	public void setMetric(String metric) {
		this.metric = metric;
	}

	/**
	 * @return the history
	 */
	public List<HistorySonarVO> getHistory() {
		return history;
	}

	/**
	 * @param history the history to set
	 */
	public void setHistory(List<HistorySonarVO> history) {
		this.history = history;
	}
}

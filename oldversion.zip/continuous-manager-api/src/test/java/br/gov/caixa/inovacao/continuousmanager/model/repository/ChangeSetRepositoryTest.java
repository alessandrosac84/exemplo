/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.model.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.model.entity.EntityBuilder;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSet;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSetPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.build.ChangeSet_;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de testes de ChangeSetRepository
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ChangeSetRepositoryTest {

	@Mock
	private EntityManager em;
	
	@Mock
	private CriteriaBuilder builder;
	
	@Mock
	private CriteriaQuery<ChangeSet> query;
	
	@Mock
	private CriteriaQuery<Long> queryCount;
	
	@Mock
	private Root<ChangeSet> from;
	
	@Mock
	private TypedQuery<ChangeSet> typedQuery;
	
	@Mock
	private TypedQuery<Long> typedQueryCount;
	
	@Mock
	private Expression<Long> expressionCount;
	
	@Mock
	private Path<ChangeSetPK> path;

	@InjectMocks
	private ChangeSetRepository changeSetRepository;

	private ChangeSet changeSet;
	
	private List<ChangeSet> listChangeSet;

	@Before
	public void before() {
		changeSet = EntityBuilder.createBuilds().get(0).getChangeSets().stream().findFirst().get();
		listChangeSet = EntityBuilder.creaChangeSets();
	}

	@Test
	public void testSave() {
		// Act
		ChangeSet save = changeSetRepository.update(changeSet);
		// Then
		Assert.assertEquals(changeSet.getId(), save.getId());
	}
	
	@Test
	public void testFindById() {
		
		// Act
		ChangeSet retorno = changeSetRepository.findById(changeSet.getId());
		
		// Then
		Assert.assertNull(retorno);
	}

	@Test
	public void testFindAll() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<ChangeSet>>any())).thenReturn(typedQuery);
		
		Mockito.when(builder.createQuery(ChangeSet.class)).thenReturn(query);
		
		Mockito.when(query.from(ChangeSet.class)).thenReturn(from);
		Mockito.when(from.get(ChangeSet_.id)).thenReturn(path);
		Mockito.when(query.select(from)).thenReturn(query);
		Mockito.when(query.distinct(true)).thenReturn(query);
		
		Mockito.when(query.where(Mockito.<Expression<Boolean>>any())).thenReturn(query);
		
		Mockito.when(typedQuery.setFirstResult(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.setMaxResults(Mockito.anyInt())).thenReturn(typedQuery);
		Mockito.when(typedQuery.getResultList()).thenReturn(listChangeSet);
		
		// Act
		List<ChangeSet> retorno = changeSetRepository.findAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", 0, 30, "", "id", AscDesc.ASC);
		
		// Then
		Assert.assertEquals(2, retorno.size());
	}
	
	@Test
	public void testCountAll() {
		// Arrange
		Mockito.when(em.getCriteriaBuilder()).thenReturn(builder);
		Mockito.when(em.createQuery(Mockito.<CriteriaQuery<Long>>any())).thenReturn(typedQueryCount);
		
		Mockito.when(builder.createQuery(Long.class)).thenReturn(queryCount);
		Mockito.when(builder.count(from)).thenReturn(expressionCount);
		
		Mockito.when(queryCount.from(ChangeSet.class)).thenReturn(from);
		Mockito.when(from.get(ChangeSet_.id)).thenReturn(path);
		Mockito.when(queryCount.select(expressionCount)).thenReturn(queryCount);
		Mockito.when(queryCount.where(Mockito.<Expression<Boolean>>any())).thenReturn(queryCount);
		
		Mockito.when(typedQueryCount.getSingleResult()).thenReturn((long) listChangeSet.size());
		
		// Act
		Long retorno = changeSetRepository.countAll("inovacao", "portal-inovacao", "portal-inovacao-api-ci-dev", "");
		
		// Then
		Assert.assertEquals(2, retorno.longValue());
	}
}

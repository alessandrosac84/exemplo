package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.math.BigDecimal;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-05-22T14:18:46.733-0300")
@StaticMetamodel(QualityGate.class)
public class QualityGate_ {
	public static volatile SingularAttribute<QualityGate, QualityGatePK> id;
	public static volatile SingularAttribute<QualityGate, BigDecimal> actualValue;
	public static volatile SingularAttribute<QualityGate, String> comparator;
	public static volatile SingularAttribute<QualityGate, Integer> errorThreshold;
	public static volatile SingularAttribute<QualityGate, Integer> periodIndex;
	public static volatile SingularAttribute<QualityGate, String> status;
	public static volatile SingularAttribute<QualityGate, Measures> measures;
}

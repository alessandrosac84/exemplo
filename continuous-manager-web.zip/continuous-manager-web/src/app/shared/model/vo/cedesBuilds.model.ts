import { Build } from '../entity/build.model';

export class CedesBuilds {
    public name: string;
    public buildsStatus: {status: string, qtdBuilds: number};
}

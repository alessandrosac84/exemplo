/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.util;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.core.Response;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;

/**
 * Classe de Utilizades
 * 
 * @author Fabio IWakoshi
 *
 */
public class Util {
	
	private Util() { }
	
	private static Logger log = Logger.getAnonymousLogger();

	/**
	 * Método responsavel por padronizar o retorno de paginações.
	 * 
	 * O Header Content-Range é inserido na resposta.
	 * 
	 * @param service
	 * @param lista
	 * @param offset
	 * @param limit
	 * @return Response
	 */
	public static Response paginacao(Long count, List<?> lista, int offset, int limit) {
		String range = String.format("rows %d-%d/%d", offset * limit, offset * limit + lista.size(), count);
		if (lista.size() < limit) {
			// Não existem mais registros para retornar
			return Response.ok(lista).header("Content-Range", range).build();
		} else {
			// Existem mais registros a serem recuperados
			return Response.status(Response.Status.PARTIAL_CONTENT).entity(lista).header("Content-Range", range)
					.build();
		}
	}
	
	public static AuditedEntity fixEntity(AuditedEntity entity) {
		Class<?> clazzEntity = entity.getClass();
		for (Field field : clazzEntity.getDeclaredFields()) {
			try {
				field.setAccessible(true);
				if (field.getType() == Set.class || field.getType() == List.class) {
					field.set(entity, null);
				}
			} catch (IllegalArgumentException | SecurityException | IllegalAccessException e) {
				log.log(Level.SEVERE, "Erro ao limpar valores da entidade", e);
			}
		}
		return entity;
	}
}

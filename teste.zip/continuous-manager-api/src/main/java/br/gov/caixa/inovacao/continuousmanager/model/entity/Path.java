package br.gov.caixa.inovacao.continuousmanager.model.entity;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the path database table.
 * 
 */
@Entity
@Cacheable
@Table(name="path")
@NamedQuery(name="Path.findAll", query="SELECT p FROM Path p")
public class Path implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PathPK id;

	@Enumerated(EnumType.STRING)
	@Column(name="edit_type", nullable=false, length=6)
	private EditType editType;

	//bi-directional one-to-one association to GitRepo
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="commit", referencedColumnName="commit", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="project", referencedColumnName="project", nullable=false, insertable=false, updatable=false),
		@JoinColumn(name="wallet", referencedColumnName="wallet", nullable=false, insertable=false, updatable=false)
		})
	private GitRepo gitRepo;

	public Path() {
		/* class constructor intentionally left blank */
	}

	public PathPK getId() {
		return this.id;
	}

	public void setId(PathPK id) {
		this.id = id;
	}

	public EditType getEditType() {
		return this.editType;
	}

	public void setEditType(EditType editType) {
		this.editType = editType;
	}

	public GitRepo getGitRepo() {
		return this.gitRepo;
	}

	public void setGitRepo(GitRepo gitRepo) {
		this.gitRepo = gitRepo;
	}

}
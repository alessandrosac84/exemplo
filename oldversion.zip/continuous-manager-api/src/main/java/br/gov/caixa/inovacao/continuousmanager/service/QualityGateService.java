package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGate;
import br.gov.caixa.inovacao.continuousmanager.model.entity.job.sonar.QualityGatePK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.QualityGateRepository;

/**
 * Classe de servicos do Quality Gate.
 * 
 * @author Alessandro Carvalho
 *
 */
@Logged
@Stateless
public class QualityGateService {

	@Inject
	private Logger log;
	
	@Inject
	private QualityGateRepository qualityGateRepository;
	
	public QualityGate save(QualityGate qualityGate) {
		log.fine("Salvando quality Gate do sonar");
		return qualityGateRepository.save(qualityGate);
	}

	public Object findById(QualityGatePK id) {
		log.fine("Finding quality Gate by Id");
		return qualityGateRepository.findById(id);
	}
}

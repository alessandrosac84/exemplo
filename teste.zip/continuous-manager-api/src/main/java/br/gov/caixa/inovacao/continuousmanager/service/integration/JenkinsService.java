/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service.integration;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Environment;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Parameter;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ParameterPK;
import br.gov.caixa.inovacao.continuousmanager.model.entity.ServerType;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpMethod;
import br.gov.caixa.inovacao.continuousmanager.model.vo.HttpProtocol;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.BuildJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.CrumbIssuerJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.JobJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.ProjectJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins.WalletJenkinsVO;
import br.gov.caixa.inovacao.continuousmanager.service.ParameterService;
import br.gov.caixa.inovacao.continuousmanager.service.integration.HttpService.IEntity;

/**
 * Classe de servicos do Jenkins.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class JenkinsService {

	private static final String JOB = "/job/";
	private static final String API_JSON = "/api/json";

	private static final String QUERY_PARAM = "tree";
	private static final String JOB_INFO = "jobs[name,displayName]";

	@Inject
	private Logger log;

	@Inject
	private ParameterService parameterService;

	/**
	 * Obtem as listas de carteiras
	 * 
	 * @return Lista de Carteiras
	 */
	public List<WalletJenkinsVO> listWallets() {
		log.fine("Listando Carteiras");
		Map<String, String> query = new HashMap<>();
		query.put(QUERY_PARAM, JOB_INFO);
		return callJenkins(Environment.DES, HttpMethod.GET, API_JSON, query, null,
				new TypeReference<List<WalletJenkinsVO>>() {
				});
	}

	/**
	 * Obtem as listas de projetos
	 * 
	 * @return Lista de Projetos
	 */
	public List<ProjectJenkinsVO> listProjects(String wallet) {
		log.fine("Listando Projetos");
		Map<String, String> query = new HashMap<>();
		query.put(QUERY_PARAM, JOB_INFO);
		return callJenkins(Environment.DES, HttpMethod.GET,
				new StringBuilder(JOB).append(wallet).append(API_JSON).toString(), query, null,
				new TypeReference<List<ProjectJenkinsVO>>() {
				});
	}

	/**
	 * Obtem as listas de projetos
	 * 
	 * @return Lista de Projetos
	 */
	public List<JobJenkinsVO> listJobs(String wallet, String project) {
		log.fine("Listando Jobs");
		Map<String, String> query = new HashMap<>();
		query.put(QUERY_PARAM, JOB_INFO);
		return callJenkins(Environment.DES, HttpMethod.GET,
				new StringBuilder(JOB).append(wallet).append(JOB).append(project).append(API_JSON).toString(), query,
				null, new TypeReference<List<JobJenkinsVO>>() {
				});
	}

	/**
	 * Obtem as listas de Builds
	 * 
	 * @return Lista de Builds
	 */
	public List<BuildJenkinsVO> listBuilds(String wallet, String project, String job) {
		log.fine("Listando Builds");
		Map<String, String> query = new HashMap<>();
		query.put(QUERY_PARAM,
				"allBuilds[number,description,duration,estimatedDuration,result,timestamp,actions[lastBuiltRevision[branch[SHA1,name]],remoteUrls],"
						+ "changeSets[items[timestamp,author[fullName],authorEmail,comment,id,msg,paths[editType,file]]]]");
		return callJenkins(
				Environment.DES, HttpMethod.GET, new StringBuilder(JOB).append(wallet).append(JOB).append(project)
						.append(JOB).append(job).append(API_JSON).toString(),
				query, null, new TypeReference<List<BuildJenkinsVO>>() {
				});
	}

	/**
	 * Cria um novo Build
	 * 
	 * @return Criacao de Builds
	 */
	public Void createVersion(String wallet, String project, String job, String commit, String version) {
		log.fine("Criando Builds");
		Map<String, String> query = new HashMap<>();
		query.put("commit", commit);
		return callJenkins(
				Environment.DES, HttpMethod.POST, new StringBuilder(JOB).append(wallet).append(JOB).append(project)
						.append(JOB).append(job).append("/buildWithParameters").toString(),
						query, null, new TypeReference<Void>() {
				});
	}

	/**
	 * Cria um novo Build
	 * 
	 * @return Criacao de Builds
	 */
	public Void createBuild(String wallet, String project, String job, String commit) {
		log.fine("Criando Builds");
		Map<String, String> query = new HashMap<>();
		query.put("commit", commit);
		return callJenkins(
				Environment.DES, HttpMethod.POST, new StringBuilder(JOB).append(wallet).append(JOB).append(project)
						.append(JOB).append(job).append("/buildWithParameters").toString(),
						query, null, new TypeReference<Void>() {
				});
	}

	/**
	 * Obtem o Log do build informado
	 * 
	 * @return Log
	 */
	public String getLog(String wallet, String project, String job, int build) {
		log.fine("Obtendo Log");
		return callJenkins(
				Environment.DES, HttpMethod.GET, new StringBuilder(JOB).append(wallet).append(JOB).append(project)
						.append(JOB).append(job).append("/").append(build).append("/consoleText").toString(),
				null, null, new TypeReference<String>() {
				});
	}

	/**
	 * Obtem Codigo de acesso
	 * 
	 * @return CrumbIssuerJenkinsVO
	 */
	private CrumbIssuerJenkinsVO getCrumbIssuer() {
		log.fine("Obtendo Crumb Issuer");
		return callJenkins(Environment.DES, HttpMethod.GET,
				new StringBuilder("/crumbIssuer").append(API_JSON).toString(), null, null,
				new TypeReference<CrumbIssuerJenkinsVO>() {
				}, false);
	}
	
	private <T> T callJenkins(Environment environment, HttpMethod httpMethod, String path, Map<String, String> queries,
			Entity<?> entity, TypeReference<T> typeReference) {
		return callJenkins(environment, httpMethod, path, queries, entity, typeReference, true);
	}

	@SuppressWarnings("unchecked")
	private <T> T callJenkins(Environment environment, HttpMethod httpMethod, String path, Map<String, String> queries,
			Entity<?> entity, TypeReference<T> typeReference, boolean replace) {

		ParameterPK parameterId = new ParameterPK();
		parameterId.setEnvironment(environment);
		parameterId.setServerType(ServerType.JENKINS);

		Parameter parameter = parameterService.findById(parameterId);

		if (parameter == null) {
			throw new NotFoundException("Erro ao obter informação do sistema!");
		}

		IEntity build = HttpService.httpProtocol(HttpProtocol.HTTPS).httpMethod(httpMethod).host(parameter.getHost())
				.path(path).queries(queries).header("Authorization", parameter.getPrincipal());

		if (httpMethod == HttpMethod.POST) {
			CrumbIssuerJenkinsVO crumbIssuer = getCrumbIssuer();
			build = build.header(crumbIssuer.getCrumbRequestField(), crumbIssuer.getCrumb());
		}
		Response response = build.entity(entity).build();

		if (response.hasEntity() && response.getStatus() == 200) {
			try {
				String resposta = response.readEntity(String.class);
				if (typeReference.getType().getTypeName().equals("java.lang.String")) {
					return (T) resposta;
				}
				if (replace) {
					resposta = resposta.replaceAll("^\\{\"_class\":\"[A-z0-9\\.]+\",*", "").replaceFirst("\"[A-z]+\":", "")
							.replaceAll("\\}$", "");
				}
				return new ObjectMapper().readValue(resposta, typeReference);
			} catch (IOException e) {
				log.log(Level.SEVERE, "Erro ao transformar informações do Jenkins!", e);
				throw new ServiceUnavailableException("Erro ao obter informações do jenkins!");
			}
		} else if (response.getStatus() == 201 || response.getStatus() == 204) {
			return null;
		}
		throw new NotFoundException("Nenhuma informação encontrada!");
	}
}

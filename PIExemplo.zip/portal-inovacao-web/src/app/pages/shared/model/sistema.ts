export class Sistema {
    public uid: number;
    public origem: string;
    public sistema: string;
    public carteira: string;
    public descricao: string;
    public alias: string;
    public tipo: string;
    public estado: string;
    public cenario: string;
    public beneficio: string;
    public objetivo: string;
    public rede: string;
    public plataforma: string;
    public integracoes: string;
    public codigo: number;
    public coordenacaoProjeto: string;
    public coordenacaoTi: string;
}

package br.gov.caixa.api.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.gov.caixa.api.dto.EspecialidadeProcessoDto;

@Entity
@Table(name = "especialidade_processo")
public class EspecialidadeProcesso {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;

	@Column(name = "rating")
	private Integer rating;

	@ManyToOne
	@JoinColumn(name = "ESPECIALIDADE_ID")
	private Especialidade especialidade;
	
	@ManyToOne
	@JoinColumn(name = "PROCESSO_ID")
	private Processo processo;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public Especialidade getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(Especialidade especialidade) {
		this.especialidade = especialidade;
	}
	
	public Processo getProcesso() {
		return processo;
	}

	public void setProcesso(Processo processo) {
		this.processo = processo;
	}
	
	public static EspecialidadeProcesso fromDtoToEspecialidadeProcesso(EspecialidadeProcessoDto dto) {
		EspecialidadeProcesso especialidadeProcesso = new EspecialidadeProcesso();
		
		especialidadeProcesso.setUid(dto.getUid());
		especialidadeProcesso.setRating(dto.getRating());
		especialidadeProcesso.setEspecialidade(Especialidade.fromDtoToEspecialidade(dto.getEspecialidadeDto()));
		especialidadeProcesso.setProcesso(Processo.fromDtoToProcesso(dto.getProcessoDto()));
		
		return especialidadeProcesso;
	}
	
	public static List<EspecialidadeProcesso> fromDtoProcessoToListEspecialidadeProcesso(List<EspecialidadeProcessoDto> especialidadeProcessos) {
		List<EspecialidadeProcesso> returnList = new ArrayList<EspecialidadeProcesso>();
		
		for (EspecialidadeProcessoDto dto : especialidadeProcessos) {		    						
			returnList.add(fromDtoToEspecialidadeProcesso(dto));		
		}
		
		return returnList;
	}	
}

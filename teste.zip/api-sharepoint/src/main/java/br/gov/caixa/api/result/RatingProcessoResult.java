package br.gov.caixa.api.result;

import java.util.List;

import br.gov.caixa.api.dto.RatingProcessoDto;

public class RatingProcessoResult extends BasicResult {

	private List<RatingProcessoDto> list;
	private RatingProcessoDto ratingProcesso;

	public List<RatingProcessoDto> getList() {
		return list;
	}

	public void setList(List<RatingProcessoDto> list) {
		this.list = list;
	}

	public RatingProcessoDto getRatingProcesso() {
		return ratingProcesso;
	}

	public void setRatingProcesso(RatingProcessoDto ratingProcesso) {
		this.ratingProcesso = ratingProcesso;
	}

}

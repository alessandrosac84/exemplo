import { Wallet } from './wallet.model';
import { NotificationSettings } from './notificatationsettings.model';

export class ReposUser {
  id: string;
  name: string;
  photo: string;
  wallet: Wallet;
  notificationSettings: NotificationSettings[];
}

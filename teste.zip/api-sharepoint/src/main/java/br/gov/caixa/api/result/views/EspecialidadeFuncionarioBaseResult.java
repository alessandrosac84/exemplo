package br.gov.caixa.api.result.views;

import java.util.List;

import br.gov.caixa.api.model.views.EspecialidadeFuncionarioBase;
import br.gov.caixa.api.result.BasicResult;

public class EspecialidadeFuncionarioBaseResult extends BasicResult {
	private List<EspecialidadeFuncionarioBase> list;
	private EspecialidadeFuncionarioBase especialidadeFuncionarioBase;

	public List<EspecialidadeFuncionarioBase> getList() {
		return list;
	}

	public void setList(List<EspecialidadeFuncionarioBase> list) {
		this.list = list;
	}

	public EspecialidadeFuncionarioBase getEspecialidadeFuncionarioBase() {
		return especialidadeFuncionarioBase;
	}

	public void setEspecialidadeFuncionarioBase(EspecialidadeFuncionarioBase especialidadeFuncionarioBase) {
		this.especialidadeFuncionarioBase = especialidadeFuncionarioBase;
	}
}
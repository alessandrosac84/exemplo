package br.gov.caixa.api.model.views;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "especialidade_treinamento_view")
public class EspecialidadeTreinamentoView {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "NOME")
	private String nome;
	
	@Column(name = "ESPECIALIDADE_ID")
	private Long especialidadeId;
	
	@Column(name = "FERRAMENTA_NOME")
	private String ferramentaNome;

	@Column(name = "FERRAMENTA_ID")
	private Long ferramentaId;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Long getEspecialidadeId() {
		return especialidadeId;
	}

	public void setEspecialidadeId(Long especialidadeId) {
		this.especialidadeId = especialidadeId;
	}
	
	public String getFerramentaNome() {
		return ferramentaNome;
	}

	public void setFerramentaNome(String ferramentaNome) {
		this.ferramentaNome = ferramentaNome;
	}

	public Long getFerramentaId() {
		return ferramentaId;
	}

	public void setFerramentaId(Long ferramentaId) {
		this.ferramentaId = ferramentaId;
	}
}


import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Rx';

import { WalletService } from '../../shared/service/wallet.service';
import { HeaderComponent } from './../../layout/header/header.component';

import { ChangeSet } from './../../shared/model/changeset.model';
import { Project } from './../../shared/model/project.model';
import { Wallet } from './../../shared/model/wallet.model';
import { Commit } from './../../shared/model/commit.model';
import { Build } from '../../shared/model/build.model';
import { Job } from '../../shared/model/job.model';

@Component({
  selector: 'jmw-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.scss']
})
export class LogComponent implements OnInit {
  pageTitle = 'Log do Jenkins';

  walletId: Wallet;
  projectId: Project;
  jobId: Job;
  page: number;
  total: number;

  wallets: Wallet[] = [];
  projects: Project[] = [];
  jobs: Job[] = [];
  builds: Build[] = [];
  changeSets: ChangeSet[] = [];

  constructor(private _title: Title,
    private _walletService: WalletService) {
  }

  ngOnInit() {
    this._title.setTitle(this.pageTitle);
    this._walletService.getWallets().subscribe(data => {
      this.wallets = data;
    });
    this.page = 1;
  }

  public chargeProjects() {
    this.projects = [];
    this.projectId = undefined;
    this.jobId = undefined;
    if (!!this.walletId) {
      this._walletService.getProjects(this.walletId.id).subscribe(data => {
        this.projects = data;
      });
    }
  }

  public chargeJobs() {
    this.jobs = [];
    this.jobId = undefined;
    if (!!this.projectId) {
      this._walletService.getJobs(this.walletId.id, this.projectId.id.id).subscribe(data => {
        this.jobs = data;
      });
    }
  }

  public chargeBuilds() {
    this.builds.length = 0;
    if (!!this.jobId) {
      this._walletService.getBuilds(this.walletId.id, this.projectId.id.id, this.jobId.id.id, this.page).subscribe((res) => {
        this.builds = res.body;
        this.builds.forEach(build => {
          build.changeSets.sort((a, b) => (a.commit.committedDate > b.commit.committedDate) ? -1 : 1);
        });
        this.total = +res.headers.get('Content-Range').substring(res.headers.get('Content-Range').indexOf('/') + 1);
      });
    }
  }

  downloadfile(buildId) {
    this._walletService.getLog(this.walletId.id, this.projectId.id.id, this.jobId.id.id, buildId).subscribe(
      res => this.exportData(res, buildId),
      (error: any) => Observable.throw(error || 'Server error')
    );
  }

  exportData(res: string, buildId) {
    const blob = res;
    const myBlob: Blob = new Blob([res], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(myBlob);
    a.download = 'Log - ' + this.walletId.name + ' - Job - ' + this.jobId.name + ' - Build - ' + buildId + '.txt';
    document.body.appendChild(a);
    a.click();
  }

  pageChanged(event) {
      this.page = event;
      this.chargeBuilds();
  }
}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InfoRoutingModule } from './info-routing.module';
import { InfoComponent } from './info.component';
import { MaterialModule } from '../../../core/material/material.module';
import { ReactiveFormsModule } from '../../../../../node_modules/@angular/forms';
import { NewsComponent } from './news/news.component';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    InfoRoutingModule
  ],
  declarations: [InfoComponent, NewsComponent]
})
export class InfoModule { }

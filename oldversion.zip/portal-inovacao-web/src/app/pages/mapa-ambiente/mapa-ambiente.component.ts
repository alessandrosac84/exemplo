import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pi-mapa-ambiente',
  templateUrl: './mapa-ambiente.component.html',
  styleUrls: ['./mapa-ambiente.component.scss']
})
export class MapaAmbienteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

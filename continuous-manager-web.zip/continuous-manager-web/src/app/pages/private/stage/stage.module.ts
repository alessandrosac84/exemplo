import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StageRoutingModule } from './stage-routing.module';

@NgModule({
  imports: [
    CommonModule,
    StageRoutingModule
  ],
  declarations: []
})
export class StageModule { }

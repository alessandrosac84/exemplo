package br.gov.caixa.api.dto;

import br.gov.caixa.api.model.Feedback;

public class FeedbackDto {

	private Long uid;
	private ParticipanteDto participanteDto;
	private String maisGostou;
	private String menosGostou;
	private String sugestao;
	private Integer qualidadeInfoMaterial;
	private Integer duracao;
	private Integer desempenhoConhecimentoInstrautor;
	private Integer satisfacaoGeral;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public ParticipanteDto getParticipanteDto() {
		return participanteDto;
	}

	public void setParticipanteDto(ParticipanteDto participanteDto) {
		this.participanteDto = participanteDto;
	}

	public String getMaisGostou() {
		return maisGostou;
	}

	public void setMaisGostou(String maisGostou) {
		this.maisGostou = maisGostou;
	}

	public String getMenosGostou() {
		return menosGostou;
	}

	public void setMenosGostou(String menosGostou) {
		this.menosGostou = menosGostou;
	}

	public String getSugestao() {
		return sugestao;
	}

	public void setSugestao(String sugestao) {
		this.sugestao = sugestao;
	}

	public Integer getQualidadeInfoMaterial() {
		return qualidadeInfoMaterial;
	}

	public void setQualidadeInfoMaterial(Integer qualidadeInfoMaterial) {
		this.qualidadeInfoMaterial = qualidadeInfoMaterial;
	}

	public Integer getDuracao() {
		return duracao;
	}

	public void setDuracao(Integer duracao) {
		this.duracao = duracao;
	}

	public Integer getDesempenhoConhecimentoInstrautor() {
		return desempenhoConhecimentoInstrautor;
	}

	public void setDesempenhoConhecimentoInstrautor(Integer desempenhoConhecimentoInstrautor) {
		this.desempenhoConhecimentoInstrautor = desempenhoConhecimentoInstrautor;
	}

	public Integer getSatisfacaoGeral() {
		return satisfacaoGeral;
	}

	public void setSatisfacaoGeral(Integer satisfacaoGeral) {
		this.satisfacaoGeral = satisfacaoGeral;
	}

	public static FeedbackDto fromFeedbackToDto(Feedback feedback) {
		FeedbackDto dto = new FeedbackDto();
		dto.setUid(feedback.getUid());
		dto.setParticipanteDto(ParticipanteDto.fromParticipanteToDto(feedback.getParticipante()));
		dto.setMaisGostou(feedback.getMaisGostou());
		dto.setMenosGostou(feedback.getMenosGostou());
		dto.setQualidadeInfoMaterial(feedback.getQualidadeInfoMaterial());
		dto.setDuracao(feedback.getDuracao());
		dto.setDesempenhoConhecimentoInstrautor(feedback.getDesempenhoConhecimentoInstrautor());
		dto.setSatisfacaoGeral(feedback.getSatisfacaoGeral());
		return dto;
	}
}
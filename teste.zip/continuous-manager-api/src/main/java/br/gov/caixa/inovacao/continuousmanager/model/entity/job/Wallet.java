package br.gov.caixa.inovacao.continuousmanager.model.entity.job;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;

import br.gov.caixa.inovacao.continuousmanager.model.AuditedEntity;
import br.gov.caixa.inovacao.continuousmanager.model.ViewJson;


/**
 * The persistent class for the wallet database table.
 * 
 * @author Fabio Iwakoshi
 */
@Entity
@Cacheable
@Table(name="wallet")
public class Wallet extends AuditedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@JsonView({ ViewJson.WalletView.class, ViewJson.WebhookView.class })
	@Column(unique=true, nullable=false, length=30)
	private String id;

	@JsonView(ViewJson.WalletView.class)
	@Column(nullable=false, length=50)
	private String name;

	//bi-directional many-to-one association to Project
	@JsonIgnoreProperties("wallet")
	@OneToMany(mappedBy="wallet", fetch = FetchType.LAZY)
	private Set<Project> projects;

	public Wallet() {
		/* class constructor intentionally left blank */
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Project> getProjects() {
		return this.projects;
	}

	public void setProjects(Set<Project> projects) {
		this.projects = projects;
	}
}
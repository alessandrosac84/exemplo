package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;

/**
 * 
 * @author Alessandro Carvalho
 * 
 */
public class SonarMeasureVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3521009178010534464L;

	/**
	 * 
	 */
	private ComponentVO component;

	/**
	 * @return the component
	 */
	public ComponentVO getComponent() {
		return component;
	}

	/**
	 * @param component the component to set
	 */
	public void setComponent(ComponentVO component) {
		this.component = component;
	}
}

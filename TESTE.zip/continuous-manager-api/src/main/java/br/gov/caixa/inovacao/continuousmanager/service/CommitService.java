/**
 * 
 */
package br.gov.caixa.inovacao.continuousmanager.service;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.NoResultException;
import javax.validation.Valid;

import br.gov.caixa.inovacao.continuousmanager.config.log.Logged;
import br.gov.caixa.inovacao.continuousmanager.model.entity.Commit;
import br.gov.caixa.inovacao.continuousmanager.model.entity.CommitPK;
import br.gov.caixa.inovacao.continuousmanager.model.repository.CommitRepository;
import br.gov.caixa.inovacao.continuousmanager.model.vo.AscDesc;

/**
 * Classe de servicos de Commit.
 * 
 * @author Fabio IWakoshi
 *
 */
@Logged
@Stateless
public class CommitService {

	@Inject
	private Logger log;

	@Inject
	private CommitRepository commitRepository;

	public List<Commit> findByStatus(String wallet, String project, int offset, int limit, String sort,
			AscDesc order) {
		log.log(Level.FINE,
				"Listando Commits : offset :: {0} :: limit :: {1} :: sort :: {2} :: order :: {3}",
				new Object[] { offset, limit, sort, order });
		return commitRepository.findByStatus(wallet, project, offset, limit, sort, order);
	}

	public Long countByStatus(String wallet, String project) {
		log.log(Level.FINE, "Contando Commits: Carteira :: {0} :: Projeto {1}", new Object[] { wallet, project });
		return commitRepository.countByStatus(wallet, project);
	}

	public Commit findById(CommitPK id) {
		log.fine("Obtendo Git Repo");
		try {
			return commitRepository.findById(id);
		} catch (NoResultException e) {
			log.log(Level.SEVERE, "Não foram encontrada informações do Commit!");
			return null;
		}
	}
	
	public Commit save(@Valid Commit commit) {
		log.log(Level.FINE, "Salvando Commit :: {0}", commit.getId());
		return commitRepository.save(commit);
	}

	public int maxSequence(String wallet, String project) {
		log.fine("Obtendo Max Sequence Commit");
		Integer max = commitRepository.maxSequence(wallet, project);
		if (max == null) {
			max = 0;
		}
		return max;
	}

	public Commit update(@Valid Commit commit) {
		log.log(Level.FINE, "Atualizando Commit :: {0}", commit.getId());
		return commitRepository.update(commit);
	}
}

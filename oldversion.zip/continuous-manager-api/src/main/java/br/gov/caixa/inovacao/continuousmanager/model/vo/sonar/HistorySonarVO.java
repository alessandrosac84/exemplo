package br.gov.caixa.inovacao.continuousmanager.model.vo.sonar;

import java.io.Serializable;
import java.util.Calendar;

/**
 * Classe de representação de histórico de Metrica do Sonar
 * 
 * @author Fabio Iwakoshi
 * 
 */
public class HistorySonarVO implements Serializable {

	private static final long serialVersionUID = -7779425185542132181L;

	private Calendar date;
	
	private String value;

	/**
	 * @return the date
	 */
	public Calendar getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Calendar date) {
		this.date = date;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}

package br.gov.caixa.inovacao.continuousmanager.model.vo.jenkins;

import java.io.Serializable;

/**
 * Classe de representação do Parameters de Notificacao do jenkins
 * 
 * @author Fabio Iwakoshi
 *
 */
public class ParametersNotificationJenkinsVO implements Serializable {

	private static final long serialVersionUID = 3766818117030139597L;

	private String commit;

	/**
	 * @return the commit
	 */
	public String getCommit() {
		return commit;
	}

	/**
	 * @param commit the commit to set
	 */
	public void setCommit(String commit) {
		this.commit = commit;
	}
		
}

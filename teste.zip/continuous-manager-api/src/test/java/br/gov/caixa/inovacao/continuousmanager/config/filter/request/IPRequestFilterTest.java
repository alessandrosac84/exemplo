package br.gov.caixa.inovacao.continuousmanager.config.filter.request;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerRequestContext;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import br.gov.caixa.inovacao.continuousmanager.config.threadlocal.HelperThreadLocal;

/**
 * Classe de Teste de CacheControlFilter
 * 
 * @author Fabio Iwakoshi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class IPRequestFilterTest {

	@InjectMocks
	private IPRequestFilter ipRequestFilter;
	
	@Mock
	private ContainerRequestContext containerRequestContext;
	
	@Mock
	private HttpServletRequest request;
	
	@Test
	public void testFilterGet() throws IOException {
		// Arrange
		Mockito.when(request.getRemoteAddr()).thenReturn("127.0.0.1");
		
		// Act
		ipRequestFilter.filter(containerRequestContext);
		
		// Then
		Assert.assertEquals("127.0.0.1", HelperThreadLocal.IP.get());
	}

}

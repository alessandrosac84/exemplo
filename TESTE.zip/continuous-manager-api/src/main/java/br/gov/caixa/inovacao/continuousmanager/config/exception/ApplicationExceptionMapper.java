package br.gov.caixa.inovacao.continuousmanager.config.exception;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.ejb.EJBException;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 * @author Fabio IWakoshi
 *
 */
@Provider
public class ApplicationExceptionMapper implements ExceptionMapper<Exception> {

	private ResourceBundle bundle = ResourceBundle.getBundle("messages", new Locale("pt", "BR"));
	
	private static final int DATABASE = 1;
	private static final int UNKNOWN = 1;

	@Override
	public Response toResponse(Exception exception) {
		if (exception instanceof WebApplicationException) {
			return responseBuilder((WebApplicationException) exception);
		} else if (exception instanceof EJBException) {
			return responseBuilder((EJBException) exception);
		}
		return build(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), UNKNOWN, bundle.getString("br.gov.caixa.message.error.internal_server_error"));
	}

	private Response responseBuilder(EJBException exception) {
		int code = 0;
		if (exception.getMessage().contains("JDBC")) {
			code = DATABASE;
		}
		return build(Response.Status.SERVICE_UNAVAILABLE.getStatusCode(), code, bundle.getString("br.gov.caixa.message.error.service_unavailable"));
	}

	private Response responseBuilder(WebApplicationException exception) {
		return build(exception.getResponse().getStatus(), 0, exception.getMessage());
	}
	
	private Response build(int status, int codeApplication, String message) {
		ErrorEntity entity = new ErrorEntity().status(status).code(codeApplication)
				.message(message).link("api/page-codes");
		
		return Response.status(status).entity(entity).type(MediaType.APPLICATION_JSON).build();
	}

}

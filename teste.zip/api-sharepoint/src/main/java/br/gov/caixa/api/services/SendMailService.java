package br.gov.caixa.api.services;

import javax.inject.Named;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.client.RestTemplate;

import br.gov.caixa.api.dto.MailDto;

@Named
public class SendMailService {
	
	private MailDto mail;		
	private static final String urlPost = "http://10.1.32.240:8101/sendMail/rest/mail";
		
	public SendMailService() {
		
	}

	public void send(MailDto mail) {
		
		this.mail = mail;		
				
		this.send();
	}
	
	public void send() {
		
		try {												
			RestTemplate restTemplate = new RestTemplateBuilder().build();

			restTemplate.postForObject(urlPost, mail, MailDto.class);
			
			System.out.print("Finalizado com Sucesso");
		 }
		 catch(Exception exception) {
			 
			 exception.printStackTrace();
		 }			
	}		

	public MailDto getMail() {
		return mail;
	}

	public void setMail(MailDto mail) {
		this.mail = mail;
	}
}

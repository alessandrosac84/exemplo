package br.gov.caixa.api.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.gov.caixa.api.dto.ComplementoDto;

@Entity
@Table(name = "complemento")
public class Complemento {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "MENSAGEM")
	private String mensagem;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}	
	
	public static Complemento fromDtoToComplemento(ComplementoDto complementoDto) {
		
		Complemento complemento = new Complemento();
		
		complemento.setUid(complementoDto.getUid());
		complemento.setMensagem(complementoDto.getMensagem());
		
		return complemento;
	}
}

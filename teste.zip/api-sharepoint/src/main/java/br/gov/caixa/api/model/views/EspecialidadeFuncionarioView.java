package br.gov.caixa.api.model.views;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "especialidade_funcionario_view")
public class EspecialidadeFuncionarioView  extends EspecialidadeFuncionarioBase {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UID")
	private Long uid;
	
	@Column(name = "NOME")
	private String nome;

	@Column(name = "RATING")
	private Integer rating;
	
	@Column(name = "TIPO_ID")
	private Long tipoId;
	
	@Column(name = "TIPO_NAME")
	private String tipoNome;
	
	@Column(name = "ESPECIALIDADE_RATING")
	private Integer ratingEspecialidade;
	
	@Column(name = "ESPECIALIDADE_ID")
	private Long especialidadeId;
	
	@Column(name = "TIPO")
	private String tipo;
	
	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public Long getTipoId() {
		return tipoId;
	}

	public void setTipoId(Long tipoId) {
		this.tipoId = tipoId;
	}

	public String getTipoNome() {
		return tipoNome;
	}

	public void setTipoNome(String tipoNome) {
		this.tipoNome = tipoNome;
	}

	public Integer getRatingEspecialidade() {
		return ratingEspecialidade;
	}

	public void setRatingEspecialidade(Integer ratingEspecialidade) {
		this.ratingEspecialidade = ratingEspecialidade;
	}

	public Long getEspecialidadeId() {
		return especialidadeId;
	}

	public void setEspecialidadeId(Long especialidadeId) {
		this.especialidadeId = especialidadeId;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}	
	
}

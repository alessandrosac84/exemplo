import { Build } from './build.model';
import { Project } from './project.model';
import { TypeRepository } from '../vo/typeRepository.model';
import { Branch } from './branch.model';
import { User } from './user.model';

export class Repository {
  id: { id: string };
  name: string;
  repoGit: string;
  lastBuild: Build;
  project: Project;
  typeRepository: TypeRepository;
  branchs: Branch[];
  members: User[];
}
